/* =============================================================================
   Workflow Designer — vanilla JS + jQuery / jQuery UI
   ============================================================================= */
(function ($) {
    'use strict';

    const API = {
        modules: 'api/modules',
        activities: 'api/activities',
        workflows: 'api/workflows'
    };
    const NODE_W = 200;
    const DATA_TYPES = ['String', 'Number', 'Decimal', 'Date', 'Boolean', 'Email'];
    const SYS_SOURCES = ['Static', 'Context', 'AppConfig', 'ActivityOutput'];
    const SYS_HINTS = {
        Static: 'Fixed value, e.g. 1000',
        Context: 'e.g. {{Context.UserId}}, {{Context.BranchCode}}, {{Context.Now}}',
        AppConfig: 'e.g. {{Config.MailFrom}}',
        ActivityOutput: 'e.g. {{act_2.Output.StatusCode}}'
    };
    const MAX_RETRIES = 10;

    // ------------------------------------------------------------------ state
    const state = {
        defs: {},            // activity definitions by type
        defList: [],
        modules: [],
        template: emptyTemplate(),
        selectedNodeId: null,
        selectedLinkId: null,
        activeTab: 'general',
        linking: null,       // { from }
        seq: {},           // id counters per prefix (act, tr)
        dirty: false
    };

    function emptyTemplate() {
        return {
            templateId: null, templateName: '', description: '',
            moduleCode: '', moduleName: '', screenCode: '', screenName: '',
            version: 0, status: 'Draft', startActivityId: null,
            activities: [], transitions: []
        };
    }

    const $canvas = $('#canvas');
    const $linkLayer = $('#linkLayer');

    // ------------------------------------------------------------------ helpers
    function api(method, url, data) {
        return $.ajax({
            method, url,
            contentType: 'application/json',
            data: data !== undefined ? JSON.stringify(data) : undefined,
            headers: { 'X-User': 'Admin1' }
        });
    }
    function errorsFrom(xhr) {
        const r = xhr.responseJSON;
        if (r && r.errors) return Array.isArray(r.errors) ? r.errors : Object.values(r.errors).flat();
        return [xhr.statusText || 'Request failed'];
    }
    function esc(s) { return $('<div>').text(s == null ? '' : String(s)).html(); }
    function toast(msg, type) {
        const $t = $('<div class="toast">').addClass(type || 'info').text(msg).appendTo('#toasts');
        setTimeout(() => $t.fadeOut(300, () => $t.remove()), 3200);
    }
    function nodeById(id) { return state.template.activities.find(a => a.id === id); }
    function setDirty(v) {
        state.dirty = v;
        $('#sbDirty').toggle(v);
    }
    function newId(prefix) {
        state.seq[prefix] = (state.seq[prefix] || 0) + 1;
        return prefix + '_' + state.seq[prefix];
    }

    // ------------------------------------------------------------------ modals
    function openModal(id) { $('#modalBackdrop').show(); $('#' + id).addClass('open'); }
    function closeModals() { $('.modal').removeClass('open'); $('#modalBackdrop').hide(); }
    $(document).on('click', '[data-close], #modalBackdrop', closeModals);
    $(document).on('keydown', e => { if (e.key === 'Escape') closeModals(); });

    function confirmBox(text) {
        const d = $.Deferred();
        $('#confirmText').text(text);
        $('#btnConfirmYes').off('click').on('click', () => { closeModals(); d.resolve(); });
        openModal('mdlConfirm');
        return d.promise();
    }

    // =================================================================== MODULES / SCREENS
    function loadModules(selectCode, selectScreen) {
        return api('GET', API.modules).done(list => {
            state.modules = list;
            const $m = $('#ddlModule').empty().append('<option value="">-- Select Module --</option>');
            list.forEach(m => $m.append($('<option>').val(m.code).text(m.name)));
            if (selectCode) $m.val(selectCode);
            renderScreens(selectScreen);
        });
    }

    function currentModule() { return state.modules.find(m => m.code === $('#ddlModule').val()); }

    function renderScreens(selectScreen) {
        const mod = currentModule();
        const $s = $('#ddlScreen').empty().append('<option value="">-- Select Screen --</option>');
        if (mod) mod.screens.forEach(s => $s.append($('<option>').val(s.code).text(s.name)));
        $s.prop('disabled', !mod);
        $('#btnNewScreen').prop('disabled', !mod);
        if (selectScreen) $s.val(selectScreen);
        syncHeaderToTemplate();
    }

    function syncHeaderToTemplate() {
        const mod = currentModule();
        const scr = mod && mod.screens.find(s => s.code === $('#ddlScreen').val());
        const t = state.template;
        t.moduleCode = mod ? mod.code : '';
        t.moduleName = mod ? mod.name : '';
        t.screenCode = scr ? scr.code : '';
        t.screenName = scr ? scr.name : '';
    }

    $('#ddlModule').on('change', function () {
        $(this).removeClass('invalid');
        renderScreens();
        setDirty(true);
    });
    $('#ddlScreen').on('change', function () {
        $(this).removeClass('invalid');
        syncHeaderToTemplate();
        setDirty(true);
    });
    $('#txtTemplateName').on('input', function () {
        $(this).removeClass('invalid');
        state.template.templateName = this.value;
        setDirty(true);
    });
    $('#ddlStatus').on('change', function () { state.template.status = this.value; setDirty(true); });

    // --- new module
    $('#btnNewModule').on('click', () => {
        $('#txtModuleCode, #txtModuleName, #txtModuleDesc').val('');
        $('#errModule').text('');
        openModal('mdlModule');
        setTimeout(() => $('#txtModuleCode').focus(), 50);
    });
    $('#txtModuleCode, #txtScreenCode').on('input', function () {
        this.value = this.value.toUpperCase().replace(/[^A-Z0-9_]/g, '');
    });
    $('#btnSaveModule').on('click', () => {
        const body = { code: $('#txtModuleCode').val().trim(), name: $('#txtModuleName').val().trim(), description: $('#txtModuleDesc').val().trim() };
        if (!body.code || !body.name) { $('#errModule').text('Module code and name are required.'); return; }
        api('POST', API.modules, body)
            .done(m => {
                closeModals();
                loadModules(m.code);
                toast(`Module "${m.name}" created`, 'success');
                setDirty(true);
            })
            .fail(x => $('#errModule').text(errorsFrom(x).join(' ')));
    });

    // --- new screen
    $('#btnNewScreen').on('click', () => {
        const mod = currentModule(); if (!mod) return;
        $('#lblScreenModule').text(mod.name);
        $('#txtScreenCode, #txtScreenName').val('');
        $('#errScreen').text('');
        openModal('mdlScreen');
        setTimeout(() => $('#txtScreenCode').focus(), 50);
    });
    $('#btnSaveScreen').on('click', () => {
        const mod = currentModule(); if (!mod) return;
        const body = { code: $('#txtScreenCode').val().trim(), name: $('#txtScreenName').val().trim() };
        if (!body.code || !body.name) { $('#errScreen').text('Screen code and name are required.'); return; }
        api('POST', `${API.modules}/${encodeURIComponent(mod.code)}/screens`, body)
            .done(s => {
                closeModals();
                loadModules(mod.code, s.code);
                toast(`Screen "${s.name}" added to ${mod.name}`, 'success');
                setDirty(true);
            })
            .fail(x => $('#errScreen').text(errorsFrom(x).join(' ')));
    });

    // =================================================================== PALETTE
    function loadActivities() {
        return api('GET', API.activities).done(list => {
            state.defList = list;
            list.forEach(d => state.defs[d.type] = d);
            renderPalette('');
        });
    }

    function renderPalette(filter) {
        const f = (filter || '').toLowerCase();
        const $p = $('#paletteList').empty();
        const cats = [...new Set(state.defList.map(d => d.category))];
        cats.forEach(cat => {
            const items = state.defList.filter(d => d.category === cat &&
                (!f || d.displayName.toLowerCase().includes(f) || d.description.toLowerCase().includes(f)));
            if (!items.length) return;
            $p.append($('<div class="pal-cat">').text(cat));
            items.forEach(d => {
                $(`<div class="pal-item" title="${esc(d.description)}">
                      <span class="ic">${esc(d.icon)}</span>
                      <div><div class="nm">${esc(d.displayName)}</div><div class="ds">${esc(d.category)}</div></div>
                   </div>`)
                    .css('--c', d.color)
                    .attr('data-type', d.type)
                    .appendTo($p)
                    .draggable({
                        helper: 'clone', appendTo: 'body', revert: 'invalid', revertDuration: 150,
                        zIndex: 1000, cursorAt: { left: 20, top: 18 },
                        start: (e, ui) => ui.helper.addClass('pal-helper')
                    })
                    .on('dblclick', () => {           // double click = add below the last node
                        const last = state.template.activities[state.template.activities.length - 1];
                        addActivity(d.type, last ? last.position.x : 400, last ? last.position.y + 130 : 60);
                    });
            });
        });
    }
    $('#txtPaletteSearch').on('input', function () { renderPalette(this.value); });

    $canvas.droppable({
        accept: '.pal-item',
        hoverClass: 'drop-hover',
        drop: function (e, ui) {
            const off = $canvas.offset();
            const x = Math.max(10, Math.round((ui.offset.left - off.left) / 10) * 10);
            const y = Math.max(20, Math.round((ui.offset.top - off.top) / 10) * 10);
            addActivity(ui.draggable.data('type'), x, y);
        }
    });

    // =================================================================== ACTIVITIES (NODES)
    function addActivity(type, x, y) {
        const def = state.defs[type];
        if (!def) return;
        const t = state.template;
        const sameType = t.activities.filter(a => a.type === type).length;
        const node = {
            id: newId('act'),
            type,
            name: def.displayName + (sameType ? ' ' + (sameType + 1) : ''),
            description: '',
            sequence: 0,
            position: { x, y },
            retry: { maxRetries: def.defaultRetries, intervalSeconds: 30, backoff: 'Fixed', onFailure: 'StopWorkflow' },
            userParameters: [],
            systemParameters: [],
            config: {}
        };
        def.configFields.forEach(f => { node.config[f.key] = f.defaultValue != null ? f.defaultValue : ''; });

        const tailId = $('#chkAutoConnect').is(':checked') ? flowTail() : null;
        t.activities.push(node);
        if (tailId) addTransition(tailId, node.id, true);
        recomputeStart();

        renderNode(node);
        selectNode(node.id);
        refreshAll();
        setDirty(true);
    }

    function renderNode(node) {
        const def = state.defs[node.type] || { icon: '?', color: '#888', displayName: node.type };
        const $n = $(`
            <div class="wf-node" id="node_${node.id}" data-id="${node.id}">
                <div class="node-seq"></div>
                <div class="port in" title="Incoming"></div>
                <div class="node-head">
                    <span class="ic">${esc(def.icon)}</span>
                    <span class="ttl"></span>
                    <button class="node-del" title="Delete activity">×</button>
                </div>
                <div class="node-body">
                    <div class="typ">${esc(def.displayName)}</div>
                    <div class="node-tags"></div>
                </div>
                <div class="port out" title="Drag to connect"></div>
            </div>`)
            .css({ '--c': def.color, left: node.position.x, top: node.position.y })
            .appendTo($canvas);

        $n.draggable({
            containment: 'parent',
            cancel: '.port, .node-del, input, select',
            grid: [10, 10],
            drag: (e, ui) => { node.position.x = ui.position.left; node.position.y = ui.position.top; drawLinks(); },
            stop: () => setDirty(true)
        });
        updateNodeView(node);
    }

    function updateNodeView(node) {
        const $n = $('#node_' + node.id);
        $n.find('.ttl').text(node.name || '(unnamed)').attr('title', node.name);
        const def = state.defs[node.type];
        $n.find('.typ').toggle(!!def && node.name !== def.displayName);
        const tags = [];
        if (node.id === state.template.startActivityId) tags.push('<span class="tag" style="background:#e6f4ea;color:#1e6b33">START</span>');
        if (node.retry.maxRetries > 0) tags.push(`<span class="tag retry">↻ ${node.retry.maxRetries} retr${node.retry.maxRetries === 1 ? 'y' : 'ies'}</span>`);
        if (node.userParameters.length) tags.push(`<span class="tag">User ${node.userParameters.length}</span>`);
        if (node.systemParameters.length) tags.push(`<span class="tag">System ${node.systemParameters.length}</span>`);
        $n.find('.node-tags').html(tags.join(''));
    }

    function deleteActivity(id) {
        const t = state.template;
        const prev = t.transitions.find(tr => tr.to === id);
        const next = t.transitions.find(tr => tr.from === id);
        t.activities = t.activities.filter(a => a.id !== id);
        t.transitions = t.transitions.filter(tr => tr.from !== id && tr.to !== id);
        if (prev && next) addTransition(prev.from, next.to, true);   // keep the chain joined
        recomputeStart();
        $('#node_' + id).remove();
        if (state.selectedNodeId === id) state.selectedNodeId = null;
        refreshAll();
        renderProperties();
        setDirty(true);
    }

    $canvas.on('click', '.node-del', function (e) {
        e.stopPropagation();
        const id = $(this).closest('.wf-node').data('id');
        const n = nodeById(id);
        confirmBox(`Delete activity "${n.name}" and its connections?`).then(() => deleteActivity(id));
    });

    $canvas.on('mousedown', '.wf-node', function (e) {
        if ($(e.target).is('.port.out, .node-del')) return;
        selectNode($(this).data('id'));
    });
    $canvas.on('mousedown', function (e) {
        if (e.target === this || e.target.id === 'svgLinks' || $(e.target).closest('.canvas-empty').length) {
            state.selectedNodeId = null; state.selectedLinkId = null;
            $('.wf-node').removeClass('selected');
            drawLinks();
            renderProperties();
        }
    });

    function selectNode(id) {
        state.selectedNodeId = id;
        state.selectedLinkId = null;
        $('.wf-node').removeClass('selected');
        $('#node_' + id).addClass('selected');
        drawLinks();
        renderProperties();
    }

    // =================================================================== TRANSITIONS (LINKS)
    // Sequential-only rules: one next step per activity, one previous step per activity, no loops.
    function connectError(from, to) {
        const t = state.template;
        if (from === to) return 'An activity cannot connect to itself.';
        if (t.transitions.some(tr => tr.from === from && tr.to === to)) return 'These activities are already connected.';
        if (t.transitions.some(tr => tr.from === from))
            return `"${nodeById(from).name}" already has a next step. Delete that connection first — the workflow is sequential.`;
        if (t.transitions.some(tr => tr.to === to))
            return `"${nodeById(to).name}" already has a previous step. Delete that connection first — the workflow is sequential.`;
        // walking forward from "to" must never reach "from", otherwise it becomes a loop
        let cur = to; const seen = new Set();
        while (cur && !seen.has(cur)) {
            if (cur === from) return 'This connection would create a loop. Only sequential order is allowed.';
            seen.add(cur);
            const nx = t.transitions.find(tr => tr.from === cur);
            cur = nx ? nx.to : null;
        }
        return null;
    }

    function addTransition(from, to, silent) {
        const err = connectError(from, to);
        if (err) { if (!silent) toast(err, 'error'); return false; }
        state.template.transitions.push({ id: newId('tr'), from, to });
        recomputeStart();
        setDirty(true);
        return true;
    }

    // Start = first activity of the longest chain (an activity with no previous step)
    function chainFrom(id) {
        const t = state.template, out = [], seen = new Set();
        let cur = id;
        while (cur && !seen.has(cur) && nodeById(cur)) {
            out.push(cur); seen.add(cur);
            const nx = t.transitions.find(tr => tr.from === cur);
            cur = nx ? nx.to : null;
        }
        return out;
    }
    function recomputeStart() {
        const t = state.template;
        const heads = t.activities.filter(a => !t.transitions.some(tr => tr.to === a.id));
        let best = null, bestLen = -1;
        heads.forEach(h => { const len = chainFrom(h.id).length; if (len > bestLen) { best = h.id; bestLen = len; } });
        t.startActivityId = best;
    }
    function flowTail() {
        const t = state.template;
        if (!t.startActivityId) return null;
        const chain = chainFrom(t.startActivityId);
        return chain.length ? chain[chain.length - 1] : null;
    }

    function portPoint(id, which) {
        const n = nodeById(id);
        const h = $('#node_' + id).outerHeight() || 70;
        return { x: n.position.x + NODE_W / 2, y: n.position.y + (which === 'out' ? h + 1 : -1) };
    }

    function pathD(a, b) {
        if (b.y >= a.y + 20) {
            const dy = Math.max(40, (b.y - a.y) / 2);
            return `M${a.x},${a.y} C${a.x},${a.y + dy} ${b.x},${b.y - dy} ${b.x},${b.y}`;
        }
        // next activity placed above the previous one: route around the right side
        const side = Math.max(a.x, b.x) + NODE_W / 2 + 40;
        return `M${a.x},${a.y} C${a.x},${a.y + 60} ${side},${a.y + 60} ${side},${(a.y + b.y) / 2} ` +
               `S${b.x},${b.y - 60} ${b.x},${b.y}`;
    }

    function drawLinks() {
        const ns = 'http://www.w3.org/2000/svg';
        const layer = $linkLayer[0];
        while (layer.firstChild) layer.removeChild(layer.firstChild);

        state.template.transitions.forEach(tr => {
            if (!nodeById(tr.from) || !nodeById(tr.to)) return;
            const a = portPoint(tr.from, 'out'), b = portPoint(tr.to, 'in');
            const d = pathD(a, b);
            const g = document.createElementNS(ns, 'g');
            g.setAttribute('class', 'link-group' + (tr.id === state.selectedLinkId ? ' selected' : ''));
            g.setAttribute('data-id', tr.id);

            const hit = document.createElementNS(ns, 'path');
            hit.setAttribute('d', d); hit.setAttribute('class', 'link-hit');
            const p = document.createElementNS(ns, 'path');
            p.setAttribute('d', d); p.setAttribute('class', 'link');
            g.appendChild(p); g.appendChild(hit);

            layer.appendChild(g);
        });
        updateSequenceBadges();
    }

    $linkLayer.on('mousedown', '.link-hit', function (e) {
        e.stopPropagation();
        state.selectedLinkId = this.parentNode.getAttribute('data-id');
        state.selectedNodeId = null;
        $('.wf-node').removeClass('selected');
        drawLinks();
        renderProperties();
    });

    // drag-to-connect
    $canvas.on('mousedown', '.port.out', function (e) {
        e.preventDefault(); e.stopPropagation();
        state.linking = { from: $(this).closest('.wf-node').data('id') };
        $('body').addClass('linking');
    });
    $(document).on('mousemove', function (e) {
        if (!state.linking) return;
        const off = $canvas.offset();
        const a = portPoint(state.linking.from, 'out');
        const b = { x: e.pageX - off.left, y: e.pageY - off.top };
        $('#tempLink').attr('d', `M${a.x},${a.y} L${b.x},${b.y}`);
        $('.port.in').removeClass('drop-ok');
        $(e.target).closest('.wf-node').find('.port.in').addClass('drop-ok');
    });
    $(document).on('mouseup', function (e) {
        if (!state.linking) return;
        const from = state.linking.from;
        state.linking = null;
        $('body').removeClass('linking');
        $('#tempLink').attr('d', '');
        $('.port.in').removeClass('drop-ok');
        const $target = $(e.target).closest('.wf-node');
        if ($target.length) {
            if (addTransition(from, $target.data('id'))) refreshAll();
        }
    });

    $(document).on('keydown', function (e) {
        if ($(e.target).is('input, textarea, select') || $('.modal.open').length) return;
        if (e.key === 'Delete' || e.key === 'Backspace') {
            if (state.selectedLinkId) { deleteLink(state.selectedLinkId); e.preventDefault(); }
            else if (state.selectedNodeId) {
                const n = nodeById(state.selectedNodeId);
                confirmBox(`Delete activity "${n.name}" and its connections?`).then(() => deleteActivity(n.id));
                e.preventDefault();
            }
        }
    });

    function deleteLink(id) {
        state.template.transitions = state.template.transitions.filter(t => t.id !== id);
        state.selectedLinkId = null;
        refreshAll();
        renderProperties();
        setDirty(true);
    }

    // order = follow the chain from the start activity; activities not in the chain go last
    function computeOrder() {
        const t = state.template;
        const chain = t.startActivityId ? chainFrom(t.startActivityId) : [];
        const seen = new Set(chain);
        const order = chain.slice();
        t.activities.forEach(a => { if (!seen.has(a.id)) order.push(a.id); });
        return { order, reachable: seen };
    }

    function updateSequenceBadges() {
        const { order, reachable } = computeOrder();
        order.forEach((id, i) => {
            $('#node_' + id + ' .node-seq').text(reachable.has(id) ? i + 1 : '!')
                .css('background', reachable.has(id) ? '' : '#c62828')
                .attr('title', reachable.has(id) ? 'Execution order' : 'Not connected to the Start activity');
        });
    }

    // =================================================================== PROPERTIES PANEL
    function renderProperties() {
        const $b = $('#propsBody');
        if (state.selectedLinkId) return renderLinkProperties();
        const node = nodeById(state.selectedNodeId);
        if (!node) {
            $('#propsTitle').text('Properties');
            $b.html('<div class="props-empty">Select an activity on the canvas to configure its parameters, retries and settings.</div>');
            return;
        }
        const def = state.defs[node.type];
        $('#propsTitle').text('Activity Properties');
        const pc = node.userParameters.length + node.systemParameters.length;

        $b.html(`
            <div class="props-type" style="--c:${def.color}">
                <span class="ic">${esc(def.icon)}</span>
                <span class="t">${esc(def.displayName)}</span>
                <span class="id">${esc(node.id)}</span>
            </div>
            <div class="tabs">
                <div class="tab" data-tab="general">General</div>
                <div class="tab" data-tab="params">Parameters <span class="cnt">${pc}</span></div>
                <div class="tab" data-tab="retry">Retry</div>
            </div>
            <div class="tab-pane" data-pane="general">${generalPane(node, def)}</div>
            <div class="tab-pane" data-pane="params"></div>
            <div class="tab-pane" data-pane="retry">${retryPane(node)}</div>
        `);
        renderParamsPane(node);
        if (!['general', 'params', 'retry'].includes(state.activeTab)) state.activeTab = 'general';
        showTab(state.activeTab);
        updateRetryPreview(node);
    }

    function showTab(tab) {
        state.activeTab = tab;
        $('#propsBody .tab').removeClass('active').filter(`[data-tab="${tab}"]`).addClass('active');
        $('#propsBody .tab-pane').removeClass('active').filter(`[data-pane="${tab}"]`).addClass('active');
    }
    $('#propsBody').on('click', '.tab', function () { showTab($(this).data('tab')); });

    function generalPane(node, def) {
        const isStart = node.id === state.template.startActivityId;
        return `
            <div class="field"><label>Activity Name <span class="req">*</span></label>
                <input type="text" data-bind="name" maxlength="150" value="${esc(node.name)}" /></div>
            <div class="field"><label>Description</label>
                <textarea data-bind="description" rows="3">${esc(node.description)}</textarea></div>
            <div class="field"><label>Position in flow</label>
                <div class="hint">${isStart ? '<b>Start</b> — the workflow begins here.' : 'Start is always the first activity in the sequence.'}</div></div>
            <div class="field"><label>Sequence</label>
                <div class="hint">${describeConnections(node)}</div></div>
            ${def.configFields.length ? '<div class="section-head">Configuration</div>' + settingsPane(node, def) : ''}`;
    }

    function describeConnections(node) {
        const t = state.template;
        const into = t.transitions.filter(tr => tr.to === node.id).map(tr => esc(nodeById(tr.from)?.name));
        const out = t.transitions.filter(tr => tr.from === node.id).map(tr => esc(nodeById(tr.to)?.name));
        return `Previous: ${into.length ? into.join(', ') : '—'}<br/>Next: ${out.length ? out.join(', ') : '—'}`;
    }

    function retryPane(node) {
        const r = node.retry;
        const opt = (v, cur, label) => `<option value="${v}" ${v === cur ? 'selected' : ''}>${label || v}</option>`;
        return `
            <div class="row2">
                <div class="field"><label>Number of Retries</label>
                    <input type="number" min="0" max="${MAX_RETRIES}" data-bind="retry.maxRetries" data-num="1" value="${r.maxRetries}" />
                    <div class="hint">0 – ${MAX_RETRIES}. 0 = no retry.</div></div>
                <div class="field"><label>Retry Interval (sec)</label>
                    <input type="number" min="0" data-bind="retry.intervalSeconds" data-num="1" value="${r.intervalSeconds}" /></div>
            </div>
            <div class="field"><label>Backoff Strategy</label>
                <select data-bind="retry.backoff">${opt('Fixed', r.backoff, 'Fixed interval')}${opt('Exponential', r.backoff, 'Exponential (interval × 2ⁿ)')}</select></div>
            <div class="field"><label>When all retries fail</label>
                <select data-bind="retry.onFailure">
                    ${opt('StopWorkflow', r.onFailure, 'Stop workflow')}
                    ${opt('SkipAndContinue', r.onFailure, 'Skip and continue')}
                    ${opt('NotifyAdmin', r.onFailure, 'Hold and notify admin')}
                </select></div>
            <div class="retry-preview" id="retryPreview"></div>`;
    }

    function updateRetryPreview(node) {
        const r = node.retry;
        if (!r.maxRetries) { $('#retryPreview').html('No retries — the activity runs once.'); return; }
        const waits = [];
        for (let i = 0; i < Math.min(r.maxRetries, MAX_RETRIES); i++)
            waits.push(r.backoff === 'Exponential' ? r.intervalSeconds * Math.pow(2, i) : r.intervalSeconds);
        $('#retryPreview').html(`Runs up to <b>${r.maxRetries + 1}</b> times.<br/>Wait before each retry: ${waits.map(w => w + 's').join(' → ')}`);
    }

    function settingsPane(node, def) {
        if (!def.configFields.length) return '<div class="props-empty">No settings for this activity.</div>';
        return def.configFields.map(f => {
            const v = node.config[f.key] == null ? '' : node.config[f.key];
            const req = f.required ? ' <span class="req">*</span>' : '';
            const ph = f.placeholder ? ` placeholder="${esc(f.placeholder)}"` : '';
            let input;
            switch (f.inputType) {
                case 'textarea': input = `<textarea data-config="${f.key}" rows="3"${ph}>${esc(v)}</textarea>`; break;
                case 'number': input = `<input type="number" data-config="${f.key}" value="${esc(v)}"${ph} />`; break;
                case 'select': input = `<select data-config="${f.key}">${(f.options || []).map(o => `<option ${o === v ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select>`; break;
                case 'checkbox':
                    return `<div class="field chk-field"><label><input type="checkbox" data-config="${f.key}" ${String(v) === 'true' ? 'checked' : ''} /> ${esc(f.label)}</label></div>`;
                default: input = `<input type="text" data-config="${f.key}" value="${esc(v)}"${ph} />`;
            }
            return `<div class="field"><label>${esc(f.label)}${req}</label>${input}</div>`;
        }).join('') + '<div class="hint">Use {{ParameterName}} to reference parameters in any setting.</div>';
    }

    function renderParamsPane(node) {
        const typeOpts = cur => DATA_TYPES.map(d => `<option ${d === cur ? 'selected' : ''}>${d}</option>`).join('');
        const srcOpts = cur => SYS_SOURCES.map(d => `<option ${d === cur ? 'selected' : ''}>${d}</option>`).join('');

        const userCards = node.userParameters.map((p, i) => `
            <div class="param-card" data-ptype="user" data-idx="${i}">
                <button class="rm" title="Remove">×</button>
                <div class="row2">
                    <div><span class="mini-label">Name *</span><input type="text" data-field="name" value="${esc(p.name)}" placeholder="ApplicationNo" /></div>
                    <div><span class="mini-label">Label</span><input type="text" data-field="label" value="${esc(p.label)}" placeholder="Application No" /></div>
                </div>
                <div class="row2">
                    <div><span class="mini-label">Data Type</span><select data-field="dataType">${typeOpts(p.dataType)}</select></div>
                    <div><span class="mini-label">Default</span><input type="text" data-field="defaultValue" value="${esc(p.defaultValue)}" /></div>
                    <div style="flex:0 0 60px"><span class="mini-label">Required</span><input type="checkbox" data-field="required" ${p.required ? 'checked' : ''} style="width:auto;margin-top:6px" /></div>
                </div>
            </div>`).join('');

        const sysCards = node.systemParameters.map((p, i) => `
            <div class="param-card" data-ptype="system" data-idx="${i}">
                <button class="rm" title="Remove">×</button>
                <div class="row2">
                    <div><span class="mini-label">Name *</span><input type="text" data-field="name" value="${esc(p.name)}" placeholder="BranchCode" /></div>
                    <div><span class="mini-label">Source</span><select data-field="source">${srcOpts(p.source)}</select></div>
                </div>
                <div class="row2">
                    <div style="flex:2"><span class="mini-label">Value / Expression *</span><input type="text" data-field="value" value="${esc(p.value)}" placeholder="${esc(SYS_HINTS[p.source] || '')}" /></div>
                    <div><span class="mini-label">Data Type</span><select data-field="dataType">${typeOpts(p.dataType)}</select></div>
                </div>
            </div>`).join('');

        $('#propsBody [data-pane="params"]').html(`
            <div class="param-section">
                <div class="param-head">
                    <h4>User Parameters <span class="sub">Entered by the user on the screen at runtime</span></h4>
                    <button class="btn btn-sm" data-add="user">＋ Add</button>
                </div>
                ${userCards || '<div class="param-empty">No user parameters</div>'}
            </div>
            <div class="param-section">
                <div class="param-head">
                    <h4>System Parameters <span class="sub">Resolved by the system — context, config or previous activity output</span></h4>
                    <button class="btn btn-sm" data-add="system">＋ Add</button>
                </div>
                ${sysCards || '<div class="param-empty">No system parameters</div>'}
            </div>`);
        $('#propsBody .tab[data-tab="params"] .cnt').text(node.userParameters.length + node.systemParameters.length);
    }

    // --- property bindings (delegated so they survive re-render)
    function setPath(obj, path, val) {
        const parts = path.split('.');
        let o = obj;
        for (let i = 0; i < parts.length - 1; i++) o = o[parts[i]];
        o[parts[parts.length - 1]] = val;
    }

    $('#propsBody').on('input change', '[data-bind]', function () {
        const node = nodeById(state.selectedNodeId); if (!node) return;
        let v = this.value;
        if ($(this).data('num')) {
            v = parseInt(v, 10); if (isNaN(v) || v < 0) v = 0;
            if (this.getAttribute('data-bind') === 'retry.maxRetries' && v > MAX_RETRIES) { v = MAX_RETRIES; }
            if (this.type === 'number' && String(v) !== this.value && this.value !== '') this.value = v;
        }
        setPath(node, this.getAttribute('data-bind'), v);
        $(this).removeClass('invalid');
        updateNodeView(node);
        if (this.getAttribute('data-bind').startsWith('retry')) updateRetryPreview(node);
        drawLinks();
        setDirty(true);
    });

    $('#propsBody').on('input change', '[data-config]', function () {
        const node = nodeById(state.selectedNodeId); if (!node) return;
        node.config[this.getAttribute('data-config')] = this.type === 'checkbox' ? String(this.checked) : this.value;
        $(this).removeClass('invalid');
        setDirty(true);
    });

    $('#propsBody').on('click', '[data-add]', function () {
        const node = nodeById(state.selectedNodeId); if (!node) return;
        if ($(this).data('add') === 'user')
            node.userParameters.push({ name: '', label: '', dataType: 'String', required: false, defaultValue: '' });
        else
            node.systemParameters.push({ name: '', source: 'Context', value: '', dataType: 'String' });
        renderParamsPane(node);
        updateNodeView(node);
        setDirty(true);
        $('#propsBody [data-pane="params"] .param-card').last().find('input:first').focus();
    });

    $('#propsBody').on('click', '.param-card .rm', function () {
        const node = nodeById(state.selectedNodeId); if (!node) return;
        const $c = $(this).closest('.param-card');
        const list = $c.data('ptype') === 'user' ? node.userParameters : node.systemParameters;
        list.splice($c.data('idx'), 1);
        renderParamsPane(node);
        updateNodeView(node);
        setDirty(true);
    });

    $('#propsBody').on('input change', '.param-card [data-field]', function () {
        const node = nodeById(state.selectedNodeId); if (!node) return;
        const $c = $(this).closest('.param-card');
        const list = $c.data('ptype') === 'user' ? node.userParameters : node.systemParameters;
        const p = list[$c.data('idx')];
        const f = this.getAttribute('data-field');
        if (f === 'name') this.value = this.value.replace(/[^A-Za-z0-9_]/g, '');
        p[f] = this.type === 'checkbox' ? this.checked : this.value;
        if (f === 'source') $c.find('[data-field="value"]').attr('placeholder', SYS_HINTS[this.value] || '');
        $(this).removeClass('invalid');
        setDirty(true);
    });

    // --- link properties
    function renderLinkProperties() {
        const tr = state.template.transitions.find(t => t.id === state.selectedLinkId);
        if (!tr) { state.selectedLinkId = null; return renderProperties(); }
        const from = nodeById(tr.from), to = nodeById(tr.to);
        $('#propsTitle').text('Connection');
        $('#propsBody').html(`
            <div class="link-props">
                <div class="field"><label>From</label><input type="text" value="${esc(from.name)}" disabled /></div>
                <div class="field"><label>To</label><input type="text" value="${esc(to.name)}" disabled /></div>
                <div class="field"><div class="hint">Workflows run in sequential order only. To change the order, delete this connection and connect the activities again.</div></div>
                <button class="btn btn-danger" id="btnDeleteLink">Delete connection</button>
            </div>`);
    }
    $('#propsBody').on('click', '#btnDeleteLink', () => deleteLink(state.selectedLinkId));

    // =================================================================== CANVAS TOOLS
    function refreshAll() {
        drawLinks();
        const t = state.template;
        $('#canvasEmpty').toggle(t.activities.length === 0);
        $('#sbCounts').text(`${t.activities.length} activities · ${t.transitions.length} connections`);
        $('#lblCanvasMeta').text(t.activities.length ? 'Sequential flow: each activity has one next step. Click a connection to delete it.' : '');
        t.activities.forEach(updateNodeView);
    }

    $('#btnArrange').on('click', () => {
        // sequence in one vertical line; activities not yet connected go in a column on the right
        const { order, reachable } = computeOrder();
        let row = 0, loose = 0;
        order.forEach(id => {
            const n = nodeById(id);
            if (reachable.has(id)) { n.position.x = 420; n.position.y = 40 + row++ * 140; }
            else { n.position.x = 760; n.position.y = 40 + loose++ * 140; }
            $('#node_' + id).css({ left: n.position.x, top: n.position.y });
        });
        drawLinks();
        setDirty(true);
    });

    $('#btnClear').on('click', () => {
        if (!state.template.activities.length) return;
        confirmBox('Remove all activities and connections from the canvas?').then(() => {
            state.template.activities = []; state.template.transitions = []; state.template.startActivityId = null;
            $('.wf-node').remove();
            state.selectedNodeId = state.selectedLinkId = null;
            refreshAll(); renderProperties(); setDirty(true);
        });
    });

    // =================================================================== SERIALIZE / VALIDATE / SAVE
    // Workflow JSON — exactly the engine format:
    //   [ { "Order": 1, "Activity": "SendEmail", "Name": "...", "Configuration": {...}, "IsParallel": false },
    //     { "Order": 2, "Activity": "ApprovalGate", "Name": "...", "Approval": {...}, "Configuration": {}, "IsParallel": false } ]
    // Retries (when set) are written inside Configuration as retryCount / retryIntervalSeconds.
    const RETRY_KEYS = ['retryCount', 'retryIntervalSeconds', 'retryBackoff', 'onFailure'];

    function buildWorkflow() {
        const { order } = computeOrder();
        return order.map(id => nodeById(id)).map((a, i) => {
            const def = state.defs[a.type] || { configFields: [] };
            const approvalFields = def.configFields.filter(f => f.target === 'Approval');

            const cfg = {};
            Object.keys(a.config).forEach(k => {
                if (approvalFields.some(f => f.key === k)) return;
                const v = a.config[k];
                if (v != null && String(v).trim() !== '') cfg[k] = String(v);
            });
            if (a.retry.maxRetries > 0) {
                cfg.retryCount = String(a.retry.maxRetries);
                cfg.retryIntervalSeconds = String(a.retry.intervalSeconds);
                if (a.retry.backoff !== 'Fixed') cfg.retryBackoff = a.retry.backoff;
                if (a.retry.onFailure !== 'StopWorkflow') cfg.onFailure = a.retry.onFailure;
            }

            const item = { Order: i + 1, Activity: a.type, Name: (a.name || '').trim() };
            if (approvalFields.length) {
                item.Approval = {};
                approvalFields.forEach(f => {
                    const v = typedValue(a.config[f.key], f.valueType);
                    if (v !== undefined) item.Approval[f.jsonKey] = v;
                });
            }
            item.Configuration = cfg;
            item.IsParallel = false;
            return item;
        });
    }

    // What is sent to the server: template details + workflow JSON + designer-only data
    function buildTemplate() {
        syncHeaderToTemplate();
        const t = state.template;
        const { order } = computeOrder();
        const nodes = order.map(id => nodeById(id));
        const clean = v => (v == null || String(v).trim() === '') ? undefined : v;
        return {
            TemplateId: t.templateId || undefined,
            TemplateName: ($('#txtTemplateName').val() || '').trim(),
            ModuleCode: t.moduleCode, ModuleName: t.moduleName,
            ScreenCode: t.screenCode, ScreenName: t.screenName,
            Version: t.version || 1, Status: $('#ddlStatus').val(),
            Workflow: buildWorkflow(),
            Designer: nodes.map((a, i) => ({
                Order: i + 1, X: Math.round(a.position.x), Y: Math.round(a.position.y),
                Description: clean((a.description || '').trim()),
                UserParameters: a.userParameters.map(p => ({
                    Name: (p.name || '').trim(), Label: clean(p.label), DataType: p.dataType,
                    Required: !!p.required, DefaultValue: clean(p.defaultValue)
                })),
                SystemParameters: a.systemParameters.map(p => ({
                    Name: (p.name || '').trim(), Source: p.source, Value: p.value, DataType: p.dataType
                }))
            })),
            CreatedBy: t.createdBy, CreatedOn: t.createdOn, ModifiedBy: t.modifiedBy, ModifiedOn: t.modifiedOn
        };
    }

    function typedValue(v, type) {
        const str = v == null ? '' : String(v).trim();
        if (type === 'int') { const n = parseInt(str, 10); return isNaN(n) ? 0 : n; }
        if (type === 'list') return str ? str.split(',').map(x => x.trim()).filter(x => x) : [];
        return str === '' ? undefined : str;
    }

    // Converts saved JSON (Order / Activity / Configuration ...) back into designer nodes + connections
    function fromSavedJson(j) {
        const acts = (j.Workflow || []).slice().sort((a, b) => a.Order - b.Order);
        const designer = {};
        (j.Designer || []).forEach(d => designer[d.Order] = d);
        const activities = acts.map((a, i) => {
            const d = designer[a.Order] || {};
            const cfg = $.extend({}, a.Configuration || {});
            const retry = {
                maxRetries: parseInt(cfg.retryCount, 10) || 0,
                intervalSeconds: cfg.retryIntervalSeconds != null ? (parseInt(cfg.retryIntervalSeconds, 10) || 0) : 30,
                backoff: cfg.retryBackoff || 'Fixed',
                onFailure: cfg.onFailure || 'StopWorkflow'
            };
            RETRY_KEYS.forEach(k => delete cfg[k]);
            const def = state.defs[a.Activity];
            if (def && a.Approval) def.configFields.filter(f => f.target === 'Approval').forEach(f => {
                const v = a.Approval[f.jsonKey];
                cfg[f.key] = v == null ? '' : (Array.isArray(v) ? v.join(', ') : String(v));
            });
            return {
                id: 'act_' + (i + 1),
                type: a.Activity,
                name: a.Name || '',
                description: d.Description || '',
                position: d.X != null ? { x: d.X, y: d.Y } : { x: 420, y: 40 + i * 140 },
                retry,
                userParameters: (d.UserParameters || []).map(p => ({ name: p.Name, label: p.Label || '', dataType: p.DataType || 'String',
                                                                    required: !!p.Required, defaultValue: p.DefaultValue || '' })),
                systemParameters: (d.SystemParameters || []).map(p => ({ name: p.Name, source: p.Source || 'Static',
                                                                        value: p.Value || '', dataType: p.DataType || 'String' })),
                config: cfg
            };
        });
        const transitions = [];
        for (let i = 1; i < activities.length; i++)
            transitions.push({ id: 'tr_' + i, from: activities[i - 1].id, to: activities[i].id });
        return {
            templateId: j.TemplateId || null, templateName: j.TemplateName || '', description: '',
            moduleCode: j.ModuleCode || '', moduleName: j.ModuleName || '',
            screenCode: j.ScreenCode || '', screenName: j.ScreenName || '',
            version: j.Version || 0, status: j.Status || 'Draft',
            createdBy: j.CreatedBy, createdOn: j.CreatedOn, modifiedBy: j.ModifiedBy, modifiedOn: j.ModifiedOn,
            startActivityId: activities.length ? activities[0].id : null,
            activities, transitions
        };
    }

    function validateClient(tpl) {
        const errs = [];
        const bad = new Set();
        $('.invalid').removeClass('invalid');
        $('.wf-node').removeClass('has-error');

        if (!tpl.ModuleCode) { errs.push('Select a module.'); $('#ddlModule').addClass('invalid'); }
        if (!tpl.ScreenCode) { errs.push('Select a screen.'); $('#ddlScreen').addClass('invalid'); }
        if (!tpl.TemplateName) { errs.push('Enter the workflow template name.'); $('#txtTemplateName').addClass('invalid'); }

        const t = state.template;
        if (!t.activities.length) errs.push('Drag at least one activity onto the canvas.');

        const nameRx = /^[A-Za-z_][A-Za-z0-9_]*$/;
        const { order, reachable } = computeOrder();
        order.map(id => nodeById(id)).forEach(a => {
            const def = state.defs[a.type];
            const lbl = (a.name || '').trim() || a.id;
            if (!(a.name || '').trim()) { errs.push(`${a.id}: activity name is required.`); bad.add(a.id); }
            if (a.retry.maxRetries < 0 || a.retry.maxRetries > MAX_RETRIES) { errs.push(`${lbl}: retries must be 0–${MAX_RETRIES}.`); bad.add(a.id); }
            if (!def) { errs.push(`${lbl}: unknown activity "${a.type}".`); bad.add(a.id); return; }
            def.configFields.filter(f => f.required).forEach(f => {
                if (!String(a.config[f.key] || '').trim()) { errs.push(`${lbl}: "${f.label}" is required (General tab).`); bad.add(a.id); }
            });
            const seen = new Set();
            [...a.userParameters.map(p => ['User', p]), ...a.systemParameters.map(p => ['System', p])].forEach(([kind, p]) => {
                const nm = (p.name || '').trim();
                if (!nameRx.test(nm)) { errs.push(`${lbl}: ${kind} parameter "${nm || '(blank)'}" needs a valid name.`); bad.add(a.id); }
                else if (seen.has(nm.toLowerCase())) { errs.push(`${lbl}: parameter "${nm}" is defined twice.`); bad.add(a.id); }
                seen.add(nm.toLowerCase());
                if (kind === 'System' && !String(p.value || '').trim()) { errs.push(`${lbl}: system parameter "${nm}" needs a value.`); bad.add(a.id); }
            });
        });

        if (t.activities.length) {
            if (t.activities.some(a => t.transitions.filter(tr => tr.from === a.id).length > 1 || t.transitions.filter(tr => tr.to === a.id).length > 1))
                errs.push('Each activity can have only one next and one previous step (sequential order).');
            if (!t.startActivityId) errs.push('The workflow has a loop — there is no starting activity. Only sequential order is allowed.');
            t.activities.filter(a => !reachable.has(a.id)).forEach(a => {
                errs.push(`${a.name}: not connected in the sequence.`); bad.add(a.id);
            });
        }
        bad.forEach(id => $('#node_' + id).addClass('has-error'));
        return errs;
    }

    function showValidation(errs, title) {
        $('#valTitle').contents().first()[0].textContent = title || (errs.length ? `Please fix ${errs.length} issue${errs.length > 1 ? 's' : ''}` : 'Validation');
        const $l = $('#valList').empty().toggleClass('ok', !errs.length);
        if (!errs.length) $l.append('<li>✔ The workflow is valid and ready to save.</li>');
        errs.forEach(e => $l.append($('<li>').text(e)));
        openModal('mdlValidation');
    }

    $('#btnValidate').on('click', () => {
        const tpl = buildTemplate();
        const errs = validateClient(tpl);
        if (errs.length) return showValidation(errs);
        api('POST', API.workflows + '/validate', tpl).done(r => showValidation(r.errors));
    });

    $('#btnSave').on('click', save);
    $(document).on('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); save(); } });

    function save() {
        const tpl = buildTemplate();
        const errs = validateClient(tpl);
        if (errs.length) return showValidation(errs);
        const $btn = $('#btnSave').prop('disabled', true).text('Saving…');
        api('POST', API.workflows, tpl)
            .done(saved => {
                applyTemplateMeta(saved);
                setDirty(false);
                toast(`Saved "${saved.TemplateName}" — version ${saved.Version}`, 'success');
            })
            .fail(x => showValidation(errorsFrom(x), 'Could not save'))
            .always(() => $btn.prop('disabled', false).text('Save Template'));
    }

    function applyTemplateMeta(saved) {
        const t = state.template;
        t.templateId = saved.TemplateId; t.version = saved.Version;
        t.createdBy = saved.CreatedBy; t.createdOn = saved.CreatedOn;
        t.modifiedBy = saved.ModifiedBy; t.modifiedOn = saved.ModifiedOn;
        t.moduleName = saved.ModuleName; t.screenName = saved.ScreenName;
        $('#sbTemplate').text(`${saved.TemplateId} · v${saved.Version} · ${saved.ModuleName} / ${saved.ScreenName}`);
    }

    // =================================================================== JSON VIEW
    function highlight(json) {
        return esc(json).replace(/(&quot;(?:\\.|[^&]|&(?!quot;))*?&quot;)(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d+)?/g,
            (m, str, colon, bool) => {
                if (str) return colon ? `<span class="k">${str}</span>${colon}` : `<span class="s">${str}</span>`;
                if (bool) return `<span class="b">${m}</span>`;
                return `<span class="n">${m}</span>`;
            });
    }
    $('#btnViewJson').on('click', () => {
        const json = JSON.stringify(buildWorkflow(), null, 2);    // workflow JSON only
        $('#preJson').html(highlight(json)).data('raw', json);
        openModal('mdlJson');
    });
    $('#btnCopyJson').on('click', () => {
        const raw = $('#preJson').data('raw');
        (navigator.clipboard ? navigator.clipboard.writeText(raw) : Promise.reject())
            .then(() => toast('JSON copied to clipboard', 'success'))
            .catch(() => {
                const ta = $('<textarea>').val(raw).appendTo('body').select();
                document.execCommand('copy'); ta.remove(); toast('JSON copied to clipboard', 'success');
            });
    });
    $('#btnDownloadJson').on('click', () => {
        const tpl = buildTemplate();
        const blob = new Blob([$('#preJson').data('raw')], { type: 'application/json' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `${(tpl.TemplateName || 'workflow').replace(/\s+/g, '_')}.json`;
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    });

    // =================================================================== NEW / OPEN
    function guardDirty() {
        return state.dirty ? confirmBox('You have unsaved changes. Discard them?') : $.Deferred().resolve().promise();
    }

    $('#btnNew').on('click', () => guardDirty().then(() => { loadTemplate(emptyTemplate(), true); }));

    $('#btnOpen').on('click', () => { openModal('mdlOpen'); loadTemplateList(); });
    $('#chkFilterCurrent').on('change', loadTemplateList);

    function loadTemplateList() {
        const q = {};
        if ($('#chkFilterCurrent').is(':checked')) {
            if ($('#ddlModule').val()) q.module = $('#ddlModule').val();
            if ($('#ddlScreen').val()) q.screen = $('#ddlScreen').val();
        }
        const $tb = $('#tblTemplates').html('<tr><td colspan="8">Loading…</td></tr>');
        api('GET', API.workflows + '?' + $.param(q)).done(list => {
            $tb.empty();
            if (!list.length) return $tb.html('<tr><td colspan="8" style="color:#66758a">No templates found.</td></tr>');
            list.forEach(s => $tb.append(`
                <tr data-id="${esc(s.templateId)}">
                    <td><b>${esc(s.templateName)}</b><br/><small style="color:#66758a">${esc(s.templateId)}</small></td>
                    <td>${esc(s.moduleName)}</td><td>${esc(s.screenName)}</td>
                    <td>${s.version}</td>
                    <td><span class="status-pill ${esc(s.status)}">${esc(s.status)}</span></td>
                    <td>${s.activityCount}</td>
                    <td>${s.modifiedOn ? esc(s.modifiedOn.replace('T', ' ').substring(0, 16)) : ''}</td>
                    <td style="white-space:nowrap">
                        <button class="btn-link" data-act="open">Open</button>
                        <a class="btn-link" href="${API.workflows}/${encodeURIComponent(s.templateId)}/download">JSON</a>
                        <button class="btn-link danger" data-act="del">Delete</button>
                    </td>
                </tr>`));
        });
    }

    $('#tblTemplates').on('click', '[data-act="open"]', function () {
        const id = $(this).closest('tr').data('id');
        guardDirty().then(() => api('GET', `${API.workflows}/${encodeURIComponent(id)}`).done(j => { closeModals(); loadTemplate(fromSavedJson(j)); }));
    });
    $('#tblTemplates').on('click', '[data-act="del"]', function () {
        const id = $(this).closest('tr').data('id');
        const name = $(this).closest('tr').find('b').text();
        closeModals();
        confirmBox(`Delete template "${name}"? This cannot be undone.`).then(() =>
            api('DELETE', `${API.workflows}/${encodeURIComponent(id)}`).done(() => {
                toast('Template deleted', 'success');
                if (state.template.templateId === id) loadTemplate(emptyTemplate(), true);
            }));
    });

    function loadTemplate(t, keepHeader) {
        $('.wf-node').remove();
        state.selectedNodeId = state.selectedLinkId = null;
        state.activeTab = 'general';

        if (keepHeader) {
            t.moduleCode = $('#ddlModule').val();
            t.screenCode = $('#ddlScreen').val();
        }
        state.template = $.extend(emptyTemplate(), t);
        state.template.activities.forEach(a => {
            a.retry = $.extend({ maxRetries: 0, intervalSeconds: 30, backoff: 'Fixed', onFailure: 'StopWorkflow' }, a.retry);
            a.userParameters = a.userParameters || [];
            a.systemParameters = a.systemParameters || [];
            a.config = a.config || {};
            a.position = a.position || { x: 40, y: 40 };
        });
        state.template.transitions = (state.template.transitions || []).map(tr => ({ id: tr.id, from: tr.from, to: tr.to }));

        // keep generated ids unique after loading
        state.seq = {};
        [...state.template.activities.map(a => a.id), ...state.template.transitions.map(x => x.id)].forEach(id => {
            const m = /^([a-z]+)_(\d+)$/i.exec(String(id));
            if (m) state.seq[m[1]] = Math.max(state.seq[m[1]] || 0, parseInt(m[2], 10));
        });

        $('#txtTemplateName').val(state.template.templateName);
        $('#ddlStatus').val(state.template.status || 'Draft');
        $('#ddlModule').val(state.template.moduleCode || '');
        renderScreens(state.template.screenCode);

        recomputeStart();
        state.template.activities.forEach(renderNode);
        refreshAll();
        renderProperties();
        $('.invalid').removeClass('invalid');
        $('#sbTemplate').text(state.template.templateId
            ? `${state.template.templateId} · v${state.template.version} · ${state.template.moduleName} / ${state.template.screenName}`
            : 'New template (unsaved)');
        setDirty(false);
    }

    window.addEventListener('beforeunload', e => { if (state.dirty) { e.preventDefault(); e.returnValue = ''; } });

    const DESIGNER_BUILD = '2026-09-29 (v5 - 3 tabs)';
    $('#sbCounts').attr('title', 'Designer build ' + DESIGNER_BUILD);
    $('.statusbar').append($('<span style="opacity:.7">').text('Build ' + DESIGNER_BUILD));
    window.WORKFLOW_DESIGNER_BUILD = DESIGNER_BUILD;

    // =================================================================== INIT
    $.when(loadActivities(), loadModules()).done(() => refreshAll())
        .fail(() => toast('Could not reach the server API', 'error'));

})(jQuery);
