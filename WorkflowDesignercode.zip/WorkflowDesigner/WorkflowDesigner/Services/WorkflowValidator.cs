using System.Text.RegularExpressions;
using WorkflowDesigner.Models;

namespace WorkflowDesigner.Services;

public static class WorkflowValidator
{
    private static readonly Regex ParamName = new("^[A-Za-z_][A-Za-z0-9_]*$", RegexOptions.Compiled);
    public const int MaxRetries = 10;

    public static List<string> Validate(WorkflowTemplate t)
    {
        var errors = new List<string>();

        if (string.IsNullOrWhiteSpace(t.TemplateName)) errors.Add("Template name is required.");
        if (string.IsNullOrWhiteSpace(t.ModuleCode)) errors.Add("Module is required.");
        if (string.IsNullOrWhiteSpace(t.ScreenCode)) errors.Add("Screen is required.");
        if (t.Workflow.Count == 0) errors.Add("Add at least one activity to the workflow.");

        // ---- Sequential order only: Order must run 1, 2, 3 ... n with no gaps or repeats ----
        var orders = t.Workflow.Select(a => a.Order).OrderBy(o => o).ToList();
        if (!orders.SequenceEqual(Enumerable.Range(1, t.Workflow.Count)))
            errors.Add("Activity Order must run 1, 2, 3 ... without gaps or duplicates (sequential order only).");
        if (t.Workflow.Any(a => a.IsParallel))
            errors.Add("Parallel activities are not allowed. Workflows run in sequential order only.");

        foreach (var a in t.Workflow.OrderBy(a => a.Order))
        {
            var label = string.IsNullOrWhiteSpace(a.Name) ? $"Order {a.Order}" : a.Name;

            if (string.IsNullOrWhiteSpace(a.Name)) errors.Add($"Activity at Order {a.Order}: name is required.");

            var def = ActivityCatalog.Find(a.Activity);
            if (def == null) { errors.Add($"Activity '{label}': unknown activity '{a.Activity}'."); continue; }

            // retries live inside Configuration ("retryCount", "retryIntervalSeconds") when set
            if (a.Configuration.TryGetValue("retryCount", out var rc) && rc != null)
                if (!int.TryParse(rc, out var n) || n < 0 || n > MaxRetries)
                    errors.Add($"Activity '{label}': retries must be between 0 and {MaxRetries}.");

            if (def.ConfigFields.Any(f => f.Target == "Approval"))
            {
                var ap = a.Approval;
                if (ap == null) errors.Add($"Activity '{label}': Approval settings are required.");
                else
                {
                    if (string.IsNullOrWhiteSpace(ap.StageId)) errors.Add($"Activity '{label}': 'Stage Id' is required.");
                    if (ap.Approvers.Count(x => !string.IsNullOrWhiteSpace(x)) == 0) errors.Add($"Activity '{label}': at least one approver is required.");
                    if (ap.TimeoutSeconds <= 0) errors.Add($"Activity '{label}': timeout must be greater than 0.");
                    if (ap.MinApprovals < 1) errors.Add($"Activity '{label}': Min Approvals must be at least 1.");
                }
            }

            foreach (var f in def.ConfigFields.Where(f => f.Required && f.Target == null))
                if (!a.Configuration.TryGetValue(f.Key, out var v) || string.IsNullOrWhiteSpace(v))
                    errors.Add($"Activity '{label}': '{f.Label}' is required.");

            var node = t.Designer.FirstOrDefault(d => d.Order == a.Order);
            if (node == null) continue;
            var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var p in node.UserParameters)
            {
                if (!ParamName.IsMatch(p.Name ?? "")) errors.Add($"Activity '{label}': user parameter '{p.Name}' is not a valid name (letters, digits, underscore).");
                else if (!names.Add(p.Name!)) errors.Add($"Activity '{label}': parameter '{p.Name}' is defined more than once.");
            }
            foreach (var p in node.SystemParameters)
            {
                if (!ParamName.IsMatch(p.Name ?? "")) errors.Add($"Activity '{label}': system parameter '{p.Name}' is not a valid name (letters, digits, underscore).");
                else if (!names.Add(p.Name!)) errors.Add($"Activity '{label}': parameter '{p.Name}' is defined more than once.");
                if (string.IsNullOrWhiteSpace(p.Value)) errors.Add($"Activity '{label}': system parameter '{p.Name}' needs a value/expression.");
            }
        }

        return errors;
    }
}
