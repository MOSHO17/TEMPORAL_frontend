using WorkflowDesigner.Models;

namespace WorkflowDesigner.Services;

/// <summary>
/// Activities shown in the designer palette. To add a new activity type,
/// add an entry here — the UI renders its config form from ConfigFields automatically.
/// </summary>
public static class ActivityCatalog
{
    private static readonly List<string> Roles = new() { "Maker", "Checker", "Approver", "Branch Manager", "Credit Officer", "Operations" };

    public static readonly IReadOnlyList<ActivityDefinition> All = new List<ActivityDefinition>
    {
        new()
        {
            Type = "Maker", DisplayName = "Maker", Category = "Human Task", Icon = "✎", Color = "#1f6feb",
            Description = "Data entry / initiation step performed by a maker.",
            DefaultRetries = 0,
            ConfigFields = new()
            {
                new() { Key = "assignedRole", Label = "Assigned Role", InputType = "select", Required = true, DefaultValue = "Maker", Options = Roles },
                new() { Key = "slaHours", Label = "SLA (hours)", InputType = "number", DefaultValue = "24" },
                new() { Key = "allowSaveDraft", Label = "Allow Save as Draft", InputType = "checkbox", DefaultValue = "true" },
                new() { Key = "instructions", Label = "Instructions to User", InputType = "textarea", Placeholder = "Shown on the maker screen" }
            }
        },
        new()
        {
            Type = "Checker", DisplayName = "Checker", Category = "Human Task", Icon = "✔", Color = "#2e7d32",
            Description = "Verification step — approve, reject or send back to maker.",
            DefaultRetries = 0,
            ConfigFields = new()
            {
                new() { Key = "assignedRole", Label = "Assigned Role", InputType = "select", Required = true, DefaultValue = "Checker", Options = Roles },
                new() { Key = "actions", Label = "Allowed Actions", InputType = "select", DefaultValue = "Approve / Reject / Send Back",
                        Options = new() { "Approve / Reject", "Approve / Reject / Send Back", "Approve only" } },
                new() { Key = "slaHours", Label = "SLA (hours)", InputType = "number", DefaultValue = "24" },
                new() { Key = "remarksMandatory", Label = "Remarks mandatory on Reject", InputType = "checkbox", DefaultValue = "true" }
            }
        },
        new()
        {
            Type = "ApprovalGate", DisplayName = "Approval Gate", Category = "Human Task", Icon = "⛨", Color = "#00838f",
            Description = "Waits for approval from one or more approvers before continuing.",
            DefaultRetries = 0,
            ConfigFields = new()
            {
                new() { Key = "stageId", JsonKey = "StageId", Target = "Approval", Label = "Stage Id", InputType = "text", Required = true, Placeholder = "vault-stage-{{usecid}}" },
                new() { Key = "mode", JsonKey = "Mode", Target = "Approval", Label = "Mode", InputType = "select", Required = true, DefaultValue = "ANY_ONE",
                        Options = new() { "ANY_ONE", "ALL", "MIN_APPROVALS" } },
                new() { Key = "approvers", JsonKey = "Approvers", Target = "Approval", ValueType = "list", Label = "Approvers (comma separated)", InputType = "text", Required = true, Placeholder = "{{vaultCustodianId}}" },
                new() { Key = "timeoutSeconds", JsonKey = "TimeoutSeconds", Target = "Approval", ValueType = "int", Label = "Timeout (seconds)", InputType = "number", Required = true, DefaultValue = "86400" },
                new() { Key = "minApprovals", JsonKey = "MinApprovals", Target = "Approval", ValueType = "int", Label = "Min Approvals", InputType = "number", Required = true, DefaultValue = "1" },
                new() { Key = "onReject", JsonKey = "OnReject", Target = "Approval", Label = "On Reject", InputType = "select", DefaultValue = "FAIL_WORKFLOW",
                        Options = new() { "FAIL_WORKFLOW", "CONTINUE_WORKFLOW" } },
                new() { Key = "onTimeout", JsonKey = "OnTimeout", Target = "Approval", Label = "On Timeout", InputType = "select", DefaultValue = "FAIL_WORKFLOW",
                        Options = new() { "FAIL_WORKFLOW", "CONTINUE_WORKFLOW" } },
                new() { Key = "subject", JsonKey = "Subject", Target = "Approval", Label = "Subject", InputType = "text", Placeholder = "Vault action required for {{requestNo}}" },
                new() { Key = "description", JsonKey = "Description", Target = "Approval", Label = "Description", InputType = "textarea", Placeholder = "Vault custodian approval required for request {{requestNo}}" }
            }
        },
        new()
        {
            Type = "Approver", DisplayName = "Approver", Category = "Human Task", Icon = "★", Color = "#6f42c1",
            Description = "Final authority approval.",
            DefaultRetries = 0,
            ConfigFields = new()
            {
                new() { Key = "assignedRole", Label = "Assigned Role", InputType = "select", Required = true, DefaultValue = "Approver", Options = Roles },
                new() { Key = "amountLimit", Label = "Approval Limit (₹)", InputType = "number", Placeholder = "Leave blank for no limit" },
                new() { Key = "slaHours", Label = "SLA (hours)", InputType = "number", DefaultValue = "48" }
            }
        },
        new()
        {
            Type = "CallHttp", DisplayName = "Call HTTP", Category = "Integration", Icon = "⇄", Color = "#d9730d",
            Description = "Invoke a REST API endpoint.",
            DefaultRetries = 0,
            ConfigFields = new()
            {
                new() { Key = "method", Label = "Method", InputType = "select", Required = true, DefaultValue = "POST",
                        Options = new() { "GET", "POST", "PUT", "PATCH", "DELETE" } },
                new() { Key = "url", Label = "URL", InputType = "text", Required = true, Placeholder = "https://api.internal/endpoint/{{ApplicationId}}" },
                new() { Key = "headers", Label = "Headers (one per line: Key: Value)", InputType = "textarea", Placeholder = "Content-Type: application/json" },
                new() { Key = "body", Label = "Request Body", InputType = "textarea", Placeholder = "{ \"applicationId\": \"{{ApplicationId}}\" }" },
                new() { Key = "timeoutSeconds", Label = "Timeout (seconds)", InputType = "number", DefaultValue = "30" },
                new() { Key = "successCodes", Label = "Success Status Codes", InputType = "text", DefaultValue = "200,201,204" }
            }
        },
        new()
        {
            Type = "SendEmail", DisplayName = "Send Email", Category = "Notification", Icon = "✉", Color = "#c62828",
            Description = "Send an email notification.",
            DefaultRetries = 0,
            ConfigFields = new()
            {
                new() { Key = "to", Label = "To", InputType = "text", Required = true, Placeholder = "user@bank.com; {{Maker.Email}}" },
                new() { Key = "cc", Label = "CC", InputType = "text" },
                new() { Key = "subject", Label = "Subject", InputType = "text", Required = true, Placeholder = "Application {{ApplicationId}} submitted" },
                new() { Key = "body", Label = "Body (HTML allowed)", InputType = "textarea" }
            }
        },
        new()
        {
            Type = "Delay", DisplayName = "Wait / Delay", Category = "Flow", Icon = "⏱", Color = "#5c6b7a",
            Description = "Pause the workflow for a fixed duration.",
            DefaultRetries = 0,
            ConfigFields = new()
            {
                new() { Key = "duration", Label = "Duration", InputType = "number", Required = true, DefaultValue = "1" },
                new() { Key = "unit", Label = "Unit", InputType = "select", DefaultValue = "Hours", Options = new() { "Minutes", "Hours", "Days" } }
            }
        }
    };

    public static ActivityDefinition? Find(string type) =>
        All.FirstOrDefault(a => string.Equals(a.Type, type, StringComparison.OrdinalIgnoreCase));
}
