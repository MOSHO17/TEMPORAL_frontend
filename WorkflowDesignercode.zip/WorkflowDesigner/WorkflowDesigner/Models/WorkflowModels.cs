using System.Text.Json.Serialization;

namespace WorkflowDesigner.Models;

// ---------------------------------------------------------------------------
//  Module / Screen master
// ---------------------------------------------------------------------------

public class Module
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    public string CreatedBy { get; set; } = "";
    public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
    public List<Screen> Screens { get; set; } = new();
}

public class Screen
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public bool IsActive { get; set; } = true;
}

public class CreateModuleRequest
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string? Description { get; set; }
}

public class CreateScreenRequest
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
}

// ---------------------------------------------------------------------------
//  Activity catalogue (what appears in the designer palette)
// ---------------------------------------------------------------------------

public class ActivityDefinition
{
    public string Type { get; set; } = "";          // Maker, CallHttp, SendEmail ...
    public string DisplayName { get; set; } = "";
    public string Category { get; set; } = "";      // Human Task / Integration / Notification / Flow
    public string Icon { get; set; } = "";
    public string Color { get; set; } = "";
    public string Description { get; set; } = "";
    public int DefaultRetries { get; set; }
    public List<ConfigField> ConfigFields { get; set; } = new();
}

public class ConfigField
{
    public string Key { get; set; } = "";
    public string Label { get; set; } = "";
    public string InputType { get; set; } = "text";  // text | textarea | number | select | checkbox
    public bool Required { get; set; }
    public string? DefaultValue { get; set; }
    public string? Placeholder { get; set; }
    public List<string>? Options { get; set; }

    /// <summary>null = saved under "Configuration"; "Approval" = saved under the activity's "Approval" block.</summary>
    public string? Target { get; set; }
    /// <summary>Property name used in the saved JSON when Target is set (e.g. "StageId").</summary>
    public string? JsonKey { get; set; }
    /// <summary>string (default) | int | list (comma separated -> JSON array)</summary>
    public string? ValueType { get; set; }
}

// ---------------------------------------------------------------------------
//  WORKFLOW JSON  (what the engine gets — exactly this shape, nothing else)
//  [
//    { "Order": 5, "Activity": "SendEmail", "Name": "MailAfterApprover",
//      "Configuration": { "to": "...", "subject": "...", "body": "..." }, "IsParallel": false },
//    { "Order": 6, "Activity": "ApprovalGate", "Name": "VaultApprovalGate",
//      "Approval": { "StageId": "...", ... }, "Configuration": {}, "IsParallel": false }
//  ]
//  Module / screen / template name and designer data are stored separately (TemplateMeta).
// ---------------------------------------------------------------------------

public class WorkflowActivity
{
    [JsonPropertyName("Order")]         public int Order { get; set; }
    [JsonPropertyName("Activity")]      public string Activity { get; set; } = "";     // Maker, Checker, ApprovalGate, Approver, CallHttp, SendEmail, Delay
    [JsonPropertyName("Name")]          public string Name { get; set; } = "";
    [JsonPropertyName("Approval")]      public ApprovalSettings? Approval { get; set; } // only for ApprovalGate
    [JsonPropertyName("Configuration")] public Dictionary<string, string?> Configuration { get; set; } = new();
    [JsonPropertyName("IsParallel")]    public bool IsParallel { get; set; }            // always false (sequential only)
}

/// <summary>Template details kept outside the workflow JSON (module, screen, name, version, designer data).</summary>
public class TemplateMeta
{
    [JsonPropertyName("TemplateId")]   public string? TemplateId { get; set; }
    [JsonPropertyName("TemplateName")] public string TemplateName { get; set; } = "";
    [JsonPropertyName("ModuleCode")]   public string ModuleCode { get; set; } = "";
    [JsonPropertyName("ModuleName")]   public string ModuleName { get; set; } = "";
    [JsonPropertyName("ScreenCode")]   public string ScreenCode { get; set; } = "";
    [JsonPropertyName("ScreenName")]   public string ScreenName { get; set; } = "";
    [JsonPropertyName("Version")]      public int Version { get; set; } = 1;
    [JsonPropertyName("Status")]       public string Status { get; set; } = "Draft";   // Draft | Active | Inactive
    [JsonPropertyName("ActivityCount")] public int ActivityCount { get; set; }

    /// <summary>Designer-only data per activity: canvas position, description, user/system parameters.</summary>
    [JsonPropertyName("Designer")]     public List<DesignerNode> Designer { get; set; } = new();

    [JsonPropertyName("CreatedBy")]    public string CreatedBy { get; set; } = "";
    [JsonPropertyName("CreatedOn")]    public DateTime CreatedOn { get; set; }
    [JsonPropertyName("ModifiedBy")]   public string? ModifiedBy { get; set; }
    [JsonPropertyName("ModifiedOn")]   public DateTime? ModifiedOn { get; set; }
}

/// <summary>What the designer sends/receives: template details + the workflow JSON.</summary>
public class WorkflowTemplate : TemplateMeta
{
    [JsonPropertyName("Workflow")] public List<WorkflowActivity> Workflow { get; set; } = new();
}

public class DesignerNode
{
    [JsonPropertyName("Order")]       public int Order { get; set; }
    [JsonPropertyName("X")]           public double X { get; set; }
    [JsonPropertyName("Y")]           public double Y { get; set; }
    [JsonPropertyName("Description")] public string? Description { get; set; }
    [JsonPropertyName("UserParameters")]   public List<UserParameter> UserParameters { get; set; } = new();
    [JsonPropertyName("SystemParameters")] public List<SystemParameter> SystemParameters { get; set; } = new();
}

public class ApprovalSettings
{
    [JsonPropertyName("StageId")]        public string StageId { get; set; } = "";
    [JsonPropertyName("Mode")]           public string Mode { get; set; } = "ANY_ONE";          // ANY_ONE | ALL | MIN_APPROVALS
    [JsonPropertyName("Approvers")]      public List<string> Approvers { get; set; } = new();
    [JsonPropertyName("TimeoutSeconds")] public int TimeoutSeconds { get; set; } = 86400;
    [JsonPropertyName("MinApprovals")]   public int MinApprovals { get; set; } = 1;
    [JsonPropertyName("OnReject")]       public string OnReject { get; set; } = "FAIL_WORKFLOW";
    [JsonPropertyName("OnTimeout")]      public string OnTimeout { get; set; } = "FAIL_WORKFLOW";
    [JsonPropertyName("Subject")]        public string? Subject { get; set; }
    [JsonPropertyName("Description")]    public string? Description { get; set; }
}

/// <summary>Value captured from the end user at runtime (on the screen).</summary>
public class UserParameter
{
    [JsonPropertyName("Name")]         public string Name { get; set; } = "";
    [JsonPropertyName("Label")]        public string? Label { get; set; }
    [JsonPropertyName("DataType")]     public string DataType { get; set; } = "String";   // String | Number | Decimal | Date | Boolean | Email
    [JsonPropertyName("Required")]     public bool Required { get; set; }
    [JsonPropertyName("DefaultValue")] public string? DefaultValue { get; set; }
}

/// <summary>Value resolved by the system at runtime (context, config, previous activity output).</summary>
public class SystemParameter
{
    [JsonPropertyName("Name")]     public string Name { get; set; } = "";
    [JsonPropertyName("Source")]   public string Source { get; set; } = "Static";     // Static | Context | AppConfig | ActivityOutput
    [JsonPropertyName("Value")]    public string Value { get; set; } = "";            // literal or expression e.g. {{Context.UserId}}
    [JsonPropertyName("DataType")] public string DataType { get; set; } = "String";
}

public class WorkflowSummary
{
    public string TemplateId { get; set; } = "";
    public string TemplateName { get; set; } = "";
    public string ModuleCode { get; set; } = "";
    public string ModuleName { get; set; } = "";
    public string ScreenCode { get; set; } = "";
    public string ScreenName { get; set; } = "";
    public int Version { get; set; }
    public string Status { get; set; } = "";
    public int ActivityCount { get; set; }
    public DateTime? ModifiedOn { get; set; }
}
