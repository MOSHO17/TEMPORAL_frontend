using System.Text.Json;
using WorkflowDesigner.Data;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers()
    .AddJsonOptions(o =>
    {
        o.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
        o.JsonSerializerOptions.PropertyNameCaseInsensitive = true;
        o.JsonSerializerOptions.DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull;
        o.JsonSerializerOptions.Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
    });

var provider = builder.Configuration["Storage:Provider"] ?? "Json";
if (provider.Equals("SqlServer", StringComparison.OrdinalIgnoreCase))
{
#if SQLSERVER
    builder.Services.AddSingleton<IWorkflowRepository, SqlWorkflowRepository>();
#else
    throw new InvalidOperationException(
        "Storage:Provider is SqlServer but the app was built without SQL support. Build with: dotnet build -p:UseSqlServer=true");
#endif
}
else
{
    builder.Services.AddSingleton<IWorkflowRepository, JsonFileRepository>();
}

var app = builder.Build();

app.UseDefaultFiles();   // serves wwwroot/index.html at "/"
app.UseStaticFiles(new StaticFileOptions
{
    // always fetch the latest html/js/css so the browser never runs an old cached designer
    OnPrepareResponse = ctx =>
    {
        var ext = Path.GetExtension(ctx.File.Name).ToLowerInvariant();
        if (ext is ".html" or ".js" or ".css")
            ctx.Context.Response.Headers["Cache-Control"] = "no-cache, no-store, must-revalidate";
    }
});
app.MapControllers();

app.Run();
