using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Mvc;
using WorkflowDesigner.Data;
using WorkflowDesigner.Models;
using WorkflowDesigner.Services;

namespace WorkflowDesigner.Controllers;

public abstract class BaseApiController : ControllerBase
{
    // Replace with the logged-in user (e.g. User.Identity.Name) once authentication is wired in.
    protected string CurrentUser =>
        Request.Headers.TryGetValue("X-User", out var u) && !string.IsNullOrWhiteSpace(u) ? u.ToString() : "Admin1";

    protected static readonly Regex CodePattern = new("^[A-Za-z0-9_]{2,30}$", RegexOptions.Compiled);
}

[ApiController]
[Route("api/modules")]
public class ModulesController : BaseApiController
{
    private readonly IWorkflowRepository _repo;
    public ModulesController(IWorkflowRepository repo) => _repo = repo;

    [HttpGet]
    public async Task<ActionResult<List<Module>>> Get() => await _repo.GetModulesAsync();

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateModuleRequest req)
    {
        var code = (req.Code ?? "").Trim().ToUpperInvariant();
        var name = (req.Name ?? "").Trim();
        if (!CodePattern.IsMatch(code)) return BadRequest(new { errors = new[] { "Module code must be 2-30 letters, digits or underscore." } });
        if (name.Length is < 2 or > 100) return BadRequest(new { errors = new[] { "Module name must be 2-100 characters." } });

        try
        {
            var m = await _repo.CreateModuleAsync(new Module
            {
                Code = code, Name = name, Description = req.Description?.Trim(),
                CreatedBy = CurrentUser, CreatedOn = DateTime.UtcNow
            });
            return Ok(m);
        }
        catch (DuplicateException ex) { return Conflict(new { errors = new[] { ex.Message } }); }
    }

    [HttpPost("{moduleCode}/screens")]
    public async Task<IActionResult> AddScreen(string moduleCode, [FromBody] CreateScreenRequest req)
    {
        var code = (req.Code ?? "").Trim().ToUpperInvariant();
        var name = (req.Name ?? "").Trim();
        if (!CodePattern.IsMatch(code)) return BadRequest(new { errors = new[] { "Screen code must be 2-30 letters, digits or underscore." } });
        if (name.Length is < 2 or > 150) return BadRequest(new { errors = new[] { "Screen name must be 2-150 characters." } });

        try { return Ok(await _repo.AddScreenAsync(moduleCode, new Screen { Code = code, Name = name })); }
        catch (NotFoundException ex) { return NotFound(new { errors = new[] { ex.Message } }); }
        catch (DuplicateException ex) { return Conflict(new { errors = new[] { ex.Message } }); }
    }
}

[ApiController]
[Route("api/activities")]
public class ActivitiesController : ControllerBase
{
    [HttpGet]
    public IEnumerable<ActivityDefinition> Get() => ActivityCatalog.All;
}

[ApiController]
[Route("api/workflows")]
public class WorkflowsController : BaseApiController
{
    private readonly IWorkflowRepository _repo;
    public WorkflowsController(IWorkflowRepository repo) => _repo = repo;

    [HttpGet]
    public async Task<ActionResult<List<WorkflowSummary>>> List([FromQuery] string? module, [FromQuery] string? screen)
        => await _repo.GetTemplatesAsync(module, screen);

    [HttpGet("{id}")]
    public async Task<IActionResult> Get(string id)
    {
        var t = await _repo.GetTemplateAsync(id);
        return t == null ? NotFound() : Ok(t);
    }

    /// <summary>Downloads the workflow JSON (activities only, exactly as the engine expects).</summary>
    [HttpGet("{id}/download")]
    public async Task<IActionResult> Download(string id)
    {
        var t = await _repo.GetTemplateAsync(id);
        if (t == null) return NotFound();
        // the download is only the workflow JSON (array of activities)
        var bytes = System.Text.Json.JsonSerializer.SerializeToUtf8Bytes(t.Workflow, JsonFileRepository.JsonOptions);
        return File(bytes, "application/json", $"{t.ModuleCode}_{t.ScreenCode}_{t.TemplateName.Replace(' ', '_')}_v{t.Version}.json");
    }

    [HttpPost("validate")]
    public IActionResult Validate([FromBody] WorkflowTemplate t)
    {
        var errors = WorkflowValidator.Validate(t);
        return Ok(new { valid = errors.Count == 0, errors });
    }

    /// <summary>Creates a new template (no templateId) or saves a new version of an existing one.</summary>
    [HttpPost]
    public async Task<IActionResult> Save([FromBody] WorkflowTemplate t)
    {
        t.TemplateName = (t.TemplateName ?? "").Trim();

        // Resolve module / screen names from master so JSON always carries correct labels
        var module = (await _repo.GetModulesAsync())
            .FirstOrDefault(m => m.Code.Equals(t.ModuleCode, StringComparison.OrdinalIgnoreCase));
        var screen = module?.Screens.FirstOrDefault(s => s.Code.Equals(t.ScreenCode, StringComparison.OrdinalIgnoreCase));

        var errors = WorkflowValidator.Validate(t);
        if (!string.IsNullOrEmpty(t.ModuleCode) && module == null) errors.Add($"Module '{t.ModuleCode}' does not exist.");
        if (module != null && !string.IsNullOrEmpty(t.ScreenCode) && screen == null) errors.Add($"Screen '{t.ScreenCode}' does not belong to {module.Name}.");
        if (errors.Count > 0) return BadRequest(new { errors });

        t.ModuleName = module!.Name;
        t.ScreenName = screen!.Name;
        // workflow JSON in execution order, tidy each activity
        t.Workflow = t.Workflow.OrderBy(a => a.Order).ToList();
        foreach (var a in t.Workflow)
        {
            a.IsParallel = false;
            a.Name = a.Name.Trim();
            if (a.Approval != null)
            {
                a.Approval.Approvers = a.Approval.Approvers.Select(x => x.Trim()).Where(x => x.Length > 0).ToList();
                a.Approval.Subject = string.IsNullOrWhiteSpace(a.Approval.Subject) ? null : a.Approval.Subject;
                a.Approval.Description = string.IsNullOrWhiteSpace(a.Approval.Description) ? null : a.Approval.Description;
            }
            a.Configuration = a.Configuration
                .Where(kv => !string.IsNullOrWhiteSpace(kv.Value))      // only settings that have a value
                .ToDictionary(kv => kv.Key, kv => kv.Value);
        }
        t.ActivityCount = t.Workflow.Count;
        t.Designer = t.Designer.Where(d => d.Order >= 1 && d.Order <= t.Workflow.Count).OrderBy(d => d.Order).ToList();
        foreach (var d in t.Designer)
        {
            d.Description = string.IsNullOrWhiteSpace(d.Description) ? null : d.Description.Trim();
            foreach (var p in d.UserParameters)
            {
                p.Label = string.IsNullOrWhiteSpace(p.Label) ? null : p.Label;
                p.DefaultValue = string.IsNullOrWhiteSpace(p.DefaultValue) ? null : p.DefaultValue;
            }
        }

        try { return Ok(await _repo.SaveTemplateAsync(t, CurrentUser)); }
        catch (DuplicateException ex) { return Conflict(new { errors = new[] { ex.Message } }); }
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(string id) =>
        await _repo.DeleteTemplateAsync(id) ? NoContent() : NotFound();
}
