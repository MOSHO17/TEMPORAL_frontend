using WorkflowDesigner.Models;

namespace WorkflowDesigner.Data;

public interface IWorkflowRepository
{
    Task<List<Module>> GetModulesAsync();
    Task<Module> CreateModuleAsync(Module module);
    Task<Screen> AddScreenAsync(string moduleCode, Screen screen);

    Task<List<WorkflowSummary>> GetTemplatesAsync(string? moduleCode, string? screenCode);
    Task<WorkflowTemplate?> GetTemplateAsync(string templateId);
    Task<WorkflowTemplate> SaveTemplateAsync(WorkflowTemplate template, string user);
    Task<bool> DeleteTemplateAsync(string templateId);
}

public class DuplicateException : Exception
{
    public DuplicateException(string message) : base(message) { }
}

public class NotFoundException : Exception
{
    public NotFoundException(string message) : base(message) { }
}
