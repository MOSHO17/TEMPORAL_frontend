#if SQLSERVER
using System.Data;
using System.Text.Json;
using Microsoft.Data.SqlClient;
using WorkflowDesigner.Models;

namespace WorkflowDesigner.Data;

/// <summary>
/// ADO.NET implementation against the tables in Database/01_Schema.sql.
/// Build with: dotnet build -p:UseSqlServer=true
/// </summary>
public class SqlWorkflowRepository : IWorkflowRepository
{
    private readonly string _cs;
    private static readonly JsonSerializerOptions Json = JsonFileRepository.JsonOptions;

    public SqlWorkflowRepository(IConfiguration config)
    {
        _cs = config.GetConnectionString("WorkflowDb")
              ?? throw new InvalidOperationException("ConnectionStrings:WorkflowDb is not configured.");
    }

    private SqlConnection Open() { var c = new SqlConnection(_cs); c.Open(); return c; }

    // ---------------- Modules / Screens ----------------

    public async Task<List<Module>> GetModulesAsync()
    {
        var modules = new Dictionary<string, Module>(StringComparer.OrdinalIgnoreCase);
        await using var con = Open();
        await using (var cmd = new SqlCommand(
            "SELECT ModuleCode, ModuleName, Description, IsActive, CreatedBy, CreatedOn FROM dbo.WF_Module WHERE IsActive = 1 ORDER BY ModuleName", con))
        await using (var r = await cmd.ExecuteReaderAsync())
        {
            while (await r.ReadAsync())
                modules[r.GetString(0)] = new Module
                {
                    Code = r.GetString(0), Name = r.GetString(1),
                    Description = r.IsDBNull(2) ? null : r.GetString(2),
                    IsActive = r.GetBoolean(3), CreatedBy = r.GetString(4), CreatedOn = r.GetDateTime(5)
                };
        }
        await using (var cmd = new SqlCommand(
            "SELECT ModuleCode, ScreenCode, ScreenName FROM dbo.WF_Screen WHERE IsActive = 1 ORDER BY ScreenName", con))
        await using (var r = await cmd.ExecuteReaderAsync())
        {
            while (await r.ReadAsync())
                if (modules.TryGetValue(r.GetString(0), out var m))
                    m.Screens.Add(new Screen { Code = r.GetString(1), Name = r.GetString(2) });
        }
        return modules.Values.ToList();
    }

    public async Task<Module> CreateModuleAsync(Module module)
    {
        await using var con = Open();
        await using var cmd = new SqlCommand(@"
IF EXISTS (SELECT 1 FROM dbo.WF_Module WHERE ModuleCode = @Code OR ModuleName = @Name)
    SELECT 0
ELSE
BEGIN
    INSERT dbo.WF_Module (ModuleCode, ModuleName, Description, CreatedBy, CreatedOn)
    VALUES (@Code, @Name, @Desc, @By, @On);
    SELECT 1
END", con);
        cmd.Parameters.Add("@Code", SqlDbType.VarChar, 30).Value = module.Code;
        cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 100).Value = module.Name;
        cmd.Parameters.Add("@Desc", SqlDbType.NVarChar, 500).Value = (object?)module.Description ?? DBNull.Value;
        cmd.Parameters.Add("@By", SqlDbType.NVarChar, 100).Value = module.CreatedBy;
        cmd.Parameters.Add("@On", SqlDbType.DateTime2).Value = module.CreatedOn;
        var ok = Convert.ToInt32(await cmd.ExecuteScalarAsync());
        if (ok == 0) throw new DuplicateException($"Module '{module.Code}' / '{module.Name}' already exists.");
        return module;
    }

    public async Task<Screen> AddScreenAsync(string moduleCode, Screen screen)
    {
        await using var con = Open();
        await using var cmd = new SqlCommand(@"
IF NOT EXISTS (SELECT 1 FROM dbo.WF_Module WHERE ModuleCode = @Mod) SELECT -1
ELSE IF EXISTS (SELECT 1 FROM dbo.WF_Screen WHERE ModuleCode = @Mod AND (ScreenCode = @Code OR ScreenName = @Name)) SELECT 0
ELSE BEGIN
    INSERT dbo.WF_Screen (ModuleCode, ScreenCode, ScreenName) VALUES (@Mod, @Code, @Name);
    SELECT 1
END", con);
        cmd.Parameters.Add("@Mod", SqlDbType.VarChar, 30).Value = moduleCode;
        cmd.Parameters.Add("@Code", SqlDbType.VarChar, 50).Value = screen.Code;
        cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 150).Value = screen.Name;
        var res = Convert.ToInt32(await cmd.ExecuteScalarAsync());
        if (res == -1) throw new NotFoundException($"Module '{moduleCode}' not found.");
        if (res == 0) throw new DuplicateException($"Screen '{screen.Name}' already exists.");
        return screen;
    }

    // ---------------- Workflow templates ----------------

    public async Task<List<WorkflowSummary>> GetTemplatesAsync(string? moduleCode, string? screenCode)
    {
        var list = new List<WorkflowSummary>();
        await using var con = Open();
        await using var cmd = new SqlCommand(@"
SELECT t.TemplateId, t.TemplateName, t.ModuleCode, m.ModuleName, t.ScreenCode, s.ScreenName,
       t.Version, t.Status, t.ActivityCount, ISNULL(t.ModifiedOn, t.CreatedOn)
FROM dbo.WF_Template t
JOIN dbo.WF_Module m ON m.ModuleCode = t.ModuleCode
JOIN dbo.WF_Screen s ON s.ModuleCode = t.ModuleCode AND s.ScreenCode = t.ScreenCode
WHERE (@Mod IS NULL OR t.ModuleCode = @Mod)
  AND (@Scr IS NULL OR t.ScreenCode = @Scr)
ORDER BY ISNULL(t.ModifiedOn, t.CreatedOn) DESC", con);
        cmd.Parameters.Add("@Mod", SqlDbType.VarChar, 30).Value = string.IsNullOrEmpty(moduleCode) ? DBNull.Value : moduleCode;
        cmd.Parameters.Add("@Scr", SqlDbType.VarChar, 50).Value = string.IsNullOrEmpty(screenCode) ? DBNull.Value : screenCode;
        await using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync())
            list.Add(new WorkflowSummary
            {
                TemplateId = r.GetString(0), TemplateName = r.GetString(1),
                ModuleCode = r.GetString(2), ModuleName = r.GetString(3),
                ScreenCode = r.GetString(4), ScreenName = r.GetString(5),
                Version = r.GetInt32(6), Status = r.GetString(7),
                ActivityCount = r.GetInt32(8), ModifiedOn = r.GetDateTime(9)
            });
        return list;
    }

    public async Task<WorkflowTemplate?> GetTemplateAsync(string templateId)
    {
        await using var con = Open();
        await using var cmd = new SqlCommand(@"
SELECT t.TemplateId, t.TemplateName, t.ModuleCode, m.ModuleName, t.ScreenCode, s.ScreenName, t.Version, t.Status,
       t.ActivityCount, t.TemplateJson, t.DesignerJson, t.CreatedBy, t.CreatedOn, t.ModifiedBy, t.ModifiedOn
FROM dbo.WF_Template t
JOIN dbo.WF_Module m ON m.ModuleCode = t.ModuleCode
JOIN dbo.WF_Screen s ON s.ModuleCode = t.ModuleCode AND s.ScreenCode = t.ScreenCode
WHERE t.TemplateId = @Id", con);
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 50).Value = templateId;
        await using var r = await cmd.ExecuteReaderAsync();
        if (!await r.ReadAsync()) return null;
        return new WorkflowTemplate
        {
            TemplateId = r.GetString(0), TemplateName = r.GetString(1),
            ModuleCode = r.GetString(2), ModuleName = r.GetString(3),
            ScreenCode = r.GetString(4), ScreenName = r.GetString(5),
            Version = r.GetInt32(6), Status = r.GetString(7), ActivityCount = r.GetInt32(8),
            Workflow = JsonSerializer.Deserialize<List<WorkflowActivity>>(r.GetString(9), Json) ?? new(),
            Designer = r.IsDBNull(10) ? new() : JsonSerializer.Deserialize<List<DesignerNode>>(r.GetString(10), Json) ?? new(),
            CreatedBy = r.GetString(11), CreatedOn = r.GetDateTime(12),
            ModifiedBy = r.IsDBNull(13) ? null : r.GetString(13),
            ModifiedOn = r.IsDBNull(14) ? null : r.GetDateTime(14)
        };
    }

    public async Task<WorkflowTemplate> SaveTemplateAsync(WorkflowTemplate t, string user)
    {
        await using var con = Open();
        await using var tx = (SqlTransaction)await con.BeginTransactionAsync(IsolationLevel.Serializable);

        await using (var chk = new SqlCommand(@"
SELECT COUNT(1) FROM dbo.WF_Template
WHERE ModuleCode = @Mod AND ScreenCode = @Scr AND TemplateName = @Name AND (@Id IS NULL OR TemplateId <> @Id)", con, tx))
        {
            chk.Parameters.Add("@Mod", SqlDbType.VarChar, 30).Value = t.ModuleCode;
            chk.Parameters.Add("@Scr", SqlDbType.VarChar, 50).Value = t.ScreenCode;
            chk.Parameters.Add("@Name", SqlDbType.NVarChar, 150).Value = t.TemplateName;
            chk.Parameters.Add("@Id", SqlDbType.VarChar, 50).Value = (object?)t.TemplateId ?? DBNull.Value;
            if (Convert.ToInt32(await chk.ExecuteScalarAsync()) > 0)
                throw new DuplicateException($"A template named '{t.TemplateName}' already exists for this module and screen.");
        }

        int? existingVersion = null; string? createdBy = null; DateTime createdOn = default;
        if (!string.IsNullOrEmpty(t.TemplateId))
        {
            await using var get = new SqlCommand("SELECT Version, CreatedBy, CreatedOn FROM dbo.WF_Template WITH (UPDLOCK) WHERE TemplateId = @Id", con, tx);
            get.Parameters.Add("@Id", SqlDbType.VarChar, 50).Value = t.TemplateId;
            await using var r = await get.ExecuteReaderAsync();
            if (await r.ReadAsync()) { existingVersion = r.GetInt32(0); createdBy = r.GetString(1); createdOn = r.GetDateTime(2); }
        }

        var now = DateTime.UtcNow;
        if (existingVersion == null)
        {
            t.TemplateId = "WF-" + now.ToString("yyyyMMddHHmmss") + "-" + Guid.NewGuid().ToString("N")[..6].ToUpper();
            t.Version = 1; t.CreatedBy = user; t.CreatedOn = now; t.ModifiedBy = null; t.ModifiedOn = null;
        }
        else
        {
            t.Version = existingVersion.Value + 1; t.CreatedBy = createdBy!; t.CreatedOn = createdOn;
            t.ModifiedBy = user; t.ModifiedOn = now;
        }

        var workflowJson = JsonSerializer.Serialize(t.Workflow, Json);   // exact engine format
        var designerJson = JsonSerializer.Serialize(t.Designer, Json);
        await using (var up = new SqlCommand(@"
MERGE dbo.WF_Template AS tgt
USING (SELECT @Id AS TemplateId) AS src ON tgt.TemplateId = src.TemplateId
WHEN MATCHED THEN UPDATE SET TemplateName = @Name, ModuleCode = @Mod, ScreenCode = @Scr, Version = @Ver,
     Status = @Status, ActivityCount = @Cnt, TemplateJson = @Json, DesignerJson = @DJson, ModifiedBy = @By, ModifiedOn = @On
WHEN NOT MATCHED THEN INSERT (TemplateId, TemplateName, ModuleCode, ScreenCode, Version, Status, ActivityCount, TemplateJson, DesignerJson, CreatedBy, CreatedOn)
     VALUES (@Id, @Name, @Mod, @Scr, @Ver, @Status, @Cnt, @Json, @DJson, @By, @On);
INSERT dbo.WF_TemplateHistory (TemplateId, Version, TemplateJson, SavedBy) VALUES (@Id, @Ver, @Json, @By);", con, tx))
        {
            up.Parameters.Add("@Id", SqlDbType.VarChar, 50).Value = t.TemplateId;
            up.Parameters.Add("@Name", SqlDbType.NVarChar, 150).Value = t.TemplateName;
            up.Parameters.Add("@Mod", SqlDbType.VarChar, 30).Value = t.ModuleCode;
            up.Parameters.Add("@Scr", SqlDbType.VarChar, 50).Value = t.ScreenCode;
            up.Parameters.Add("@Ver", SqlDbType.Int).Value = t.Version;
            up.Parameters.Add("@Status", SqlDbType.VarChar, 20).Value = t.Status;
            up.Parameters.Add("@Cnt", SqlDbType.Int).Value = t.Workflow.Count;
            up.Parameters.Add("@Json", SqlDbType.NVarChar, -1).Value = workflowJson;
            up.Parameters.Add("@DJson", SqlDbType.NVarChar, -1).Value = designerJson;
            up.Parameters.Add("@By", SqlDbType.NVarChar, 100).Value = user;
            up.Parameters.Add("@On", SqlDbType.DateTime2).Value = now;
            await up.ExecuteNonQueryAsync();
        }

        await tx.CommitAsync();
        return t;
    }

    public async Task<bool> DeleteTemplateAsync(string templateId)
    {
        await using var con = Open();
        await using var cmd = new SqlCommand("DELETE FROM dbo.WF_Template WHERE TemplateId = @Id", con);
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 50).Value = templateId;
        return await cmd.ExecuteNonQueryAsync() > 0;
    }
}
#endif
