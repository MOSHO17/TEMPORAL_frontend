using System.Text.Json;
using WorkflowDesigner.Models;

namespace WorkflowDesigner.Data;

/// <summary>
/// File based storage. Every workflow template is written as its own .json file
/// under App_Data/workflows, and modules/screens live in App_Data/modules.json.
/// </summary>
public class JsonFileRepository : IWorkflowRepository
{
    private readonly string _root;
    private readonly string _modulesFile;
    private readonly string _workflowDir;
    private readonly SemaphoreSlim _lock = new(1, 1);

    public static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true,
        WriteIndented = true,
        DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull,
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping   // keep {{ }}, ₹, quotes readable
    };

    public JsonFileRepository(IWebHostEnvironment env, IConfiguration config)
    {
        _root = Path.Combine(env.ContentRootPath, config["Storage:JsonFolder"] ?? "App_Data");
        _modulesFile = Path.Combine(_root, "modules.json");
        _workflowDir = Path.Combine(_root, "workflows");
        Directory.CreateDirectory(_workflowDir);
        if (!File.Exists(_modulesFile)) WriteJson(_modulesFile, SeedModules());
    }

    // ---------------- Modules / Screens ----------------

    public async Task<List<Module>> GetModulesAsync()
    {
        await _lock.WaitAsync();
        try { return ReadModules().OrderBy(m => m.Name).ToList(); }
        finally { _lock.Release(); }
    }

    public async Task<Module> CreateModuleAsync(Module module)
    {
        await _lock.WaitAsync();
        try
        {
            var modules = ReadModules();
            if (modules.Any(m => m.Code.Equals(module.Code, StringComparison.OrdinalIgnoreCase)))
                throw new DuplicateException($"Module code '{module.Code}' already exists.");
            if (modules.Any(m => m.Name.Equals(module.Name, StringComparison.OrdinalIgnoreCase)))
                throw new DuplicateException($"Module name '{module.Name}' already exists.");
            modules.Add(module);
            WriteJson(_modulesFile, modules);
            return module;
        }
        finally { _lock.Release(); }
    }

    public async Task<Screen> AddScreenAsync(string moduleCode, Screen screen)
    {
        await _lock.WaitAsync();
        try
        {
            var modules = ReadModules();
            var module = modules.FirstOrDefault(m => m.Code.Equals(moduleCode, StringComparison.OrdinalIgnoreCase))
                         ?? throw new NotFoundException($"Module '{moduleCode}' not found.");
            if (module.Screens.Any(s => s.Code.Equals(screen.Code, StringComparison.OrdinalIgnoreCase)
                                     || s.Name.Equals(screen.Name, StringComparison.OrdinalIgnoreCase)))
                throw new DuplicateException($"Screen '{screen.Name}' already exists in {module.Name}.");
            module.Screens.Add(screen);
            WriteJson(_modulesFile, modules);
            return screen;
        }
        finally { _lock.Release(); }
    }

    // ---------------- Workflow templates ----------------

    // Each template is stored as two files:
    //   <TemplateId>.json       -> the workflow JSON only (array of activities, exact engine format)
    //   <TemplateId>.meta.json  -> module, screen, name, version, designer data

    public async Task<List<WorkflowSummary>> GetTemplatesAsync(string? moduleCode, string? screenCode)
    {
        await _lock.WaitAsync();
        try
        {
            return AllMeta()
                .Where(t => string.IsNullOrEmpty(moduleCode) || t.ModuleCode.Equals(moduleCode, StringComparison.OrdinalIgnoreCase))
                .Where(t => string.IsNullOrEmpty(screenCode) || t.ScreenCode.Equals(screenCode, StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(t => t.ModifiedOn ?? t.CreatedOn)
                .Select(t => new WorkflowSummary
                {
                    TemplateId = t.TemplateId!,
                    TemplateName = t.TemplateName,
                    ModuleCode = t.ModuleCode,
                    ModuleName = t.ModuleName,
                    ScreenCode = t.ScreenCode,
                    ScreenName = t.ScreenName,
                    Version = t.Version,
                    Status = t.Status,
                    ActivityCount = t.ActivityCount,
                    ModifiedOn = t.ModifiedOn ?? t.CreatedOn
                }).ToList();
        }
        finally { _lock.Release(); }
    }

    public async Task<WorkflowTemplate?> GetTemplateAsync(string templateId)
    {
        await _lock.WaitAsync();
        try { return ReadTemplate(templateId); }
        finally { _lock.Release(); }
    }

    public async Task<WorkflowTemplate> SaveTemplateAsync(WorkflowTemplate t, string user)
    {
        await _lock.WaitAsync();
        try
        {
            var now = DateTime.UtcNow;

            // Same name cannot be reused for another template on the same module + screen
            var clash = AllMeta().FirstOrDefault(x =>
                    x.TemplateId != t.TemplateId
                    && x.ModuleCode.Equals(t.ModuleCode, StringComparison.OrdinalIgnoreCase)
                    && x.ScreenCode.Equals(t.ScreenCode, StringComparison.OrdinalIgnoreCase)
                    && x.TemplateName.Equals(t.TemplateName, StringComparison.OrdinalIgnoreCase));
            if (clash != null)
                throw new DuplicateException($"A template named '{t.TemplateName}' already exists for this module and screen.");

            TemplateMeta? existing = null;
            if (!string.IsNullOrEmpty(t.TemplateId) && File.Exists(MetaPath(t.TemplateId)))
                existing = ReadJson<TemplateMeta>(MetaPath(t.TemplateId));

            if (existing == null)
            {
                t.TemplateId = "WF-" + now.ToString("yyyyMMddHHmmss") + "-" + Guid.NewGuid().ToString("N")[..6].ToUpper();
                t.Version = 1;
                t.CreatedBy = user;
                t.CreatedOn = now;
                t.ModifiedBy = null;
                t.ModifiedOn = null;
            }
            else
            {
                t.Version = existing.Version + 1;
                t.CreatedBy = existing.CreatedBy;
                t.CreatedOn = existing.CreatedOn;
                t.ModifiedBy = user;
                t.ModifiedOn = now;
            }

            WriteJson<List<WorkflowActivity>>(WorkflowPath(t.TemplateId!), t.Workflow);
            WriteJson<TemplateMeta>(MetaPath(t.TemplateId!), t);    // base type only -> no workflow inside
            return t;
        }
        finally { _lock.Release(); }
    }

    public async Task<bool> DeleteTemplateAsync(string templateId)
    {
        await _lock.WaitAsync();
        try
        {
            if (!File.Exists(MetaPath(templateId))) return false;
            File.Delete(MetaPath(templateId));
            if (File.Exists(WorkflowPath(templateId))) File.Delete(WorkflowPath(templateId));
            return true;
        }
        finally { _lock.Release(); }
    }

    // ---------------- helpers ----------------

    private IEnumerable<TemplateMeta> AllMeta() =>
        Directory.GetFiles(_workflowDir, "*.meta.json")
            .Select(f => ReadJson<TemplateMeta>(f))
            .Where(m => m != null && !string.IsNullOrEmpty(m.TemplateId))
            .Select(m => m!);

    private WorkflowTemplate? ReadTemplate(string id)
    {
        if (!File.Exists(MetaPath(id))) return null;
        var json = File.ReadAllText(MetaPath(id));
        var t = JsonSerializer.Deserialize<WorkflowTemplate>(json, JsonOptions)!;
        t.Workflow = File.Exists(WorkflowPath(id))
            ? ReadJson<List<WorkflowActivity>>(WorkflowPath(id)) ?? new()
            : new();
        return t;
    }

    private static string SafeId(string id) => string.Concat(id.Where(c => char.IsLetterOrDigit(c) || c == '-' || c == '_'));
    private string WorkflowPath(string id) => Path.Combine(_workflowDir, SafeId(id) + ".json");
    private string MetaPath(string id) => Path.Combine(_workflowDir, SafeId(id) + ".meta.json");

    private List<Module> ReadModules() => ReadJson<List<Module>>(_modulesFile) ?? new();

    private static T? ReadJson<T>(string path) =>
        JsonSerializer.Deserialize<T>(File.ReadAllText(path), JsonOptions);

    private static void WriteJson<T>(string path, T data)
    {
        var tmp = path + ".tmp";
        File.WriteAllText(tmp, JsonSerializer.Serialize(data, JsonOptions));
        File.Move(tmp, path, overwrite: true);
    }

    private static List<Module> SeedModules() => new()
    {
        new() { Code = "RAMS", Name = "RAMS", Description = "Sample module", CreatedBy = "system",
                Screens = new() { new() { Code = "RAMS_ENTRY", Name = "Application Entry" },
                                  new() { Code = "RAMS_REVIEW", Name = "Application Review" } } },
        new() { Code = "SUBSIDY", Name = "Subsidy", Description = "Sample module", CreatedBy = "system",
                Screens = new() { new() { Code = "SUB_CLAIM", Name = "Subsidy Claim Entry" },
                                  new() { Code = "SUB_VERIFY", Name = "Claim Verification" } } }
    };
}
