# Workflow Designer (.NET 8 + vanilla JS + jQuery)

Admin screen for designing workflow templates by drag and drop. Each template is saved as JSON.

## Run

    dotnet run
    -> open http://localhost:5000 (or the URL printed in the console)

Needs the .NET 8 SDK. jQuery 3.7.1 and jQuery UI 1.13.3 are included under wwwroot/lib,
so the app does not load anything from a CDN (works on an intranet).

## What Admin 1 can do

1. Module    - pick a module (RAMS, Subsidy, ...) or click "+" to create a new one.
2. Screen    - pick a screen of that module, or click "+" to add one.
3. Template  - enter the template name and status (Draft / Active / Inactive).
4. Drag activities from the left palette onto the canvas:
   Maker, Checker, Approval Gate, Approver, Call HTTP, Send Email, Wait/Delay.
   - Workflows are SEQUENTIAL ONLY: each activity has at most one next and one previous step.
     Loops (circular connections) and branches are blocked in the designer and rejected by the API.
   - Drag from the bottom dot of one activity to the next activity to connect them.
   - Click a connection to delete it (to change the order, delete and reconnect).
   - Deleting an activity in the middle joins its previous and next activities automatically.
   - With "Auto-append" ticked, a new activity is added to the end of the flow automatically.
   - The Start activity is always the first activity in the sequence.
5. Select an activity and use the Properties panel:
   - General    : name, description, position in the sequence, and the activity's
                  configuration (HTTP method/URL, mail to/subject/body, approval gate settings ...)
   - Parameters : User Parameters (entered by the user at runtime: name, label, data type,
                  required, default) and System Parameters (resolved by the system: source
                  Static / Context / AppConfig / ActivityOutput, value or {{expression}})
   - Retry      : number of retries (0-10), interval, Fixed/Exponential backoff,
                  action after the last failure
6. Save Template (or Ctrl+S). The template is validated in the browser and again on the
   server, then saved as JSON. Every save of an existing template increments its version.
   Open lists saved templates; View JSON shows / copies / downloads the JSON.

## Workflow JSON format

The workflow JSON is only the list of activities, in execution order — nothing else:

    [
      {
        "Order": 5,
        "Activity": "SendEmail",
        "Name": "MailAfterApprover",
        "Configuration": {
          "to": "{{vaultCustodianEmail}}",
          "subject": "Request {{requestNo}} approved by approver",
          "body": "Request {{requestNo}} is approved and pending with vault custodian."
        },
        "IsParallel": false
      },
      {
        "Order": 6,
        "Activity": "ApprovalGate",
        "Name": "VaultApprovalGate",
        "Approval": {
          "StageId": "vault-stage-{{usecid}}",
          "Mode": "ANY_ONE",
          "Approvers": [ "{{vaultCustodianId}}" ],
          "TimeoutSeconds": 86400,
          "MinApprovals": 1,
          "OnReject": "FAIL_WORKFLOW",
          "OnTimeout": "FAIL_WORKFLOW",
          "Subject": "Vault action required for {{requestNo}}",
          "Description": "Vault custodian approval required for request {{requestNo}}"
        },
        "Configuration": {},
        "IsParallel": false
      }
    ]

- Activity values: Maker, Checker, ApprovalGate, Approver, CallHttp, SendEmail, Delay
- Configuration holds only the settings that have a value
- Retries, when set (> 0), are written in Configuration as "retryCount" and "retryIntervalSeconds"
- IsParallel is always false (sequential order only)
- View JSON / Download show exactly this JSON. Full example: Samples/Vault_Request_Approval.json
- Module, screen, template name, version, canvas positions and user/system parameters are
  NOT in the workflow JSON; they are stored separately (see Storage)

## Storage

Default: JSON files, no database needed.
    App_Data/modules.json               modules and screens
    App_Data/workflows/<TemplateId>.json       workflow JSON only (the format above)
    App_Data/workflows/<TemplateId>.meta.json  module, screen, name, version, designer data

SQL Server (optional):
    1. Run Database/01_Schema.sql
    2. appsettings.json -> "Storage": { "Provider": "SqlServer" } and set ConnectionStrings:WorkflowDb
    3. dotnet run -p:UseSqlServer=true
       (adds Microsoft.Data.SqlClient; workflow JSON goes to WF_Template.TemplateJson,
        designer data to WF_Template.DesignerJson,
        every version is also kept in WF_TemplateHistory)

## API

    GET    /api/modules                          modules with screens
    POST   /api/modules                          { code, name, description }
    POST   /api/modules/{code}/screens           { code, name }
    GET    /api/activities                       palette / activity definitions
    GET    /api/workflows?module=&screen=        template list
    GET    /api/workflows/{id}                   template JSON
    GET    /api/workflows/{id}/download          template as .json file
    POST   /api/workflows/validate               validate without saving
    POST   /api/workflows                        create (no templateId) or save new version
    DELETE /api/workflows/{id}

## Adding a new activity type

Add an entry in Services/ActivityCatalog.cs. The palette and the Configuration fields (General tab) are built from
ConfigFields automatically - no JavaScript change needed.

## Not included yet

- Login / roles: the user is hard-coded as "Admin1" (see BaseApiController.CurrentUser).
  Plug in Windows/AD or your SSO and read User.Identity.Name there.
- Runtime engine that executes the saved templates.

## Project layout

    Program.cs                       startup, storage provider selection
    Controllers/ApiControllers.cs    Modules, Activities, Workflows APIs
    Models/WorkflowModels.cs         template JSON shape
    Services/ActivityCatalog.cs      palette definitions
    Services/WorkflowValidator.cs    server-side validation
    Data/JsonFileRepository.cs       JSON file storage (default)
    Data/SqlWorkflowRepository.cs    SQL Server storage (ADO.NET)
    Database/01_Schema.sql           tables + seed data
    Samples/                         example saved template (Vault_Request_Approval.json)
    wwwroot/                         index.html, css/designer.css, js/designer.js, lib/
