/* ============================================================================
   Workflow Designer - SQL Server schema (SQL Server 2016+; tested syntax on 2019)
   Only needed when Storage:Provider = "SqlServer".
   ============================================================================ */

IF OBJECT_ID('dbo.WF_TemplateHistory', 'U') IS NOT NULL DROP TABLE dbo.WF_TemplateHistory;
IF OBJECT_ID('dbo.WF_Template', 'U')        IS NOT NULL DROP TABLE dbo.WF_Template;
IF OBJECT_ID('dbo.WF_Screen', 'U')          IS NOT NULL DROP TABLE dbo.WF_Screen;
IF OBJECT_ID('dbo.WF_Module', 'U')          IS NOT NULL DROP TABLE dbo.WF_Module;
GO

CREATE TABLE dbo.WF_Module
(
    ModuleCode   VARCHAR(30)    NOT NULL CONSTRAINT PK_WF_Module PRIMARY KEY,
    ModuleName   NVARCHAR(100)  NOT NULL CONSTRAINT UQ_WF_Module_Name UNIQUE,
    Description  NVARCHAR(500)  NULL,
    IsActive     BIT            NOT NULL CONSTRAINT DF_WF_Module_IsActive DEFAULT (1),
    CreatedBy    NVARCHAR(100)  NOT NULL,
    CreatedOn    DATETIME2(0)   NOT NULL CONSTRAINT DF_WF_Module_CreatedOn DEFAULT (SYSUTCDATETIME())
);
GO

CREATE TABLE dbo.WF_Screen
(
    ModuleCode   VARCHAR(30)    NOT NULL CONSTRAINT FK_WF_Screen_Module REFERENCES dbo.WF_Module(ModuleCode),
    ScreenCode   VARCHAR(50)    NOT NULL,
    ScreenName   NVARCHAR(150)  NOT NULL,
    IsActive     BIT            NOT NULL CONSTRAINT DF_WF_Screen_IsActive DEFAULT (1),
    CreatedOn    DATETIME2(0)   NOT NULL CONSTRAINT DF_WF_Screen_CreatedOn DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT PK_WF_Screen PRIMARY KEY (ModuleCode, ScreenCode),
    CONSTRAINT UQ_WF_Screen_Name UNIQUE (ModuleCode, ScreenName)
);
GO

CREATE TABLE dbo.WF_Template
(
    TemplateId    VARCHAR(50)    NOT NULL CONSTRAINT PK_WF_Template PRIMARY KEY,
    TemplateName  NVARCHAR(150)  NOT NULL,
    ModuleCode    VARCHAR(30)    NOT NULL,
    ScreenCode    VARCHAR(50)    NOT NULL,
    Version       INT            NOT NULL,
    Status        VARCHAR(20)    NOT NULL,
    ActivityCount INT            NOT NULL,
    TemplateJson  NVARCHAR(MAX)  NOT NULL CONSTRAINT CK_WF_Template_Json CHECK (ISJSON(TemplateJson) = 1),   -- workflow JSON only (array of activities)
    DesignerJson  NVARCHAR(MAX)  NULL     CONSTRAINT CK_WF_Template_DJson CHECK (DesignerJson IS NULL OR ISJSON(DesignerJson) = 1), -- canvas positions, parameters
    CreatedBy     NVARCHAR(100)  NOT NULL,
    CreatedOn     DATETIME2(0)   NOT NULL,
    ModifiedBy    NVARCHAR(100)  NULL,
    ModifiedOn    DATETIME2(0)   NULL,
    CONSTRAINT FK_WF_Template_Screen FOREIGN KEY (ModuleCode, ScreenCode) REFERENCES dbo.WF_Screen(ModuleCode, ScreenCode),
    CONSTRAINT UQ_WF_Template_Name UNIQUE (ModuleCode, ScreenCode, TemplateName)
);
GO

/* Every saved version is kept here for audit / rollback */
CREATE TABLE dbo.WF_TemplateHistory
(
    HistoryId     BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WF_TemplateHistory PRIMARY KEY,
    TemplateId    VARCHAR(50)    NOT NULL,
    Version       INT            NOT NULL,
    TemplateJson  NVARCHAR(MAX)  NOT NULL,
    SavedBy       NVARCHAR(100)  NOT NULL,
    SavedOn       DATETIME2(0)   NOT NULL CONSTRAINT DF_WF_TemplateHistory_SavedOn DEFAULT (SYSUTCDATETIME())
);
CREATE INDEX IX_WF_TemplateHistory_Template ON dbo.WF_TemplateHistory (TemplateId, Version);
GO

/* ---------------- Sample seed data ---------------- */
INSERT dbo.WF_Module (ModuleCode, ModuleName, Description, CreatedBy) VALUES
 ('RAMS',    N'RAMS',    N'Sample module', N'system'),
 ('SUBSIDY', N'Subsidy', N'Sample module', N'system');

INSERT dbo.WF_Screen (ModuleCode, ScreenCode, ScreenName) VALUES
 ('RAMS',    'RAMS_ENTRY',  N'Application Entry'),
 ('RAMS',    'RAMS_REVIEW', N'Application Review'),
 ('SUBSIDY', 'SUB_CLAIM',   N'Subsidy Claim Entry'),
 ('SUBSIDY', 'SUB_VERIFY',  N'Claim Verification');
GO

/* ---------------- Handy queries on the saved JSON ----------------
-- All activities of a template in order
SELECT t.TemplateName, a.[Order], a.Activity, a.[Name]
FROM dbo.WF_Template t
CROSS APPLY OPENJSON(t.TemplateJson)
     WITH ([Order]  INT           '$.Order',
           Activity VARCHAR(30)   '$.Activity',
           [Name]   NVARCHAR(150) '$.Name') a
WHERE t.ModuleCode = 'RAMS';
------------------------------------------------------------------ */
