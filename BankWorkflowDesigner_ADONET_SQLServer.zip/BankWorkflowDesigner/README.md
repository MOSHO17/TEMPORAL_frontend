# Bank Workflow Designer

Centralised portal and REST API through which banking source systems **create, configure, validate, version and
publish workflow templates**. Published templates become immutable, hash-sealed JSON definitions that a separate
**Temporal execution service** consumes.

- ASP.NET Core 8 MVC + Razor views + Bootstrap 5 + vanilla JavaScript (no React / Angular / Blazor / TypeScript)
- ASP.NET Core 8 Web API, **ADO.NET only** (`Microsoft.Data.SqlClient`, stored procedures, table-valued parameters) - no Entity Framework
- SQL Server 2016 SP1+ (uses `CREATE OR ALTER`, `ISJSON`, `FOR JSON`, filtered unique indexes)

**Out of scope by design:** Temporal workers / workflow execution, the approval inbox, Quartz.NET job execution,
SFTP and external API execution. The portal only produces validated definitions and scheduler metadata.

---

## 1. Solution layout

```
BankWorkflowDesigner.sln
├── src/
│   ├── BankWorkflowDesigner.Domain          Entities, enums, request/response DTOs, activity catalog, definition contract
│   ├── BankWorkflowDesigner.Application     Services, validation engine, definition builder, security guard, interfaces
│   ├── BankWorkflowDesigner.Infrastructure  ADO.NET repositories (SqlConnection/SqlCommand/SqlDataReader/SqlTransaction)
│   ├── BankWorkflowDesigner.Api             REST API, authentication/authorisation, anti-forgery, error handling, Swagger
│   └── BankWorkflowDesigner.Web             MVC front end: Razor views + wwwroot/js + wwwroot/css (+ local Bootstrap)
├── database/
│   └── BankWorkflowDesigner.Database        SQL scripts (tables, types, triggers, procedures, seed) + ADO.NET deploy tool
├── tests/
│   ├── BankWorkflowDesigner.UnitTests       Validator, builder, services, samples (xUnit)
│   └── BankWorkflowDesigner.ApiTests        Full HTTP pipeline integration tests (xUnit)
├── samples/
│   ├── workflow-templates/                  14 importable templates covering every activity type
│   └── published-definitions/               Definitions produced by the API for two samples (contract reference)
├── postman/                                 Postman collection + environment (46 requests, self-chaining)
└── docs/DEFINITION-CONTRACT.md              JSON contract for the Temporal execution service
```

Dependency direction: `Web` → (HTTP) → `Api` → `Application` → `Domain`; `Infrastructure` implements the
`Application` repository interfaces. Every interface is registered with dependency injection
(`AddApplicationServices`, `AddSqlServerInfrastructure`).

```
 Browser (Razor shell + vanilla JS)
      │ fetch + credentials + X-XSRF-TOKEN
      ▼
 BankWorkflowDesigner.Api ── AuthN (Windows/AD | JWT/IAM | Dev) → role policies → source-system guard
      │  services: validation · four-eyes · secret/SQL scanning · definition builder (SHA-256)
      ▼
 ADO.NET repositories ── stored procedures only (parameterised, TVPs) ── SQL Server (triggers enforce immutability, audit)
      ▲
 Temporal execution service ── GET /api/definitions/{templateCode}[?version=N]   (role WF_DEFINITION_CONSUMER)
 Quartz.NET scheduler service ── reads wf.SchedulerConfiguration                  (out of scope)
```

---

## 2. Prerequisites

- .NET 8 SDK (8.0.100 or later) and Visual Studio 2022 17.8+ / VS Code / Rider
- SQL Server 2016 SP1 or later (Developer / Express is fine for local work) and `sqlcmd` or SSMS
- For production: IIS 10 with the ASP.NET Core 8 Hosting Bundle, Windows Authentication feature installed

---

## 3. Quick start (local development)

### 3.1 Create the database

Option A - the included ADO.NET deployment tool (runs scripts `01`-`11` in order, splitting on `GO`):

```bash
dotnet run --project database/BankWorkflowDesigner.Database -- "Server=localhost;Database=BankWorkflowDesigner;Integrated Security=true;TrustServerCertificate=true" --create-database
```

(`--create-database` runs `01_CreateDatabase.sql` against `master`; omit it if a DBA created the database. Add `--skip-seed` to skip sample reference data.)

Option B - `sqlcmd` / SSMS in SQLCMD mode:

```bash
sqlcmd -S localhost -E -i database/BankWorkflowDesigner.Database/Scripts/01_CreateDatabase.sql
cd database/BankWorkflowDesigner.Database/Scripts
sqlcmd -S localhost -E -i 00_DeployAll.sql
```

Scripts are idempotent (tables/types created only when missing, procedures via `CREATE OR ALTER`), so re-running them upgrades procedures in place.

| Script | Content |
|---|---|
| `01_CreateDatabase.sql` | Database + READ_COMMITTED_SNAPSHOT |
| `02_Tables.sql` | 16 tables in schema `wf`, constraints, indexes (one open draft / one published version per template) |
| `03_TableTypes.sql` | Table-valued parameter types |
| `04_Triggers.sql` | Immutability of published versions (all child tables) and append-only audit log |
| `05`-`09` | 37 stored procedures (every write also writes the audit row in the same transaction) |
| `10_SecurityRoles.sql` | `wf_app_executor` role: EXECUTE on schema `wf` only, no direct table DML |
| `11_SeedData.sql` | Sample source systems, modules, authorised users, connection profiles, approved Oracle queries |

### 3.2 Configure and run the API

`src/BankWorkflowDesigner.Api/appsettings.Development.json` already contains a local connection string and
**Development authentication**. Change the connection string there or, better, with user secrets:

```bash
cd src/BankWorkflowDesigner.Api
dotnet user-secrets set "ConnectionStrings:WorkflowDesignerDb" "Server=localhost;Database=BankWorkflowDesigner;Integrated Security=true;TrustServerCertificate=true"
dotnet run --launch-profile BankWorkflowDesigner.Api        # https://localhost:7101/swagger
```

### 3.3 Run the web front end

```bash
cd src/BankWorkflowDesigner.Web
dotnet run --launch-profile BankWorkflowDesigner.Web        # https://localhost:7102
```

Or set both projects as startup projects in Visual Studio (Solution → Configure Startup Projects → Multiple).
Trust the development certificate once with `dotnet dev-certs https --trust`.

### 3.4 Try it

1. Use the user selector in the navigation bar (Development mode only): `alice.designer` (designer), `rita.reviewer`,
   `bob.publisher`, `dev.admin` (source-system admin), `temporal.svc` (definition consumer).
2. **Workflow Templates → Import JSON** → pick any file from `samples/workflow-templates/`.
3. Explore the designer, activity configuration, parameters & mapping, approvals; **Validate**.
4. Switch to `bob.publisher` → **Publish** (the four-eyes rule prevents the draft's author from publishing).
5. **Versions** shows history, audit trail and the published JSON; `GET /api/definitions/{templateCode}` serves it.
6. **Schedulers → New schedule** targets a published workflow with a governed Oracle query.

---

## 4. Configuration

See `src/BankWorkflowDesigner.Api/appsettings.json.example` and `src/BankWorkflowDesigner.Web/appsettings.json.example`
(both documented inline). Key settings:

| Setting | Purpose |
|---|---|
| `ConnectionStrings:WorkflowDesignerDb` | SQL Server connection. Prefer integrated security with the app-pool identity; never commit passwords. |
| `Authentication:Mode` | `Windows` (AD via IIS), `Jwt` (enterprise IAM / OIDC), `Development` (local only - refused outside the Development environment). |
| `Authentication:RoleMappings` | Application role → AD groups / IAM role claims. |
| `Authentication:Jwt:*` | Authority, audience, role/name claim types for bearer tokens. |
| `WorkflowSecurity:EnforcePublishSegregation` | Four-eyes: the creator / last modifier of a draft cannot publish it (default `true`). |
| `WorkflowSecurity:AdminsBypassSourceSystemAuthorization` | Source-system admins see all systems (default `true`). |
| `Antiforgery:Enabled` | CSRF protection for browser calls (keep `true`). |
| `Cors:AllowedOrigins` | Web origin(s) when Web and API are on different origins. |
| `Swagger:Enabled` | Swagger UI at `/swagger` (enabled in Development). |
| `FrontEnd:ApiBaseUrl` (Web) | API URL used by the browser and whitelisted in the CSP. |
| `FrontEnd:AuthenticationMode` (Web) | `Windows` or `Development`. |

Both applications **fail fast at start-up** if `Windows` mode is configured but the app is not hosted in IIS with
Windows Authentication (instead of failing on every request).

---

## 5. Security model

**Roles** (from AD groups or IAM claims via `RoleMappings`):

| Role | Can |
|---|---|
| `WF_SOURCE_ADMIN` | Register / update source systems, modules and authorised users; global audit |
| `WF_DESIGNER` | Create, import, edit, clone, version workflows; activities, connections, parameters, approvals; schedulers |
| `WF_REVIEWER` | Read and validate |
| `WF_PUBLISHER` | Publish, deactivate / re-activate |
| `WF_DEFINITION_CONSUMER` | Read published definitions (Temporal service account) |

**Source-system authorisation** is a second layer: besides the global role, the user must be listed as an active
authorised user of the workflow's source system with a suitable access role (`Administrator`, `Designer`,
`Reviewer`, `Publisher`, `Viewer`). Lists, dashboards and schedulers are filtered to authorised systems.

**Controls implemented**

- **SQL injection** - all data access through stored procedures with typed `SqlParameter`s and table-valued parameters; no dynamic SQL anywhere (C# or T-SQL). The API's database login only needs the `wf_app_executor` role.
- **XSS** - the front end never uses `innerHTML` with data; all text goes through `textContent` (`WF.dom.el`). A strict CSP (`script-src 'self'; style-src 'self'`, no inline script/style) is sent by the Web app; the API sends `default-src 'none'`.
- **CSRF** - every POST/PUT/DELETE must carry `X-XSRF-TOKEN` (from `GET /api/security/antiforgery-token`, cookie `SameSite=Strict`); bearer-token service calls are exempt. MVC forms use `AutoValidateAntiforgeryToken`.
- **No secrets in workflow JSON** - configuration keys are whitelisted per activity type; values, defaults, literals and scheduler parameters are scanned for passwords, keys, tokens, JWTs, credentials in URLs and secret-named parameters (save time **and** validation/publish time). Credentials are referenced through `wf.ConnectionProfile` (vault references such as `cyberark://…`), which are not even returned to the browser.
- **No unrestricted Oracle SQL** - the Scheduled Oracle Query activity and scheduler configurations can only reference governance-approved query codes (`wf.ApprovedOracleQuery`); SQL text is never stored or accepted, and SQL-like values are rejected anywhere in configuration.
- **Immutability** - published/superseded versions cannot be changed: enforced in services, in every stored procedure (`usp_Internal_AssertVersionEditable`) and by triggers on every child table.
- **Concurrency** - SQL Server `rowversion` on templates, versions, activities, parameters, source systems and schedulers; stale updates return **409 `CONCURRENCY_CONFLICT`**. Publishing checks the draft's row version so a draft edited after validation cannot be published unseen.
- **Four-eyes publishing** and **maker-checker segregation** flags in approval configuration.
- **Audit trail** - every change writes `wf.AuditLog` (user, UTC time, correlation id, client IP, JSON details) inside the same transaction; the table is append-only (trigger).
- Consistent error payloads (no stack traces outside Development), security headers, HSTS, CORS allow-list, correlation ids (`X-Correlation-Id`).

---

## 6. Functional overview

**Lifecycle:** `Draft` → (validate) `Validated` → (publish) `Published` → (next publish) `Superseded`.
Any edit returns a `Validated` draft to `Draft`. Only one open draft per template. A template can be deactivated
(no edits, no new instances; explicit versions remain readable for running instances).

**Visual designer** (`/Workflows/Designer/{id}`, `wwwroot/js/workflow-designer.js`, no third-party library):
drag activities from the toolbox, drag from a node's right-hand port to another node to connect (Sequence,
Conditional, Parallel, Rejection, Error), drag nodes to rearrange (auto-saved), select + Delete to remove,
properties panel for quick edits, auto-layout, zoom, validation highlighting, definition preview. Published
versions open read-only.

**Activity library** (`Domain/Catalog/ActivityCatalog.cs` drives the toolbox, forms, defaults and validation):
Maker, Checker, Approver, Multilevel Approver, Sequential Approver, Parallel Approver, SFTP File Push, SFTP File Pull,
API Data Push, API Data Pull, File Generation, File Reading, Scheduled Oracle Query - plus Start, End/Terminate,
Decision, Parallel Split and Parallel Join. Every activity supports input/output parameters, data mappings, timeout,
retry policy, error handling (fail / continue / route / terminate) and an optional execution condition.

**Validation** (`Application/Validation/WorkflowValidator.cs`, 100+ distinct rule codes) - structure (single start, ends, reachability,
path to end, dead ends, loops only via rejection routes, decision/parallel rules), approvals (levels, roles, modes,
quorum, escalation, rejection routing), configuration (required, patterns, options, profile types, approved queries,
bind variables), parameters (types, JSON schema, mandatory mappings, upstream-only activity outputs, type
compatibility), expressions (restricted grammar, references), secrets and free SQL.

---

## 7. REST API

Swagger/OpenAPI: `https://localhost:7101/swagger`. Postman: import `postman/BankWorkflowDesigner.postman_collection.json`
(+ environment) and run the folders in order - IDs, row versions and anti-forgery tokens are chained automatically.

| Method | Route | Policy |
|---|---|---|
| POST / GET | `/api/source-systems` | admin / any |
| GET / PUT | `/api/source-systems/{id}` | any / admin |
| POST / GET | `/api/workflows` | designer / any |
| POST | `/api/workflows/import` | designer |
| GET / PUT | `/api/workflows/{id}` (`?version=N`) | any / designer |
| POST | `/api/workflows/{id}/clone` | designer |
| POST / GET | `/api/workflows/{id}/versions` | designer / any |
| POST | `/api/workflows/{id}/validate` | reviewer, designer, publisher |
| POST | `/api/workflows/{id}/publish` | publisher |
| POST | `/api/workflows/{id}/status` | publisher |
| GET | `/api/workflows/{id}/definition` (`?version=N`), `/definition/preview`, `/audit` | consumer / any |
| POST | `/api/workflows/{id}/activities` | designer |
| PUT / DELETE | `/api/workflows/{id}/activities/{activityId}` | designer |
| PUT | `/api/workflows/{id}/activities/{activityId}/approval` | designer |
| PUT | `/api/workflows/{id}/layout` | designer |
| POST / PUT / DELETE | `/api/workflows/{id}/connections[/{connectionId}]` | designer |
| POST / PUT / DELETE | `/api/workflows/{id}/parameters[/{parameterId}]` | designer |
| GET | `/api/definitions/{templateCode}` (`?version=N`) | consumer |
| GET / POST / PUT | `/api/schedulers[/{id}]`, POST `/api/schedulers/validate-cron` | any / designer |
| GET | `/api/catalog/activities`, `/api/reference/connection-profiles`, `/api/reference/approved-queries` | any |
| GET | `/api/dashboard`, `/api/me`, `/api/security/antiforgery-token`, `/api/audit` | any / admin |
| GET | `/health/live`, `/health/ready` (SQL connectivity) | anonymous |

Errors always use one shape (`application/problem+json`):

```json
{ "type": "https://httpstatuses.io/409", "title": "Conflict", "status": 409, "code": "VERSION_IMMUTABLE",
  "detail": "Published or superseded workflow versions are immutable...", "traceId": "3f2c...", "errors": null }
```

Codes: `VALIDATION_FAILED` (400, with field `errors`), `ANTIFORGERY_FAILED` (400), `UNAUTHENTICATED` (401), `FORBIDDEN` (403),
`NOT_FOUND` (404), `CONFLICT` / `DUPLICATE_CODE` / `DRAFT_EXISTS` / `VERSION_MISMATCH` / `TEMPLATE_INACTIVE` / `VERSION_IMMUTABLE` /
`CONCURRENCY_CONFLICT` (409), `INTERNAL_ERROR` (500).

The published definition format is documented in **`docs/DEFINITION-CONTRACT.md`**.

---

## 8. Deployment (IIS)

Recommended: host Web and API on **the same origin** (e.g. site `https://wf-designer.bank.local` with the API as the
IIS application `/api-host`, then `FrontEnd:ApiBaseUrl = https://wf-designer.bank.local/api-host`). Same-origin avoids
CORS entirely and keeps cookies first-party.

1. `dotnet publish src/BankWorkflowDesigner.Api -c Release -o publish/api` and the same for `src/BankWorkflowDesigner.Web`.
2. Create two app pools (No Managed Code) running as domain service accounts (gMSA recommended).
3. IIS Authentication for both apps: **Windows Authentication = Enabled**. For the API, if Web and API are on different
   origins also enable Anonymous Authentication so CORS pre-flight (`OPTIONS`) requests succeed - the API's fallback
   policy still requires Windows authentication for every endpoint.
4. Database: create a login/user for the API app-pool account and add it to `wf_app_executor`.
5. Configure `appsettings.Production.json` (or environment variables) from the `.example` files; set `Swagger:Enabled=false`.
6. Map AD groups in `Authentication:RoleMappings`; register source systems and their authorised users in the portal.
7. Grant the Temporal execution service account `WF_DEFINITION_CONSUMER` (Windows group or IAM role).

For JWT (e.g. Azure AD / Keycloak): set `Authentication:Mode=Jwt`, `Authority`, `Audience`; tokens must carry the
mapped role claims.

---

## 9. Tests

```bash
dotnet test BankWorkflowDesigner.sln
```

- **Unit tests** (`tests/BankWorkflowDesigner.UnitTests`, 104 cases): expression language, secret/SQL scanner, Quartz cron
  validator, time-zone validator, value/JSON-schema validation, 15 workflow-validator scenarios, definition builder
  (hash determinism, defaults, no vault references), service layer (authorisation, four-eyes, immutability, versioning,
  cloning, concurrency, deactivation, source systems, schedulers) and a test that **imports, validates and publishes
  every sample template** and checks every activity type is covered.
- **API integration tests** (`tests/BankWorkflowDesigner.ApiTests`, 9 end-to-end scenarios, 100+ assertions): the real
  HTTP pipeline (routing, Development authentication, role policies, anti-forgery, model validation, error middleware,
  security headers, Swagger, controllers, services) on a random local port with in-memory repositories: authorisation
  matrix, import → validate → publish → consume by code → immutability → new version → four-eyes, all activity /
  connection / parameter / layout / clone / delete endpoints, concurrency 409s, secret rejection, source systems,
  schedulers, dashboard.

### What was verified while building this package - and what could not be

Verified in the build environment (Linux, .NET 8.0.131):

- The whole solution builds with **0 warnings, 0 errors**.
- **All 104 unit test cases and 9 API integration tests pass.**
- The Web front end was driven end to end in Chromium (Playwright) against the running API: dashboard, import,
  designer drag-and-drop / connect / rename / delete / validate, activity configuration, parameters, approvals,
  validation, publish, version history + definition viewer, read-only designer, scheduler editor, source-system
  editor, create workflow, template list - **no browser console errors and no failed requests**.
- The Postman collection was executed with Newman against the running API: **74 requests, 46 assertions, 0 failures**
  (twice, to confirm it is re-runnable).
- All SQL scripts were parsed with a T-SQL grammar (sqlfluff) and every C# stored-procedure call was cross-checked
  mechanically against the procedure signatures (37 procedures, all parameters and all 134 result columns matched).

**Not testable in the build environment - please verify in your environment:**

1. **Execution of the SQL scripts and the ADO.NET repositories against a real SQL Server.** No SQL Server engine was
   available, so the Infrastructure layer (stored procedures, triggers, table-valued parameters, transactions,
   `rowversion` handling) is compiled and statically cross-checked but not executed. The tests use an in-memory
   repository implementation that mirrors the stored-procedure behaviour. Recommended first step: deploy the database,
   run the API against it and run the Postman collection.
2. **Windows / AD authentication under IIS and JWT with a real IAM provider** - covered by configuration only; tests use
   the Development scheme.
3. **The xUnit runner itself.** The xUnit and Test SDK packages could not be downloaded in the build environment, so the
   tests were compiled and executed through an API-compatible stand-in runner. They are ordinary xUnit 2.9 tests
   and should run unchanged with `dotnet test` / Visual Studio Test Explorer.
4. Browsers other than Chromium, load/performance, and accessibility audits.

---

## 10. Troubleshooting

| Symptom | Fix |
|---|---|
| API start-up error "Authentication:Mode is 'Windows' but…" | Run under IIS with Windows Authentication, or use `Jwt` / `Development`. |
| Browser shows "Cannot reach the Workflow API" | Check `FrontEnd:ApiBaseUrl`, that the API runs, the HTTPS dev certificate is trusted, and `Cors:AllowedOrigins` contains the Web origin. |
| 400 `ANTIFORGERY_FAILED` | Reload the page (token is per user/session); cookies must be allowed for the API host. |
| 403 on a workflow | The user lacks the global role **or** is not an authorised user of that source system. |
| 409 `VERSION_IMMUTABLE` | Create a new draft version (`POST /api/workflows/{id}/versions` or the banner button). |
| Unknown time zone | Use a Windows id (`India Standard Time`) or an IANA id (`Asia/Kolkata`). |
