/* =============================================================================
   BankWorkflowDesigner - 06 Source systems, modules, authorised users, reference data
   ============================================================================= */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

/* Returns 3 result sets: systems, modules, users - filtered by @SourceSystemId / @SystemCode when supplied. */
CREATE OR ALTER PROCEDURE wf.usp_SourceSystem_Get
    @SourceSystemId INT          = NULL,
    @SystemCode     NVARCHAR(50) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Ids TABLE (SourceSystemId INT PRIMARY KEY);
    INSERT @Ids (SourceSystemId)
    SELECT SourceSystemId
    FROM wf.SourceSystem
    WHERE (@SourceSystemId IS NULL OR SourceSystemId = @SourceSystemId)
      AND (@SystemCode IS NULL OR SystemCode = @SystemCode);

    SELECT s.SourceSystemId, s.SystemCode, s.ApplicationName, s.Description, s.DefaultTaskQueue, s.Status,
           s.CreatedBy, s.CreatedOn, s.ModifiedBy, s.ModifiedOn, s.RowVer
    FROM wf.SourceSystem s
    JOIN @Ids i ON i.SourceSystemId = s.SourceSystemId
    ORDER BY s.SystemCode;

    SELECT m.ModuleId, m.SourceSystemId, m.ModuleCode, m.ModuleName, m.Description, m.Status,
           m.CreatedBy, m.CreatedOn, m.ModifiedBy, m.ModifiedOn, m.RowVer
    FROM wf.SourceSystemModule m
    JOIN @Ids i ON i.SourceSystemId = m.SourceSystemId
    ORDER BY m.SourceSystemId, m.ModuleCode;

    SELECT u.SourceSystemUserId, u.SourceSystemId, u.UserPrincipal, u.DisplayName, u.AccessRole, u.IsActive, u.CreatedBy, u.CreatedOn
    FROM wf.SourceSystemUser u
    JOIN @Ids i ON i.SourceSystemId = u.SourceSystemId
    ORDER BY u.SourceSystemId, u.UserPrincipal, u.AccessRole;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_SourceSystem_Create
    @SystemCode       NVARCHAR(50),
    @ApplicationName  NVARCHAR(200),
    @Description      NVARCHAR(1000),
    @DefaultTaskQueue NVARCHAR(200),
    @Status           NVARCHAR(20),
    @Modules          wf.ModuleTableType READONLY,
    @Users            wf.SourceSystemUserTableType READONLY,
    @UserName         NVARCHAR(256),
    @CorrelationId    NVARCHAR(100) = NULL,
    @ClientIp         NVARCHAR(64)  = NULL,
    @SourceSystemId   INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF EXISTS (SELECT 1 FROM wf.SourceSystem WHERE SystemCode = @SystemCode)
        THROW 51409, N'Source system code already exists.', 1;

    BEGIN TRANSACTION;

    INSERT wf.SourceSystem (SystemCode, ApplicationName, Description, DefaultTaskQueue, Status, CreatedBy)
    VALUES (@SystemCode, @ApplicationName, @Description, @DefaultTaskQueue, @Status, @UserName);

    SET @SourceSystemId = CAST(SCOPE_IDENTITY() AS INT);

    INSERT wf.SourceSystemModule (SourceSystemId, ModuleCode, ModuleName, Description, Status, CreatedBy)
    SELECT @SourceSystemId, ModuleCode, ModuleName, Description, Status, @UserName FROM @Modules;

    INSERT wf.SourceSystemUser (SourceSystemId, UserPrincipal, DisplayName, AccessRole, IsActive, CreatedBy)
    SELECT @SourceSystemId, UserPrincipal, DisplayName, AccessRole, IsActive, @UserName FROM @Users;

    DECLARE @Details NVARCHAR(MAX) =
        (SELECT @SystemCode AS systemCode, @ApplicationName AS applicationName,
                (SELECT ModuleCode AS code FROM @Modules FOR JSON PATH) AS modules,
                (SELECT UserPrincipal AS principal, AccessRole AS role FROM @Users FOR JSON PATH) AS users
         FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    DECLARE @EntityId NVARCHAR(50) = CAST(@SourceSystemId AS NVARCHAR(50));
    EXEC wf.usp_Internal_WriteAudit N'SourceSystem', @EntityId, N'Created', @UserName, @CorrelationId, @ClientIp, @Details;

    COMMIT TRANSACTION;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_SourceSystem_Update
    @SourceSystemId   INT,
    @ApplicationName  NVARCHAR(200),
    @Description      NVARCHAR(1000),
    @DefaultTaskQueue NVARCHAR(200),
    @Status           NVARCHAR(20),
    @RowVersion       BINARY(8),
    @Modules          wf.ModuleTableType READONLY,
    @Users            wf.SourceSystemUserTableType READONLY,
    @UserName         NVARCHAR(256),
    @CorrelationId    NVARCHAR(100) = NULL,
    @ClientIp         NVARCHAR(64)  = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRANSACTION;

    UPDATE wf.SourceSystem
    SET ApplicationName  = @ApplicationName,
        Description      = @Description,
        DefaultTaskQueue = @DefaultTaskQueue,
        Status           = @Status,
        ModifiedBy       = @UserName,
        ModifiedOn       = SYSUTCDATETIME()
    WHERE SourceSystemId = @SourceSystemId
      AND RowVer = @RowVersion;

    IF @@ROWCOUNT = 0
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM wf.SourceSystem WHERE SourceSystemId = @SourceSystemId)
            THROW 51404, N'Source system not found.', 1;
        THROW 51410, N'The source system was modified by another user. Reload and try again.', 1;
    END

    -- Modules are never deleted (templates reference them); they are updated or added.
    UPDATE m
    SET ModuleName  = t.ModuleName,
        Description = t.Description,
        Status      = t.Status,
        ModifiedBy  = @UserName,
        ModifiedOn  = SYSUTCDATETIME()
    FROM wf.SourceSystemModule m
    JOIN @Modules t ON t.ModuleCode = m.ModuleCode
    WHERE m.SourceSystemId = @SourceSystemId
      AND (m.ModuleName <> t.ModuleName OR ISNULL(m.Description, N'') <> ISNULL(t.Description, N'') OR m.Status <> t.Status);

    INSERT wf.SourceSystemModule (SourceSystemId, ModuleCode, ModuleName, Description, Status, CreatedBy)
    SELECT @SourceSystemId, t.ModuleCode, t.ModuleName, t.Description, t.Status, @UserName
    FROM @Modules t
    WHERE NOT EXISTS (SELECT 1 FROM wf.SourceSystemModule m WHERE m.SourceSystemId = @SourceSystemId AND m.ModuleCode = t.ModuleCode);

    -- Authorised users are replaced as a set.
    DELETE FROM wf.SourceSystemUser WHERE SourceSystemId = @SourceSystemId;

    INSERT wf.SourceSystemUser (SourceSystemId, UserPrincipal, DisplayName, AccessRole, IsActive, CreatedBy)
    SELECT @SourceSystemId, UserPrincipal, DisplayName, AccessRole, IsActive, @UserName FROM @Users;

    DECLARE @Details NVARCHAR(MAX) =
        (SELECT @ApplicationName AS applicationName, @Status AS status,
                (SELECT ModuleCode AS code, Status AS status FROM @Modules FOR JSON PATH) AS modules,
                (SELECT UserPrincipal AS principal, AccessRole AS role, IsActive AS active FROM @Users FOR JSON PATH) AS users
         FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    DECLARE @EntityId NVARCHAR(50) = CAST(@SourceSystemId AS NVARCHAR(50));
    EXEC wf.usp_Internal_WriteAudit N'SourceSystem', @EntityId, N'Updated', @UserName, @CorrelationId, @ClientIp, @Details;

    COMMIT TRANSACTION;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_SourceSystemUser_GetAccessRoles
    @SourceSystemId INT,
    @UserPrincipal  NVARCHAR(256)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT DISTINCT u.AccessRole
    FROM wf.SourceSystemUser u
    JOIN wf.SourceSystem s ON s.SourceSystemId = u.SourceSystemId
    WHERE u.SourceSystemId = @SourceSystemId
      AND u.UserPrincipal = @UserPrincipal
      AND u.IsActive = 1
      AND s.Status = N'Active';
END
GO

CREATE OR ALTER PROCEDURE wf.usp_SourceSystemUser_GetAuthorizedSystems
    @UserPrincipal NVARCHAR(256)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT DISTINCT u.SourceSystemId
    FROM wf.SourceSystemUser u
    JOIN wf.SourceSystem s ON s.SourceSystemId = u.SourceSystemId
    WHERE u.UserPrincipal = @UserPrincipal
      AND u.IsActive = 1
      AND s.Status = N'Active';
END
GO

CREATE OR ALTER PROCEDURE wf.usp_ConnectionProfile_GetAll
AS
BEGIN
    SET NOCOUNT ON;
    SELECT ConnectionProfileId, ProfileCode, ProfileType, Description, SecretStoreReference, Environment, SourceSystemId, IsActive
    FROM wf.ConnectionProfile
    ORDER BY ProfileType, ProfileCode;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_ApprovedOracleQuery_GetAll
AS
BEGIN
    SET NOCOUNT ON;
    SELECT ApprovedQueryId, QueryCode, QueryName, Description, SourceSystemId, DataSourceProfileCode,
           ParameterNamesJson, ApprovedBy, ApprovedOn, IsActive
    FROM wf.ApprovedOracleQuery
    ORDER BY QueryCode;
END
GO
