/* =============================================================================
   BankWorkflowDesigner - 03 User-defined table types (table-valued parameters)
   ============================================================================= */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

IF TYPE_ID(N'wf.IntListType') IS NULL
    CREATE TYPE wf.IntListType AS TABLE (Id INT NOT NULL PRIMARY KEY);
GO

IF TYPE_ID(N'wf.ModuleTableType') IS NULL
    CREATE TYPE wf.ModuleTableType AS TABLE
    (
        ModuleCode  NVARCHAR(50)   NOT NULL PRIMARY KEY,
        ModuleName  NVARCHAR(200)  NOT NULL,
        Description NVARCHAR(1000) NULL,
        Status      NVARCHAR(20)   NOT NULL
    );
GO

IF TYPE_ID(N'wf.SourceSystemUserTableType') IS NULL
    CREATE TYPE wf.SourceSystemUserTableType AS TABLE
    (
        UserPrincipal NVARCHAR(256) NOT NULL,
        DisplayName   NVARCHAR(200) NULL,
        AccessRole    NVARCHAR(20)  NOT NULL,
        IsActive      BIT           NOT NULL,
        PRIMARY KEY (UserPrincipal, AccessRole)
    );
GO

IF TYPE_ID(N'wf.ParameterTableType') IS NULL
    CREATE TYPE wf.ParameterTableType AS TABLE
    (
        Direction       NVARCHAR(10)   NOT NULL,
        Name            NVARCHAR(100)  NOT NULL,
        DataType        NVARCHAR(20)   NOT NULL,
        IsMandatory     BIT            NOT NULL,
        DefaultValue    NVARCHAR(4000) NULL,
        JsonSchema      NVARCHAR(MAX)  NULL,
        Description     NVARCHAR(1000) NULL,
        SourceType      NVARCHAR(30)   NOT NULL,
        SourceReference NVARCHAR(500)  NULL,
        SortOrder       INT            NOT NULL,
        PRIMARY KEY (Direction, Name)
    );
GO

IF TYPE_ID(N'wf.ApprovalLevelTableType') IS NULL
    CREATE TYPE wf.ApprovalLevelTableType AS TABLE
    (
        LevelNo       INT           NOT NULL PRIMARY KEY,
        LevelName     NVARCHAR(200) NOT NULL,
        ExecutionMode NVARCHAR(20)  NOT NULL,
        MinApprovals  INT           NOT NULL,
        SlaHours      INT           NULL
    );
GO

IF TYPE_ID(N'wf.ApprovalLevelRoleTableType') IS NULL
    CREATE TYPE wf.ApprovalLevelRoleTableType AS TABLE
    (
        LevelNo    INT           NOT NULL,
        RoleCode   NVARCHAR(100) NOT NULL,
        GroupName  NVARCHAR(200) NULL,
        SequenceNo INT           NOT NULL,
        PRIMARY KEY (LevelNo, RoleCode)
    );
GO

IF TYPE_ID(N'wf.ActivityPositionTableType') IS NULL
    CREATE TYPE wf.ActivityPositionTableType AS TABLE
    (
        ActivityKey NVARCHAR(100) NOT NULL PRIMARY KEY,
        PositionX   INT           NOT NULL,
        PositionY   INT           NOT NULL
    );
GO
