/* =============================================================================
   BankWorkflowDesigner - 01 Create database
   Run as a login with CREATE DATABASE permission (DBA). Optional - skip if the
   DBA team provisions the database. Adjust file paths / sizes to bank standards.
   ============================================================================= */
IF DB_ID(N'BankWorkflowDesigner') IS NULL
BEGIN
    CREATE DATABASE BankWorkflowDesigner;
END
GO

ALTER DATABASE BankWorkflowDesigner SET READ_COMMITTED_SNAPSHOT ON WITH ROLLBACK IMMEDIATE;
GO
ALTER DATABASE BankWorkflowDesigner SET ALLOW_SNAPSHOT_ISOLATION ON;
GO
