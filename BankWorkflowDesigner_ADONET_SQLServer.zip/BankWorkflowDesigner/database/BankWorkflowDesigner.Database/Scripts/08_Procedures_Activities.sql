/* =============================================================================
   BankWorkflowDesigner - 08 Activities, connections, approval configuration, parameters
   Every procedure asserts that the target version is an editable draft.
   @WriteAudit = 0 is used when the caller writes one summarising audit row (import).
   ============================================================================= */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE wf.usp_Activity_Get
    @ActivityId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT ActivityId, WorkflowVersionId, ActivityKey, ActivityType, DisplayName, Description, PositionX, PositionY,
           TimeoutSeconds, RetryMaxAttempts, RetryInitialIntervalSeconds, RetryBackoffCoefficient, RetryMaxIntervalSeconds,
           NonRetryableErrorsJson, ErrorHandling, ErrorRouteActivityKey, ExecutionCondition, ConfigJson,
           ModifiedBy, ModifiedOn, RowVer
    FROM wf.WorkflowActivity WHERE ActivityId = @ActivityId;

    SELECT ActivityParameterId, ActivityId, Direction, Name, DataType, IsMandatory, DefaultValue, JsonSchema, Description,
           SourceType, SourceReference, SortOrder
    FROM wf.ActivityParameter WHERE ActivityId = @ActivityId
    ORDER BY Direction, SortOrder, Name;

    SELECT ApprovalConfigId, ActivityId, ApprovalPolicy, QuorumCount, RejectionRouting, RejectionTargetActivityKey,
           SlaHours, EscalationAfterHours, EscalationRole, ReminderIntervalHours, AllowDelegation, EnforceMakerCheckerSegregation
    FROM wf.ApprovalConfiguration WHERE ActivityId = @ActivityId;

    SELECT l.ApprovalLevelId, l.ApprovalConfigId, l.LevelNo, l.LevelName, l.ExecutionMode, l.MinApprovals, l.SlaHours
    FROM wf.ApprovalLevel l
    JOIN wf.ApprovalConfiguration c ON c.ApprovalConfigId = l.ApprovalConfigId
    WHERE c.ActivityId = @ActivityId
    ORDER BY l.LevelNo;

    SELECT r.ApprovalLevelId, r.RoleCode, r.GroupName, r.SequenceNo
    FROM wf.ApprovalLevelRole r
    JOIN wf.ApprovalLevel l ON l.ApprovalLevelId = r.ApprovalLevelId
    JOIN wf.ApprovalConfiguration c ON c.ApprovalConfigId = l.ApprovalConfigId
    WHERE c.ActivityId = @ActivityId
    ORDER BY r.ApprovalLevelId, r.SequenceNo, r.RoleCode;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_Activity_Insert
    @WorkflowVersionId           INT,
    @ActivityKey                 NVARCHAR(100),
    @ActivityType                NVARCHAR(50),
    @DisplayName                 NVARCHAR(200),
    @Description                 NVARCHAR(1000),
    @PositionX                   INT,
    @PositionY                   INT,
    @TimeoutSeconds              INT,
    @RetryMaxAttempts            INT,
    @RetryInitialIntervalSeconds INT,
    @RetryBackoffCoefficient     DECIMAL(5,2),
    @RetryMaxIntervalSeconds     INT,
    @NonRetryableErrorsJson      NVARCHAR(2000),
    @ErrorHandling               NVARCHAR(30),
    @ErrorRouteActivityKey       NVARCHAR(100),
    @ExecutionCondition          NVARCHAR(1000),
    @ConfigJson                  NVARCHAR(MAX),
    @Parameters                  wf.ParameterTableType READONLY,
    @WriteAudit                  BIT = 1,
    @UserName                    NVARCHAR(256),
    @CorrelationId               NVARCHAR(100) = NULL,
    @ClientIp                    NVARCHAR(64)  = NULL,
    @ActivityId                  INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRANSACTION;

    DECLARE @TemplateId INT;
    EXEC wf.usp_Internal_AssertVersionEditable @WorkflowVersionId, @TemplateId OUTPUT;

    IF EXISTS (SELECT 1 FROM wf.WorkflowActivity WHERE WorkflowVersionId = @WorkflowVersionId AND ActivityKey = @ActivityKey)
        THROW 51409, N'Activity key already exists in this version.', 1;
    IF @ActivityType = N'Start' AND EXISTS (SELECT 1 FROM wf.WorkflowActivity WHERE WorkflowVersionId = @WorkflowVersionId AND ActivityType = N'Start')
        THROW 51409, N'The workflow already has a Start node.', 1;

    INSERT wf.WorkflowActivity (WorkflowVersionId, ActivityKey, ActivityType, DisplayName, Description, PositionX, PositionY,
        TimeoutSeconds, RetryMaxAttempts, RetryInitialIntervalSeconds, RetryBackoffCoefficient, RetryMaxIntervalSeconds,
        NonRetryableErrorsJson, ErrorHandling, ErrorRouteActivityKey, ExecutionCondition, ConfigJson, CreatedBy)
    VALUES (@WorkflowVersionId, @ActivityKey, @ActivityType, @DisplayName, @Description, @PositionX, @PositionY,
        @TimeoutSeconds, @RetryMaxAttempts, @RetryInitialIntervalSeconds, @RetryBackoffCoefficient, @RetryMaxIntervalSeconds,
        @NonRetryableErrorsJson, @ErrorHandling, @ErrorRouteActivityKey, @ExecutionCondition, @ConfigJson, @UserName);

    SET @ActivityId = CAST(SCOPE_IDENTITY() AS INT);

    INSERT wf.ActivityParameter (ActivityId, Direction, Name, DataType, IsMandatory, DefaultValue, JsonSchema, Description, SourceType, SourceReference, SortOrder)
    SELECT @ActivityId, Direction, Name, DataType, IsMandatory, DefaultValue, JsonSchema, Description, SourceType, SourceReference, SortOrder
    FROM @Parameters;

    EXEC wf.usp_Internal_TouchVersion @WorkflowVersionId, @UserName;

    IF @WriteAudit = 1
    BEGIN
        DECLARE @Details NVARCHAR(MAX) = (SELECT @ActivityKey AS activityKey, @ActivityType AS activityType, @DisplayName AS displayName FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
        DECLARE @EntityId NVARCHAR(50) = CAST(@TemplateId AS NVARCHAR(50));
        EXEC wf.usp_Internal_WriteAudit N'WorkflowTemplate', @EntityId, N'ActivityAdded', @UserName, @CorrelationId, @ClientIp, @Details;
    END

    COMMIT TRANSACTION;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_Activity_Update
    @WorkflowVersionId           INT,
    @ActivityId                  INT,
    @ActivityKey                 NVARCHAR(100),
    @DisplayName                 NVARCHAR(200),
    @Description                 NVARCHAR(1000),
    @PositionX                   INT,
    @PositionY                   INT,
    @TimeoutSeconds              INT,
    @RetryMaxAttempts            INT,
    @RetryInitialIntervalSeconds INT,
    @RetryBackoffCoefficient     DECIMAL(5,2),
    @RetryMaxIntervalSeconds     INT,
    @NonRetryableErrorsJson      NVARCHAR(2000),
    @ErrorHandling               NVARCHAR(30),
    @ErrorRouteActivityKey       NVARCHAR(100),
    @ExecutionCondition          NVARCHAR(1000),
    @ConfigJson                  NVARCHAR(MAX),
    @RowVersion                  BINARY(8),
    @ReplaceParameters           BIT,
    @Parameters                  wf.ParameterTableType READONLY,
    @UserName                    NVARCHAR(256),
    @CorrelationId               NVARCHAR(100) = NULL,
    @ClientIp                    NVARCHAR(64)  = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRANSACTION;

    DECLARE @TemplateId INT, @OldKey NVARCHAR(100);
    EXEC wf.usp_Internal_AssertVersionEditable @WorkflowVersionId, @TemplateId OUTPUT;

    SELECT @OldKey = ActivityKey FROM wf.WorkflowActivity WHERE ActivityId = @ActivityId AND WorkflowVersionId = @WorkflowVersionId;
    IF @OldKey IS NULL
        THROW 51404, N'Activity not found in this workflow version.', 1;

    IF @OldKey <> @ActivityKey AND EXISTS (SELECT 1 FROM wf.WorkflowActivity WHERE WorkflowVersionId = @WorkflowVersionId AND ActivityKey = @ActivityKey)
        THROW 51409, N'Activity key already exists in this version.', 1;

    UPDATE wf.WorkflowActivity
    SET ActivityKey = @ActivityKey,
        DisplayName = @DisplayName,
        Description = @Description,
        PositionX = @PositionX,
        PositionY = @PositionY,
        TimeoutSeconds = @TimeoutSeconds,
        RetryMaxAttempts = @RetryMaxAttempts,
        RetryInitialIntervalSeconds = @RetryInitialIntervalSeconds,
        RetryBackoffCoefficient = @RetryBackoffCoefficient,
        RetryMaxIntervalSeconds = @RetryMaxIntervalSeconds,
        NonRetryableErrorsJson = @NonRetryableErrorsJson,
        ErrorHandling = @ErrorHandling,
        ErrorRouteActivityKey = @ErrorRouteActivityKey,
        ExecutionCondition = @ExecutionCondition,
        ConfigJson = @ConfigJson,
        ModifiedBy = @UserName,
        ModifiedOn = SYSUTCDATETIME()
    WHERE ActivityId = @ActivityId AND RowVer = @RowVersion;

    IF @@ROWCOUNT = 0
        THROW 51410, N'The activity was modified by another user. Reload and try again.', 1;

    IF @ReplaceParameters = 1
    BEGIN
        DELETE FROM wf.ActivityParameter WHERE ActivityId = @ActivityId;
        INSERT wf.ActivityParameter (ActivityId, Direction, Name, DataType, IsMandatory, DefaultValue, JsonSchema, Description, SourceType, SourceReference, SortOrder)
        SELECT @ActivityId, Direction, Name, DataType, IsMandatory, DefaultValue, JsonSchema, Description, SourceType, SourceReference, SortOrder
        FROM @Parameters;
    END

    EXEC wf.usp_Internal_TouchVersion @WorkflowVersionId, @UserName;

    DECLARE @Details NVARCHAR(MAX) = (SELECT @ActivityId AS activityId, @OldKey AS previousKey, @ActivityKey AS activityKey,
        CAST(@ReplaceParameters AS BIT) AS parametersReplaced FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    DECLARE @EntityId NVARCHAR(50) = CAST(@TemplateId AS NVARCHAR(50));
    EXEC wf.usp_Internal_WriteAudit N'WorkflowTemplate', @EntityId, N'ActivityUpdated', @UserName, @CorrelationId, @ClientIp, @Details;

    COMMIT TRANSACTION;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_Activity_Delete
    @WorkflowVersionId INT,
    @ActivityId        INT,
    @UserName          NVARCHAR(256),
    @CorrelationId     NVARCHAR(100) = NULL,
    @ClientIp          NVARCHAR(64)  = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRANSACTION;

    DECLARE @TemplateId INT, @Key NVARCHAR(100);
    EXEC wf.usp_Internal_AssertVersionEditable @WorkflowVersionId, @TemplateId OUTPUT;

    SELECT @Key = ActivityKey FROM wf.WorkflowActivity WHERE ActivityId = @ActivityId AND WorkflowVersionId = @WorkflowVersionId;
    IF @Key IS NULL
        THROW 51404, N'Activity not found in this workflow version.', 1;

    DELETE FROM wf.ActivityConnection WHERE FromActivityId = @ActivityId OR ToActivityId = @ActivityId;
    DELETE FROM wf.WorkflowActivity WHERE ActivityId = @ActivityId;   -- parameters & approval cascade

    EXEC wf.usp_Internal_TouchVersion @WorkflowVersionId, @UserName;

    DECLARE @Details NVARCHAR(MAX) = (SELECT @ActivityId AS activityId, @Key AS activityKey FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    DECLARE @EntityId NVARCHAR(50) = CAST(@TemplateId AS NVARCHAR(50));
    EXEC wf.usp_Internal_WriteAudit N'WorkflowTemplate', @EntityId, N'ActivityDeleted', @UserName, @CorrelationId, @ClientIp, @Details;

    COMMIT TRANSACTION;
END
GO

/* Canvas layout only - not a content change, so neither the four-eyes modifier nor the audit trail is touched. */
CREATE OR ALTER PROCEDURE wf.usp_Activity_UpdateLayout
    @WorkflowVersionId INT,
    @Positions         wf.ActivityPositionTableType READONLY,
    @UserName          NVARCHAR(256)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRANSACTION;

    DECLARE @TemplateId INT;
    EXEC wf.usp_Internal_AssertVersionEditable @WorkflowVersionId, @TemplateId OUTPUT;

    UPDATE a
    SET PositionX = p.PositionX,
        PositionY = p.PositionY
    FROM wf.WorkflowActivity a
    JOIN @Positions p ON p.ActivityKey = a.ActivityKey
    WHERE a.WorkflowVersionId = @WorkflowVersionId;

    COMMIT TRANSACTION;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_ApprovalConfig_Save
    @WorkflowVersionId              INT,
    @ActivityId                     INT,
    @ApprovalPolicy                 NVARCHAR(20),
    @QuorumCount                    INT,
    @RejectionRouting               NVARCHAR(20),
    @RejectionTargetActivityKey     NVARCHAR(100),
    @SlaHours                       INT,
    @EscalationAfterHours           INT,
    @EscalationRole                 NVARCHAR(100),
    @ReminderIntervalHours          INT,
    @AllowDelegation                BIT,
    @EnforceMakerCheckerSegregation BIT,
    @Levels                         wf.ApprovalLevelTableType READONLY,
    @Roles                          wf.ApprovalLevelRoleTableType READONLY,
    @WriteAudit                     BIT = 1,
    @UserName                       NVARCHAR(256),
    @CorrelationId                  NVARCHAR(100) = NULL,
    @ClientIp                       NVARCHAR(64)  = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRANSACTION;

    DECLARE @TemplateId INT, @ActivityType NVARCHAR(50), @ConfigId INT;
    EXEC wf.usp_Internal_AssertVersionEditable @WorkflowVersionId, @TemplateId OUTPUT;

    SELECT @ActivityType = ActivityType FROM wf.WorkflowActivity WHERE ActivityId = @ActivityId AND WorkflowVersionId = @WorkflowVersionId;
    IF @ActivityType IS NULL
        THROW 51404, N'Activity not found in this workflow version.', 1;
    IF @ActivityType NOT IN (N'Checker', N'Approver', N'MultilevelApprover', N'SequentialApprover', N'ParallelApprover')
        THROW 51400, N'Approval configuration is only allowed on approval activities.', 1;
    IF EXISTS (SELECT 1 FROM @Roles r WHERE NOT EXISTS (SELECT 1 FROM @Levels l WHERE l.LevelNo = r.LevelNo))
        THROW 51400, N'Approval role references an unknown level.', 1;

    SELECT @ConfigId = ApprovalConfigId FROM wf.ApprovalConfiguration WHERE ActivityId = @ActivityId;

    IF @ConfigId IS NULL
    BEGIN
        INSERT wf.ApprovalConfiguration (ActivityId, ApprovalPolicy, QuorumCount, RejectionRouting, RejectionTargetActivityKey, SlaHours,
            EscalationAfterHours, EscalationRole, ReminderIntervalHours, AllowDelegation, EnforceMakerCheckerSegregation, ModifiedBy)
        VALUES (@ActivityId, @ApprovalPolicy, @QuorumCount, @RejectionRouting, @RejectionTargetActivityKey, @SlaHours,
            @EscalationAfterHours, @EscalationRole, @ReminderIntervalHours, @AllowDelegation, @EnforceMakerCheckerSegregation, @UserName);
        SET @ConfigId = CAST(SCOPE_IDENTITY() AS INT);
    END
    ELSE
    BEGIN
        UPDATE wf.ApprovalConfiguration
        SET ApprovalPolicy = @ApprovalPolicy,
            QuorumCount = @QuorumCount,
            RejectionRouting = @RejectionRouting,
            RejectionTargetActivityKey = @RejectionTargetActivityKey,
            SlaHours = @SlaHours,
            EscalationAfterHours = @EscalationAfterHours,
            EscalationRole = @EscalationRole,
            ReminderIntervalHours = @ReminderIntervalHours,
            AllowDelegation = @AllowDelegation,
            EnforceMakerCheckerSegregation = @EnforceMakerCheckerSegregation,
            ModifiedBy = @UserName,
            ModifiedOn = SYSUTCDATETIME()
        WHERE ApprovalConfigId = @ConfigId;

        DELETE FROM wf.ApprovalLevel WHERE ApprovalConfigId = @ConfigId;   -- roles cascade
    END

    INSERT wf.ApprovalLevel (ApprovalConfigId, LevelNo, LevelName, ExecutionMode, MinApprovals, SlaHours)
    SELECT @ConfigId, LevelNo, LevelName, ExecutionMode, MinApprovals, SlaHours FROM @Levels;

    INSERT wf.ApprovalLevelRole (ApprovalLevelId, RoleCode, GroupName, SequenceNo)
    SELECT l.ApprovalLevelId, r.RoleCode, r.GroupName, r.SequenceNo
    FROM @Roles r
    JOIN wf.ApprovalLevel l ON l.ApprovalConfigId = @ConfigId AND l.LevelNo = r.LevelNo;

    EXEC wf.usp_Internal_TouchVersion @WorkflowVersionId, @UserName;

    IF @WriteAudit = 1
    BEGIN
        DECLARE @Details NVARCHAR(MAX) = (SELECT @ActivityId AS activityId, @ApprovalPolicy AS approvalPolicy, @RejectionRouting AS rejectionRouting,
            (SELECT COUNT(*) FROM @Levels) AS levelCount FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
        DECLARE @EntityId NVARCHAR(50) = CAST(@TemplateId AS NVARCHAR(50));
        EXEC wf.usp_Internal_WriteAudit N'WorkflowTemplate', @EntityId, N'ApprovalConfigured', @UserName, @CorrelationId, @ClientIp, @Details;
    END

    COMMIT TRANSACTION;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_Connection_Save
    @WorkflowVersionId   INT,
    @ConnectionId        INT = NULL,          -- NULL = insert
    @FromActivityKey     NVARCHAR(100),
    @ToActivityKey       NVARCHAR(100),
    @ConnectionType      NVARCHAR(20),
    @ConditionExpression NVARCHAR(1000),
    @IsDefault           BIT,
    @Label               NVARCHAR(200),
    @Priority            INT,
    @WriteAudit          BIT = 1,
    @UserName            NVARCHAR(256),
    @CorrelationId       NVARCHAR(100) = NULL,
    @ClientIp            NVARCHAR(64)  = NULL,
    @SavedConnectionId   INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRANSACTION;

    DECLARE @TemplateId INT, @FromId INT, @ToId INT;
    EXEC wf.usp_Internal_AssertVersionEditable @WorkflowVersionId, @TemplateId OUTPUT;

    SELECT @FromId = ActivityId FROM wf.WorkflowActivity WHERE WorkflowVersionId = @WorkflowVersionId AND ActivityKey = @FromActivityKey;
    SELECT @ToId = ActivityId FROM wf.WorkflowActivity WHERE WorkflowVersionId = @WorkflowVersionId AND ActivityKey = @ToActivityKey;
    IF @FromId IS NULL OR @ToId IS NULL
        THROW 51400, N'Connection references an activity that does not exist in this version.', 1;

    IF EXISTS (SELECT 1 FROM wf.ActivityConnection WHERE FromActivityId = @FromId AND ToActivityId = @ToId
               AND ConnectionType = @ConnectionType AND ConnectionId <> ISNULL(@ConnectionId, -1))
        THROW 51409, N'An identical connection already exists.', 1;

    IF @ConnectionId IS NULL
    BEGIN
        INSERT wf.ActivityConnection (WorkflowVersionId, FromActivityId, ToActivityId, ConnectionType, ConditionExpression, IsDefault, Label, Priority, CreatedBy)
        VALUES (@WorkflowVersionId, @FromId, @ToId, @ConnectionType, @ConditionExpression, @IsDefault, @Label, @Priority, @UserName);
        SET @SavedConnectionId = CAST(SCOPE_IDENTITY() AS INT);
    END
    ELSE
    BEGIN
        UPDATE wf.ActivityConnection
        SET FromActivityId = @FromId, ToActivityId = @ToId, ConnectionType = @ConnectionType, ConditionExpression = @ConditionExpression,
            IsDefault = @IsDefault, Label = @Label, Priority = @Priority
        WHERE ConnectionId = @ConnectionId AND WorkflowVersionId = @WorkflowVersionId;
        IF @@ROWCOUNT = 0
            THROW 51404, N'Connection not found in this workflow version.', 1;
        SET @SavedConnectionId = @ConnectionId;
    END

    EXEC wf.usp_Internal_TouchVersion @WorkflowVersionId, @UserName;

    IF @WriteAudit = 1
    BEGIN
        DECLARE @Details NVARCHAR(MAX) = (SELECT @SavedConnectionId AS connectionId, @FromActivityKey AS [from], @ToActivityKey AS [to],
            @ConnectionType AS connectionType, @ConditionExpression AS condition FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
        DECLARE @EntityId NVARCHAR(50) = CAST(@TemplateId AS NVARCHAR(50));
        DECLARE @Action NVARCHAR(50) = CASE WHEN @ConnectionId IS NULL THEN N'ConnectionAdded' ELSE N'ConnectionUpdated' END;
        EXEC wf.usp_Internal_WriteAudit N'WorkflowTemplate', @EntityId, @Action, @UserName, @CorrelationId, @ClientIp, @Details;
    END

    COMMIT TRANSACTION;

    SELECT c.ConnectionId, c.WorkflowVersionId, f.ActivityKey AS FromActivityKey, t.ActivityKey AS ToActivityKey,
           c.ConnectionType, c.ConditionExpression, c.IsDefault, c.Label, c.Priority
    FROM wf.ActivityConnection c
    JOIN wf.WorkflowActivity f ON f.ActivityId = c.FromActivityId
    JOIN wf.WorkflowActivity t ON t.ActivityId = c.ToActivityId
    WHERE c.ConnectionId = @SavedConnectionId;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_Connection_Delete
    @WorkflowVersionId INT,
    @ConnectionId      INT,
    @UserName          NVARCHAR(256),
    @CorrelationId     NVARCHAR(100) = NULL,
    @ClientIp          NVARCHAR(64)  = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRANSACTION;

    DECLARE @TemplateId INT;
    EXEC wf.usp_Internal_AssertVersionEditable @WorkflowVersionId, @TemplateId OUTPUT;

    DELETE FROM wf.ActivityConnection WHERE ConnectionId = @ConnectionId AND WorkflowVersionId = @WorkflowVersionId;
    IF @@ROWCOUNT = 0
        THROW 51404, N'Connection not found in this workflow version.', 1;

    EXEC wf.usp_Internal_TouchVersion @WorkflowVersionId, @UserName;

    DECLARE @Details NVARCHAR(MAX) = (SELECT @ConnectionId AS connectionId FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    DECLARE @EntityId NVARCHAR(50) = CAST(@TemplateId AS NVARCHAR(50));
    EXEC wf.usp_Internal_WriteAudit N'WorkflowTemplate', @EntityId, N'ConnectionDeleted', @UserName, @CorrelationId, @ClientIp, @Details;

    COMMIT TRANSACTION;
END
GO

/* ------------------------------------------------------------------ Workflow parameters */

CREATE OR ALTER PROCEDURE wf.usp_WorkflowParameter_Save
    @WorkflowVersionId INT,
    @ParameterId       INT = NULL,          -- NULL = insert
    @Direction         NVARCHAR(10),
    @Name              NVARCHAR(100),
    @DataType          NVARCHAR(20),
    @IsMandatory       BIT,
    @DefaultValue      NVARCHAR(4000),
    @JsonSchema        NVARCHAR(MAX),
    @Description       NVARCHAR(1000),
    @SourceType        NVARCHAR(30),
    @SourceReference   NVARCHAR(500),
    @SortOrder         INT,
    @RowVersion        BINARY(8) = NULL,
    @WriteAudit        BIT = 1,
    @UserName          NVARCHAR(256),
    @CorrelationId     NVARCHAR(100) = NULL,
    @ClientIp          NVARCHAR(64)  = NULL,
    @SavedParameterId  INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRANSACTION;

    DECLARE @TemplateId INT;
    EXEC wf.usp_Internal_AssertVersionEditable @WorkflowVersionId, @TemplateId OUTPUT;

    IF EXISTS (SELECT 1 FROM wf.WorkflowParameter WHERE WorkflowVersionId = @WorkflowVersionId AND Direction = @Direction
               AND Name = @Name AND ParameterId <> ISNULL(@ParameterId, -1))
        THROW 51409, N'A workflow parameter with this name and direction already exists.', 1;

    IF @ParameterId IS NULL
    BEGIN
        INSERT wf.WorkflowParameter (WorkflowVersionId, Direction, Name, DataType, IsMandatory, DefaultValue, JsonSchema, Description, SourceType, SourceReference, SortOrder, CreatedBy)
        VALUES (@WorkflowVersionId, @Direction, @Name, @DataType, @IsMandatory, @DefaultValue, @JsonSchema, @Description, @SourceType, @SourceReference, @SortOrder, @UserName);
        SET @SavedParameterId = CAST(SCOPE_IDENTITY() AS INT);
    END
    ELSE
    BEGIN
        UPDATE wf.WorkflowParameter
        SET Direction = @Direction, Name = @Name, DataType = @DataType, IsMandatory = @IsMandatory, DefaultValue = @DefaultValue,
            JsonSchema = @JsonSchema, Description = @Description, SourceType = @SourceType, SourceReference = @SourceReference,
            SortOrder = @SortOrder, ModifiedBy = @UserName, ModifiedOn = SYSUTCDATETIME()
        WHERE ParameterId = @ParameterId AND WorkflowVersionId = @WorkflowVersionId AND RowVer = @RowVersion;

        IF @@ROWCOUNT = 0
        BEGIN
            IF NOT EXISTS (SELECT 1 FROM wf.WorkflowParameter WHERE ParameterId = @ParameterId AND WorkflowVersionId = @WorkflowVersionId)
                THROW 51404, N'Parameter not found in this workflow version.', 1;
            THROW 51410, N'The parameter was modified by another user. Reload and try again.', 1;
        END
        SET @SavedParameterId = @ParameterId;
    END

    EXEC wf.usp_Internal_TouchVersion @WorkflowVersionId, @UserName;

    IF @WriteAudit = 1
    BEGIN
        DECLARE @Details NVARCHAR(MAX) = (SELECT @SavedParameterId AS parameterId, @Direction AS direction, @Name AS name, @DataType AS dataType,
            @SourceType AS sourceType, @SourceReference AS sourceReference FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
        DECLARE @EntityId NVARCHAR(50) = CAST(@TemplateId AS NVARCHAR(50));
        DECLARE @Action NVARCHAR(50) = CASE WHEN @ParameterId IS NULL THEN N'ParameterAdded' ELSE N'ParameterUpdated' END;
        EXEC wf.usp_Internal_WriteAudit N'WorkflowTemplate', @EntityId, @Action, @UserName, @CorrelationId, @ClientIp, @Details;
    END

    COMMIT TRANSACTION;

    SELECT ParameterId, WorkflowVersionId, Direction, Name, DataType, IsMandatory, DefaultValue, JsonSchema, Description,
           SourceType, SourceReference, SortOrder, RowVer
    FROM wf.WorkflowParameter WHERE ParameterId = @SavedParameterId;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_WorkflowParameter_Delete
    @WorkflowVersionId INT,
    @ParameterId       INT,
    @UserName          NVARCHAR(256),
    @CorrelationId     NVARCHAR(100) = NULL,
    @ClientIp          NVARCHAR(64)  = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRANSACTION;

    DECLARE @TemplateId INT, @Name NVARCHAR(100);
    EXEC wf.usp_Internal_AssertVersionEditable @WorkflowVersionId, @TemplateId OUTPUT;

    SELECT @Name = Name FROM wf.WorkflowParameter WHERE ParameterId = @ParameterId AND WorkflowVersionId = @WorkflowVersionId;
    IF @Name IS NULL
        THROW 51404, N'Parameter not found in this workflow version.', 1;

    DELETE FROM wf.WorkflowParameter WHERE ParameterId = @ParameterId;

    EXEC wf.usp_Internal_TouchVersion @WorkflowVersionId, @UserName;

    DECLARE @Details NVARCHAR(MAX) = (SELECT @ParameterId AS parameterId, @Name AS name FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    DECLARE @EntityId NVARCHAR(50) = CAST(@TemplateId AS NVARCHAR(50));
    EXEC wf.usp_Internal_WriteAudit N'WorkflowTemplate', @EntityId, N'ParameterDeleted', @UserName, @CorrelationId, @ClientIp, @Details;

    COMMIT TRANSACTION;
END
GO
