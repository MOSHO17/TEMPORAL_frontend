/* =============================================================================
   BankWorkflowDesigner - 11 Reference & development seed data (idempotent)
   Connection profiles and approved queries are governed data maintained by the
   platform / DBA team - the portal only reads them.
   The sample users match the "Development" authentication users in appsettings.Development.json.
   ============================================================================= */
SET NOCOUNT ON;
GO

DECLARE @Seed NVARCHAR(256) = N'SYSTEM.SEED';
DECLARE @AgriId INT, @TreasuryId INT;

IF NOT EXISTS (SELECT 1 FROM wf.SourceSystem WHERE SystemCode = N'AGRI_LOS')
    INSERT wf.SourceSystem (SystemCode, ApplicationName, Description, DefaultTaskQueue, Status, CreatedBy)
    VALUES (N'AGRI_LOS', N'Agri Loan Origination System', N'AGRI Business Group loan origination and renewal', N'agri-los-workflows', N'Active', @Seed);

IF NOT EXISTS (SELECT 1 FROM wf.SourceSystem WHERE SystemCode = N'TREASURY_OPS')
    INSERT wf.SourceSystem (SystemCode, ApplicationName, Description, DefaultTaskQueue, Status, CreatedBy)
    VALUES (N'TREASURY_OPS', N'Treasury Operations', N'Treasury back-office settlements', N'treasury-ops-workflows', N'Active', @Seed);

SELECT @AgriId = SourceSystemId FROM wf.SourceSystem WHERE SystemCode = N'AGRI_LOS';
SELECT @TreasuryId = SourceSystemId FROM wf.SourceSystem WHERE SystemCode = N'TREASURY_OPS';

INSERT wf.SourceSystemModule (SourceSystemId, ModuleCode, ModuleName, Description, Status, CreatedBy)
SELECT x.SourceSystemId, x.ModuleCode, x.ModuleName, x.Description, N'Active', @Seed
FROM (VALUES
    (@AgriId, N'CAM_RENEWAL', N'CAM Renewal', N'Credit appraisal memo renewals'),
    (@AgriId, N'KCC_SANCTION', N'KCC Sanction', N'Kisan Credit Card sanctions'),
    (@AgriId, N'ECLGS', N'ECLGS Processing', N'Emergency credit line guarantee scheme'),
    (@AgriId, N'SECURITIZATION', N'Securitization Sell-Down', N'Pool selection and sell-down'),
    (@TreasuryId, N'SETTLEMENT', N'Settlement', N'Daily settlement files')
) x (SourceSystemId, ModuleCode, ModuleName, Description)
WHERE NOT EXISTS (SELECT 1 FROM wf.SourceSystemModule m WHERE m.SourceSystemId = x.SourceSystemId AND m.ModuleCode = x.ModuleCode);

INSERT wf.SourceSystemUser (SourceSystemId, UserPrincipal, DisplayName, AccessRole, IsActive, CreatedBy)
SELECT x.SourceSystemId, x.UserPrincipal, x.DisplayName, x.AccessRole, 1, @Seed
FROM (VALUES
    (@AgriId, N'alice.designer', N'Alice (Designer)', N'Designer'),
    (@AgriId, N'rita.reviewer', N'Rita (Reviewer)', N'Reviewer'),
    (@AgriId, N'bob.publisher', N'Bob (Publisher)', N'Publisher'),
    (@AgriId, N'bob.publisher', N'Bob (Publisher)', N'Designer'),
    (@TreasuryId, N'tom.treasury', N'Tom (Treasury designer)', N'Designer')
) x (SourceSystemId, UserPrincipal, DisplayName, AccessRole)
WHERE NOT EXISTS (SELECT 1 FROM wf.SourceSystemUser u WHERE u.SourceSystemId = x.SourceSystemId AND u.UserPrincipal = x.UserPrincipal AND u.AccessRole = x.AccessRole);

INSERT wf.ConnectionProfile (ProfileCode, ProfileType, Description, SecretStoreReference, Environment, SourceSystemId, IsActive, CreatedBy)
SELECT x.ProfileCode, x.ProfileType, x.Description, x.SecretStoreReference, N'UAT', x.SourceSystemId, 1, @Seed
FROM (VALUES
    (N'SFTP_CBS_OUTBOUND', N'Sftp', N'Core banking outbound SFTP drop zone', N'cyberark://AGRI-SAFE/sftp-cbs-outbound', @AgriId),
    (N'SFTP_PARTNER_INBOUND', N'Sftp', N'Partner bank inbound SFTP', N'cyberark://AGRI-SAFE/sftp-partner-inbound', @AgriId),
    (N'API_CBS_CORE', N'Api', N'Core banking REST gateway', N'cyberark://AGRI-SAFE/api-cbs-core', @AgriId),
    (N'API_CREDIT_BUREAU', N'Api', N'Credit bureau API gateway', N'cyberark://AGRI-SAFE/api-credit-bureau', @AgriId),
    (N'ORA_AGRI_DWH', N'Oracle', N'Agri data warehouse (read-only)', N'cyberark://AGRI-SAFE/ora-agri-dwh-ro', @AgriId),
    (N'SFTP_TREASURY_SETTLE', N'Sftp', N'Treasury settlement SFTP', N'cyberark://TRSY-SAFE/sftp-settlement', @TreasuryId)
) x (ProfileCode, ProfileType, Description, SecretStoreReference, SourceSystemId)
WHERE NOT EXISTS (SELECT 1 FROM wf.ConnectionProfile p WHERE p.ProfileCode = x.ProfileCode);

INSERT wf.ApprovedOracleQuery (QueryCode, QueryName, Description, SourceSystemId, DataSourceProfileCode, ParameterNamesJson, ApprovedBy, ApprovedOn, IsActive)
SELECT x.QueryCode, x.QueryName, x.Description, x.SourceSystemId, N'ORA_AGRI_DWH', x.ParameterNamesJson, N'dba.governance', SYSUTCDATETIME(), 1
FROM (VALUES
    (N'Q_CAM_RENEWAL_DUE', N'CAM renewals due', N'Accounts whose CAM renewal falls due in the window', @AgriId, N'["asOfDate","windowDays"]'),
    (N'Q_ECLGS_PIPELINE', N'ECLGS pipeline summary', N'Date-wise ECLGS pipeline', @AgriId, N'["businessDate"]'),
    (N'Q_SECURITIZATION_POOL', N'Securitization candidate pool', N'Eligible loans for sell-down pool', @AgriId, N'[]')
) x (QueryCode, QueryName, Description, SourceSystemId, ParameterNamesJson)
WHERE NOT EXISTS (SELECT 1 FROM wf.ApprovedOracleQuery q WHERE q.QueryCode = x.QueryCode);
GO
