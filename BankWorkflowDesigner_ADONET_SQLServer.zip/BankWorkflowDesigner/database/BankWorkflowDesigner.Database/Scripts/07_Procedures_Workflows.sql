/* =============================================================================
   BankWorkflowDesigner - 07 Workflow templates, versions, validation, publishing
   ============================================================================= */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER VIEW wf.vw_WorkflowTemplate
AS
SELECT t.WorkflowTemplateId, t.TemplateCode, t.SourceSystemId, s.SystemCode AS SourceSystemCode,
       t.ModuleId, m.ModuleCode, t.WorkflowName, t.Description, t.Status, t.LatestVersionNo, t.PublishedVersionNo,
       t.ClonedFromTemplateId, t.CreatedBy, t.CreatedOn, t.ModifiedBy, t.ModifiedOn, t.RowVer,
       lv.Status AS LatestVersionStatus
FROM wf.WorkflowTemplate t
JOIN wf.SourceSystem s ON s.SourceSystemId = t.SourceSystemId
JOIN wf.SourceSystemModule m ON m.ModuleId = t.ModuleId
LEFT JOIN wf.WorkflowVersion lv ON lv.WorkflowTemplateId = t.WorkflowTemplateId AND lv.VersionNo = t.LatestVersionNo;
GO

CREATE OR ALTER PROCEDURE wf.usp_Workflow_Search
    @SourceSystemId INT            = NULL,
    @ModuleId       INT            = NULL,
    @Search         NVARCHAR(200)  = NULL,
    @Status         NVARCHAR(20)   = NULL,
    @PageNumber     INT            = 1,
    @PageSize       INT            = 25,
    @RestrictToIds  BIT            = 0,
    @AllowedIds     wf.IntListType READONLY
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Pattern NVARCHAR(210) = CASE WHEN NULLIF(LTRIM(RTRIM(@Search)), N'') IS NULL THEN NULL
        ELSE N'%' + REPLACE(REPLACE(REPLACE(@Search, N'[', N'[[]'), N'%', N'[%]'), N'_', N'[_]') + N'%' END;

    ;WITH filtered AS
    (
        SELECT v.*
        FROM wf.vw_WorkflowTemplate v
        WHERE (@SourceSystemId IS NULL OR v.SourceSystemId = @SourceSystemId)
          AND (@ModuleId IS NULL OR v.ModuleId = @ModuleId)
          AND (@Status IS NULL OR v.Status = @Status OR v.LatestVersionStatus = @Status)
          AND (@Pattern IS NULL OR v.TemplateCode LIKE @Pattern OR v.WorkflowName LIKE @Pattern)
          AND (@RestrictToIds = 0 OR v.SourceSystemId IN (SELECT Id FROM @AllowedIds))
    )
    SELECT COUNT(*) AS TotalCount FROM filtered;

    SELECT v.*
    FROM wf.vw_WorkflowTemplate v
    WHERE (@SourceSystemId IS NULL OR v.SourceSystemId = @SourceSystemId)
      AND (@ModuleId IS NULL OR v.ModuleId = @ModuleId)
      AND (@Status IS NULL OR v.Status = @Status OR v.LatestVersionStatus = @Status)
      AND (@Pattern IS NULL OR v.TemplateCode LIKE @Pattern OR v.WorkflowName LIKE @Pattern)
      AND (@RestrictToIds = 0 OR v.SourceSystemId IN (SELECT Id FROM @AllowedIds))
    ORDER BY COALESCE(v.ModifiedOn, v.CreatedOn) DESC, v.WorkflowTemplateId DESC
    OFFSET (@PageNumber - 1) * @PageSize ROWS FETCH NEXT @PageSize ROWS ONLY;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_Workflow_Get
    @WorkflowTemplateId INT          = NULL,
    @TemplateCode       NVARCHAR(50) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT v.*
    FROM wf.vw_WorkflowTemplate v
    WHERE (@WorkflowTemplateId IS NOT NULL AND v.WorkflowTemplateId = @WorkflowTemplateId)
       OR (@WorkflowTemplateId IS NULL AND v.TemplateCode = @TemplateCode);
END
GO

CREATE OR ALTER PROCEDURE wf.usp_WorkflowVersion_GetList
    @WorkflowTemplateId INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT WorkflowVersionId, WorkflowTemplateId, VersionNo, Status, ChangeNotes, BasedOnVersionNo,
           ValidationResultJson, ValidatedOn, ValidatedBy, CAST(NULL AS NVARCHAR(MAX)) AS DefinitionJson, DefinitionHash,
           PublishedOn, PublishedBy, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn, RowVer
    FROM wf.WorkflowVersion
    WHERE WorkflowTemplateId = @WorkflowTemplateId
    ORDER BY VersionNo DESC;
END
GO

/* Complete graph of one version. Null @VersionNo = latest version.
   Result sets: 1 version, 2 template, 3 source system + module, 4 activities, 5 activity parameters,
                6 approval configurations, 7 approval levels, 8 approval roles, 9 connections, 10 workflow parameters. */
CREATE OR ALTER PROCEDURE wf.usp_WorkflowGraph_Get
    @WorkflowTemplateId INT,
    @VersionNo          INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @VersionId INT;
    SELECT @VersionId = v.WorkflowVersionId
    FROM wf.WorkflowVersion v
    JOIN wf.WorkflowTemplate t ON t.WorkflowTemplateId = v.WorkflowTemplateId
    WHERE v.WorkflowTemplateId = @WorkflowTemplateId
      AND v.VersionNo = COALESCE(@VersionNo, t.LatestVersionNo);

    SELECT WorkflowVersionId, WorkflowTemplateId, VersionNo, Status, ChangeNotes, BasedOnVersionNo,
           ValidationResultJson, ValidatedOn, ValidatedBy, CAST(NULL AS NVARCHAR(MAX)) AS DefinitionJson, DefinitionHash,
           PublishedOn, PublishedBy, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn, RowVer
    FROM wf.WorkflowVersion
    WHERE WorkflowVersionId = @VersionId;

    SELECT v.* FROM wf.vw_WorkflowTemplate v WHERE v.WorkflowTemplateId = @WorkflowTemplateId AND @VersionId IS NOT NULL;

    SELECT s.SourceSystemId, s.SystemCode, s.ApplicationName, s.DefaultTaskQueue, s.Status AS SourceSystemStatus,
           m.ModuleId, m.ModuleCode, m.ModuleName, m.Status AS ModuleStatus
    FROM wf.WorkflowTemplate t
    JOIN wf.SourceSystem s ON s.SourceSystemId = t.SourceSystemId
    JOIN wf.SourceSystemModule m ON m.ModuleId = t.ModuleId
    WHERE t.WorkflowTemplateId = @WorkflowTemplateId AND @VersionId IS NOT NULL;

    SELECT ActivityId, WorkflowVersionId, ActivityKey, ActivityType, DisplayName, Description, PositionX, PositionY,
           TimeoutSeconds, RetryMaxAttempts, RetryInitialIntervalSeconds, RetryBackoffCoefficient, RetryMaxIntervalSeconds,
           NonRetryableErrorsJson, ErrorHandling, ErrorRouteActivityKey, ExecutionCondition, ConfigJson,
           ModifiedBy, ModifiedOn, RowVer
    FROM wf.WorkflowActivity
    WHERE WorkflowVersionId = @VersionId
    ORDER BY ActivityId;

    SELECT p.ActivityParameterId, p.ActivityId, p.Direction, p.Name, p.DataType, p.IsMandatory, p.DefaultValue,
           p.JsonSchema, p.Description, p.SourceType, p.SourceReference, p.SortOrder
    FROM wf.ActivityParameter p
    JOIN wf.WorkflowActivity a ON a.ActivityId = p.ActivityId
    WHERE a.WorkflowVersionId = @VersionId
    ORDER BY p.ActivityId, p.Direction, p.SortOrder, p.Name;

    SELECT c.ApprovalConfigId, c.ActivityId, c.ApprovalPolicy, c.QuorumCount, c.RejectionRouting, c.RejectionTargetActivityKey,
           c.SlaHours, c.EscalationAfterHours, c.EscalationRole, c.ReminderIntervalHours, c.AllowDelegation, c.EnforceMakerCheckerSegregation
    FROM wf.ApprovalConfiguration c
    JOIN wf.WorkflowActivity a ON a.ActivityId = c.ActivityId
    WHERE a.WorkflowVersionId = @VersionId;

    SELECT l.ApprovalLevelId, l.ApprovalConfigId, l.LevelNo, l.LevelName, l.ExecutionMode, l.MinApprovals, l.SlaHours
    FROM wf.ApprovalLevel l
    JOIN wf.ApprovalConfiguration c ON c.ApprovalConfigId = l.ApprovalConfigId
    JOIN wf.WorkflowActivity a ON a.ActivityId = c.ActivityId
    WHERE a.WorkflowVersionId = @VersionId
    ORDER BY l.ApprovalConfigId, l.LevelNo;

    SELECT r.ApprovalLevelId, r.RoleCode, r.GroupName, r.SequenceNo
    FROM wf.ApprovalLevelRole r
    JOIN wf.ApprovalLevel l ON l.ApprovalLevelId = r.ApprovalLevelId
    JOIN wf.ApprovalConfiguration c ON c.ApprovalConfigId = l.ApprovalConfigId
    JOIN wf.WorkflowActivity a ON a.ActivityId = c.ActivityId
    WHERE a.WorkflowVersionId = @VersionId
    ORDER BY r.ApprovalLevelId, r.SequenceNo, r.RoleCode;

    SELECT c.ConnectionId, c.WorkflowVersionId, f.ActivityKey AS FromActivityKey, t.ActivityKey AS ToActivityKey,
           c.ConnectionType, c.ConditionExpression, c.IsDefault, c.Label, c.Priority
    FROM wf.ActivityConnection c
    JOIN wf.WorkflowActivity f ON f.ActivityId = c.FromActivityId
    JOIN wf.WorkflowActivity t ON t.ActivityId = c.ToActivityId
    WHERE c.WorkflowVersionId = @VersionId
    ORDER BY c.ConnectionId;

    SELECT ParameterId, WorkflowVersionId, Direction, Name, DataType, IsMandatory, DefaultValue, JsonSchema, Description,
           SourceType, SourceReference, SortOrder, RowVer
    FROM wf.WorkflowParameter
    WHERE WorkflowVersionId = @VersionId
    ORDER BY Direction, SortOrder, Name;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_Workflow_Create
    @TemplateCode       NVARCHAR(50),
    @SourceSystemId     INT,
    @ModuleId           INT,
    @WorkflowName       NVARCHAR(200),
    @Description        NVARCHAR(2000),
    @ChangeNotes        NVARCHAR(2000),
    @UserName           NVARCHAR(256),
    @CorrelationId      NVARCHAR(100) = NULL,
    @ClientIp           NVARCHAR(64)  = NULL,
    @WorkflowTemplateId INT OUTPUT,
    @WorkflowVersionId  INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF NOT EXISTS (SELECT 1 FROM wf.SourceSystemModule WHERE ModuleId = @ModuleId AND SourceSystemId = @SourceSystemId AND Status = N'Active')
        THROW 51400, N'Module does not belong to the source system or is inactive.', 1;

    IF EXISTS (SELECT 1 FROM wf.WorkflowTemplate WHERE TemplateCode = @TemplateCode)
        THROW 51409, N'Template code already exists.', 1;

    BEGIN TRANSACTION;

    INSERT wf.WorkflowTemplate (TemplateCode, SourceSystemId, ModuleId, WorkflowName, Description, LatestVersionNo, CreatedBy)
    VALUES (@TemplateCode, @SourceSystemId, @ModuleId, @WorkflowName, @Description, 1, @UserName);
    SET @WorkflowTemplateId = CAST(SCOPE_IDENTITY() AS INT);

    INSERT wf.WorkflowVersion (WorkflowTemplateId, VersionNo, Status, ChangeNotes, CreatedBy)
    VALUES (@WorkflowTemplateId, 1, N'Draft', @ChangeNotes, @UserName);
    SET @WorkflowVersionId = CAST(SCOPE_IDENTITY() AS INT);

    DECLARE @Details NVARCHAR(MAX) = (SELECT @TemplateCode AS templateCode, @WorkflowName AS workflowName, 1 AS versionNo FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    DECLARE @EntityId NVARCHAR(50) = CAST(@WorkflowTemplateId AS NVARCHAR(50));
    EXEC wf.usp_Internal_WriteAudit N'WorkflowTemplate', @EntityId, N'Created', @UserName, @CorrelationId, @ClientIp, @Details;

    COMMIT TRANSACTION;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_Workflow_UpdateHeader
    @WorkflowTemplateId INT,
    @WorkflowName       NVARCHAR(200),
    @Description        NVARCHAR(2000),
    @ChangeNotes        NVARCHAR(2000),
    @RowVersion         BINARY(8),
    @UserName           NVARCHAR(256),
    @CorrelationId      NVARCHAR(100) = NULL,
    @ClientIp           NVARCHAR(64)  = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRANSACTION;

    UPDATE wf.WorkflowTemplate
    SET WorkflowName = @WorkflowName,
        Description  = @Description,
        ModifiedBy   = @UserName,
        ModifiedOn   = SYSUTCDATETIME()
    WHERE WorkflowTemplateId = @WorkflowTemplateId
      AND RowVer = @RowVersion;

    IF @@ROWCOUNT = 0
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM wf.WorkflowTemplate WHERE WorkflowTemplateId = @WorkflowTemplateId)
            THROW 51404, N'Workflow template not found.', 1;
        THROW 51410, N'The workflow was modified by another user. Reload and try again.', 1;
    END

    -- Change notes belong to the open draft (if any).
    UPDATE wf.WorkflowVersion
    SET ChangeNotes = @ChangeNotes
    WHERE WorkflowTemplateId = @WorkflowTemplateId
      AND Status IN (N'Draft', N'Validated')
      AND ISNULL(ChangeNotes, N'') <> ISNULL(@ChangeNotes, N'');

    DECLARE @Details NVARCHAR(MAX) = (SELECT @WorkflowName AS workflowName FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    DECLARE @EntityId NVARCHAR(50) = CAST(@WorkflowTemplateId AS NVARCHAR(50));
    EXEC wf.usp_Internal_WriteAudit N'WorkflowTemplate', @EntityId, N'HeaderUpdated', @UserName, @CorrelationId, @ClientIp, @Details;

    COMMIT TRANSACTION;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_WorkflowVersion_Create
    @WorkflowTemplateId INT,
    @BasedOnVersionNo   INT,
    @ChangeNotes        NVARCHAR(2000),
    @UserName           NVARCHAR(256),
    @CorrelationId      NVARCHAR(100) = NULL,
    @ClientIp           NVARCHAR(64)  = NULL,
    @NewVersionNo       INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRANSACTION;

    DECLARE @SourceVersionId INT, @Latest INT, @TemplateStatus NVARCHAR(20);

    SELECT @Latest = LatestVersionNo, @TemplateStatus = Status
    FROM wf.WorkflowTemplate WITH (UPDLOCK, HOLDLOCK)
    WHERE WorkflowTemplateId = @WorkflowTemplateId;

    IF @Latest IS NULL
        THROW 51404, N'Workflow template not found.', 1;
    IF @TemplateStatus <> N'Active'
        THROW 51409, N'The workflow template is deactivated.', 1;
    IF EXISTS (SELECT 1 FROM wf.WorkflowVersion WHERE WorkflowTemplateId = @WorkflowTemplateId AND Status IN (N'Draft', N'Validated'))
        THROW 51409, N'An open draft version already exists.', 1;

    SELECT @SourceVersionId = WorkflowVersionId
    FROM wf.WorkflowVersion
    WHERE WorkflowTemplateId = @WorkflowTemplateId AND VersionNo = @BasedOnVersionNo;

    IF @SourceVersionId IS NULL
        THROW 51404, N'Base version not found.', 1;

    SET @NewVersionNo = @Latest + 1;

    INSERT wf.WorkflowVersion (WorkflowTemplateId, VersionNo, Status, ChangeNotes, BasedOnVersionNo, CreatedBy)
    VALUES (@WorkflowTemplateId, @NewVersionNo, N'Draft', @ChangeNotes, @BasedOnVersionNo, @UserName);

    DECLARE @NewVersionId INT = CAST(SCOPE_IDENTITY() AS INT);
    EXEC wf.usp_Internal_CopyVersionGraph @SourceVersionId, @NewVersionId, @UserName;

    UPDATE wf.WorkflowTemplate
    SET LatestVersionNo = @NewVersionNo, ModifiedBy = @UserName, ModifiedOn = SYSUTCDATETIME()
    WHERE WorkflowTemplateId = @WorkflowTemplateId;

    DECLARE @Details NVARCHAR(MAX) = (SELECT @NewVersionNo AS versionNo, @BasedOnVersionNo AS basedOnVersionNo, @ChangeNotes AS changeNotes FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    DECLARE @EntityId NVARCHAR(50) = CAST(@WorkflowTemplateId AS NVARCHAR(50));
    EXEC wf.usp_Internal_WriteAudit N'WorkflowTemplate', @EntityId, N'VersionCreated', @UserName, @CorrelationId, @ClientIp, @Details;

    COMMIT TRANSACTION;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_Workflow_Clone
    @SourceTemplateId INT,
    @FromVersionNo    INT,
    @NewTemplateCode  NVARCHAR(50),
    @WorkflowName     NVARCHAR(200),
    @SourceSystemId   INT,
    @ModuleId         INT,
    @UserName         NVARCHAR(256),
    @CorrelationId    NVARCHAR(100) = NULL,
    @ClientIp         NVARCHAR(64)  = NULL,
    @NewTemplateId    INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @SourceVersionId INT, @Description NVARCHAR(2000);

    SELECT @SourceVersionId = v.WorkflowVersionId, @Description = t.Description
    FROM wf.WorkflowVersion v
    JOIN wf.WorkflowTemplate t ON t.WorkflowTemplateId = v.WorkflowTemplateId
    WHERE v.WorkflowTemplateId = @SourceTemplateId AND v.VersionNo = @FromVersionNo;

    IF @SourceVersionId IS NULL
        THROW 51404, N'Source workflow version not found.', 1;
    IF EXISTS (SELECT 1 FROM wf.WorkflowTemplate WHERE TemplateCode = @NewTemplateCode)
        THROW 51409, N'Template code already exists.', 1;
    IF NOT EXISTS (SELECT 1 FROM wf.SourceSystemModule WHERE ModuleId = @ModuleId AND SourceSystemId = @SourceSystemId AND Status = N'Active')
        THROW 51400, N'Module does not belong to the source system or is inactive.', 1;

    BEGIN TRANSACTION;

    INSERT wf.WorkflowTemplate (TemplateCode, SourceSystemId, ModuleId, WorkflowName, Description, LatestVersionNo, ClonedFromTemplateId, CreatedBy)
    VALUES (@NewTemplateCode, @SourceSystemId, @ModuleId, @WorkflowName, @Description, 1, @SourceTemplateId, @UserName);
    SET @NewTemplateId = CAST(SCOPE_IDENTITY() AS INT);

    DECLARE @Notes NVARCHAR(2000) = CONCAT(N'Cloned from template ', @SourceTemplateId, N' version ', @FromVersionNo);
    INSERT wf.WorkflowVersion (WorkflowTemplateId, VersionNo, Status, ChangeNotes, CreatedBy)
    VALUES (@NewTemplateId, 1, N'Draft', @Notes, @UserName);

    DECLARE @NewVersionId INT = CAST(SCOPE_IDENTITY() AS INT);
    EXEC wf.usp_Internal_CopyVersionGraph @SourceVersionId, @NewVersionId, @UserName;

    DECLARE @Details NVARCHAR(MAX) = (SELECT @NewTemplateCode AS templateCode, @SourceTemplateId AS clonedFromTemplateId, @FromVersionNo AS clonedFromVersionNo FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    DECLARE @EntityId NVARCHAR(50) = CAST(@NewTemplateId AS NVARCHAR(50));
    EXEC wf.usp_Internal_WriteAudit N'WorkflowTemplate', @EntityId, N'Cloned', @UserName, @CorrelationId, @ClientIp, @Details;
    SET @EntityId = CAST(@SourceTemplateId AS NVARCHAR(50));
    EXEC wf.usp_Internal_WriteAudit N'WorkflowTemplate', @EntityId, N'ClonedTo', @UserName, @CorrelationId, @ClientIp, @Details;

    COMMIT TRANSACTION;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_WorkflowVersion_SaveValidation
    @WorkflowVersionId INT,
    @IsValid           BIT,
    @ReportJson        NVARCHAR(MAX),
    @UserName          NVARCHAR(256),
    @CorrelationId     NVARCHAR(100) = NULL,
    @ClientIp          NVARCHAR(64)  = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRANSACTION;

    DECLARE @TemplateId INT;
    EXEC wf.usp_Internal_AssertVersionEditable @WorkflowVersionId, @TemplateId OUTPUT;

    -- Validation does not count as a content change (ModifiedBy is not touched).
    UPDATE wf.WorkflowVersion
    SET Status               = CASE WHEN @IsValid = 1 THEN N'Validated' ELSE N'Draft' END,
        ValidationResultJson = @ReportJson,
        ValidatedOn          = SYSUTCDATETIME(),
        ValidatedBy          = @UserName
    WHERE WorkflowVersionId = @WorkflowVersionId;

    DECLARE @Details NVARCHAR(MAX) = (SELECT VersionNo AS versionNo, CAST(@IsValid AS BIT) AS isValid FROM wf.WorkflowVersion WHERE WorkflowVersionId = @WorkflowVersionId FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    DECLARE @EntityId NVARCHAR(50) = CAST(@TemplateId AS NVARCHAR(50));
    EXEC wf.usp_Internal_WriteAudit N'WorkflowTemplate', @EntityId, N'Validated', @UserName, @CorrelationId, @ClientIp, @Details;

    COMMIT TRANSACTION;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_WorkflowVersion_Publish
    @WorkflowVersionId  INT,
    @ExpectedRowVersion BINARY(8),
    @DefinitionJson     NVARCHAR(MAX),
    @DefinitionHash     CHAR(64),
    @Comments           NVARCHAR(2000),
    @UserName           NVARCHAR(256),
    @CorrelationId      NVARCHAR(100) = NULL,
    @ClientIp           NVARCHAR(64)  = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF ISJSON(@DefinitionJson) = 0
        THROW 51400, N'Definition is not valid JSON.', 1;

    BEGIN TRANSACTION;

    DECLARE @TemplateId INT, @VersionNo INT;
    EXEC wf.usp_Internal_AssertVersionEditable @WorkflowVersionId, @TemplateId OUTPUT;

    SELECT @VersionNo = VersionNo FROM wf.WorkflowVersion WHERE WorkflowVersionId = @WorkflowVersionId;

    IF NOT EXISTS (SELECT 1 FROM wf.WorkflowVersion WHERE WorkflowVersionId = @WorkflowVersionId AND RowVer = @ExpectedRowVersion)
        THROW 51410, N'The draft changed after it was validated for publishing. Reload and try again.', 1;

    -- Supersede the currently published version first (filtered unique index allows one Published per template).
    UPDATE wf.WorkflowVersion
    SET Status = N'Superseded'
    WHERE WorkflowTemplateId = @TemplateId AND Status = N'Published';

    UPDATE wf.WorkflowVersion
    SET Status          = N'Published',
        DefinitionJson  = @DefinitionJson,
        DefinitionHash  = @DefinitionHash,
        PublishComments = @Comments,
        PublishedOn     = SYSUTCDATETIME(),
        PublishedBy     = @UserName
    WHERE WorkflowVersionId = @WorkflowVersionId;

    UPDATE wf.WorkflowTemplate
    SET PublishedVersionNo = @VersionNo, ModifiedBy = @UserName, ModifiedOn = SYSUTCDATETIME()
    WHERE WorkflowTemplateId = @TemplateId;

    DECLARE @Details NVARCHAR(MAX) = (SELECT @VersionNo AS versionNo, @DefinitionHash AS definitionHash, @Comments AS comments FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    DECLARE @EntityId NVARCHAR(50) = CAST(@TemplateId AS NVARCHAR(50));
    EXEC wf.usp_Internal_WriteAudit N'WorkflowTemplate', @EntityId, N'Published', @UserName, @CorrelationId, @ClientIp, @Details;

    COMMIT TRANSACTION;

    SELECT t.WorkflowTemplateId, t.TemplateCode, v.VersionNo, v.DefinitionHash, v.PublishedOn, v.PublishedBy
    FROM wf.WorkflowVersion v
    JOIN wf.WorkflowTemplate t ON t.WorkflowTemplateId = v.WorkflowTemplateId
    WHERE v.WorkflowVersionId = @WorkflowVersionId;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_Workflow_SetStatus
    @WorkflowTemplateId INT,
    @Status             NVARCHAR(20),
    @Reason             NVARCHAR(1000),
    @UserName           NVARCHAR(256),
    @CorrelationId      NVARCHAR(100) = NULL,
    @ClientIp           NVARCHAR(64)  = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRANSACTION;

    UPDATE wf.WorkflowTemplate
    SET Status = @Status, ModifiedBy = @UserName, ModifiedOn = SYSUTCDATETIME()
    WHERE WorkflowTemplateId = @WorkflowTemplateId;

    IF @@ROWCOUNT = 0
        THROW 51404, N'Workflow template not found.', 1;

    DECLARE @Details NVARCHAR(MAX) = (SELECT @Status AS status, @Reason AS reason FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    DECLARE @EntityId NVARCHAR(50) = CAST(@WorkflowTemplateId AS NVARCHAR(50));
    DECLARE @Action NVARCHAR(50) = CASE WHEN @Status = N'Active' THEN N'Activated' ELSE N'Deactivated' END;
    EXEC wf.usp_Internal_WriteAudit N'WorkflowTemplate', @EntityId, @Action, @UserName, @CorrelationId, @ClientIp, @Details;

    COMMIT TRANSACTION;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_WorkflowVersion_GetDefinition
    @WorkflowTemplateId INT,
    @VersionNo          INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT v.DefinitionJson
    FROM wf.WorkflowVersion v
    JOIN wf.WorkflowTemplate t ON t.WorkflowTemplateId = v.WorkflowTemplateId
    WHERE v.WorkflowTemplateId = @WorkflowTemplateId
      AND v.VersionNo = COALESCE(@VersionNo, t.PublishedVersionNo)
      AND v.Status IN (N'Published', N'Superseded');
END
GO

CREATE OR ALTER PROCEDURE wf.usp_Dashboard_Get
    @RestrictToIds BIT = 0,
    @AllowedIds    wf.IntListType READONLY
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        (SELECT COUNT(*) FROM wf.SourceSystem s WHERE @RestrictToIds = 0 OR s.SourceSystemId IN (SELECT Id FROM @AllowedIds)) AS SourceSystemCount,
        (SELECT COUNT(*) FROM wf.WorkflowTemplate t WHERE @RestrictToIds = 0 OR t.SourceSystemId IN (SELECT Id FROM @AllowedIds)) AS TemplateCount,
        (SELECT COUNT(*) FROM wf.WorkflowVersion v JOIN wf.WorkflowTemplate t ON t.WorkflowTemplateId = v.WorkflowTemplateId
            WHERE v.Status IN (N'Draft', N'Validated') AND (@RestrictToIds = 0 OR t.SourceSystemId IN (SELECT Id FROM @AllowedIds))) AS DraftVersionCount,
        (SELECT COUNT(*) FROM wf.WorkflowTemplate t WHERE t.PublishedVersionNo IS NOT NULL AND (@RestrictToIds = 0 OR t.SourceSystemId IN (SELECT Id FROM @AllowedIds))) AS PublishedTemplateCount,
        (SELECT COUNT(*) FROM wf.WorkflowTemplate t WHERE t.Status = N'Inactive' AND (@RestrictToIds = 0 OR t.SourceSystemId IN (SELECT Id FROM @AllowedIds))) AS InactiveTemplateCount,
        (SELECT COUNT(*) FROM wf.SchedulerConfiguration c WHERE @RestrictToIds = 0 OR c.SourceSystemId IN (SELECT Id FROM @AllowedIds)) AS SchedulerCount;

    SELECT TOP (15) a.AuditLogId, a.EntityType, a.EntityId, a.Action, a.UserName, a.ActionOn, a.CorrelationId, a.ClientIp, a.Details
    FROM wf.AuditLog a
    WHERE @RestrictToIds = 0
       OR (a.EntityType = N'WorkflowTemplate' AND EXISTS (SELECT 1 FROM wf.WorkflowTemplate t
               WHERE CAST(t.WorkflowTemplateId AS NVARCHAR(50)) = a.EntityId AND t.SourceSystemId IN (SELECT Id FROM @AllowedIds)))
       OR (a.EntityType = N'SourceSystem' AND a.EntityId IN (SELECT CAST(Id AS NVARCHAR(50)) FROM @AllowedIds))
    ORDER BY a.ActionOn DESC, a.AuditLogId DESC;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_AuditLog_Get
    @EntityType NVARCHAR(50) = NULL,
    @EntityId   NVARCHAR(50) = NULL,
    @MaxRows    INT          = 200
AS
BEGIN
    SET NOCOUNT ON;
    SELECT TOP (@MaxRows) AuditLogId, EntityType, EntityId, Action, UserName, ActionOn, CorrelationId, ClientIp, Details
    FROM wf.AuditLog
    WHERE (@EntityType IS NULL OR EntityType = @EntityType)
      AND (@EntityId IS NULL OR EntityId = @EntityId)
    ORDER BY ActionOn DESC, AuditLogId DESC;
END
GO
