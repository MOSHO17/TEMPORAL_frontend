/* =============================================================================
   BankWorkflowDesigner - 09 Scheduler configuration (metadata only - Quartz.NET executes elsewhere)
   ============================================================================= */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE wf.usp_Scheduler_Get
    @SchedulerConfigId INT = NULL,
    @RestrictToIds     BIT = 0,
    @AllowedIds        wf.IntListType READONLY
AS
BEGIN
    SET NOCOUNT ON;
    SELECT c.SchedulerConfigId, c.SchedulerCode, c.SourceSystemId, c.SchedulerName, c.Description, c.ApprovedQueryId,
           q.QueryCode AS ApprovedQueryCode, c.CronExpression, c.TimeZoneId, c.TargetWorkflowTemplateId, t.TemplateCode AS TargetTemplateCode,
           c.TargetVersionPolicy, c.PinnedVersionNo, c.ExecutionParametersJson, c.MisfirePolicy, c.MaxConcurrentRuns,
           c.EffectiveFrom, c.EffectiveTo, c.IsActive, c.CreatedBy, c.CreatedOn, c.ModifiedBy, c.ModifiedOn, c.RowVer
    FROM wf.SchedulerConfiguration c
    JOIN wf.ApprovedOracleQuery q ON q.ApprovedQueryId = c.ApprovedQueryId
    JOIN wf.WorkflowTemplate t ON t.WorkflowTemplateId = c.TargetWorkflowTemplateId
    WHERE (@SchedulerConfigId IS NULL OR c.SchedulerConfigId = @SchedulerConfigId)
      AND (@RestrictToIds = 0 OR c.SourceSystemId IN (SELECT Id FROM @AllowedIds))
    ORDER BY c.SchedulerCode;
END
GO

CREATE OR ALTER PROCEDURE wf.usp_Scheduler_Save
    @SchedulerConfigId        INT = NULL,     -- NULL = insert
    @SchedulerCode            NVARCHAR(50),
    @SourceSystemId           INT,
    @SchedulerName            NVARCHAR(200),
    @Description              NVARCHAR(1000),
    @ApprovedQueryId          INT,
    @CronExpression           NVARCHAR(120),
    @TimeZoneId               NVARCHAR(100),
    @TargetWorkflowTemplateId INT,
    @TargetVersionPolicy      NVARCHAR(20),
    @PinnedVersionNo          INT,
    @ExecutionParametersJson  NVARCHAR(MAX),
    @MisfirePolicy            NVARCHAR(20),
    @MaxConcurrentRuns        INT,
    @EffectiveFrom            DATETIME2(0),
    @EffectiveTo              DATETIME2(0),
    @IsActive                 BIT,
    @RowVersion               BINARY(8) = NULL,
    @UserName                 NVARCHAR(256),
    @CorrelationId            NVARCHAR(100) = NULL,
    @ClientIp                 NVARCHAR(64)  = NULL,
    @SavedSchedulerConfigId   INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF NOT EXISTS (SELECT 1 FROM wf.ApprovedOracleQuery WHERE ApprovedQueryId = @ApprovedQueryId AND IsActive = 1
                   AND (SourceSystemId IS NULL OR SourceSystemId = @SourceSystemId))
        THROW 51400, N'Only active approved Oracle queries of this source system can be scheduled.', 1;

    IF NOT EXISTS (SELECT 1 FROM wf.WorkflowTemplate WHERE WorkflowTemplateId = @TargetWorkflowTemplateId AND SourceSystemId = @SourceSystemId)
        THROW 51400, N'Target workflow must belong to the same source system.', 1;

    BEGIN TRANSACTION;

    IF @SchedulerConfigId IS NULL
    BEGIN
        IF EXISTS (SELECT 1 FROM wf.SchedulerConfiguration WHERE SchedulerCode = @SchedulerCode)
            THROW 51409, N'Scheduler code already exists.', 1;

        INSERT wf.SchedulerConfiguration (SchedulerCode, SourceSystemId, SchedulerName, Description, ApprovedQueryId, CronExpression, TimeZoneId,
            TargetWorkflowTemplateId, TargetVersionPolicy, PinnedVersionNo, ExecutionParametersJson, MisfirePolicy, MaxConcurrentRuns,
            EffectiveFrom, EffectiveTo, IsActive, CreatedBy)
        VALUES (@SchedulerCode, @SourceSystemId, @SchedulerName, @Description, @ApprovedQueryId, @CronExpression, @TimeZoneId,
            @TargetWorkflowTemplateId, @TargetVersionPolicy, @PinnedVersionNo, @ExecutionParametersJson, @MisfirePolicy, @MaxConcurrentRuns,
            @EffectiveFrom, @EffectiveTo, @IsActive, @UserName);
        SET @SavedSchedulerConfigId = CAST(SCOPE_IDENTITY() AS INT);
    END
    ELSE
    BEGIN
        UPDATE wf.SchedulerConfiguration
        SET SourceSystemId = @SourceSystemId, SchedulerName = @SchedulerName, Description = @Description, ApprovedQueryId = @ApprovedQueryId,
            CronExpression = @CronExpression, TimeZoneId = @TimeZoneId, TargetWorkflowTemplateId = @TargetWorkflowTemplateId,
            TargetVersionPolicy = @TargetVersionPolicy, PinnedVersionNo = @PinnedVersionNo, ExecutionParametersJson = @ExecutionParametersJson,
            MisfirePolicy = @MisfirePolicy, MaxConcurrentRuns = @MaxConcurrentRuns, EffectiveFrom = @EffectiveFrom, EffectiveTo = @EffectiveTo,
            IsActive = @IsActive, ModifiedBy = @UserName, ModifiedOn = SYSUTCDATETIME()
        WHERE SchedulerConfigId = @SchedulerConfigId AND RowVer = @RowVersion;

        IF @@ROWCOUNT = 0
        BEGIN
            IF NOT EXISTS (SELECT 1 FROM wf.SchedulerConfiguration WHERE SchedulerConfigId = @SchedulerConfigId)
                THROW 51404, N'Scheduler configuration not found.', 1;
            THROW 51410, N'The scheduler configuration was modified by another user. Reload and try again.', 1;
        END
        SET @SavedSchedulerConfigId = @SchedulerConfigId;
    END

    DECLARE @Details NVARCHAR(MAX) = (SELECT @SchedulerCode AS schedulerCode, @CronExpression AS cron, @ApprovedQueryId AS approvedQueryId,
        @TargetWorkflowTemplateId AS targetWorkflowTemplateId, CAST(@IsActive AS BIT) AS isActive FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    DECLARE @EntityId NVARCHAR(50) = CAST(@SavedSchedulerConfigId AS NVARCHAR(50));
    DECLARE @Action NVARCHAR(50) = CASE WHEN @SchedulerConfigId IS NULL THEN N'Created' ELSE N'Updated' END;
    EXEC wf.usp_Internal_WriteAudit N'SchedulerConfiguration', @EntityId, @Action, @UserName, @CorrelationId, @ClientIp, @Details;

    COMMIT TRANSACTION;
END
GO
