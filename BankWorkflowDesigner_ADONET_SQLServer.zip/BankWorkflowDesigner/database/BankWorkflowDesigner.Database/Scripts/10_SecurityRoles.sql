/* =============================================================================
   BankWorkflowDesigner - 10 Database security
   The application login gets EXECUTE on the wf schema only - no direct table access.
   Replace the login names with the service accounts used in each environment.
   ============================================================================= */
IF DATABASE_PRINCIPAL_ID(N'wf_app_executor') IS NULL
    CREATE ROLE wf_app_executor AUTHORIZATION dbo;
GO

GRANT EXECUTE ON SCHEMA::wf TO wf_app_executor;
DENY INSERT, UPDATE, DELETE ON SCHEMA::wf TO wf_app_executor;
GO

GRANT EXECUTE ON TYPE::wf.IntListType TO wf_app_executor;
GRANT EXECUTE ON TYPE::wf.ModuleTableType TO wf_app_executor;
GRANT EXECUTE ON TYPE::wf.SourceSystemUserTableType TO wf_app_executor;
GRANT EXECUTE ON TYPE::wf.ParameterTableType TO wf_app_executor;
GRANT EXECUTE ON TYPE::wf.ApprovalLevelTableType TO wf_app_executor;
GRANT EXECUTE ON TYPE::wf.ApprovalLevelRoleTableType TO wf_app_executor;
GRANT EXECUTE ON TYPE::wf.ActivityPositionTableType TO wf_app_executor;
GO

/* Example (run per environment):
   CREATE USER [BANK\svc_wfdesigner_api] FOR LOGIN [BANK\svc_wfdesigner_api];
   ALTER ROLE wf_app_executor ADD MEMBER [BANK\svc_wfdesigner_api];
*/
