/* =============================================================================
   BankWorkflowDesigner - 05 Internal helper procedures
   Error numbers raised by this database (mapped by the API):
     51400 validation   51403 forbidden   51404 not found
     51409 conflict     51410 concurrency 51411 version immutable   51412 audit append-only
   ============================================================================= */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE wf.usp_Internal_WriteAudit
    @EntityType    NVARCHAR(50),
    @EntityId      NVARCHAR(50),
    @Action        NVARCHAR(50),
    @UserName      NVARCHAR(256),
    @CorrelationId NVARCHAR(100) = NULL,
    @ClientIp      NVARCHAR(64)  = NULL,
    @Details       NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    INSERT wf.AuditLog (EntityType, EntityId, Action, UserName, CorrelationId, ClientIp, Details)
    VALUES (@EntityType, @EntityId, @Action, @UserName, @CorrelationId, @ClientIp,
            CASE WHEN @Details IS NULL OR ISJSON(@Details) = 1 THEN @Details ELSE (SELECT @Details AS [message] FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) END);
END
GO

/* Throws unless the version exists and is editable (Draft / Validated). Returns the template id. */
CREATE OR ALTER PROCEDURE wf.usp_Internal_AssertVersionEditable
    @WorkflowVersionId  INT,
    @WorkflowTemplateId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Status NVARCHAR(20);

    SELECT @Status = Status, @WorkflowTemplateId = WorkflowTemplateId
    FROM wf.WorkflowVersion WITH (UPDLOCK, HOLDLOCK)
    WHERE WorkflowVersionId = @WorkflowVersionId;

    IF @Status IS NULL
        THROW 51404, N'Workflow version not found.', 1;

    IF @Status NOT IN (N'Draft', N'Validated')
        THROW 51411, N'Published or superseded workflow versions are immutable. Create a new version to make changes.', 1;

    IF EXISTS (SELECT 1 FROM wf.WorkflowTemplate WHERE WorkflowTemplateId = @WorkflowTemplateId AND Status <> N'Active')
        THROW 51409, N'The workflow template is deactivated.', 1;
END
GO

/* Records a content change on a draft: last modifier (four-eyes rule) and resets Validated -> Draft. */
CREATE OR ALTER PROCEDURE wf.usp_Internal_TouchVersion
    @WorkflowVersionId INT,
    @UserName          NVARCHAR(256)
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE wf.WorkflowVersion
    SET ModifiedBy = @UserName,
        ModifiedOn = SYSUTCDATETIME(),
        Status     = N'Draft'
    WHERE WorkflowVersionId = @WorkflowVersionId
      AND Status IN (N'Draft', N'Validated');
END
GO

/* Deep copy of a version graph (activities, parameters, approvals, connections, workflow parameters). */
CREATE OR ALTER PROCEDURE wf.usp_Internal_CopyVersionGraph
    @SourceVersionId INT,
    @TargetVersionId INT,
    @UserName        NVARCHAR(256)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @ActivityMap TABLE (OldId INT NOT NULL PRIMARY KEY, NewId INT NOT NULL);

    -- MERGE is used only to capture the old->new identity mapping via OUTPUT.
    MERGE wf.WorkflowActivity AS target
    USING (SELECT * FROM wf.WorkflowActivity WHERE WorkflowVersionId = @SourceVersionId) AS src
    ON 1 = 0
    WHEN NOT MATCHED THEN
        INSERT (WorkflowVersionId, ActivityKey, ActivityType, DisplayName, Description, PositionX, PositionY,
                TimeoutSeconds, RetryMaxAttempts, RetryInitialIntervalSeconds, RetryBackoffCoefficient, RetryMaxIntervalSeconds,
                NonRetryableErrorsJson, ErrorHandling, ErrorRouteActivityKey, ExecutionCondition, ConfigJson, CreatedBy)
        VALUES (@TargetVersionId, src.ActivityKey, src.ActivityType, src.DisplayName, src.Description, src.PositionX, src.PositionY,
                src.TimeoutSeconds, src.RetryMaxAttempts, src.RetryInitialIntervalSeconds, src.RetryBackoffCoefficient, src.RetryMaxIntervalSeconds,
                src.NonRetryableErrorsJson, src.ErrorHandling, src.ErrorRouteActivityKey, src.ExecutionCondition, src.ConfigJson, @UserName)
    OUTPUT src.ActivityId, inserted.ActivityId INTO @ActivityMap (OldId, NewId);

    INSERT wf.ActivityParameter (ActivityId, Direction, Name, DataType, IsMandatory, DefaultValue, JsonSchema, Description, SourceType, SourceReference, SortOrder)
    SELECT m.NewId, p.Direction, p.Name, p.DataType, p.IsMandatory, p.DefaultValue, p.JsonSchema, p.Description, p.SourceType, p.SourceReference, p.SortOrder
    FROM wf.ActivityParameter p
    JOIN @ActivityMap m ON m.OldId = p.ActivityId;

    DECLARE @ConfigMap TABLE (OldId INT NOT NULL PRIMARY KEY, NewId INT NOT NULL);

    MERGE wf.ApprovalConfiguration AS target
    USING (SELECT c.*, m.NewId AS NewActivityId
           FROM wf.ApprovalConfiguration c
           JOIN @ActivityMap m ON m.OldId = c.ActivityId) AS src
    ON 1 = 0
    WHEN NOT MATCHED THEN
        INSERT (ActivityId, ApprovalPolicy, QuorumCount, RejectionRouting, RejectionTargetActivityKey, SlaHours, EscalationAfterHours,
                EscalationRole, ReminderIntervalHours, AllowDelegation, EnforceMakerCheckerSegregation, ModifiedBy)
        VALUES (src.NewActivityId, src.ApprovalPolicy, src.QuorumCount, src.RejectionRouting, src.RejectionTargetActivityKey, src.SlaHours,
                src.EscalationAfterHours, src.EscalationRole, src.ReminderIntervalHours, src.AllowDelegation, src.EnforceMakerCheckerSegregation, @UserName)
    OUTPUT src.ApprovalConfigId, inserted.ApprovalConfigId INTO @ConfigMap (OldId, NewId);

    DECLARE @LevelMap TABLE (OldId INT NOT NULL PRIMARY KEY, NewId INT NOT NULL);

    MERGE wf.ApprovalLevel AS target
    USING (SELECT l.*, m.NewId AS NewConfigId
           FROM wf.ApprovalLevel l
           JOIN @ConfigMap m ON m.OldId = l.ApprovalConfigId) AS src
    ON 1 = 0
    WHEN NOT MATCHED THEN
        INSERT (ApprovalConfigId, LevelNo, LevelName, ExecutionMode, MinApprovals, SlaHours)
        VALUES (src.NewConfigId, src.LevelNo, src.LevelName, src.ExecutionMode, src.MinApprovals, src.SlaHours)
    OUTPUT src.ApprovalLevelId, inserted.ApprovalLevelId INTO @LevelMap (OldId, NewId);

    INSERT wf.ApprovalLevelRole (ApprovalLevelId, RoleCode, GroupName, SequenceNo)
    SELECT m.NewId, r.RoleCode, r.GroupName, r.SequenceNo
    FROM wf.ApprovalLevelRole r
    JOIN @LevelMap m ON m.OldId = r.ApprovalLevelId;

    INSERT wf.ActivityConnection (WorkflowVersionId, FromActivityId, ToActivityId, ConnectionType, ConditionExpression, IsDefault, Label, Priority, CreatedBy)
    SELECT @TargetVersionId, mf.NewId, mt.NewId, c.ConnectionType, c.ConditionExpression, c.IsDefault, c.Label, c.Priority, @UserName
    FROM wf.ActivityConnection c
    JOIN @ActivityMap mf ON mf.OldId = c.FromActivityId
    JOIN @ActivityMap mt ON mt.OldId = c.ToActivityId
    WHERE c.WorkflowVersionId = @SourceVersionId;

    INSERT wf.WorkflowParameter (WorkflowVersionId, Direction, Name, DataType, IsMandatory, DefaultValue, JsonSchema, Description, SourceType, SourceReference, SortOrder, CreatedBy)
    SELECT @TargetVersionId, Direction, Name, DataType, IsMandatory, DefaultValue, JsonSchema, Description, SourceType, SourceReference, SortOrder, @UserName
    FROM wf.WorkflowParameter
    WHERE WorkflowVersionId = @SourceVersionId;
END
GO
