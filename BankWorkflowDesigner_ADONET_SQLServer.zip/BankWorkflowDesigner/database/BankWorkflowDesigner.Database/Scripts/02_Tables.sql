/* =============================================================================
   BankWorkflowDesigner - 02 Schema, tables, constraints and indexes
   Idempotent: objects are created only when missing.
   ============================================================================= */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

IF SCHEMA_ID(N'wf') IS NULL EXEC(N'CREATE SCHEMA wf AUTHORIZATION dbo;');
GO

/* ---------------------------------------------------------------- Source systems */
IF OBJECT_ID(N'wf.SourceSystem', N'U') IS NULL
CREATE TABLE wf.SourceSystem
(
    SourceSystemId    INT IDENTITY(1,1)  NOT NULL CONSTRAINT PK_SourceSystem PRIMARY KEY,
    SystemCode        NVARCHAR(50)       NOT NULL,
    ApplicationName   NVARCHAR(200)      NOT NULL,
    Description       NVARCHAR(1000)     NULL,
    DefaultTaskQueue  NVARCHAR(200)      NOT NULL,
    Status            NVARCHAR(20)       NOT NULL CONSTRAINT DF_SourceSystem_Status DEFAULT (N'Active'),
    CreatedBy         NVARCHAR(256)      NOT NULL,
    CreatedOn         DATETIME2(3)       NOT NULL CONSTRAINT DF_SourceSystem_CreatedOn DEFAULT (SYSUTCDATETIME()),
    ModifiedBy        NVARCHAR(256)      NULL,
    ModifiedOn        DATETIME2(3)       NULL,
    RowVer            ROWVERSION         NOT NULL,
    CONSTRAINT UQ_SourceSystem_SystemCode UNIQUE (SystemCode),
    CONSTRAINT CK_SourceSystem_Status CHECK (Status IN (N'Active', N'Inactive')),
    CONSTRAINT CK_SourceSystem_Code CHECK (SystemCode NOT LIKE N'%[^A-Z0-9_-]%' COLLATE Latin1_General_BIN2 AND LEN(SystemCode) >= 2)
);
GO

IF OBJECT_ID(N'wf.SourceSystemModule', N'U') IS NULL
CREATE TABLE wf.SourceSystemModule
(
    ModuleId          INT IDENTITY(1,1)  NOT NULL CONSTRAINT PK_SourceSystemModule PRIMARY KEY,
    SourceSystemId    INT                NOT NULL CONSTRAINT FK_Module_SourceSystem REFERENCES wf.SourceSystem (SourceSystemId),
    ModuleCode        NVARCHAR(50)       NOT NULL,
    ModuleName        NVARCHAR(200)      NOT NULL,
    Description       NVARCHAR(1000)     NULL,
    Status            NVARCHAR(20)       NOT NULL CONSTRAINT DF_Module_Status DEFAULT (N'Active'),
    CreatedBy         NVARCHAR(256)      NOT NULL,
    CreatedOn         DATETIME2(3)       NOT NULL CONSTRAINT DF_Module_CreatedOn DEFAULT (SYSUTCDATETIME()),
    ModifiedBy        NVARCHAR(256)      NULL,
    ModifiedOn        DATETIME2(3)       NULL,
    RowVer            ROWVERSION         NOT NULL,
    CONSTRAINT UQ_Module_Code UNIQUE (SourceSystemId, ModuleCode),
    CONSTRAINT CK_Module_Status CHECK (Status IN (N'Active', N'Inactive'))
);
GO

IF OBJECT_ID(N'wf.SourceSystemUser', N'U') IS NULL
CREATE TABLE wf.SourceSystemUser
(
    SourceSystemUserId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_SourceSystemUser PRIMARY KEY,
    SourceSystemId     INT               NOT NULL CONSTRAINT FK_SSUser_SourceSystem REFERENCES wf.SourceSystem (SourceSystemId),
    UserPrincipal      NVARCHAR(256)     NOT NULL,
    DisplayName        NVARCHAR(200)     NULL,
    AccessRole         NVARCHAR(20)      NOT NULL,
    IsActive           BIT               NOT NULL CONSTRAINT DF_SSUser_IsActive DEFAULT (1),
    CreatedBy          NVARCHAR(256)     NOT NULL,
    CreatedOn          DATETIME2(3)      NOT NULL CONSTRAINT DF_SSUser_CreatedOn DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT UQ_SSUser UNIQUE (SourceSystemId, UserPrincipal, AccessRole),
    CONSTRAINT CK_SSUser_Role CHECK (AccessRole IN (N'Administrator', N'Designer', N'Reviewer', N'Publisher', N'Viewer'))
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_SSUser_Principal' AND object_id = OBJECT_ID(N'wf.SourceSystemUser'))
    CREATE INDEX IX_SSUser_Principal ON wf.SourceSystemUser (UserPrincipal) INCLUDE (SourceSystemId, AccessRole, IsActive);
GO

/* ---------------------------------------------------------------- Governed reference data */
IF OBJECT_ID(N'wf.ConnectionProfile', N'U') IS NULL
CREATE TABLE wf.ConnectionProfile
(
    ConnectionProfileId  INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ConnectionProfile PRIMARY KEY,
    ProfileCode          NVARCHAR(100)     NOT NULL,
    ProfileType          NVARCHAR(20)      NOT NULL,
    Description          NVARCHAR(1000)    NULL,
    -- Vault reference only (e.g. cyberark://safe/object or kv://vault/secret). NEVER a secret value.
    SecretStoreReference NVARCHAR(500)     NOT NULL,
    Environment          NVARCHAR(50)      NULL,
    SourceSystemId       INT               NULL CONSTRAINT FK_Profile_SourceSystem REFERENCES wf.SourceSystem (SourceSystemId),
    IsActive             BIT               NOT NULL CONSTRAINT DF_Profile_IsActive DEFAULT (1),
    CreatedBy            NVARCHAR(256)     NOT NULL CONSTRAINT DF_Profile_CreatedBy DEFAULT (SUSER_SNAME()),
    CreatedOn            DATETIME2(3)      NOT NULL CONSTRAINT DF_Profile_CreatedOn DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT UQ_ConnectionProfile_Code UNIQUE (ProfileCode),
    CONSTRAINT CK_ConnectionProfile_Type CHECK (ProfileType IN (N'Sftp', N'Api', N'Oracle')),
    CONSTRAINT CK_ConnectionProfile_Ref CHECK (SecretStoreReference LIKE N'%://%')
);
GO

IF OBJECT_ID(N'wf.ApprovedOracleQuery', N'U') IS NULL
CREATE TABLE wf.ApprovedOracleQuery
(
    ApprovedQueryId       INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ApprovedOracleQuery PRIMARY KEY,
    QueryCode             NVARCHAR(100)     NOT NULL,
    QueryName             NVARCHAR(200)     NOT NULL,
    Description           NVARCHAR(1000)    NULL,
    SourceSystemId        INT               NULL CONSTRAINT FK_Query_SourceSystem REFERENCES wf.SourceSystem (SourceSystemId),
    DataSourceProfileCode NVARCHAR(100)     NOT NULL,
    ParameterNamesJson    NVARCHAR(2000)    NOT NULL CONSTRAINT DF_Query_Params DEFAULT (N'[]'),
    -- The SQL text itself lives in the governed query repository owned by the DBA / data-governance
    -- team and is resolved by the execution service. The configuration portal never stores or runs SQL.
    ApprovedBy            NVARCHAR(256)     NULL,
    ApprovedOn            DATETIME2(3)      NULL,
    IsActive              BIT               NOT NULL CONSTRAINT DF_Query_IsActive DEFAULT (1),
    CONSTRAINT UQ_ApprovedOracleQuery_Code UNIQUE (QueryCode),
    CONSTRAINT CK_ApprovedOracleQuery_Params CHECK (ISJSON(ParameterNamesJson) = 1)
);
GO

/* ---------------------------------------------------------------- Workflow templates & versions */
IF OBJECT_ID(N'wf.WorkflowTemplate', N'U') IS NULL
CREATE TABLE wf.WorkflowTemplate
(
    WorkflowTemplateId   INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WorkflowTemplate PRIMARY KEY,
    TemplateCode         NVARCHAR(50)      NOT NULL,
    SourceSystemId       INT               NOT NULL CONSTRAINT FK_Template_SourceSystem REFERENCES wf.SourceSystem (SourceSystemId),
    ModuleId             INT               NOT NULL CONSTRAINT FK_Template_Module REFERENCES wf.SourceSystemModule (ModuleId),
    WorkflowName         NVARCHAR(200)     NOT NULL,
    Description          NVARCHAR(2000)    NULL,
    Status               NVARCHAR(20)      NOT NULL CONSTRAINT DF_Template_Status DEFAULT (N'Active'),
    LatestVersionNo      INT               NOT NULL CONSTRAINT DF_Template_Latest DEFAULT (1),
    PublishedVersionNo   INT               NULL,
    ClonedFromTemplateId INT               NULL CONSTRAINT FK_Template_ClonedFrom REFERENCES wf.WorkflowTemplate (WorkflowTemplateId),
    CreatedBy            NVARCHAR(256)     NOT NULL,
    CreatedOn            DATETIME2(3)      NOT NULL CONSTRAINT DF_Template_CreatedOn DEFAULT (SYSUTCDATETIME()),
    ModifiedBy           NVARCHAR(256)     NULL,
    ModifiedOn           DATETIME2(3)      NULL,
    RowVer               ROWVERSION        NOT NULL,
    CONSTRAINT UQ_WorkflowTemplate_Code UNIQUE (TemplateCode),
    CONSTRAINT CK_WorkflowTemplate_Status CHECK (Status IN (N'Active', N'Inactive'))
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Template_SourceModule' AND object_id = OBJECT_ID(N'wf.WorkflowTemplate'))
    CREATE INDEX IX_Template_SourceModule ON wf.WorkflowTemplate (SourceSystemId, ModuleId) INCLUDE (TemplateCode, WorkflowName, Status);
GO

IF OBJECT_ID(N'wf.WorkflowVersion', N'U') IS NULL
CREATE TABLE wf.WorkflowVersion
(
    WorkflowVersionId    INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WorkflowVersion PRIMARY KEY,
    WorkflowTemplateId   INT               NOT NULL CONSTRAINT FK_Version_Template REFERENCES wf.WorkflowTemplate (WorkflowTemplateId),
    VersionNo            INT               NOT NULL,
    Status               NVARCHAR(20)      NOT NULL CONSTRAINT DF_Version_Status DEFAULT (N'Draft'),
    ChangeNotes          NVARCHAR(2000)    NULL,
    BasedOnVersionNo     INT               NULL,
    ValidationResultJson NVARCHAR(MAX)     NULL,
    ValidatedOn          DATETIME2(3)      NULL,
    ValidatedBy          NVARCHAR(256)     NULL,
    DefinitionJson       NVARCHAR(MAX)     NULL,
    DefinitionHash       CHAR(64)          NULL,
    PublishComments      NVARCHAR(2000)    NULL,
    PublishedOn          DATETIME2(3)      NULL,
    PublishedBy          NVARCHAR(256)     NULL,
    CreatedBy            NVARCHAR(256)     NOT NULL,
    CreatedOn            DATETIME2(3)      NOT NULL CONSTRAINT DF_Version_CreatedOn DEFAULT (SYSUTCDATETIME()),
    ModifiedBy           NVARCHAR(256)     NULL,
    ModifiedOn           DATETIME2(3)      NULL,
    RowVer               ROWVERSION        NOT NULL,
    CONSTRAINT UQ_WorkflowVersion UNIQUE (WorkflowTemplateId, VersionNo),
    CONSTRAINT CK_WorkflowVersion_Status CHECK (Status IN (N'Draft', N'Validated', N'Published', N'Superseded', N'Deactivated')),
    CONSTRAINT CK_WorkflowVersion_Definition CHECK (DefinitionJson IS NULL OR ISJSON(DefinitionJson) = 1),
    CONSTRAINT CK_WorkflowVersion_Validation CHECK (ValidationResultJson IS NULL OR ISJSON(ValidationResultJson) = 1),
    CONSTRAINT CK_WorkflowVersion_PublishedHasDefinition CHECK (Status NOT IN (N'Published', N'Superseded') OR (DefinitionJson IS NOT NULL AND DefinitionHash IS NOT NULL))
);
GO

-- At most one open (editable) draft per template.
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_Version_OneOpenDraft' AND object_id = OBJECT_ID(N'wf.WorkflowVersion'))
    CREATE UNIQUE INDEX UX_Version_OneOpenDraft ON wf.WorkflowVersion (WorkflowTemplateId) WHERE Status IN (N'Draft', N'Validated');
GO
-- At most one current published version per template.
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_Version_OnePublished' AND object_id = OBJECT_ID(N'wf.WorkflowVersion'))
    CREATE UNIQUE INDEX UX_Version_OnePublished ON wf.WorkflowVersion (WorkflowTemplateId) WHERE Status = N'Published';
GO

/* ---------------------------------------------------------------- Activities & connections */
IF OBJECT_ID(N'wf.WorkflowActivity', N'U') IS NULL
CREATE TABLE wf.WorkflowActivity
(
    ActivityId                  INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WorkflowActivity PRIMARY KEY,
    WorkflowVersionId           INT               NOT NULL CONSTRAINT FK_Activity_Version REFERENCES wf.WorkflowVersion (WorkflowVersionId),
    ActivityKey                 NVARCHAR(100)     NOT NULL,
    ActivityType                NVARCHAR(50)      NOT NULL,
    DisplayName                 NVARCHAR(200)     NOT NULL,
    Description                 NVARCHAR(1000)    NULL,
    PositionX                   INT               NOT NULL CONSTRAINT DF_Activity_X DEFAULT (0),
    PositionY                   INT               NOT NULL CONSTRAINT DF_Activity_Y DEFAULT (0),
    TimeoutSeconds              INT               NOT NULL,
    RetryMaxAttempts            INT               NOT NULL,
    RetryInitialIntervalSeconds INT               NOT NULL,
    RetryBackoffCoefficient     DECIMAL(5,2)      NOT NULL,
    RetryMaxIntervalSeconds     INT               NOT NULL,
    NonRetryableErrorsJson      NVARCHAR(2000)    NOT NULL CONSTRAINT DF_Activity_NonRetry DEFAULT (N'[]'),
    ErrorHandling               NVARCHAR(30)      NOT NULL CONSTRAINT DF_Activity_ErrorHandling DEFAULT (N'FailWorkflow'),
    ErrorRouteActivityKey       NVARCHAR(100)     NULL,
    ExecutionCondition          NVARCHAR(1000)    NULL,
    ConfigJson                  NVARCHAR(MAX)     NOT NULL CONSTRAINT DF_Activity_Config DEFAULT (N'{}'),
    CreatedBy                   NVARCHAR(256)     NOT NULL,
    CreatedOn                   DATETIME2(3)      NOT NULL CONSTRAINT DF_Activity_CreatedOn DEFAULT (SYSUTCDATETIME()),
    ModifiedBy                  NVARCHAR(256)     NULL,
    ModifiedOn                  DATETIME2(3)      NULL,
    RowVer                      ROWVERSION        NOT NULL,
    CONSTRAINT UQ_Activity_Key UNIQUE (WorkflowVersionId, ActivityKey),
    CONSTRAINT CK_Activity_Type CHECK (ActivityType IN (N'Start', N'End', N'Decision', N'ParallelSplit', N'ParallelJoin',
        N'Maker', N'Checker', N'Approver', N'MultilevelApprover', N'SequentialApprover', N'ParallelApprover',
        N'SftpFilePush', N'SftpFilePull', N'ApiDataPush', N'ApiDataPull', N'FileGeneration', N'FileReading', N'ScheduledOracleQuery')),
    CONSTRAINT CK_Activity_ErrorHandling CHECK (ErrorHandling IN (N'FailWorkflow', N'Continue', N'RouteToActivity', N'Terminate')),
    CONSTRAINT CK_Activity_Timeout CHECK (TimeoutSeconds BETWEEN 1 AND 31536000),
    CONSTRAINT CK_Activity_Retry CHECK (RetryMaxAttempts BETWEEN 1 AND 100 AND RetryInitialIntervalSeconds >= 1
        AND RetryBackoffCoefficient >= 1.0 AND RetryMaxIntervalSeconds >= RetryInitialIntervalSeconds),
    CONSTRAINT CK_Activity_ConfigJson CHECK (ISJSON(ConfigJson) = 1),
    CONSTRAINT CK_Activity_NonRetryJson CHECK (ISJSON(NonRetryableErrorsJson) = 1)
);
GO

IF OBJECT_ID(N'wf.ActivityConnection', N'U') IS NULL
CREATE TABLE wf.ActivityConnection
(
    ConnectionId        INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ActivityConnection PRIMARY KEY,
    WorkflowVersionId   INT               NOT NULL CONSTRAINT FK_Connection_Version REFERENCES wf.WorkflowVersion (WorkflowVersionId),
    FromActivityId      INT               NOT NULL CONSTRAINT FK_Connection_From REFERENCES wf.WorkflowActivity (ActivityId),
    ToActivityId        INT               NOT NULL CONSTRAINT FK_Connection_To REFERENCES wf.WorkflowActivity (ActivityId),
    ConnectionType      NVARCHAR(20)      NOT NULL,
    ConditionExpression NVARCHAR(1000)    NULL,
    IsDefault           BIT               NOT NULL CONSTRAINT DF_Connection_IsDefault DEFAULT (0),
    Label               NVARCHAR(200)     NULL,
    Priority            INT               NOT NULL CONSTRAINT DF_Connection_Priority DEFAULT (0),
    CreatedBy           NVARCHAR(256)     NOT NULL,
    CreatedOn           DATETIME2(3)      NOT NULL CONSTRAINT DF_Connection_CreatedOn DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT UQ_Connection UNIQUE (FromActivityId, ToActivityId, ConnectionType),
    CONSTRAINT CK_Connection_Type CHECK (ConnectionType IN (N'Sequence', N'Conditional', N'Parallel', N'Rejection', N'Error')),
    CONSTRAINT CK_Connection_NotSelf CHECK (FromActivityId <> ToActivityId)
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Connection_Version' AND object_id = OBJECT_ID(N'wf.ActivityConnection'))
    CREATE INDEX IX_Connection_Version ON wf.ActivityConnection (WorkflowVersionId);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Connection_To' AND object_id = OBJECT_ID(N'wf.ActivityConnection'))
    CREATE INDEX IX_Connection_To ON wf.ActivityConnection (ToActivityId);
GO

/* ---------------------------------------------------------------- Parameters */
IF OBJECT_ID(N'wf.WorkflowParameter', N'U') IS NULL
CREATE TABLE wf.WorkflowParameter
(
    ParameterId       INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WorkflowParameter PRIMARY KEY,
    WorkflowVersionId INT               NOT NULL CONSTRAINT FK_WfParam_Version REFERENCES wf.WorkflowVersion (WorkflowVersionId),
    Direction         NVARCHAR(10)      NOT NULL,
    Name              NVARCHAR(100)     NOT NULL,
    DataType          NVARCHAR(20)      NOT NULL,
    IsMandatory       BIT               NOT NULL CONSTRAINT DF_WfParam_Mandatory DEFAULT (0),
    DefaultValue      NVARCHAR(4000)    NULL,
    JsonSchema        NVARCHAR(MAX)     NULL,
    Description       NVARCHAR(1000)    NULL,
    SourceType        NVARCHAR(30)      NOT NULL CONSTRAINT DF_WfParam_Source DEFAULT (N'None'),
    SourceReference   NVARCHAR(500)     NULL,
    SortOrder         INT               NOT NULL CONSTRAINT DF_WfParam_Sort DEFAULT (0),
    CreatedBy         NVARCHAR(256)     NOT NULL,
    CreatedOn         DATETIME2(3)      NOT NULL CONSTRAINT DF_WfParam_CreatedOn DEFAULT (SYSUTCDATETIME()),
    ModifiedBy        NVARCHAR(256)     NULL,
    ModifiedOn        DATETIME2(3)      NULL,
    RowVer            ROWVERSION        NOT NULL,
    CONSTRAINT UQ_WfParam UNIQUE (WorkflowVersionId, Direction, Name),
    CONSTRAINT CK_WfParam_Direction CHECK (Direction IN (N'Input', N'Output')),
    CONSTRAINT CK_WfParam_DataType CHECK (DataType IN (N'String', N'Integer', N'Decimal', N'Boolean', N'Date', N'DateTime', N'Json', N'Array', N'File')),
    CONSTRAINT CK_WfParam_SourceType CHECK (SourceType IN (N'None', N'Literal', N'WorkflowInput', N'ActivityOutput', N'ConnectionProfile', N'SystemVariable')),
    CONSTRAINT CK_WfParam_Schema CHECK (JsonSchema IS NULL OR ISJSON(JsonSchema) = 1)
);
GO

IF OBJECT_ID(N'wf.ActivityParameter', N'U') IS NULL
CREATE TABLE wf.ActivityParameter
(
    ActivityParameterId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ActivityParameter PRIMARY KEY,
    ActivityId          INT               NOT NULL CONSTRAINT FK_ActParam_Activity REFERENCES wf.WorkflowActivity (ActivityId) ON DELETE CASCADE,
    Direction           NVARCHAR(10)      NOT NULL,
    Name                NVARCHAR(100)     NOT NULL,
    DataType            NVARCHAR(20)      NOT NULL,
    IsMandatory         BIT               NOT NULL CONSTRAINT DF_ActParam_Mandatory DEFAULT (0),
    DefaultValue        NVARCHAR(4000)    NULL,
    JsonSchema          NVARCHAR(MAX)     NULL,
    Description         NVARCHAR(1000)    NULL,
    SourceType          NVARCHAR(30)      NOT NULL CONSTRAINT DF_ActParam_Source DEFAULT (N'None'),
    SourceReference     NVARCHAR(500)     NULL,
    SortOrder           INT               NOT NULL CONSTRAINT DF_ActParam_Sort DEFAULT (0),
    CONSTRAINT UQ_ActParam UNIQUE (ActivityId, Direction, Name),
    CONSTRAINT CK_ActParam_Direction CHECK (Direction IN (N'Input', N'Output')),
    CONSTRAINT CK_ActParam_DataType CHECK (DataType IN (N'String', N'Integer', N'Decimal', N'Boolean', N'Date', N'DateTime', N'Json', N'Array', N'File')),
    CONSTRAINT CK_ActParam_SourceType CHECK (SourceType IN (N'None', N'Literal', N'WorkflowInput', N'ActivityOutput', N'ConnectionProfile', N'SystemVariable')),
    CONSTRAINT CK_ActParam_Schema CHECK (JsonSchema IS NULL OR ISJSON(JsonSchema) = 1)
);
GO

/* ---------------------------------------------------------------- Approval configuration */
IF OBJECT_ID(N'wf.ApprovalConfiguration', N'U') IS NULL
CREATE TABLE wf.ApprovalConfiguration
(
    ApprovalConfigId               INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ApprovalConfiguration PRIMARY KEY,
    ActivityId                     INT               NOT NULL CONSTRAINT FK_Approval_Activity REFERENCES wf.WorkflowActivity (ActivityId) ON DELETE CASCADE,
    ApprovalPolicy                 NVARCHAR(20)      NOT NULL,
    QuorumCount                    INT               NULL,
    RejectionRouting               NVARCHAR(20)      NOT NULL,
    RejectionTargetActivityKey     NVARCHAR(100)     NULL,
    SlaHours                       INT               NOT NULL,
    EscalationAfterHours           INT               NULL,
    EscalationRole                 NVARCHAR(100)     NULL,
    ReminderIntervalHours          INT               NULL,
    AllowDelegation                BIT               NOT NULL CONSTRAINT DF_Approval_Delegation DEFAULT (0),
    EnforceMakerCheckerSegregation BIT               NOT NULL CONSTRAINT DF_Approval_Segregation DEFAULT (1),
    ModifiedBy                     NVARCHAR(256)     NOT NULL,
    ModifiedOn                     DATETIME2(3)      NOT NULL CONSTRAINT DF_Approval_ModifiedOn DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT UQ_Approval_Activity UNIQUE (ActivityId),
    CONSTRAINT CK_Approval_Policy CHECK (ApprovalPolicy IN (N'AnyOne', N'All', N'Majority', N'Quorum')),
    CONSTRAINT CK_Approval_Rejection CHECK (RejectionRouting IN (N'ToMaker', N'ToPreviousLevel', N'ToActivity', N'Terminate')),
    CONSTRAINT CK_Approval_Sla CHECK (SlaHours BETWEEN 1 AND 8760)
);
GO

IF OBJECT_ID(N'wf.ApprovalLevel', N'U') IS NULL
CREATE TABLE wf.ApprovalLevel
(
    ApprovalLevelId  INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ApprovalLevel PRIMARY KEY,
    ApprovalConfigId INT               NOT NULL CONSTRAINT FK_Level_Config REFERENCES wf.ApprovalConfiguration (ApprovalConfigId) ON DELETE CASCADE,
    LevelNo          INT               NOT NULL,
    LevelName        NVARCHAR(200)     NOT NULL,
    ExecutionMode    NVARCHAR(20)      NOT NULL,
    MinApprovals     INT               NOT NULL CONSTRAINT DF_Level_Min DEFAULT (1),
    SlaHours         INT               NULL,
    CONSTRAINT UQ_ApprovalLevel UNIQUE (ApprovalConfigId, LevelNo),
    CONSTRAINT CK_ApprovalLevel_Mode CHECK (ExecutionMode IN (N'Sequential', N'Parallel')),
    CONSTRAINT CK_ApprovalLevel_Min CHECK (MinApprovals BETWEEN 1 AND 50)
);
GO

IF OBJECT_ID(N'wf.ApprovalLevelRole', N'U') IS NULL
CREATE TABLE wf.ApprovalLevelRole
(
    ApprovalLevelRoleId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ApprovalLevelRole PRIMARY KEY,
    ApprovalLevelId     INT               NOT NULL CONSTRAINT FK_LevelRole_Level REFERENCES wf.ApprovalLevel (ApprovalLevelId) ON DELETE CASCADE,
    RoleCode            NVARCHAR(100)     NOT NULL,
    GroupName           NVARCHAR(200)     NULL,
    SequenceNo          INT               NOT NULL CONSTRAINT DF_LevelRole_Seq DEFAULT (0),
    CONSTRAINT UQ_ApprovalLevelRole UNIQUE (ApprovalLevelId, RoleCode)
);
GO

/* ---------------------------------------------------------------- Scheduler configuration (metadata only) */
IF OBJECT_ID(N'wf.SchedulerConfiguration', N'U') IS NULL
CREATE TABLE wf.SchedulerConfiguration
(
    SchedulerConfigId        INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_SchedulerConfiguration PRIMARY KEY,
    SchedulerCode            NVARCHAR(50)      NOT NULL,
    SourceSystemId           INT               NOT NULL CONSTRAINT FK_Scheduler_SourceSystem REFERENCES wf.SourceSystem (SourceSystemId),
    SchedulerName            NVARCHAR(200)     NOT NULL,
    Description              NVARCHAR(1000)    NULL,
    ApprovedQueryId          INT               NOT NULL CONSTRAINT FK_Scheduler_Query REFERENCES wf.ApprovedOracleQuery (ApprovedQueryId),
    CronExpression           NVARCHAR(120)     NOT NULL,
    TimeZoneId               NVARCHAR(100)     NOT NULL,
    TargetWorkflowTemplateId INT               NOT NULL CONSTRAINT FK_Scheduler_Template REFERENCES wf.WorkflowTemplate (WorkflowTemplateId),
    TargetVersionPolicy      NVARCHAR(20)      NOT NULL CONSTRAINT DF_Scheduler_Policy DEFAULT (N'LatestPublished'),
    PinnedVersionNo          INT               NULL,
    ExecutionParametersJson  NVARCHAR(MAX)     NOT NULL CONSTRAINT DF_Scheduler_Params DEFAULT (N'{}'),
    MisfirePolicy            NVARCHAR(20)      NOT NULL CONSTRAINT DF_Scheduler_Misfire DEFAULT (N'DoNothing'),
    MaxConcurrentRuns        INT               NOT NULL CONSTRAINT DF_Scheduler_MaxRuns DEFAULT (1),
    EffectiveFrom            DATETIME2(0)      NULL,
    EffectiveTo              DATETIME2(0)      NULL,
    IsActive                 BIT               NOT NULL CONSTRAINT DF_Scheduler_IsActive DEFAULT (1),
    CreatedBy                NVARCHAR(256)     NOT NULL,
    CreatedOn                DATETIME2(3)      NOT NULL CONSTRAINT DF_Scheduler_CreatedOn DEFAULT (SYSUTCDATETIME()),
    ModifiedBy               NVARCHAR(256)     NULL,
    ModifiedOn               DATETIME2(3)      NULL,
    RowVer                   ROWVERSION        NOT NULL,
    CONSTRAINT UQ_Scheduler_Code UNIQUE (SchedulerCode),
    CONSTRAINT CK_Scheduler_Policy CHECK (TargetVersionPolicy IN (N'LatestPublished', N'Pinned')),
    CONSTRAINT CK_Scheduler_Pinned CHECK (TargetVersionPolicy <> N'Pinned' OR PinnedVersionNo IS NOT NULL),
    CONSTRAINT CK_Scheduler_Misfire CHECK (MisfirePolicy IN (N'FireNow', N'DoNothing', N'FireOnceNow')),
    CONSTRAINT CK_Scheduler_Params CHECK (ISJSON(ExecutionParametersJson) = 1),
    CONSTRAINT CK_Scheduler_MaxRuns CHECK (MaxConcurrentRuns BETWEEN 1 AND 10),
    CONSTRAINT CK_Scheduler_Effective CHECK (EffectiveTo IS NULL OR EffectiveFrom IS NULL OR EffectiveTo > EffectiveFrom)
);
GO

/* ---------------------------------------------------------------- Audit trail (append-only) */
IF OBJECT_ID(N'wf.AuditLog', N'U') IS NULL
CREATE TABLE wf.AuditLog
(
    AuditLogId    BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_AuditLog PRIMARY KEY,
    EntityType    NVARCHAR(50)         NOT NULL,
    EntityId      NVARCHAR(50)         NOT NULL,
    Action        NVARCHAR(50)         NOT NULL,
    UserName      NVARCHAR(256)        NOT NULL,
    ActionOn      DATETIME2(3)         NOT NULL CONSTRAINT DF_Audit_ActionOn DEFAULT (SYSUTCDATETIME()),
    CorrelationId NVARCHAR(100)        NULL,
    ClientIp      NVARCHAR(64)         NULL,
    Details       NVARCHAR(MAX)        NULL,
    CONSTRAINT CK_Audit_Details CHECK (Details IS NULL OR ISJSON(Details) = 1)
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Audit_Entity' AND object_id = OBJECT_ID(N'wf.AuditLog'))
    CREATE INDEX IX_Audit_Entity ON wf.AuditLog (EntityType, EntityId, ActionOn DESC);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Audit_ActionOn' AND object_id = OBJECT_ID(N'wf.AuditLog'))
    CREATE INDEX IX_Audit_ActionOn ON wf.AuditLog (ActionOn DESC);
GO
