/* =============================================================================
   BankWorkflowDesigner - 04 Immutability triggers (defence in depth)
   Stored procedures already refuse to modify published versions; these triggers
   guarantee it even for ad-hoc DML executed by privileged accounts.
   Error 51411 = VERSION_IMMUTABLE (mapped to HTTP 409 by the API).
   ============================================================================= */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER TRIGGER wf.TR_WorkflowVersion_Immutable
ON wf.WorkflowVersion
AFTER UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    -- Published / superseded content can never change; only the status may move Published -> Superseded/Deactivated.
    IF EXISTS
    (
        SELECT 1
        FROM deleted d
        LEFT JOIN inserted i ON i.WorkflowVersionId = d.WorkflowVersionId
        WHERE d.Status IN (N'Published', N'Superseded', N'Deactivated')
          AND (
                i.WorkflowVersionId IS NULL                                          -- delete
             OR ISNULL(i.DefinitionJson, N'') <> ISNULL(d.DefinitionJson, N'')
             OR ISNULL(i.DefinitionHash, '') <> ISNULL(d.DefinitionHash, '')
             OR i.VersionNo <> d.VersionNo
             OR i.WorkflowTemplateId <> d.WorkflowTemplateId
             OR i.Status IN (N'Draft', N'Validated')
             OR (d.Status = N'Superseded' AND i.Status = N'Published')
          )
    )
    BEGIN
        THROW 51411, N'Published workflow versions are immutable.', 1;
    END
END
GO

CREATE OR ALTER TRIGGER wf.TR_WorkflowActivity_Immutable
ON wf.WorkflowActivity
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS
    (
        SELECT 1
        FROM (SELECT WorkflowVersionId FROM inserted UNION SELECT WorkflowVersionId FROM deleted) x
        JOIN wf.WorkflowVersion v ON v.WorkflowVersionId = x.WorkflowVersionId
        WHERE v.Status NOT IN (N'Draft', N'Validated')
    )
        THROW 51411, N'Activities of a published workflow version are immutable.', 1;
END
GO

CREATE OR ALTER TRIGGER wf.TR_ActivityConnection_Immutable
ON wf.ActivityConnection
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS
    (
        SELECT 1
        FROM (SELECT WorkflowVersionId FROM inserted UNION SELECT WorkflowVersionId FROM deleted) x
        JOIN wf.WorkflowVersion v ON v.WorkflowVersionId = x.WorkflowVersionId
        WHERE v.Status NOT IN (N'Draft', N'Validated')
    )
        THROW 51411, N'Connections of a published workflow version are immutable.', 1;
END
GO

CREATE OR ALTER TRIGGER wf.TR_WorkflowParameter_Immutable
ON wf.WorkflowParameter
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS
    (
        SELECT 1
        FROM (SELECT WorkflowVersionId FROM inserted UNION SELECT WorkflowVersionId FROM deleted) x
        JOIN wf.WorkflowVersion v ON v.WorkflowVersionId = x.WorkflowVersionId
        WHERE v.Status NOT IN (N'Draft', N'Validated')
    )
        THROW 51411, N'Parameters of a published workflow version are immutable.', 1;
END
GO

CREATE OR ALTER TRIGGER wf.TR_ActivityParameter_Immutable
ON wf.ActivityParameter
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS
    (
        SELECT 1
        FROM (SELECT ActivityId FROM inserted UNION SELECT ActivityId FROM deleted) x
        JOIN wf.WorkflowActivity a ON a.ActivityId = x.ActivityId
        JOIN wf.WorkflowVersion v ON v.WorkflowVersionId = a.WorkflowVersionId
        WHERE v.Status NOT IN (N'Draft', N'Validated')
    )
        THROW 51411, N'Activity parameters of a published workflow version are immutable.', 1;
END
GO

CREATE OR ALTER TRIGGER wf.TR_ApprovalConfiguration_Immutable
ON wf.ApprovalConfiguration
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS
    (
        SELECT 1
        FROM (SELECT ActivityId FROM inserted UNION SELECT ActivityId FROM deleted) x
        JOIN wf.WorkflowActivity a ON a.ActivityId = x.ActivityId
        JOIN wf.WorkflowVersion v ON v.WorkflowVersionId = a.WorkflowVersionId
        WHERE v.Status NOT IN (N'Draft', N'Validated')
    )
        THROW 51411, N'Approval configuration of a published workflow version is immutable.', 1;
END
GO

CREATE OR ALTER TRIGGER wf.TR_ApprovalLevel_Immutable
ON wf.ApprovalLevel
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS
    (
        SELECT 1
        FROM (SELECT ApprovalConfigId FROM inserted UNION SELECT ApprovalConfigId FROM deleted) x
        JOIN wf.ApprovalConfiguration c ON c.ApprovalConfigId = x.ApprovalConfigId
        JOIN wf.WorkflowActivity a ON a.ActivityId = c.ActivityId
        JOIN wf.WorkflowVersion v ON v.WorkflowVersionId = a.WorkflowVersionId
        WHERE v.Status NOT IN (N'Draft', N'Validated')
    )
        THROW 51411, N'Approval levels of a published workflow version are immutable.', 1;
END
GO

CREATE OR ALTER TRIGGER wf.TR_ApprovalLevelRole_Immutable
ON wf.ApprovalLevelRole
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS
    (
        SELECT 1
        FROM (SELECT ApprovalLevelId FROM inserted UNION SELECT ApprovalLevelId FROM deleted) x
        JOIN wf.ApprovalLevel l ON l.ApprovalLevelId = x.ApprovalLevelId
        JOIN wf.ApprovalConfiguration c ON c.ApprovalConfigId = l.ApprovalConfigId
        JOIN wf.WorkflowActivity a ON a.ActivityId = c.ActivityId
        JOIN wf.WorkflowVersion v ON v.WorkflowVersionId = a.WorkflowVersionId
        WHERE v.Status NOT IN (N'Draft', N'Validated')
    )
        THROW 51411, N'Approval roles of a published workflow version are immutable.', 1;
END
GO

-- The audit log is append-only.
CREATE OR ALTER TRIGGER wf.TR_AuditLog_AppendOnly
ON wf.AuditLog
AFTER UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    THROW 51412, N'The audit log is append-only.', 1;
END
GO
