/* =============================================================================
   BankWorkflowDesigner - deploy everything with SQLCMD mode
     sqlcmd -S <server> -E -i 00_DeployAll.sql
   (or open in SSMS -> Query -> SQLCMD Mode -> Execute)
   01_CreateDatabase.sql is run separately by a DBA if the database does not exist.
   ============================================================================= */
:on error exit
USE BankWorkflowDesigner;
GO
:r .\02_Tables.sql
:r .\03_TableTypes.sql
:r .\04_Triggers.sql
:r .\05_Procedures_Internal.sql
:r .\06_Procedures_SourceSystems.sql
:r .\07_Procedures_Workflows.sql
:r .\08_Procedures_Activities.sql
:r .\09_Procedures_Scheduler.sql
:r .\10_SecurityRoles.sql
:r .\11_SeedData.sql
PRINT N'BankWorkflowDesigner database deployed.';
GO
