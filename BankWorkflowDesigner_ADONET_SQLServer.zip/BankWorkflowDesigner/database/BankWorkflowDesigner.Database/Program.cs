using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Data.SqlClient;

namespace BankWorkflowDesigner.Database;

/// <summary>
/// Minimal, dependency-free deployment tool: executes the numbered scripts in order,
/// splitting batches on "GO" lines exactly like sqlcmd. SQLCMD directives (:r, :on error) are skipped.
/// </summary>
public static class Program
{
    private static readonly Regex GoSeparator = new(@"^\s*GO\s*(--.*)?$", RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.Compiled);

    public static async Task<int> Main(string[] args)
    {
        if (args.Length == 0 || args[0] is "-h" or "--help")
        {
            Console.WriteLine("Usage: BankWorkflowDesigner.Database \"<connection string>\" [--create-database] [--skip-seed]");
            return 1;
        }

        var connectionString = args[0];
        var createDatabase = args.Contains("--create-database");
        var skipSeed = args.Contains("--skip-seed");
        var scriptsDirectory = Path.Combine(AppContext.BaseDirectory, "Scripts");

        var scripts = Directory.GetFiles(scriptsDirectory, "*.sql")
            .Select(Path.GetFileName)
            .Where(n => n is not null && Regex.IsMatch(n, @"^\d{2}_"))
            .Where(n => !n!.StartsWith("00_", StringComparison.Ordinal))
            .Where(n => createDatabase || !n!.StartsWith("01_", StringComparison.Ordinal))
            .Where(n => !skipSeed || !n!.Contains("SeedData", StringComparison.OrdinalIgnoreCase))
            .OrderBy(n => n, StringComparer.Ordinal)
            .ToList();

        try
        {
            foreach (var script in scripts)
            {
                var builder = new SqlConnectionStringBuilder(connectionString);
                if (script!.StartsWith("01_", StringComparison.Ordinal))
                {
                    builder.InitialCatalog = "master";
                }

                Console.WriteLine($"Executing {script} ...");
                await ExecuteScriptAsync(builder.ConnectionString, await File.ReadAllTextAsync(Path.Combine(scriptsDirectory, script)));
            }

            Console.WriteLine("Database deployment completed successfully.");
            return 0;
        }
        catch (SqlException ex)
        {
            Console.Error.WriteLine($"Deployment failed: SQL error {ex.Number} at line {ex.LineNumber}: {ex.Message}");
            return 2;
        }
    }

    private static async Task ExecuteScriptAsync(string connectionString, string script)
    {
        await using var connection = new SqlConnection(connectionString);
        await connection.OpenAsync();

        foreach (var batch in SplitBatches(script))
        {
            await using var command = new SqlCommand(batch, connection) { CommandTimeout = 300 };
            await command.ExecuteNonQueryAsync();
        }
    }

    public static IEnumerable<string> SplitBatches(string script)
    {
        var current = new StringBuilder();
        foreach (var line in script.Replace("\r\n", "\n").Split('\n'))
        {
            if (GoSeparator.IsMatch(line))
            {
                if (current.ToString().Trim().Length > 0)
                {
                    yield return current.ToString();
                }

                current.Clear();
                continue;
            }

            if (line.TrimStart().StartsWith(':'))
            {
                continue; // SQLCMD directive
            }

            current.AppendLine(line);
        }

        if (current.ToString().Trim().Length > 0)
        {
            yield return current.ToString();
        }
    }
}
