using BankWorkflowDesigner.Application.Abstractions;
using BankWorkflowDesigner.Infrastructure.Data;
using BankWorkflowDesigner.Infrastructure.Repositories;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace BankWorkflowDesigner.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddSqlServerInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<DatabaseOptions>(configuration.GetSection(DatabaseOptions.SectionName));
        services.AddSingleton<ISqlConnectionFactory, SqlConnectionFactory>();

        services.AddScoped<ISourceSystemRepository, SourceSystemRepository>();
        services.AddScoped<IWorkflowRepository, WorkflowRepository>();
        services.AddScoped<IActivityRepository, ActivityRepository>();
        services.AddScoped<IParameterRepository, ParameterRepository>();
        services.AddScoped<ISchedulerRepository, SchedulerRepository>();
        services.AddScoped<IReferenceDataRepository, ReferenceDataRepository>();
        services.AddScoped<IAuditRepository, AuditRepository>();
        return services;
    }
}
