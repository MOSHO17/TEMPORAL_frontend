using System.Data;
using BankWorkflowDesigner.Application.Abstractions;
using BankWorkflowDesigner.Domain.Entities;
using BankWorkflowDesigner.Domain.Enums;
using BankWorkflowDesigner.Infrastructure.Data;
using Microsoft.Data.SqlClient;

namespace BankWorkflowDesigner.Infrastructure.Repositories;

public sealed class SourceSystemRepository : ISourceSystemRepository
{
    private readonly ISqlConnectionFactory _factory;

    public SourceSystemRepository(ISqlConnectionFactory factory) => _factory = factory;

    public Task<IReadOnlyList<SourceSystem>> GetAllAsync(CancellationToken ct) => LoadAsync(null, null, ct);

    public async Task<SourceSystem?> GetByIdAsync(int sourceSystemId, CancellationToken ct) =>
        (await LoadAsync(sourceSystemId, null, ct)).FirstOrDefault();

    public async Task<SourceSystem?> GetByCodeAsync(string systemCode, CancellationToken ct) =>
        (await LoadAsync(null, systemCode, ct)).FirstOrDefault();

    public Task<int> CreateAsync(SourceSystem sourceSystem, AuditContext audit, CancellationToken ct) =>
        SqlErrorTranslator.Run(async () =>
        {
            await using var connection = await _factory.OpenAsync(ct);
            await using var command = Sql.Procedure(connection, "wf.usp_SourceSystem_Create", _factory.CommandTimeoutSeconds);
            command.AddNVarChar("@SystemCode", sourceSystem.SystemCode, 50);
            command.AddNVarChar("@ApplicationName", sourceSystem.ApplicationName, 200);
            command.AddNVarChar("@Description", sourceSystem.Description, 1000);
            command.AddNVarChar("@DefaultTaskQueue", sourceSystem.DefaultTaskQueue, 200);
            command.AddNVarChar("@Status", sourceSystem.Status.ToString(), 20);
            command.AddTable("@Modules", "wf.ModuleTableType", Mappers.ModuleTable(sourceSystem.Modules));
            command.AddTable("@Users", "wf.SourceSystemUserTableType", Mappers.UserTable(sourceSystem.AuthorizedUsers));
            command.AddAudit(audit);
            var id = command.AddOutputInt("@SourceSystemId");
            await command.ExecuteNonQueryAsync(ct);
            return (int)id.Value;
        });

    public Task UpdateAsync(SourceSystem sourceSystem, AuditContext audit, CancellationToken ct) =>
        SqlErrorTranslator.Run(async () =>
        {
            await using var connection = await _factory.OpenAsync(ct);
            await using var command = Sql.Procedure(connection, "wf.usp_SourceSystem_Update", _factory.CommandTimeoutSeconds);
            command.AddInt("@SourceSystemId", sourceSystem.SourceSystemId);
            command.AddNVarChar("@ApplicationName", sourceSystem.ApplicationName, 200);
            command.AddNVarChar("@Description", sourceSystem.Description, 1000);
            command.AddNVarChar("@DefaultTaskQueue", sourceSystem.DefaultTaskQueue, 200);
            command.AddNVarChar("@Status", sourceSystem.Status.ToString(), 20);
            command.AddRowVersion("@RowVersion", sourceSystem.RowVersion);
            command.AddTable("@Modules", "wf.ModuleTableType", Mappers.ModuleTable(sourceSystem.Modules));
            command.AddTable("@Users", "wf.SourceSystemUserTableType", Mappers.UserTable(sourceSystem.AuthorizedUsers));
            command.AddAudit(audit);
            await command.ExecuteNonQueryAsync(ct);
        });

    public async Task<IReadOnlyList<SourceSystemAccessRole>> GetUserAccessRolesAsync(int sourceSystemId, string userPrincipal, CancellationToken ct)
    {
        await using var connection = await _factory.OpenAsync(ct);
        await using var command = Sql.Procedure(connection, "wf.usp_SourceSystemUser_GetAccessRoles", _factory.CommandTimeoutSeconds);
        command.AddInt("@SourceSystemId", sourceSystemId);
        command.AddNVarChar("@UserPrincipal", userPrincipal, 256);
        var roles = new List<SourceSystemAccessRole>();
        await using var reader = await command.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct))
        {
            roles.Add(reader.GetEnum<SourceSystemAccessRole>("AccessRole"));
        }

        return roles;
    }

    public async Task<IReadOnlyList<int>> GetAuthorizedSourceSystemIdsAsync(string userPrincipal, CancellationToken ct)
    {
        await using var connection = await _factory.OpenAsync(ct);
        await using var command = Sql.Procedure(connection, "wf.usp_SourceSystemUser_GetAuthorizedSystems", _factory.CommandTimeoutSeconds);
        command.AddNVarChar("@UserPrincipal", userPrincipal, 256);
        var ids = new List<int>();
        await using var reader = await command.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct))
        {
            ids.Add(reader.GetInt("SourceSystemId"));
        }

        return ids;
    }

    private async Task<IReadOnlyList<SourceSystem>> LoadAsync(int? id, string? code, CancellationToken ct)
    {
        await using var connection = await _factory.OpenAsync(ct);
        await using var command = Sql.Procedure(connection, "wf.usp_SourceSystem_Get", _factory.CommandTimeoutSeconds);
        command.AddInt("@SourceSystemId", id);
        command.AddNVarChar("@SystemCode", code, 50);

        await using var reader = await command.ExecuteReaderAsync(ct);
        var systems = new List<SourceSystem>();
        while (await reader.ReadAsync(ct))
        {
            systems.Add(Mappers.ReadSourceSystem(reader));
        }

        var byId = systems.ToDictionary(s => s.SourceSystemId);

        await reader.NextResultAsync(ct);
        while (await reader.ReadAsync(ct))
        {
            var module = Mappers.ReadModule(reader);
            if (byId.TryGetValue(module.SourceSystemId, out var owner))
            {
                owner.Modules.Add(module);
            }
        }

        await reader.NextResultAsync(ct);
        while (await reader.ReadAsync(ct))
        {
            var user = Mappers.ReadSourceSystemUser(reader);
            if (byId.TryGetValue(user.SourceSystemId, out var owner))
            {
                owner.AuthorizedUsers.Add(user);
            }
        }

        return systems;
    }
}

public sealed class ReferenceDataRepository : IReferenceDataRepository
{
    private readonly ISqlConnectionFactory _factory;

    public ReferenceDataRepository(ISqlConnectionFactory factory) => _factory = factory;

    public async Task<IReadOnlyList<ConnectionProfile>> GetConnectionProfilesAsync(CancellationToken ct)
    {
        await using var connection = await _factory.OpenAsync(ct);
        await using var command = Sql.Procedure(connection, "wf.usp_ConnectionProfile_GetAll", _factory.CommandTimeoutSeconds);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var list = new List<ConnectionProfile>();
        while (await reader.ReadAsync(ct))
        {
            list.Add(new ConnectionProfile
            {
                ConnectionProfileId = reader.GetInt("ConnectionProfileId"),
                ProfileCode = reader.GetString("ProfileCode"),
                ProfileType = reader.GetEnum<ConnectionProfileType>("ProfileType"),
                Description = reader.GetNullableString("Description"),
                SecretStoreReference = reader.GetString("SecretStoreReference"),
                Environment = reader.GetNullableString("Environment"),
                SourceSystemId = reader.GetNullableInt("SourceSystemId"),
                IsActive = reader.GetBool("IsActive")
            });
        }

        return list;
    }

    public async Task<IReadOnlyList<ApprovedOracleQuery>> GetApprovedQueriesAsync(CancellationToken ct)
    {
        await using var connection = await _factory.OpenAsync(ct);
        await using var command = Sql.Procedure(connection, "wf.usp_ApprovedOracleQuery_GetAll", _factory.CommandTimeoutSeconds);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var list = new List<ApprovedOracleQuery>();
        while (await reader.ReadAsync(ct))
        {
            list.Add(new ApprovedOracleQuery
            {
                ApprovedQueryId = reader.GetInt("ApprovedQueryId"),
                QueryCode = reader.GetString("QueryCode"),
                QueryName = reader.GetString("QueryName"),
                Description = reader.GetNullableString("Description"),
                SourceSystemId = reader.GetNullableInt("SourceSystemId"),
                DataSourceProfileCode = reader.GetString("DataSourceProfileCode"),
                ParameterNames = System.Text.Json.JsonSerializer.Deserialize<List<string>>(reader.GetString("ParameterNamesJson")) ?? new List<string>(),
                ApprovedBy = reader.GetNullableString("ApprovedBy"),
                ApprovedOn = reader.GetNullableDate("ApprovedOn"),
                IsActive = reader.GetBool("IsActive")
            });
        }

        return list;
    }
}

public sealed class AuditRepository : IAuditRepository
{
    private readonly ISqlConnectionFactory _factory;

    public AuditRepository(ISqlConnectionFactory factory) => _factory = factory;

    public async Task<IReadOnlyList<AuditLogEntry>> GetAsync(string? entityType, string? entityId, int maxRows, CancellationToken ct)
    {
        await using var connection = await _factory.OpenAsync(ct);
        await using var command = Sql.Procedure(connection, "wf.usp_AuditLog_Get", _factory.CommandTimeoutSeconds);
        command.AddNVarChar("@EntityType", entityType, 50);
        command.AddNVarChar("@EntityId", entityId, 50);
        command.AddInt("@MaxRows", maxRows);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var list = new List<AuditLogEntry>();
        while (await reader.ReadAsync(ct))
        {
            list.Add(Mappers.ReadAudit(reader));
        }

        return list;
    }
}
