using System.Text.Json;
using BankWorkflowDesigner.Application.Abstractions;
using BankWorkflowDesigner.Domain.Dtos;
using BankWorkflowDesigner.Domain.Entities;
using BankWorkflowDesigner.Infrastructure.Data;
using Microsoft.Data.SqlClient;

namespace BankWorkflowDesigner.Infrastructure.Repositories;

public sealed class ActivityRepository : IActivityRepository
{
    private readonly ISqlConnectionFactory _factory;

    public ActivityRepository(ISqlConnectionFactory factory) => _factory = factory;

    public Task<WorkflowActivity> AddAsync(int workflowVersionId, WorkflowActivity activity, AuditContext audit, CancellationToken ct) =>
        SqlErrorTranslator.Run(async () =>
        {
            await using var connection = await _factory.OpenAsync(ct);
            await using var transaction = (SqlTransaction)await connection.BeginTransactionAsync(ct);
            try
            {
                var id = await InsertActivityAsync(connection, transaction, workflowVersionId, activity, writeAudit: true, audit, _factory.CommandTimeoutSeconds, ct);
                if (activity.Approval is not null)
                {
                    await SaveApprovalAsync(connection, transaction, workflowVersionId, id, activity.Approval, writeAudit: false, audit, _factory.CommandTimeoutSeconds, ct);
                }

                await transaction.CommitAsync(ct);
                return await LoadAsync(connection, id, ct);
            }
            catch
            {
                await Sql.SafeRollbackAsync(transaction);
                throw;
            }
        });

    public Task<WorkflowActivity> UpdateAsync(int workflowVersionId, WorkflowActivity activity, bool replaceParameters, AuditContext audit, CancellationToken ct) =>
        SqlErrorTranslator.Run(async () =>
        {
            await using var connection = await _factory.OpenAsync(ct);
            await using var transaction = (SqlTransaction)await connection.BeginTransactionAsync(ct);
            try
            {
                await using (var command = Sql.Procedure(connection, "wf.usp_Activity_Update", _factory.CommandTimeoutSeconds, transaction))
                {
                    command.AddInt("@WorkflowVersionId", workflowVersionId);
                    command.AddInt("@ActivityId", activity.ActivityId);
                    command.AddNVarChar("@ActivityKey", activity.ActivityKey, 100);
                    AddActivityFields(command, activity);
                    command.AddRowVersion("@RowVersion", activity.RowVersion);
                    command.AddBit("@ReplaceParameters", replaceParameters);
                    command.AddTable("@Parameters", "wf.ParameterTableType", Mappers.ParameterTable(replaceParameters ? activity.Parameters : Array.Empty<ActivityParameter>()));
                    command.AddAudit(audit);
                    await command.ExecuteNonQueryAsync(ct);
                }

                if (activity.Approval is not null)
                {
                    await SaveApprovalAsync(connection, transaction, workflowVersionId, activity.ActivityId, activity.Approval, writeAudit: false, audit, _factory.CommandTimeoutSeconds, ct);
                }

                await transaction.CommitAsync(ct);
                return await LoadAsync(connection, activity.ActivityId, ct);
            }
            catch
            {
                await Sql.SafeRollbackAsync(transaction);
                throw;
            }
        });

    public Task DeleteAsync(int workflowVersionId, int activityId, AuditContext audit, CancellationToken ct) =>
        SqlErrorTranslator.Run(async () =>
        {
            await using var connection = await _factory.OpenAsync(ct);
            await using var command = Sql.Procedure(connection, "wf.usp_Activity_Delete", _factory.CommandTimeoutSeconds);
            command.AddInt("@WorkflowVersionId", workflowVersionId);
            command.AddInt("@ActivityId", activityId);
            command.AddAudit(audit);
            await command.ExecuteNonQueryAsync(ct);
        });

    public Task UpdateLayoutAsync(int workflowVersionId, IReadOnlyList<ActivityPositionRequest> positions, AuditContext audit, CancellationToken ct) =>
        SqlErrorTranslator.Run(async () =>
        {
            await using var connection = await _factory.OpenAsync(ct);
            await using var command = Sql.Procedure(connection, "wf.usp_Activity_UpdateLayout", _factory.CommandTimeoutSeconds);
            command.AddInt("@WorkflowVersionId", workflowVersionId);
            command.AddTable("@Positions", "wf.ActivityPositionTableType",
                Mappers.PositionTable(positions.GroupBy(p => p.ActivityKey).Select(g => g.Last()).Select(p => (p.ActivityKey, p.PositionX, p.PositionY))));
            command.AddNVarChar("@UserName", audit.UserName, 256);
            await command.ExecuteNonQueryAsync(ct);
        });

    public Task SaveApprovalAsync(int workflowVersionId, int activityId, ApprovalConfiguration configuration, AuditContext audit, CancellationToken ct) =>
        SqlErrorTranslator.Run(async () =>
        {
            await using var connection = await _factory.OpenAsync(ct);
            await SaveApprovalAsync(connection, null, workflowVersionId, activityId, configuration, writeAudit: true, audit, _factory.CommandTimeoutSeconds, ct);
        });

    public Task<ActivityConnection> AddConnectionAsync(int workflowVersionId, ActivityConnection connection, AuditContext audit, CancellationToken ct) =>
        SqlErrorTranslator.Run(async () =>
        {
            await using var sqlConnection = await _factory.OpenAsync(ct);
            return await SaveConnectionAsync(sqlConnection, null, workflowVersionId, connection, writeAudit: true, audit, _factory.CommandTimeoutSeconds, ct);
        });

    public Task<ActivityConnection> UpdateConnectionAsync(int workflowVersionId, ActivityConnection connection, AuditContext audit, CancellationToken ct) =>
        SqlErrorTranslator.Run(async () =>
        {
            await using var sqlConnection = await _factory.OpenAsync(ct);
            return await SaveConnectionAsync(sqlConnection, null, workflowVersionId, connection, writeAudit: true, audit, _factory.CommandTimeoutSeconds, ct);
        });

    public Task DeleteConnectionAsync(int workflowVersionId, int connectionId, AuditContext audit, CancellationToken ct) =>
        SqlErrorTranslator.Run(async () =>
        {
            await using var connection = await _factory.OpenAsync(ct);
            await using var command = Sql.Procedure(connection, "wf.usp_Connection_Delete", _factory.CommandTimeoutSeconds);
            command.AddInt("@WorkflowVersionId", workflowVersionId);
            command.AddInt("@ConnectionId", connectionId);
            command.AddAudit(audit);
            await command.ExecuteNonQueryAsync(ct);
        });

    // ------------------------------------------------------------------ shared (also used by WorkflowRepository inside its transaction)

    internal static async Task<int> InsertActivityAsync(SqlConnection connection, SqlTransaction? transaction, int workflowVersionId,
        WorkflowActivity activity, bool writeAudit, AuditContext audit, int timeout, CancellationToken ct)
    {
        await using var command = Sql.Procedure(connection, "wf.usp_Activity_Insert", timeout, transaction);
        command.AddInt("@WorkflowVersionId", workflowVersionId);
        command.AddNVarChar("@ActivityKey", activity.ActivityKey, 100);
        command.AddNVarChar("@ActivityType", activity.ActivityType.ToString(), 50);
        AddActivityFields(command, activity);
        command.AddTable("@Parameters", "wf.ParameterTableType", Mappers.ParameterTable(activity.Parameters));
        command.AddBit("@WriteAudit", writeAudit);
        command.AddAudit(audit);
        var id = command.AddOutputInt("@ActivityId");
        await command.ExecuteNonQueryAsync(ct);
        return (int)id.Value;
    }

    internal static async Task SaveApprovalAsync(SqlConnection connection, SqlTransaction? transaction, int workflowVersionId, int activityId,
        ApprovalConfiguration configuration, bool writeAudit, AuditContext audit, int timeout, CancellationToken ct)
    {
        await using var command = Sql.Procedure(connection, "wf.usp_ApprovalConfig_Save", timeout, transaction);
        command.AddInt("@WorkflowVersionId", workflowVersionId);
        command.AddInt("@ActivityId", activityId);
        command.AddNVarChar("@ApprovalPolicy", configuration.ApprovalPolicy.ToString(), 20);
        command.AddInt("@QuorumCount", configuration.QuorumCount);
        command.AddNVarChar("@RejectionRouting", configuration.RejectionRouting.ToString(), 20);
        command.AddNVarChar("@RejectionTargetActivityKey", configuration.RejectionTargetActivityKey, 100);
        command.AddInt("@SlaHours", configuration.SlaHours);
        command.AddInt("@EscalationAfterHours", configuration.EscalationAfterHours);
        command.AddNVarChar("@EscalationRole", configuration.EscalationRole, 100);
        command.AddInt("@ReminderIntervalHours", configuration.ReminderIntervalHours);
        command.AddBit("@AllowDelegation", configuration.AllowDelegation);
        command.AddBit("@EnforceMakerCheckerSegregation", configuration.EnforceMakerCheckerSegregation);
        command.AddTable("@Levels", "wf.ApprovalLevelTableType", Mappers.LevelTable(configuration.Levels));
        command.AddTable("@Roles", "wf.ApprovalLevelRoleTableType", Mappers.LevelRoleTable(configuration.Levels));
        command.AddBit("@WriteAudit", writeAudit);
        command.AddAudit(audit);
        await command.ExecuteNonQueryAsync(ct);
    }

    internal static async Task<ActivityConnection> SaveConnectionAsync(SqlConnection connection, SqlTransaction? transaction, int workflowVersionId,
        ActivityConnection item, bool writeAudit, AuditContext audit, int timeout, CancellationToken ct)
    {
        await using var command = Sql.Procedure(connection, "wf.usp_Connection_Save", timeout, transaction);
        command.AddInt("@WorkflowVersionId", workflowVersionId);
        command.AddInt("@ConnectionId", item.ConnectionId == 0 ? null : item.ConnectionId);
        command.AddNVarChar("@FromActivityKey", item.FromActivityKey, 100);
        command.AddNVarChar("@ToActivityKey", item.ToActivityKey, 100);
        command.AddNVarChar("@ConnectionType", item.ConnectionType.ToString(), 20);
        command.AddNVarChar("@ConditionExpression", item.ConditionExpression, 1000);
        command.AddBit("@IsDefault", item.IsDefault);
        command.AddNVarChar("@Label", item.Label, 200);
        command.AddInt("@Priority", item.Priority);
        command.AddBit("@WriteAudit", writeAudit);
        command.AddAudit(audit);
        command.AddOutputInt("@SavedConnectionId");
        await using var reader = await command.ExecuteReaderAsync(ct);
        if (!await reader.ReadAsync(ct))
        {
            throw new InvalidOperationException("Saving the connection returned no row.");
        }

        return Mappers.ReadConnection(reader);
    }

    private static void AddActivityFields(SqlCommand command, WorkflowActivity activity)
    {
        command.AddNVarChar("@DisplayName", activity.DisplayName, 200);
        command.AddNVarChar("@Description", activity.Description, 1000);
        command.AddInt("@PositionX", activity.PositionX);
        command.AddInt("@PositionY", activity.PositionY);
        command.AddInt("@TimeoutSeconds", activity.TimeoutSeconds);
        command.AddInt("@RetryMaxAttempts", activity.RetryMaxAttempts);
        command.AddInt("@RetryInitialIntervalSeconds", activity.RetryInitialIntervalSeconds);
        var backoff = command.Add("@RetryBackoffCoefficient", System.Data.SqlDbType.Decimal, activity.RetryBackoffCoefficient);
        backoff.Precision = 5;
        backoff.Scale = 2;
        command.AddInt("@RetryMaxIntervalSeconds", activity.RetryMaxIntervalSeconds);
        command.AddNVarChar("@NonRetryableErrorsJson", JsonSerializer.Serialize(activity.NonRetryableErrors), 2000);
        command.AddNVarChar("@ErrorHandling", activity.ErrorHandling.ToString(), 30);
        command.AddNVarChar("@ErrorRouteActivityKey", activity.ErrorRouteActivityKey, 100);
        command.AddNVarChar("@ExecutionCondition", activity.ExecutionCondition, 1000);
        command.AddNVarCharMax("@ConfigJson", JsonSerializer.Serialize(activity.Config));
    }

    private async Task<WorkflowActivity> LoadAsync(SqlConnection connection, int activityId, CancellationToken ct)
    {
        await using var command = Sql.Procedure(connection, "wf.usp_Activity_Get", _factory.CommandTimeoutSeconds);
        command.AddInt("@ActivityId", activityId);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var list = await Mappers.ReadActivityAggregateAsync(reader, ct);
        return list.Single();
    }
}

public sealed class ParameterRepository : IParameterRepository
{
    private readonly ISqlConnectionFactory _factory;

    public ParameterRepository(ISqlConnectionFactory factory) => _factory = factory;

    public Task<WorkflowParameter> AddAsync(int workflowVersionId, WorkflowParameter parameter, AuditContext audit, CancellationToken ct) =>
        SqlErrorTranslator.Run(async () =>
        {
            await using var connection = await _factory.OpenAsync(ct);
            return await SaveAsync(connection, null, workflowVersionId, parameter, isUpdate: false, writeAudit: true, audit, _factory.CommandTimeoutSeconds, ct);
        });

    public Task<WorkflowParameter> UpdateAsync(int workflowVersionId, WorkflowParameter parameter, AuditContext audit, CancellationToken ct) =>
        SqlErrorTranslator.Run(async () =>
        {
            await using var connection = await _factory.OpenAsync(ct);
            return await SaveAsync(connection, null, workflowVersionId, parameter, isUpdate: true, writeAudit: true, audit, _factory.CommandTimeoutSeconds, ct);
        });

    public Task DeleteAsync(int workflowVersionId, int parameterId, AuditContext audit, CancellationToken ct) =>
        SqlErrorTranslator.Run(async () =>
        {
            await using var connection = await _factory.OpenAsync(ct);
            await using var command = Sql.Procedure(connection, "wf.usp_WorkflowParameter_Delete", _factory.CommandTimeoutSeconds);
            command.AddInt("@WorkflowVersionId", workflowVersionId);
            command.AddInt("@ParameterId", parameterId);
            command.AddAudit(audit);
            await command.ExecuteNonQueryAsync(ct);
        });

    internal static async Task<WorkflowParameter> SaveAsync(SqlConnection connection, SqlTransaction? transaction, int workflowVersionId,
        WorkflowParameter p, bool isUpdate, bool writeAudit, AuditContext audit, int timeout, CancellationToken ct)
    {
        await using var command = Sql.Procedure(connection, "wf.usp_WorkflowParameter_Save", timeout, transaction);
        command.AddInt("@WorkflowVersionId", workflowVersionId);
        command.AddInt("@ParameterId", isUpdate ? p.ParameterId : null);
        command.AddNVarChar("@Direction", p.Direction.ToString(), 10);
        command.AddNVarChar("@Name", p.Name, 100);
        command.AddNVarChar("@DataType", p.DataType.ToString(), 20);
        command.AddBit("@IsMandatory", p.IsMandatory);
        command.AddNVarChar("@DefaultValue", p.DefaultValue, 4000);
        command.AddNVarCharMax("@JsonSchema", p.JsonSchema);
        command.AddNVarChar("@Description", p.Description, 1000);
        command.AddNVarChar("@SourceType", p.SourceType.ToString(), 30);
        command.AddNVarChar("@SourceReference", p.SourceReference, 500);
        command.AddInt("@SortOrder", p.SortOrder);
        command.AddRowVersion("@RowVersion", isUpdate ? p.RowVersion : null);
        command.AddBit("@WriteAudit", writeAudit);
        command.AddAudit(audit);
        command.AddOutputInt("@SavedParameterId");
        await using var reader = await command.ExecuteReaderAsync(ct);
        if (!await reader.ReadAsync(ct))
        {
            throw new InvalidOperationException("Saving the parameter returned no row.");
        }

        return Mappers.ReadWorkflowParameter(reader);
    }
}

public sealed class SchedulerRepository : ISchedulerRepository
{
    private readonly ISqlConnectionFactory _factory;

    public SchedulerRepository(ISqlConnectionFactory factory) => _factory = factory;

    public async Task<IReadOnlyList<SchedulerConfiguration>> GetAllAsync(IReadOnlyCollection<int>? allowedSourceSystemIds, CancellationToken ct) =>
        await LoadAsync(null, allowedSourceSystemIds, ct);

    public async Task<SchedulerConfiguration?> GetByIdAsync(int schedulerConfigId, CancellationToken ct) =>
        (await LoadAsync(schedulerConfigId, null, ct)).FirstOrDefault();

    public Task<int> CreateAsync(SchedulerConfiguration configuration, AuditContext audit, CancellationToken ct) => SaveAsync(configuration, false, audit, ct);

    public Task UpdateAsync(SchedulerConfiguration configuration, AuditContext audit, CancellationToken ct) => SaveAsync(configuration, true, audit, ct);

    private Task<int> SaveAsync(SchedulerConfiguration c, bool isUpdate, AuditContext audit, CancellationToken ct) =>
        SqlErrorTranslator.Run(async () =>
        {
            await using var connection = await _factory.OpenAsync(ct);
            await using var command = Sql.Procedure(connection, "wf.usp_Scheduler_Save", _factory.CommandTimeoutSeconds);
            command.AddInt("@SchedulerConfigId", isUpdate ? c.SchedulerConfigId : null);
            command.AddNVarChar("@SchedulerCode", c.SchedulerCode, 50);
            command.AddInt("@SourceSystemId", c.SourceSystemId);
            command.AddNVarChar("@SchedulerName", c.SchedulerName, 200);
            command.AddNVarChar("@Description", c.Description, 1000);
            command.AddInt("@ApprovedQueryId", c.ApprovedQueryId);
            command.AddNVarChar("@CronExpression", c.CronExpression, 120);
            command.AddNVarChar("@TimeZoneId", c.TimeZoneId, 100);
            command.AddInt("@TargetWorkflowTemplateId", c.TargetWorkflowTemplateId);
            command.AddNVarChar("@TargetVersionPolicy", c.TargetVersionPolicy.ToString(), 20);
            command.AddInt("@PinnedVersionNo", c.PinnedVersionNo);
            command.AddNVarCharMax("@ExecutionParametersJson", c.ExecutionParametersJson);
            command.AddNVarChar("@MisfirePolicy", c.MisfirePolicy.ToString(), 20);
            command.AddInt("@MaxConcurrentRuns", c.MaxConcurrentRuns);
            command.Add("@EffectiveFrom", System.Data.SqlDbType.DateTime2, c.EffectiveFrom);
            command.Add("@EffectiveTo", System.Data.SqlDbType.DateTime2, c.EffectiveTo);
            command.AddBit("@IsActive", c.IsActive);
            command.AddRowVersion("@RowVersion", isUpdate ? c.RowVersion : null);
            command.AddAudit(audit);
            var id = command.AddOutputInt("@SavedSchedulerConfigId");
            await command.ExecuteNonQueryAsync(ct);
            return (int)id.Value;
        });

    private async Task<IReadOnlyList<SchedulerConfiguration>> LoadAsync(int? id, IReadOnlyCollection<int>? allowed, CancellationToken ct)
    {
        await using var connection = await _factory.OpenAsync(ct);
        await using var command = Sql.Procedure(connection, "wf.usp_Scheduler_Get", _factory.CommandTimeoutSeconds);
        command.AddInt("@SchedulerConfigId", id);
        command.AddBit("@RestrictToIds", allowed is not null);
        command.AddTable("@AllowedIds", "wf.IntListType", Sql.IntList(allowed ?? Array.Empty<int>()));
        await using var reader = await command.ExecuteReaderAsync(ct);
        var list = new List<SchedulerConfiguration>();
        while (await reader.ReadAsync(ct))
        {
            list.Add(Mappers.ReadScheduler(reader));
        }

        return list;
    }
}
