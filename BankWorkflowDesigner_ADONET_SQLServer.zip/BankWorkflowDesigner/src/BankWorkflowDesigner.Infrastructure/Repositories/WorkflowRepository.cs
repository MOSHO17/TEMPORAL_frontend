using System.Text.Json;
using BankWorkflowDesigner.Application.Abstractions;
using BankWorkflowDesigner.Domain.Dtos;
using BankWorkflowDesigner.Domain.Entities;
using BankWorkflowDesigner.Domain.Enums;
using BankWorkflowDesigner.Infrastructure.Data;
using Microsoft.Data.SqlClient;

namespace BankWorkflowDesigner.Infrastructure.Repositories;

public sealed class WorkflowRepository : IWorkflowRepository
{
    private readonly ISqlConnectionFactory _factory;

    public WorkflowRepository(ISqlConnectionFactory factory) => _factory = factory;

    public async Task<PagedResult<WorkflowTemplate>> SearchAsync(WorkflowQuery query, IReadOnlyCollection<int>? allowedSourceSystemIds, CancellationToken ct)
    {
        await using var connection = await _factory.OpenAsync(ct);
        await using var command = Sql.Procedure(connection, "wf.usp_Workflow_Search", _factory.CommandTimeoutSeconds);
        command.AddInt("@SourceSystemId", query.SourceSystemId);
        command.AddInt("@ModuleId", query.ModuleId);
        command.AddNVarChar("@Search", string.IsNullOrWhiteSpace(query.Search) ? null : query.Search.Trim(), 200);
        command.AddNVarChar("@Status", string.IsNullOrWhiteSpace(query.Status) ? null : query.Status.Trim(), 20);
        command.AddInt("@PageNumber", query.PageNumber);
        command.AddInt("@PageSize", query.PageSize);
        command.AddBit("@RestrictToIds", allowedSourceSystemIds is not null);
        command.AddTable("@AllowedIds", "wf.IntListType", Sql.IntList(allowedSourceSystemIds ?? Array.Empty<int>()));

        await using var reader = await command.ExecuteReaderAsync(ct);
        var total = 0;
        if (await reader.ReadAsync(ct))
        {
            total = reader.GetInt("TotalCount");
        }

        await reader.NextResultAsync(ct);
        var items = new List<WorkflowTemplate>();
        while (await reader.ReadAsync(ct))
        {
            items.Add(Mappers.ReadTemplate(reader));
        }

        return new PagedResult<WorkflowTemplate> { Items = items, TotalCount = total, PageNumber = query.PageNumber, PageSize = query.PageSize };
    }

    public Task<WorkflowTemplate?> GetTemplateAsync(int workflowTemplateId, CancellationToken ct) => GetTemplateInternalAsync(workflowTemplateId, null, ct);

    public Task<WorkflowTemplate?> GetTemplateByCodeAsync(string templateCode, CancellationToken ct) => GetTemplateInternalAsync(null, templateCode, ct);

    private async Task<WorkflowTemplate?> GetTemplateInternalAsync(int? id, string? code, CancellationToken ct)
    {
        await using var connection = await _factory.OpenAsync(ct);
        await using var command = Sql.Procedure(connection, "wf.usp_Workflow_Get", _factory.CommandTimeoutSeconds);
        command.AddInt("@WorkflowTemplateId", id);
        command.AddNVarChar("@TemplateCode", code, 50);
        await using var reader = await command.ExecuteReaderAsync(ct);
        return await reader.ReadAsync(ct) ? Mappers.ReadTemplate(reader) : null;
    }

    public async Task<IReadOnlyList<WorkflowVersion>> GetVersionsAsync(int workflowTemplateId, CancellationToken ct)
    {
        await using var connection = await _factory.OpenAsync(ct);
        await using var command = Sql.Procedure(connection, "wf.usp_WorkflowVersion_GetList", _factory.CommandTimeoutSeconds);
        command.AddInt("@WorkflowTemplateId", workflowTemplateId);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var list = new List<WorkflowVersion>();
        while (await reader.ReadAsync(ct))
        {
            list.Add(Mappers.ReadVersion(reader));
        }

        return list;
    }

    public async Task<WorkflowGraph?> GetGraphAsync(int workflowTemplateId, int? versionNo, CancellationToken ct)
    {
        await using var connection = await _factory.OpenAsync(ct);
        await using var command = Sql.Procedure(connection, "wf.usp_WorkflowGraph_Get", _factory.CommandTimeoutSeconds);
        command.AddInt("@WorkflowTemplateId", workflowTemplateId);
        command.AddInt("@VersionNo", versionNo);

        await using var reader = await command.ExecuteReaderAsync(ct);
        if (!await reader.ReadAsync(ct))
        {
            return null;
        }

        var graph = new WorkflowGraph { Version = Mappers.ReadVersion(reader) };

        await reader.NextResultAsync(ct);
        if (await reader.ReadAsync(ct))
        {
            graph.Template = Mappers.ReadTemplate(reader);
        }

        await reader.NextResultAsync(ct);
        if (await reader.ReadAsync(ct))
        {
            graph.SourceSystem = new SourceSystem
            {
                SourceSystemId = reader.GetInt("SourceSystemId"),
                SystemCode = reader.GetString("SystemCode"),
                ApplicationName = reader.GetString("ApplicationName"),
                DefaultTaskQueue = reader.GetString("DefaultTaskQueue"),
                Status = reader.GetEnum<EntityStatus>("SourceSystemStatus")
            };
            graph.Module = new SourceSystemModule
            {
                ModuleId = reader.GetInt("ModuleId"),
                SourceSystemId = graph.SourceSystem.SourceSystemId,
                ModuleCode = reader.GetString("ModuleCode"),
                ModuleName = reader.GetString("ModuleName"),
                Status = reader.GetEnum<EntityStatus>("ModuleStatus")
            };
        }

        await reader.NextResultAsync(ct);
        graph.Activities = await Mappers.ReadActivityAggregateAsync(reader, ct);

        await reader.NextResultAsync(ct);
        while (await reader.ReadAsync(ct))
        {
            graph.Connections.Add(Mappers.ReadConnection(reader));
        }

        await reader.NextResultAsync(ct);
        while (await reader.ReadAsync(ct))
        {
            graph.Parameters.Add(Mappers.ReadWorkflowParameter(reader));
        }

        return graph;
    }

    public Task<int> CreateAsync(WorkflowTemplate template, string? changeNotes, WorkflowGraph initialGraph, AuditContext audit, CancellationToken ct) =>
        SqlErrorTranslator.Run(async () =>
        {
            await using var connection = await _factory.OpenAsync(ct);
            await using var transaction = (SqlTransaction)await connection.BeginTransactionAsync(ct);
            try
            {
                int templateId, versionId;
                await using (var command = Sql.Procedure(connection, "wf.usp_Workflow_Create", _factory.CommandTimeoutSeconds, transaction))
                {
                    command.AddNVarChar("@TemplateCode", template.TemplateCode, 50);
                    command.AddInt("@SourceSystemId", template.SourceSystemId);
                    command.AddInt("@ModuleId", template.ModuleId);
                    command.AddNVarChar("@WorkflowName", template.WorkflowName, 200);
                    command.AddNVarChar("@Description", template.Description, 2000);
                    command.AddNVarChar("@ChangeNotes", changeNotes, 2000);
                    command.AddAudit(audit);
                    var templateIdParam = command.AddOutputInt("@WorkflowTemplateId");
                    var versionIdParam = command.AddOutputInt("@WorkflowVersionId");
                    await command.ExecuteNonQueryAsync(ct);
                    templateId = (int)templateIdParam.Value;
                    versionId = (int)versionIdParam.Value;
                }

                // Initial graph (Start/End nodes or an imported template) - same transaction, per-row audit suppressed.
                foreach (var activity in initialGraph.Activities)
                {
                    activity.ActivityId = await ActivityRepository.InsertActivityAsync(connection, transaction, versionId, activity, writeAudit: false, audit, _factory.CommandTimeoutSeconds, ct);
                    if (activity.Approval is not null)
                    {
                        await ActivityRepository.SaveApprovalAsync(connection, transaction, versionId, activity.ActivityId, activity.Approval, writeAudit: false, audit, _factory.CommandTimeoutSeconds, ct);
                    }
                }

                foreach (var connectionItem in initialGraph.Connections)
                {
                    await ActivityRepository.SaveConnectionAsync(connection, transaction, versionId, connectionItem, writeAudit: false, audit, _factory.CommandTimeoutSeconds, ct);
                }

                foreach (var parameter in initialGraph.Parameters)
                {
                    await ParameterRepository.SaveAsync(connection, transaction, versionId, parameter, isUpdate: false, writeAudit: false, audit, _factory.CommandTimeoutSeconds, ct);
                }

                await transaction.CommitAsync(ct);
                return templateId;
            }
            catch
            {
                await Sql.SafeRollbackAsync(transaction);
                throw;
            }
        });

    public Task UpdateHeaderAsync(int workflowTemplateId, string workflowName, string? description, string? changeNotes, string rowVersion, AuditContext audit, CancellationToken ct) =>
        SqlErrorTranslator.Run(async () =>
        {
            await using var connection = await _factory.OpenAsync(ct);
            await using var command = Sql.Procedure(connection, "wf.usp_Workflow_UpdateHeader", _factory.CommandTimeoutSeconds);
            command.AddInt("@WorkflowTemplateId", workflowTemplateId);
            command.AddNVarChar("@WorkflowName", workflowName, 200);
            command.AddNVarChar("@Description", description, 2000);
            command.AddNVarChar("@ChangeNotes", changeNotes, 2000);
            command.AddRowVersion("@RowVersion", rowVersion);
            command.AddAudit(audit);
            await command.ExecuteNonQueryAsync(ct);
        });

    public Task<int> CreateVersionAsync(int workflowTemplateId, int basedOnVersionNo, string? changeNotes, AuditContext audit, CancellationToken ct) =>
        SqlErrorTranslator.Run(async () =>
        {
            await using var connection = await _factory.OpenAsync(ct);
            await using var command = Sql.Procedure(connection, "wf.usp_WorkflowVersion_Create", _factory.CommandTimeoutSeconds);
            command.AddInt("@WorkflowTemplateId", workflowTemplateId);
            command.AddInt("@BasedOnVersionNo", basedOnVersionNo);
            command.AddNVarChar("@ChangeNotes", changeNotes, 2000);
            command.AddAudit(audit);
            var output = command.AddOutputInt("@NewVersionNo");
            await command.ExecuteNonQueryAsync(ct);
            return (int)output.Value;
        });

    public Task<int> CloneAsync(int workflowTemplateId, int fromVersionNo, string newTemplateCode, string workflowName, int sourceSystemId, int moduleId, AuditContext audit, CancellationToken ct) =>
        SqlErrorTranslator.Run(async () =>
        {
            await using var connection = await _factory.OpenAsync(ct);
            await using var command = Sql.Procedure(connection, "wf.usp_Workflow_Clone", _factory.CommandTimeoutSeconds);
            command.AddInt("@SourceTemplateId", workflowTemplateId);
            command.AddInt("@FromVersionNo", fromVersionNo);
            command.AddNVarChar("@NewTemplateCode", newTemplateCode, 50);
            command.AddNVarChar("@WorkflowName", workflowName, 200);
            command.AddInt("@SourceSystemId", sourceSystemId);
            command.AddInt("@ModuleId", moduleId);
            command.AddAudit(audit);
            var output = command.AddOutputInt("@NewTemplateId");
            await command.ExecuteNonQueryAsync(ct);
            return (int)output.Value;
        });

    public Task SaveValidationAsync(int workflowVersionId, bool isValid, string reportJson, AuditContext audit, CancellationToken ct) =>
        SqlErrorTranslator.Run(async () =>
        {
            await using var connection = await _factory.OpenAsync(ct);
            await using var command = Sql.Procedure(connection, "wf.usp_WorkflowVersion_SaveValidation", _factory.CommandTimeoutSeconds);
            command.AddInt("@WorkflowVersionId", workflowVersionId);
            command.AddBit("@IsValid", isValid);
            command.AddNVarCharMax("@ReportJson", reportJson);
            command.AddAudit(audit);
            await command.ExecuteNonQueryAsync(ct);
        });

    public Task<PublishResult> PublishAsync(int workflowVersionId, string expectedVersionRowVersion, string definitionJson, string definitionHash, string? comments, AuditContext audit, CancellationToken ct) =>
        SqlErrorTranslator.Run(async () =>
        {
            await using var connection = await _factory.OpenAsync(ct);
            await using var command = Sql.Procedure(connection, "wf.usp_WorkflowVersion_Publish", _factory.CommandTimeoutSeconds);
            command.AddInt("@WorkflowVersionId", workflowVersionId);
            command.AddRowVersion("@ExpectedRowVersion", expectedVersionRowVersion);
            command.AddNVarCharMax("@DefinitionJson", definitionJson);
            command.Add("@DefinitionHash", System.Data.SqlDbType.Char, definitionHash, 64);
            command.AddNVarChar("@Comments", comments, 2000);
            command.AddAudit(audit);
            await using var reader = await command.ExecuteReaderAsync(ct);
            if (!await reader.ReadAsync(ct))
            {
                throw new InvalidOperationException("Publish did not return a result.");
            }

            return new PublishResult
            {
                WorkflowTemplateId = reader.GetInt("WorkflowTemplateId"),
                TemplateCode = reader.GetString("TemplateCode"),
                VersionNo = reader.GetInt("VersionNo"),
                DefinitionHash = reader.GetString("DefinitionHash"),
                PublishedOn = reader.GetDate("PublishedOn"),
                PublishedBy = reader.GetString("PublishedBy")
            };
        });

    public Task SetTemplateStatusAsync(int workflowTemplateId, TemplateStatus status, string reason, AuditContext audit, CancellationToken ct) =>
        SqlErrorTranslator.Run(async () =>
        {
            await using var connection = await _factory.OpenAsync(ct);
            await using var command = Sql.Procedure(connection, "wf.usp_Workflow_SetStatus", _factory.CommandTimeoutSeconds);
            command.AddInt("@WorkflowTemplateId", workflowTemplateId);
            command.AddNVarChar("@Status", status.ToString(), 20);
            command.AddNVarChar("@Reason", reason, 1000);
            command.AddAudit(audit);
            await command.ExecuteNonQueryAsync(ct);
        });

    public async Task<string?> GetPublishedDefinitionAsync(int workflowTemplateId, int? versionNo, CancellationToken ct)
    {
        await using var connection = await _factory.OpenAsync(ct);
        await using var command = Sql.Procedure(connection, "wf.usp_WorkflowVersion_GetDefinition", _factory.CommandTimeoutSeconds);
        command.AddInt("@WorkflowTemplateId", workflowTemplateId);
        command.AddInt("@VersionNo", versionNo);
        var result = await command.ExecuteScalarAsync(ct);
        return result is null or DBNull ? null : (string)result;
    }

    public async Task<DashboardSummary> GetDashboardAsync(IReadOnlyCollection<int>? allowedSourceSystemIds, CancellationToken ct)
    {
        await using var connection = await _factory.OpenAsync(ct);
        await using var command = Sql.Procedure(connection, "wf.usp_Dashboard_Get", _factory.CommandTimeoutSeconds);
        command.AddBit("@RestrictToIds", allowedSourceSystemIds is not null);
        command.AddTable("@AllowedIds", "wf.IntListType", Sql.IntList(allowedSourceSystemIds ?? Array.Empty<int>()));
        await using var reader = await command.ExecuteReaderAsync(ct);
        var summary = new DashboardSummary();
        if (await reader.ReadAsync(ct))
        {
            summary.SourceSystemCount = reader.GetInt("SourceSystemCount");
            summary.TemplateCount = reader.GetInt("TemplateCount");
            summary.DraftVersionCount = reader.GetInt("DraftVersionCount");
            summary.PublishedTemplateCount = reader.GetInt("PublishedTemplateCount");
            summary.InactiveTemplateCount = reader.GetInt("InactiveTemplateCount");
            summary.SchedulerCount = reader.GetInt("SchedulerCount");
        }

        await reader.NextResultAsync(ct);
        var recent = new List<AuditLogEntry>();
        while (await reader.ReadAsync(ct))
        {
            recent.Add(Mappers.ReadAudit(reader));
        }

        summary.RecentActivity = recent;
        return summary;
    }
}
