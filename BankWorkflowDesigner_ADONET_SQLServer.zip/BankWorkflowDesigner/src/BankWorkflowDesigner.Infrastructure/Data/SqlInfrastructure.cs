using System.Data;
using System.Text.Json;
using BankWorkflowDesigner.Application.Abstractions;
using BankWorkflowDesigner.Domain.Exceptions;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;

namespace BankWorkflowDesigner.Infrastructure.Data;

public sealed class DatabaseOptions
{
    public const string SectionName = "Database";

    /// <summary>Name of the connection string in the ConnectionStrings section.</summary>
    public string ConnectionStringName { get; set; } = "WorkflowDesignerDb";

    public int CommandTimeoutSeconds { get; set; } = 30;
}

public interface ISqlConnectionFactory
{
    Task<SqlConnection> OpenAsync(CancellationToken ct);
    int CommandTimeoutSeconds { get; }
}

public sealed class SqlConnectionFactory : ISqlConnectionFactory
{
    private readonly string _connectionString;

    public SqlConnectionFactory(IConfiguration configuration, IOptions<DatabaseOptions> options)
    {
        CommandTimeoutSeconds = options.Value.CommandTimeoutSeconds;
        _connectionString = configuration.GetConnectionString(options.Value.ConnectionStringName)
                            ?? throw new InvalidOperationException($"Connection string '{options.Value.ConnectionStringName}' is not configured.");
    }

    public int CommandTimeoutSeconds { get; }

    public async Task<SqlConnection> OpenAsync(CancellationToken ct)
    {
        var connection = new SqlConnection(_connectionString);
        await connection.OpenAsync(ct);
        return connection;
    }
}

/// <summary>Helpers for parameterised stored procedure calls.</summary>
internal static class Sql
{
    public static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    public static SqlCommand Procedure(SqlConnection connection, string name, int timeoutSeconds, SqlTransaction? transaction = null) =>
        new(name, connection, transaction)
        {
            CommandType = CommandType.StoredProcedure,
            CommandTimeout = timeoutSeconds
        };

    public static SqlParameter Add(this SqlCommand command, string name, SqlDbType type, object? value, int size = 0)
    {
        var parameter = size > 0 ? new SqlParameter(name, type, size) : new SqlParameter(name, type);
        parameter.Value = value ?? DBNull.Value;
        command.Parameters.Add(parameter);
        return parameter;
    }

    public static SqlParameter AddNVarChar(this SqlCommand command, string name, string? value, int size) =>
        command.Add(name, SqlDbType.NVarChar, value, size);

    public static SqlParameter AddNVarCharMax(this SqlCommand command, string name, string? value) =>
        command.Add(name, SqlDbType.NVarChar, value, -1);

    public static SqlParameter AddInt(this SqlCommand command, string name, int? value) =>
        command.Add(name, SqlDbType.Int, value);

    public static SqlParameter AddBit(this SqlCommand command, string name, bool value) =>
        command.Add(name, SqlDbType.Bit, value);

    public static SqlParameter AddRowVersion(this SqlCommand command, string name, string? base64)
    {
        byte[]? bytes = null;
        if (!string.IsNullOrEmpty(base64))
        {
            try
            {
                bytes = Convert.FromBase64String(base64);
            }
            catch (FormatException)
            {
                throw new BusinessValidationException("rowVersion", "RowVersion is not a valid value.");
            }

            if (bytes.Length != 8)
            {
                throw new BusinessValidationException("rowVersion", "RowVersion is not a valid value.");
            }
        }

        return command.Add(name, SqlDbType.Binary, bytes, 8);
    }

    public static SqlParameter AddOutputInt(this SqlCommand command, string name)
    {
        var parameter = new SqlParameter(name, SqlDbType.Int) { Direction = ParameterDirection.Output };
        command.Parameters.Add(parameter);
        return parameter;
    }

    public static SqlParameter AddTable(this SqlCommand command, string name, string typeName, DataTable table)
    {
        var parameter = new SqlParameter(name, SqlDbType.Structured) { TypeName = typeName, Value = table };
        command.Parameters.Add(parameter);
        return parameter;
    }

    public static void AddAudit(this SqlCommand command, AuditContext audit)
    {
        command.AddNVarChar("@UserName", audit.UserName, 256);
        command.AddNVarChar("@CorrelationId", audit.CorrelationId, 100);
        command.AddNVarChar("@ClientIp", audit.ClientIp, 64);
    }

    /// <summary>With XACT_ABORT ON the server may already have rolled back - never mask the original error.</summary>
    public static async Task SafeRollbackAsync(SqlTransaction transaction)
    {
        try
        {
            if (transaction.Connection is not null)
            {
                await transaction.RollbackAsync(CancellationToken.None);
            }
        }
        catch (InvalidOperationException)
        {
        }
        catch (SqlException)
        {
        }
    }

    public static DataTable IntList(IEnumerable<int> ids)
    {
        var table = new DataTable();
        table.Columns.Add("Id", typeof(int));
        foreach (var id in ids.Distinct())
        {
            table.Rows.Add(id);
        }

        return table;
    }

    // ------------------------------------------------------------ reader helpers

    public static string GetString(this SqlDataReader reader, string column) => reader.GetString(reader.GetOrdinal(column));

    public static string? GetNullableString(this SqlDataReader reader, string column)
    {
        var ordinal = reader.GetOrdinal(column);
        return reader.IsDBNull(ordinal) ? null : reader.GetValue(ordinal).ToString();
    }

    public static int GetInt(this SqlDataReader reader, string column) => reader.GetInt32(reader.GetOrdinal(column));

    public static int? GetNullableInt(this SqlDataReader reader, string column)
    {
        var ordinal = reader.GetOrdinal(column);
        return reader.IsDBNull(ordinal) ? null : reader.GetInt32(ordinal);
    }

    public static long GetLong(this SqlDataReader reader, string column) => reader.GetInt64(reader.GetOrdinal(column));

    public static bool GetBool(this SqlDataReader reader, string column) => reader.GetBoolean(reader.GetOrdinal(column));

    public static decimal GetDecimalValue(this SqlDataReader reader, string column) => reader.GetDecimal(reader.GetOrdinal(column));

    public static DateTime GetDate(this SqlDataReader reader, string column) =>
        DateTime.SpecifyKind(reader.GetDateTime(reader.GetOrdinal(column)), DateTimeKind.Utc);

    public static DateTime? GetNullableDate(this SqlDataReader reader, string column)
    {
        var ordinal = reader.GetOrdinal(column);
        return reader.IsDBNull(ordinal) ? null : DateTime.SpecifyKind(reader.GetDateTime(ordinal), DateTimeKind.Utc);
    }

    public static string? GetRowVersion(this SqlDataReader reader, string column = "RowVer")
    {
        var ordinal = reader.GetOrdinal(column);
        return reader.IsDBNull(ordinal) ? null : Convert.ToBase64String((byte[])reader.GetValue(ordinal));
    }

    public static TEnum GetEnum<TEnum>(this SqlDataReader reader, string column) where TEnum : struct, Enum =>
        Enum.Parse<TEnum>(reader.GetString(reader.GetOrdinal(column)), ignoreCase: true);

    public static TEnum? GetNullableEnum<TEnum>(this SqlDataReader reader, string column) where TEnum : struct, Enum
    {
        var value = reader.GetNullableString(column);
        return value is null ? null : Enum.Parse<TEnum>(value, ignoreCase: true);
    }
}

/// <summary>Translates SQL Server errors raised by the stored procedures into domain exceptions.</summary>
internal static class SqlErrorTranslator
{
    public static async Task<T> Run<T>(Func<Task<T>> action)
    {
        try
        {
            return await action();
        }
        catch (SqlException ex)
        {
            throw Translate(ex);
        }
    }

    public static async Task Run(Func<Task> action)
    {
        try
        {
            await action();
        }
        catch (SqlException ex)
        {
            throw Translate(ex);
        }
    }

    public static Exception Translate(SqlException ex) => ex.Number switch
    {
        51400 => new BusinessValidationException(ex.Message),
        51403 => new ForbiddenException(ex.Message),
        51404 => new NotFoundException(ex.Message),
        51409 => new ConflictException(ex.Message),
        51410 => new ConcurrencyException(ex.Message),
        51411 => new ImmutableVersionException(ex.Message),
        2601 or 2627 => new ConflictException("A record with the same unique key already exists.", "DUPLICATE_KEY"),
        547 => new ConflictException("The operation violates a data integrity rule (referenced record missing or still in use).", "INTEGRITY_VIOLATION"),
        1205 => new ConflictException("The operation was chosen as a deadlock victim. Please retry.", "DEADLOCK"),
        _ => ex
    };
}
