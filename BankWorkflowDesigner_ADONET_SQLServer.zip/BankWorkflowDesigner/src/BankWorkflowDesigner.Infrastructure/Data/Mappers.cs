using System.Data;
using System.Text.Json;
using BankWorkflowDesigner.Domain.Entities;
using BankWorkflowDesigner.Domain.Enums;
using Microsoft.Data.SqlClient;

namespace BankWorkflowDesigner.Infrastructure.Data;

/// <summary>Row mappers (SqlDataReader -> domain) and table-valued parameter builders (domain -> DataTable).</summary>
internal static class Mappers
{
    // ================================================================ readers

    public static SourceSystem ReadSourceSystem(SqlDataReader r) => new()
    {
        SourceSystemId = r.GetInt("SourceSystemId"),
        SystemCode = r.GetString("SystemCode"),
        ApplicationName = r.GetString("ApplicationName"),
        Description = r.GetNullableString("Description"),
        DefaultTaskQueue = r.GetString("DefaultTaskQueue"),
        Status = r.GetEnum<EntityStatus>("Status"),
        CreatedBy = r.GetString("CreatedBy"),
        CreatedOn = r.GetDate("CreatedOn"),
        ModifiedBy = r.GetNullableString("ModifiedBy"),
        ModifiedOn = r.GetNullableDate("ModifiedOn"),
        RowVersion = r.GetRowVersion()
    };

    public static SourceSystemModule ReadModule(SqlDataReader r) => new()
    {
        ModuleId = r.GetInt("ModuleId"),
        SourceSystemId = r.GetInt("SourceSystemId"),
        ModuleCode = r.GetString("ModuleCode"),
        ModuleName = r.GetString("ModuleName"),
        Description = r.GetNullableString("Description"),
        Status = r.GetEnum<EntityStatus>("Status"),
        CreatedBy = r.GetString("CreatedBy"),
        CreatedOn = r.GetDate("CreatedOn"),
        ModifiedBy = r.GetNullableString("ModifiedBy"),
        ModifiedOn = r.GetNullableDate("ModifiedOn"),
        RowVersion = r.GetRowVersion()
    };

    public static SourceSystemUser ReadSourceSystemUser(SqlDataReader r) => new()
    {
        SourceSystemUserId = r.GetInt("SourceSystemUserId"),
        SourceSystemId = r.GetInt("SourceSystemId"),
        UserPrincipal = r.GetString("UserPrincipal"),
        DisplayName = r.GetNullableString("DisplayName"),
        AccessRole = r.GetEnum<SourceSystemAccessRole>("AccessRole"),
        IsActive = r.GetBool("IsActive"),
        CreatedBy = r.GetString("CreatedBy"),
        CreatedOn = r.GetDate("CreatedOn")
    };

    public static WorkflowTemplate ReadTemplate(SqlDataReader r) => new()
    {
        WorkflowTemplateId = r.GetInt("WorkflowTemplateId"),
        TemplateCode = r.GetString("TemplateCode"),
        SourceSystemId = r.GetInt("SourceSystemId"),
        SourceSystemCode = r.GetString("SourceSystemCode"),
        ModuleId = r.GetInt("ModuleId"),
        ModuleCode = r.GetString("ModuleCode"),
        WorkflowName = r.GetString("WorkflowName"),
        Description = r.GetNullableString("Description"),
        Status = r.GetEnum<TemplateStatus>("Status"),
        LatestVersionNo = r.GetInt("LatestVersionNo"),
        PublishedVersionNo = r.GetNullableInt("PublishedVersionNo"),
        ClonedFromTemplateId = r.GetNullableInt("ClonedFromTemplateId"),
        LatestVersionStatus = r.GetNullableEnum<VersionStatus>("LatestVersionStatus"),
        CreatedBy = r.GetString("CreatedBy"),
        CreatedOn = r.GetDate("CreatedOn"),
        ModifiedBy = r.GetNullableString("ModifiedBy"),
        ModifiedOn = r.GetNullableDate("ModifiedOn"),
        RowVersion = r.GetRowVersion()
    };

    public static WorkflowVersion ReadVersion(SqlDataReader r) => new()
    {
        WorkflowVersionId = r.GetInt("WorkflowVersionId"),
        WorkflowTemplateId = r.GetInt("WorkflowTemplateId"),
        VersionNo = r.GetInt("VersionNo"),
        Status = r.GetEnum<VersionStatus>("Status"),
        ChangeNotes = r.GetNullableString("ChangeNotes"),
        BasedOnVersionNo = r.GetNullableInt("BasedOnVersionNo"),
        ValidationResultJson = r.GetNullableString("ValidationResultJson"),
        ValidatedOn = r.GetNullableDate("ValidatedOn"),
        ValidatedBy = r.GetNullableString("ValidatedBy"),
        DefinitionJson = r.GetNullableString("DefinitionJson"),
        DefinitionHash = r.GetNullableString("DefinitionHash"),
        PublishedOn = r.GetNullableDate("PublishedOn"),
        PublishedBy = r.GetNullableString("PublishedBy"),
        CreatedBy = r.GetString("CreatedBy"),
        CreatedOn = r.GetDate("CreatedOn"),
        ModifiedBy = r.GetNullableString("ModifiedBy"),
        ModifiedOn = r.GetNullableDate("ModifiedOn"),
        RowVersion = r.GetRowVersion()
    };

    public static WorkflowActivity ReadActivity(SqlDataReader r) => new()
    {
        ActivityId = r.GetInt("ActivityId"),
        WorkflowVersionId = r.GetInt("WorkflowVersionId"),
        ActivityKey = r.GetString("ActivityKey"),
        ActivityType = r.GetEnum<ActivityType>("ActivityType"),
        DisplayName = r.GetString("DisplayName"),
        Description = r.GetNullableString("Description"),
        PositionX = r.GetInt("PositionX"),
        PositionY = r.GetInt("PositionY"),
        TimeoutSeconds = r.GetInt("TimeoutSeconds"),
        RetryMaxAttempts = r.GetInt("RetryMaxAttempts"),
        RetryInitialIntervalSeconds = r.GetInt("RetryInitialIntervalSeconds"),
        RetryBackoffCoefficient = r.GetDecimalValue("RetryBackoffCoefficient"),
        RetryMaxIntervalSeconds = r.GetInt("RetryMaxIntervalSeconds"),
        NonRetryableErrors = JsonSerializer.Deserialize<List<string>>(r.GetString("NonRetryableErrorsJson")) ?? new List<string>(),
        ErrorHandling = r.GetEnum<ErrorHandlingStrategy>("ErrorHandling"),
        ErrorRouteActivityKey = r.GetNullableString("ErrorRouteActivityKey"),
        ExecutionCondition = r.GetNullableString("ExecutionCondition"),
        Config = new Dictionary<string, string?>(
            JsonSerializer.Deserialize<Dictionary<string, string?>>(r.GetString("ConfigJson")) ?? new Dictionary<string, string?>(),
            StringComparer.OrdinalIgnoreCase),
        ModifiedBy = r.GetNullableString("ModifiedBy"),
        ModifiedOn = r.GetNullableDate("ModifiedOn"),
        RowVersion = r.GetRowVersion()
    };

    public static ActivityParameter ReadActivityParameter(SqlDataReader r)
    {
        var p = new ActivityParameter
        {
            ActivityParameterId = r.GetInt("ActivityParameterId"),
            ActivityId = r.GetInt("ActivityId")
        };
        ReadParameterBase(r, p);
        return p;
    }

    public static WorkflowParameter ReadWorkflowParameter(SqlDataReader r)
    {
        var p = new WorkflowParameter
        {
            ParameterId = r.GetInt("ParameterId"),
            WorkflowVersionId = r.GetInt("WorkflowVersionId"),
            RowVersion = r.GetRowVersion()
        };
        ReadParameterBase(r, p);
        return p;
    }

    private static void ReadParameterBase(SqlDataReader r, ParameterBase p)
    {
        p.Direction = r.GetEnum<Domain.Enums.ParameterDirection>("Direction");
        p.Name = r.GetString("Name");
        p.DataType = r.GetEnum<ParameterDataType>("DataType");
        p.IsMandatory = r.GetBool("IsMandatory");
        p.DefaultValue = r.GetNullableString("DefaultValue");
        p.JsonSchema = r.GetNullableString("JsonSchema");
        p.Description = r.GetNullableString("Description");
        p.SourceType = r.GetEnum<MappingSourceType>("SourceType");
        p.SourceReference = r.GetNullableString("SourceReference");
        p.SortOrder = r.GetInt("SortOrder");
    }

    public static (int ConfigId, ApprovalConfiguration Config) ReadApproval(SqlDataReader r) => (r.GetInt("ApprovalConfigId"), new ApprovalConfiguration
    {
        ApprovalConfigId = r.GetInt("ApprovalConfigId"),
        ActivityId = r.GetInt("ActivityId"),
        ApprovalPolicy = r.GetEnum<ApprovalPolicy>("ApprovalPolicy"),
        QuorumCount = r.GetNullableInt("QuorumCount"),
        RejectionRouting = r.GetEnum<RejectionRouting>("RejectionRouting"),
        RejectionTargetActivityKey = r.GetNullableString("RejectionTargetActivityKey"),
        SlaHours = r.GetInt("SlaHours"),
        EscalationAfterHours = r.GetNullableInt("EscalationAfterHours"),
        EscalationRole = r.GetNullableString("EscalationRole"),
        ReminderIntervalHours = r.GetNullableInt("ReminderIntervalHours"),
        AllowDelegation = r.GetBool("AllowDelegation"),
        EnforceMakerCheckerSegregation = r.GetBool("EnforceMakerCheckerSegregation")
    });

    public static (int ConfigId, ApprovalLevel Level) ReadLevel(SqlDataReader r) => (r.GetInt("ApprovalConfigId"), new ApprovalLevel
    {
        ApprovalLevelId = r.GetInt("ApprovalLevelId"),
        LevelNo = r.GetInt("LevelNo"),
        LevelName = r.GetString("LevelName"),
        ExecutionMode = r.GetEnum<LevelExecutionMode>("ExecutionMode"),
        MinApprovals = r.GetInt("MinApprovals"),
        SlaHours = r.GetNullableInt("SlaHours")
    });

    public static (int LevelId, ApprovalLevelRole Role) ReadLevelRole(SqlDataReader r) => (r.GetInt("ApprovalLevelId"), new ApprovalLevelRole
    {
        RoleCode = r.GetString("RoleCode"),
        GroupName = r.GetNullableString("GroupName"),
        SequenceNo = r.GetInt("SequenceNo")
    });

    public static ActivityConnection ReadConnection(SqlDataReader r) => new()
    {
        ConnectionId = r.GetInt("ConnectionId"),
        WorkflowVersionId = r.GetInt("WorkflowVersionId"),
        FromActivityKey = r.GetString("FromActivityKey"),
        ToActivityKey = r.GetString("ToActivityKey"),
        ConnectionType = r.GetEnum<ConnectionType>("ConnectionType"),
        ConditionExpression = r.GetNullableString("ConditionExpression"),
        IsDefault = r.GetBool("IsDefault"),
        Label = r.GetNullableString("Label"),
        Priority = r.GetInt("Priority")
    };

    public static AuditLogEntry ReadAudit(SqlDataReader r) => new()
    {
        AuditLogId = r.GetLong("AuditLogId"),
        EntityType = r.GetString("EntityType"),
        EntityId = r.GetString("EntityId"),
        Action = r.GetString("Action"),
        UserName = r.GetString("UserName"),
        ActionOn = r.GetDate("ActionOn"),
        CorrelationId = r.GetNullableString("CorrelationId"),
        ClientIp = r.GetNullableString("ClientIp"),
        Details = r.GetNullableString("Details")
    };

    public static SchedulerConfiguration ReadScheduler(SqlDataReader r) => new()
    {
        SchedulerConfigId = r.GetInt("SchedulerConfigId"),
        SchedulerCode = r.GetString("SchedulerCode"),
        SourceSystemId = r.GetInt("SourceSystemId"),
        SchedulerName = r.GetString("SchedulerName"),
        Description = r.GetNullableString("Description"),
        ApprovedQueryId = r.GetInt("ApprovedQueryId"),
        ApprovedQueryCode = r.GetNullableString("ApprovedQueryCode"),
        CronExpression = r.GetString("CronExpression"),
        TimeZoneId = r.GetString("TimeZoneId"),
        TargetWorkflowTemplateId = r.GetInt("TargetWorkflowTemplateId"),
        TargetTemplateCode = r.GetNullableString("TargetTemplateCode"),
        TargetVersionPolicy = r.GetEnum<TargetVersionPolicy>("TargetVersionPolicy"),
        PinnedVersionNo = r.GetNullableInt("PinnedVersionNo"),
        ExecutionParametersJson = r.GetString("ExecutionParametersJson"),
        MisfirePolicy = r.GetEnum<MisfirePolicy>("MisfirePolicy"),
        MaxConcurrentRuns = r.GetInt("MaxConcurrentRuns"),
        EffectiveFrom = r.GetNullableDate("EffectiveFrom"),
        EffectiveTo = r.GetNullableDate("EffectiveTo"),
        IsActive = r.GetBool("IsActive"),
        CreatedBy = r.GetString("CreatedBy"),
        CreatedOn = r.GetDate("CreatedOn"),
        ModifiedBy = r.GetNullableString("ModifiedBy"),
        ModifiedOn = r.GetNullableDate("ModifiedOn"),
        RowVersion = r.GetRowVersion()
    };

    /// <summary>Reads result sets: activities, activity parameters, approvals, levels, roles - and stitches them together.</summary>
    public static async Task<List<WorkflowActivity>> ReadActivityAggregateAsync(SqlDataReader reader, CancellationToken ct)
    {
        var activities = new List<WorkflowActivity>();
        while (await reader.ReadAsync(ct))
        {
            activities.Add(ReadActivity(reader));
        }

        var byId = activities.ToDictionary(a => a.ActivityId);

        await reader.NextResultAsync(ct);
        while (await reader.ReadAsync(ct))
        {
            var parameter = ReadActivityParameter(reader);
            if (byId.TryGetValue(parameter.ActivityId, out var owner))
            {
                owner.Parameters.Add(parameter);
            }
        }

        var configs = new Dictionary<int, ApprovalConfiguration>();
        await reader.NextResultAsync(ct);
        while (await reader.ReadAsync(ct))
        {
            var (configId, config) = ReadApproval(reader);
            configs[configId] = config;
            if (byId.TryGetValue(config.ActivityId, out var owner))
            {
                owner.Approval = config;
            }
        }

        var levels = new Dictionary<int, ApprovalLevel>();
        await reader.NextResultAsync(ct);
        while (await reader.ReadAsync(ct))
        {
            var (configId, level) = ReadLevel(reader);
            levels[level.ApprovalLevelId] = level;
            if (configs.TryGetValue(configId, out var config))
            {
                config.Levels.Add(level);
            }
        }

        await reader.NextResultAsync(ct);
        while (await reader.ReadAsync(ct))
        {
            var (levelId, role) = ReadLevelRole(reader);
            if (levels.TryGetValue(levelId, out var level))
            {
                level.Roles.Add(role);
            }
        }

        return activities;
    }

    // ================================================================ table-valued parameters

    public static DataTable ModuleTable(IEnumerable<SourceSystemModule> modules)
    {
        var table = new DataTable();
        table.Columns.Add("ModuleCode", typeof(string));
        table.Columns.Add("ModuleName", typeof(string));
        table.Columns.Add("Description", typeof(string));
        table.Columns.Add("Status", typeof(string));
        foreach (var m in modules)
        {
            table.Rows.Add(m.ModuleCode, m.ModuleName, (object?)m.Description ?? DBNull.Value, m.Status.ToString());
        }

        return table;
    }

    public static DataTable UserTable(IEnumerable<SourceSystemUser> users)
    {
        var table = new DataTable();
        table.Columns.Add("UserPrincipal", typeof(string));
        table.Columns.Add("DisplayName", typeof(string));
        table.Columns.Add("AccessRole", typeof(string));
        table.Columns.Add("IsActive", typeof(bool));
        foreach (var u in users)
        {
            table.Rows.Add(u.UserPrincipal, (object?)u.DisplayName ?? DBNull.Value, u.AccessRole.ToString(), u.IsActive);
        }

        return table;
    }

    public static DataTable ParameterTable(IEnumerable<ParameterBase> parameters)
    {
        var table = new DataTable();
        table.Columns.Add("Direction", typeof(string));
        table.Columns.Add("Name", typeof(string));
        table.Columns.Add("DataType", typeof(string));
        table.Columns.Add("IsMandatory", typeof(bool));
        table.Columns.Add("DefaultValue", typeof(string));
        table.Columns.Add("JsonSchema", typeof(string));
        table.Columns.Add("Description", typeof(string));
        table.Columns.Add("SourceType", typeof(string));
        table.Columns.Add("SourceReference", typeof(string));
        table.Columns.Add("SortOrder", typeof(int));
        foreach (var p in parameters)
        {
            table.Rows.Add(p.Direction.ToString(), p.Name, p.DataType.ToString(), p.IsMandatory,
                (object?)p.DefaultValue ?? DBNull.Value, (object?)p.JsonSchema ?? DBNull.Value, (object?)p.Description ?? DBNull.Value,
                p.SourceType.ToString(), (object?)p.SourceReference ?? DBNull.Value, p.SortOrder);
        }

        return table;
    }

    public static DataTable LevelTable(IEnumerable<ApprovalLevel> levels)
    {
        var table = new DataTable();
        table.Columns.Add("LevelNo", typeof(int));
        table.Columns.Add("LevelName", typeof(string));
        table.Columns.Add("ExecutionMode", typeof(string));
        table.Columns.Add("MinApprovals", typeof(int));
        table.Columns.Add("SlaHours", typeof(int));
        foreach (var l in levels)
        {
            table.Rows.Add(l.LevelNo, l.LevelName, l.ExecutionMode.ToString(), l.MinApprovals, (object?)l.SlaHours ?? DBNull.Value);
        }

        return table;
    }

    public static DataTable LevelRoleTable(IEnumerable<ApprovalLevel> levels)
    {
        var table = new DataTable();
        table.Columns.Add("LevelNo", typeof(int));
        table.Columns.Add("RoleCode", typeof(string));
        table.Columns.Add("GroupName", typeof(string));
        table.Columns.Add("SequenceNo", typeof(int));
        foreach (var l in levels)
        {
            foreach (var r in l.Roles)
            {
                table.Rows.Add(l.LevelNo, r.RoleCode, (object?)r.GroupName ?? DBNull.Value, r.SequenceNo);
            }
        }

        return table;
    }

    public static DataTable PositionTable(IEnumerable<(string Key, int X, int Y)> positions)
    {
        var table = new DataTable();
        table.Columns.Add("ActivityKey", typeof(string));
        table.Columns.Add("PositionX", typeof(int));
        table.Columns.Add("PositionY", typeof(int));
        foreach (var (key, x, y) in positions)
        {
            table.Rows.Add(key, x, y);
        }

        return table;
    }
}
