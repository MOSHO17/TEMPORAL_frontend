using BankWorkflowDesigner.Web;
using Microsoft.AspNetCore.Authorization;

var builder = WebApplication.CreateBuilder(args);

builder.Services.Configure<FrontEndOptions>(builder.Configuration.GetSection(FrontEndOptions.SectionName));
var frontEnd = builder.Configuration.GetSection(FrontEndOptions.SectionName).Get<FrontEndOptions>() ?? new FrontEndOptions();

if (string.Equals(frontEnd.AuthenticationMode, "Windows", StringComparison.OrdinalIgnoreCase))
{
    // Pages are served only to AD-authenticated users (IIS Windows authentication). Data access is authorised again by the API.
    builder.Services.AddAuthentication(Microsoft.AspNetCore.Server.IISIntegration.IISDefaults.AuthenticationScheme);
    builder.Services.AddAuthorization(o => o.FallbackPolicy = new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build());
}

builder.Services.AddControllersWithViews(options =>
{
    options.Filters.Add(new Microsoft.AspNetCore.Mvc.AutoValidateAntiforgeryTokenAttribute());
});

var app = builder.Build();

if (string.Equals(frontEnd.AuthenticationMode, "Windows", StringComparison.OrdinalIgnoreCase))
{
    var schemes = app.Services.GetRequiredService<Microsoft.AspNetCore.Authentication.IAuthenticationSchemeProvider>();
    if (await schemes.GetSchemeAsync("Windows") is null)
    {
        throw new InvalidOperationException(
            "FrontEnd:AuthenticationMode is 'Windows' but the site is not hosted in IIS with Windows Authentication enabled. " +
            "Host it in IIS, or set FrontEnd:AuthenticationMode to 'Development' for local use.");
    }
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseMiddleware<SecurityHeadersMiddleware>();
app.UseStaticFiles();
app.UseRouting();

if (string.Equals(frontEnd.AuthenticationMode, "Windows", StringComparison.OrdinalIgnoreCase))
{
    app.UseAuthentication();
    app.UseAuthorization();
}

app.MapControllerRoute("default", "{controller=Home}/{action=Index}/{id?}");

app.Run();
