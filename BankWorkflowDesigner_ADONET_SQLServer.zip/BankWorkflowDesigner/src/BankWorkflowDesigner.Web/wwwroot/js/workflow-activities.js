/* =============================================================================
   workflow-activities.js - activity catalog, catalog-driven configuration forms,
   the Activity Configuration page and the Approval Configuration page.
   ============================================================================= */
(function (WF) {
    'use strict';
    const { el, qs, qsa, clear, icon } = WF.dom;

    // ------------------------------------------------------------------ catalog
    let catalogPromise = null;
    WF.catalog = {
        load() {
            if (!catalogPromise) {
                catalogPromise = WF.api.catalog().then(list => {
                    const map = {};
                    list.forEach(d => { map[d.type] = d; });
                    return { list, map };
                });
            }
            return catalogPromise;
        },
        colorClass(descriptor) { return `wf-color-${(descriptor.color || '#0d6efd').replace('#', '')}`; }
    };

    /**
     * Renders the catalog-defined settings of an activity type.
     * refs = { profiles, queries, sourceSystemId }
     */
    function renderConfigFields(container, descriptor, config, refs, readOnly) {
        clear(container);
        if (!descriptor.configFields.length) {
            container.appendChild(el('p', { class: 'small text-muted mb-0', text: 'This activity type has no additional settings.' }));
            return { read: () => ({}) };
        }

        const controls = {};
        const row = el('div', { class: 'row g-2' });
        descriptor.configFields.forEach(field => {
            const id = `cfg-${field.key}`;
            const value = config && config[field.key] !== undefined && config[field.key] !== null ? config[field.key] : (field.defaultValue ?? '');
            let control;
            switch (field.fieldType) {
                case 'Select':
                    control = el('select', { class: 'form-select form-select-sm', attrs: { id } }, el('option', { value: '', text: '(not set)' }), field.options.map(o => el('option', { value: o, text: o })));
                    control.value = value;
                    break;
                case 'Boolean':
                    control = el('select', { class: 'form-select form-select-sm', attrs: { id } },
                        el('option', { value: '', text: '(default)' }), el('option', { value: 'true', text: 'Yes' }), el('option', { value: 'false', text: 'No' }));
                    control.value = value;
                    break;
                case 'ConnectionProfile': {
                    const profiles = (refs.profiles || []).filter(p => p.isActive && (!field.profileType || p.profileType === field.profileType));
                    control = el('select', { class: 'form-select form-select-sm', attrs: { id } }, el('option', { value: '', text: 'Select profile...' }),
                        profiles.map(p => el('option', { value: p.profileCode, text: `${p.profileCode}${p.environment ? ' [' + p.environment + ']' : ''}` })));
                    if (value && !profiles.some(p => p.profileCode === value)) { control.appendChild(el('option', { value, text: `${value} (unknown)` })); }
                    control.value = value;
                    break;
                }
                case 'ApprovedQuery': {
                    const queries = (refs.queries || []).filter(q => q.isActive && (!q.sourceSystemId || !refs.sourceSystemId || q.sourceSystemId === refs.sourceSystemId));
                    control = el('select', { class: 'form-select form-select-sm', attrs: { id } }, el('option', { value: '', text: 'Select approved query...' }),
                        queries.map(q => el('option', { value: q.queryCode, text: `${q.queryCode} - ${q.queryName}` })));
                    if (value && !queries.some(q => q.queryCode === value)) { control.appendChild(el('option', { value, text: `${value} (not approved)` })); }
                    control.value = value;
                    break;
                }
                case 'TextArea':
                    control = el('textarea', { class: 'form-control form-control-sm', attrs: { id, rows: 3, maxlength: 4000 } });
                    control.value = value;
                    break;
                case 'Number':
                    control = el('input', { class: 'form-control form-control-sm', value, attrs: { id, type: 'number', min: field.min ?? undefined, max: field.max ?? undefined } });
                    break;
                default:
                    control = el('input', { class: 'form-control form-control-sm', value, attrs: { id, maxlength: 4000, pattern: field.pattern || undefined } });
            }
            if (readOnly) { control.disabled = true; }
            controls[field.key] = control;
            row.appendChild(el('div', { class: field.fieldType === 'TextArea' ? 'col-12' : 'col-md-6' },
                el('label', { class: 'form-label small mb-0', attrs: { for: id } }, field.label, field.required ? el('span', { class: 'text-danger', text: ' *' }) : null),
                control,
                field.helpText ? el('div', { class: 'form-text', text: field.helpText }) : null));
        });
        container.appendChild(row);

        return {
            read() {
                const result = {};
                Object.entries(controls).forEach(([key, control]) => {
                    const v = control.value.trim();
                    result[key] = v === '' ? null : v;
                });
                return result;
            }
        };
    }

    WF.activities = { renderConfigFields };

    // ================================================================== Activity Configuration page
    WF.pages.activity = {
        async init(root) {
            const workflowId = Number(root.dataset.workflowId);
            const activityId = Number(root.dataset.activityId);
            const form = qs('[data-role="form"]', root);
            const errors = qs('[data-role="errors"]', root);

            const [detail, catalog, profiles, queries] = await Promise.all([
                WF.workflowContext.load(workflowId), WF.catalog.load(), WF.api.connectionProfiles(), WF.api.approvedQueries()]);
            const graph = detail.graph;
            let activity = graph.activities.find(a => a.activityId === activityId);
            if (!activity) { throw new Error(`Activity ${activityId} does not exist in the latest version of this workflow.`); }
            const descriptor = catalog.map[activity.activityType];
            const editable = WF.workflowContext.isEditable(detail);

            qs('[data-bind="activityTitle"]', root).textContent = activity.displayName;
            qs('[data-bind="activityType"]', root).textContent = descriptor.displayName;
            qs('[data-bind="activityIcon"]', root).classList.add(descriptor.icon);
            qs('[data-bind-href="designer"]', root).setAttribute('href', `/Workflows/Designer/${workflowId}`);
            const approvalLink = qs('[data-role="approval-link"]', root);
            approvalLink.setAttribute('href', `/Workflows/Approval/${workflowId}?activityId=${activityId}`);
            approvalLink.classList.toggle('d-none', !descriptor.isApproval);

            const fill = a => {
                WF.forms.fill(form, {
                    activityKey: a.activityKey, displayName: a.displayName, description: a.description, executionCondition: a.executionCondition,
                    timeoutSeconds: a.timeoutSeconds, maxAttempts: a.retryMaxAttempts, backoffCoefficient: a.retryBackoffCoefficient,
                    initialIntervalSeconds: a.retryInitialIntervalSeconds, maxIntervalSeconds: a.retryMaxIntervalSeconds,
                    nonRetryableErrors: (a.nonRetryableErrors || []).join(', '), errorHandling: a.errorHandling
                });
                const route = qs('#a-errroute', form);
                WF.forms.fillSelect(route, graph.activities.filter(x => x.activityId !== a.activityId), x => x.activityKey, x => `${x.displayName} (${x.activityKey})`, '(none)');
                route.value = a.errorRouteActivityKey || '';
            };
            fill(activity);

            let configEditor = renderConfigFields(qs('[data-role="config"]', root), descriptor, activity.config, { profiles, queries, sourceSystemId: detail.template.sourceSystemId }, !editable);
            let paramTable = WF.parameters.createActivityParameterTable(qs('[data-role="parameters"]', root), activity.parameters,
                { graph, ownerKey: activity.activityKey, profiles }, !editable);

            qs('[data-action="add-input"]', root).addEventListener('click', () => paramTable.add('Input'));
            qs('[data-action="add-output"]', root).addEventListener('click', () => paramTable.add('Output'));

            WF.ui.setReadOnly(root, !editable);
            qsa('input, select, textarea', form).forEach(c => { if (!editable) { c.disabled = true; } });

            form.addEventListener('submit', async evt => {
                evt.preventDefault();
                WF.ui.clearError(errors);
                const data = WF.forms.read(form);
                const body = WF.api.toActivityRequest(activity, {
                    activityKey: data.activityKey,
                    displayName: data.displayName,
                    description: data.description,
                    executionCondition: data.executionCondition,
                    timeoutSeconds: data.timeoutSeconds,
                    retryPolicy: {
                        maxAttempts: data.maxAttempts,
                        initialIntervalSeconds: data.initialIntervalSeconds,
                        backoffCoefficient: data.backoffCoefficient,
                        maxIntervalSeconds: data.maxIntervalSeconds,
                        nonRetryableErrors: (data.nonRetryableErrors || '').split(',').map(s => s.trim()).filter(Boolean)
                    },
                    errorHandling: data.errorHandling,
                    errorRouteActivityKey: data.errorRouteActivityKey,
                    config: configEditor.read(),
                    parameters: paramTable.read()
                });
                await WF.ui.busy(form.querySelector('button[type="submit"]'), async () => {
                    try {
                        activity = await WF.api.updateActivity(workflowId, activityId, body);
                        const i = graph.activities.findIndex(a => a.activityId === activityId);
                        graph.activities[i] = activity;
                        fill(activity);
                        qs('[data-bind="activityTitle"]', root).textContent = activity.displayName;
                        configEditor = renderConfigFields(qs('[data-role="config"]', root), descriptor, activity.config, { profiles, queries, sourceSystemId: detail.template.sourceSystemId }, false);
                        paramTable = WF.parameters.createActivityParameterTable(qs('[data-role="parameters"]', root), activity.parameters, { graph, ownerKey: activity.activityKey, profiles }, false);
                        WF.ui.toast('Activity saved.');
                    } catch (e) {
                        WF.ui.showError(errors, e);
                    }
                });
            });
        }
    };

    // ================================================================== Approval Configuration page
    const approvalState = { workflowId: 0, detail: null, catalog: null, activity: null, levels: [] };

    function levelCard(level, onRemove) {
        const rolesBody = el('tbody');
        const name = el('input', { class: 'form-control form-control-sm', value: level.levelName || `Level ${level.levelNo}`, attrs: { maxlength: 200, 'aria-label': 'Level name' } });
        const mode = el('select', { class: 'form-select form-select-sm', attrs: { 'aria-label': 'Execution mode' } }, ['Sequential', 'Parallel'].map(m => el('option', { value: m, text: m })));
        mode.value = level.executionMode || 'Sequential';
        const min = el('input', { class: 'form-control form-control-sm', value: level.minApprovals || 1, attrs: { type: 'number', min: 1, max: 50, 'aria-label': 'Minimum approvals' } });
        const sla = el('input', { class: 'form-control form-control-sm', value: level.slaHours || '', attrs: { type: 'number', min: 1, max: 8760, 'aria-label': 'Level SLA hours' } });
        const levelNo = el('span', { class: 'badge text-bg-primary', text: `L${level.levelNo}` });

        const addRole = r => {
            const code = el('input', { class: 'form-control form-control-sm font-monospace', value: r.roleCode || '', attrs: { maxlength: 100, placeholder: 'ROLE_CODE', 'aria-label': 'Role code' } });
            const group = el('input', { class: 'form-control form-control-sm', value: r.groupName || '', attrs: { maxlength: 200, placeholder: 'Group / committee', 'aria-label': 'Group name' } });
            const seq = el('input', { class: 'form-control form-control-sm', value: r.sequenceNo ?? rolesBody.children.length + 1, attrs: { type: 'number', min: 0, max: 100, 'aria-label': 'Sequence' } });
            const tr = el('tr', {}, el('td', {}, code), el('td', {}, group), el('td', {}, seq),
                el('td', { class: 'text-end' }, el('button', { class: 'btn btn-sm btn-outline-danger', attrs: { type: 'button', title: 'Remove role' }, on: { click: () => tr.remove() } }, icon('bi-x'))));
            tr.read = () => ({ roleCode: code.value.trim(), groupName: group.value.trim() || null, sequenceNo: Number(seq.value || 0) });
            rolesBody.appendChild(tr);
        };
        (level.roles || []).forEach(addRole);
        if (!(level.roles || []).length) { addRole({}); }

        const card = el('div', { class: 'card wf-level-card mb-2' },
            el('div', { class: 'card-body p-2' },
                el('div', { class: 'row g-2 align-items-end mb-2' },
                    el('div', { class: 'col-auto' }, levelNo),
                    el('div', { class: 'col-md-4' }, el('label', { class: 'form-label small mb-0', text: 'Level name' }), name),
                    el('div', { class: 'col-md-2' }, el('label', { class: 'form-label small mb-0', text: 'Mode' }), mode),
                    el('div', { class: 'col-md-2' }, el('label', { class: 'form-label small mb-0', text: 'Min approvals' }), min),
                    el('div', { class: 'col-md-2' }, el('label', { class: 'form-label small mb-0', text: 'Level SLA (h)' }), sla),
                    el('div', { class: 'col text-end' }, el('button', { class: 'btn btn-sm btn-outline-danger', attrs: { type: 'button' }, on: { click: onRemove } }, icon('bi-trash'), ' Level'))),
                el('table', { class: 'table table-sm mb-1' },
                    el('thead', {}, el('tr', {}, el('th', { text: 'Role / AD group code' }), el('th', { text: 'Parallel group name' }), el('th', { text: 'Seq.' }), el('th'))),
                    rolesBody),
                el('button', { class: 'btn btn-sm btn-link p-0', attrs: { type: 'button' }, on: { click: () => addRole({}) } }, icon('bi-plus'), ' Add role')));

        card.setLevelNo = n => { level.levelNo = n; levelNo.textContent = `L${n}`; };
        card.read = () => ({
            levelNo: level.levelNo,
            levelName: name.value.trim(),
            executionMode: mode.value,
            minApprovals: Number(min.value || 1),
            slaHours: sla.value ? Number(sla.value) : null,
            roles: Array.from(rolesBody.children).map(tr => tr.read()).filter(r => r.roleCode)
        });
        return card;
    }

    function renderLevels(root) {
        const holder = clear(qs('[data-role="levels"]', root));
        approvalState.levels.forEach((card, i) => { card.setLevelNo(i + 1); holder.appendChild(card); });
        if (!approvalState.levels.length) { holder.appendChild(el('p', { class: 'small text-muted', text: 'No levels yet - add at least one.' })); }
    }

    function selectApprovalActivity(root, activity) {
        approvalState.activity = activity;
        const form = qs('[data-role="form"]', root);
        const descriptor = approvalState.catalog.map[activity.activityType];
        const editable = WF.workflowContext.isEditable(approvalState.detail);
        qs('[data-bind="approvalTitle"]', root).textContent = `${activity.displayName} (${descriptor.displayName})`;
        qsa('[data-role="activity-list"] .list-group-item', root).forEach(i => i.classList.toggle('active', i.dataset.key === activity.activityKey));

        const cfg = activity.approval || {
            approvalPolicy: 'AnyOne', rejectionRouting: 'ToMaker', slaHours: 24, enforceMakerCheckerSegregation: true, allowDelegation: false,
            levels: [{ levelNo: 1, levelName: 'Level 1', executionMode: descriptor.requiredLevelMode || 'Sequential', minApprovals: 1, roles: [] }]
        };
        WF.forms.fill(form, cfg);
        const target = qs('#ap-rejtarget', form);
        WF.forms.fillSelect(target, approvalState.detail.graph.activities.filter(a => a.activityKey !== activity.activityKey), a => a.activityKey, a => `${a.displayName} (${a.activityKey})`, '(none)');
        target.value = cfg.rejectionTargetActivityKey || '';

        approvalState.levels = cfg.levels.map(l => {
            const card = levelCard(JSON.parse(JSON.stringify(l)), () => { approvalState.levels.splice(approvalState.levels.indexOf(card), 1); renderLevels(root); });
            return card;
        });
        renderLevels(root);

        const hints = {
            Checker: 'Checker: one level; the maker of the request can never check it when segregation is on.',
            Approver: 'Approver: a single approval level.',
            MultilevelApprover: 'Multilevel Approver: two or more levels, processed level by level.',
            SequentialApprover: 'Sequential Approver: levels must be Sequential; approvers act in the order of the sequence numbers.',
            ParallelApprover: 'Parallel Approver: at least one Parallel level with two or more groups; the approval policy decides the outcome.'
        };
        qs('[data-role="type-hint"]', root).textContent = hints[activity.activityType] || '';
        qs('[data-role="fields"]', root).disabled = !editable;
        form.querySelector('button[type="submit"]').disabled = !editable;
        WF.ui.clearError(qs('[data-role="errors"]', root));
    }

    function renderApprovalList(root) {
        const catalog = approvalState.catalog;
        const approvals = approvalState.detail.graph.activities.filter(a => catalog.map[a.activityType].isApproval);
        const list = clear(qs('[data-role="activity-list"]', root));
        if (!approvals.length) {
            list.appendChild(el('div', { class: 'list-group-item small text-muted', text: 'This workflow has no approval activities. Add a Checker / Approver in the designer.' }));
        }

        approvals.forEach(a => list.appendChild(el('button', {
            class: `list-group-item list-group-item-action d-flex justify-content-between align-items-center${approvalState.activity && approvalState.activity.activityKey === a.activityKey ? ' active' : ''}`,
            attrs: { type: 'button' }, dataset: { key: a.activityKey },
            on: { click: () => selectApprovalActivity(root, a) }
        }, el('span', {}, a.displayName, el('div', { class: 'small text-muted', text: catalog.map[a.activityType].displayName })),
            a.approval ? el('span', { class: 'badge text-bg-success', text: `${a.approval.levels.length} lvl` }) : el('span', { class: 'badge text-bg-warning', text: 'not set' }))));
        return approvals;
    }

    WF.pages.approval = {
        async init(root) {
            approvalState.workflowId = Number(root.dataset.workflowId);
            const [detail, catalog] = await Promise.all([WF.workflowContext.load(approvalState.workflowId), WF.catalog.load()]);
            approvalState.detail = detail;
            approvalState.catalog = catalog;
            const approvals = renderApprovalList(root);

            qs('[data-action="add-level"]', root).addEventListener('click', () => {
                const card = levelCard({ levelNo: approvalState.levels.length + 1, executionMode: 'Sequential', minApprovals: 1, roles: [] },
                    () => { approvalState.levels.splice(approvalState.levels.indexOf(card), 1); renderLevels(root); });
                approvalState.levels.push(card);
                renderLevels(root);
            });

            const form = qs('[data-role="form"]', root);
            form.addEventListener('submit', async evt => {
                evt.preventDefault();
                if (!approvalState.activity) { return; }
                const data = WF.forms.read(form);
                const body = {
                    approvalPolicy: data.approvalPolicy, quorumCount: data.quorumCount, rejectionRouting: data.rejectionRouting,
                    rejectionTargetActivityKey: data.rejectionTargetActivityKey, slaHours: data.slaHours || 24,
                    escalationAfterHours: data.escalationAfterHours, escalationRole: data.escalationRole, reminderIntervalHours: data.reminderIntervalHours,
                    allowDelegation: data.allowDelegation, enforceMakerCheckerSegregation: data.enforceMakerCheckerSegregation,
                    levels: approvalState.levels.map(c => c.read())
                };
                await WF.ui.busy(form.querySelector('button[type="submit"]'), async () => {
                    try {
                        const updated = await WF.api.saveApproval(approvalState.workflowId, approvalState.activity.activityId, body);
                        const graph = approvalState.detail.graph;
                        graph.activities[graph.activities.findIndex(a => a.activityId === updated.activityId)] = updated;
                        approvalState.activity = updated;
                        renderApprovalList(root);
                        selectApprovalActivity(root, updated);
                        WF.ui.toast('Approval configuration saved.');
                    } catch (e) {
                        WF.ui.showError(qs('[data-role="errors"]', root), e);
                    }
                });
            });

            const requested = Number(root.dataset.activityId || 0);
            const initial = approvals.find(a => a.activityId === requested) || approvals[0];
            if (initial) { selectApprovalActivity(root, initial); }
        }
    };
})(window.WF);
