/* =============================================================================
   workflow-api.js - the only place the front end talks to BankWorkflowDesigner.Api.
   Uses fetch with credentials (Windows / cookie auth), anti-forgery header on every
   state-changing call, correlation ids and consistent error objects.
   ============================================================================= */
(function (window) {
    'use strict';

    const WF = window.WF = window.WF || {};
    const DEV_USER_KEY = 'wf-dev-user';
    let antiforgeryToken = null;
    let antiforgeryPromise = null;

    class ApiError extends Error {
        constructor(status, body) {
            super((body && (body.detail || body.title)) || `Request failed with status ${status}`);
            this.name = 'ApiError';
            this.status = status;
            this.code = body && body.code;
            this.errors = body && body.errors;
            this.traceId = body && body.traceId;
        }
    }

    WF.ApiError = ApiError;

    function getDevUser() {
        try { return window.localStorage.getItem(DEV_USER_KEY); } catch { return null; }
    }

    function setDevUser(name) {
        try { window.localStorage.setItem(DEV_USER_KEY, name); } catch { /* ignore */ }
        antiforgeryToken = null;
    }

    function newCorrelationId() {
        if (window.crypto && window.crypto.randomUUID) { return window.crypto.randomUUID().replace(/-/g, ''); }
        return `${Date.now().toString(16)}${Math.random().toString(16).slice(2)}`;
    }

    function baseHeaders() {
        const headers = { 'Accept': 'application/json', 'X-Correlation-Id': newCorrelationId() };
        if (WF.config.authMode.toLowerCase() === 'development') {
            const user = getDevUser();
            if (user) { headers['X-Dev-User'] = user; }
        }
        return headers;
    }

    async function ensureAntiforgeryToken() {
        if (antiforgeryToken) { return antiforgeryToken; }
        if (!antiforgeryPromise) {
            antiforgeryPromise = fetch(`${WF.config.apiBaseUrl}/api/security/antiforgery-token`, {
                method: 'GET', headers: baseHeaders(), credentials: 'include', cache: 'no-store'
            }).then(async r => {
                if (!r.ok) { throw new ApiError(r.status, await safeJson(r)); }
                const body = await r.json();
                antiforgeryToken = body.token;
                return antiforgeryToken;
            }).finally(() => { antiforgeryPromise = null; });
        }
        return antiforgeryPromise;
    }

    async function safeJson(response) {
        const text = await response.text();
        if (!text) { return null; }
        try { return JSON.parse(text); } catch { return { detail: text.slice(0, 300) }; }
    }

    async function request(method, path, body, options) {
        options = options || {};
        const unsafe = !['GET', 'HEAD'].includes(method);
        const send = async () => {
            const headers = baseHeaders();
            if (body !== undefined) { headers['Content-Type'] = 'application/json'; }
            if (unsafe) { headers['X-XSRF-TOKEN'] = await ensureAntiforgeryToken(); }
            return fetch(`${WF.config.apiBaseUrl}${path}`, {
                method,
                headers,
                credentials: 'include',
                cache: 'no-store',
                body: body === undefined ? undefined : JSON.stringify(body)
            });
        };

        let response = await send();
        if (unsafe && response.status === 400) {
            const clone = response.clone();
            const problem = await safeJson(clone);
            if (problem && problem.code === 'ANTIFORGERY_FAILED') {
                antiforgeryToken = null;
                response = await send();
            }
        }

        if (!response.ok) { throw new ApiError(response.status, await safeJson(response)); }
        if (response.status === 204) { return null; }
        if (options.raw) { return response.text(); }
        return safeJson(response);
    }

    function qs(params) {
        const parts = Object.entries(params || {})
            .filter(([, v]) => v !== null && v !== undefined && v !== '')
            .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`);
        return parts.length ? `?${parts.join('&')}` : '';
    }

    const id = v => encodeURIComponent(String(v));

    WF.api = {
        request, getDevUser, setDevUser,

        // session & reference data
        me: () => request('GET', '/api/me'),
        devUsers: () => request('GET', '/api/security/dev-users'),
        dashboard: () => request('GET', '/api/dashboard'),
        catalog: () => request('GET', '/api/catalog/activities'),
        connectionProfiles: () => request('GET', '/api/reference/connection-profiles'),
        approvedQueries: () => request('GET', '/api/reference/approved-queries'),

        // source systems
        getSourceSystems: () => request('GET', '/api/source-systems'),
        getSourceSystem: ssId => request('GET', `/api/source-systems/${id(ssId)}`),
        createSourceSystem: body => request('POST', '/api/source-systems', body),
        updateSourceSystem: (ssId, body) => request('PUT', `/api/source-systems/${id(ssId)}`, body),

        // workflow templates
        searchWorkflows: query => request('GET', `/api/workflows${qs(query)}`),
        getWorkflow: (wfId, version) => request('GET', `/api/workflows/${id(wfId)}${qs({ version })}`),
        createWorkflow: body => request('POST', '/api/workflows', body),
        importWorkflow: body => request('POST', '/api/workflows/import', body),
        updateWorkflow: (wfId, body) => request('PUT', `/api/workflows/${id(wfId)}`, body),
        cloneWorkflow: (wfId, body) => request('POST', `/api/workflows/${id(wfId)}/clone`, body),
        createVersion: (wfId, body) => request('POST', `/api/workflows/${id(wfId)}/versions`, body),
        getVersions: wfId => request('GET', `/api/workflows/${id(wfId)}/versions`),
        validateWorkflow: wfId => request('POST', `/api/workflows/${id(wfId)}/validate`),
        publishWorkflow: (wfId, body) => request('POST', `/api/workflows/${id(wfId)}/publish`, body),
        changeStatus: (wfId, body) => request('POST', `/api/workflows/${id(wfId)}/status`, body),
        getDefinition: (wfId, version) => request('GET', `/api/workflows/${id(wfId)}/definition${qs({ version })}`, undefined, { raw: true }),
        previewDefinition: wfId => request('GET', `/api/workflows/${id(wfId)}/definition/preview`, undefined, { raw: true }),
        getAudit: wfId => request('GET', `/api/workflows/${id(wfId)}/audit`),

        // activities & connections
        addActivity: (wfId, body) => request('POST', `/api/workflows/${id(wfId)}/activities`, body),
        updateActivity: (wfId, activityId, body) => request('PUT', `/api/workflows/${id(wfId)}/activities/${id(activityId)}`, body),
        deleteActivity: (wfId, activityId) => request('DELETE', `/api/workflows/${id(wfId)}/activities/${id(activityId)}`),
        saveApproval: (wfId, activityId, body) => request('PUT', `/api/workflows/${id(wfId)}/activities/${id(activityId)}/approval`, body),
        saveLayout: (wfId, positions) => request('PUT', `/api/workflows/${id(wfId)}/layout`, { positions }),
        addConnection: (wfId, body) => request('POST', `/api/workflows/${id(wfId)}/connections`, body),
        updateConnection: (wfId, connectionId, body) => request('PUT', `/api/workflows/${id(wfId)}/connections/${id(connectionId)}`, body),
        deleteConnection: (wfId, connectionId) => request('DELETE', `/api/workflows/${id(wfId)}/connections/${id(connectionId)}`),

        // workflow parameters
        addParameter: (wfId, body) => request('POST', `/api/workflows/${id(wfId)}/parameters`, body),
        updateParameter: (wfId, parameterId, body) => request('PUT', `/api/workflows/${id(wfId)}/parameters/${id(parameterId)}`, body),
        deleteParameter: (wfId, parameterId) => request('DELETE', `/api/workflows/${id(wfId)}/parameters/${id(parameterId)}`),

        // schedulers
        getSchedulers: () => request('GET', '/api/schedulers'),
        getScheduler: sId => request('GET', `/api/schedulers/${id(sId)}`),
        createScheduler: body => request('POST', '/api/schedulers', body),
        updateScheduler: (sId, body) => request('PUT', `/api/schedulers/${id(sId)}`, body),
        validateCron: cronExpression => request('POST', '/api/schedulers/validate-cron', { cronExpression })
    };

    /** Converts a loaded activity entity back into an ActivityRequest for PUT /activities/{id}. */
    WF.api.toActivityRequest = function (activity, overrides) {
        const request = {
            activityKey: activity.activityKey,
            activityType: activity.activityType,
            displayName: activity.displayName,
            description: activity.description,
            positionX: activity.positionX,
            positionY: activity.positionY,
            timeoutSeconds: activity.timeoutSeconds,
            retryPolicy: {
                maxAttempts: activity.retryMaxAttempts,
                initialIntervalSeconds: activity.retryInitialIntervalSeconds,
                backoffCoefficient: activity.retryBackoffCoefficient,
                maxIntervalSeconds: activity.retryMaxIntervalSeconds,
                nonRetryableErrors: activity.nonRetryableErrors || []
            },
            errorHandling: activity.errorHandling,
            errorRouteActivityKey: activity.errorRouteActivityKey,
            executionCondition: activity.executionCondition,
            config: Object.assign({}, activity.config || {}),
            parameters: null,
            rowVersion: activity.rowVersion
        };
        return Object.assign(request, overrides || {});
    };
})(window);
