/* workflow-templates.js - template list, create, edit, clone, import, activate/deactivate */
(function (WF) {
    'use strict';
    const { el, qs, clear, icon } = WF.dom;

    let sourceSystemsCache = null;
    async function sourceSystems() {
        if (!sourceSystemsCache) { sourceSystemsCache = await WF.api.getSourceSystems(); }
        return sourceSystemsCache;
    }

    function bindSourceModuleSelects(ssSelect, moduleSelect, systems, placeholder, activeOnly) {
        const list = activeOnly ? systems.filter(s => s.status === 'Active') : systems;
        WF.forms.fillSelect(ssSelect, list, s => s.sourceSystemId, s => `${s.systemCode} - ${s.applicationName}`, placeholder);
        const refreshModules = () => {
            const ss = systems.find(s => String(s.sourceSystemId) === ssSelect.value);
            const modules = ss ? ss.modules.filter(m => !activeOnly || m.status === 'Active') : [];
            WF.forms.fillSelect(moduleSelect, modules, m => m.moduleId, m => `${m.moduleCode} - ${m.moduleName}`, placeholder);
        };
        ssSelect.addEventListener('change', refreshModules);
        refreshModules();
        return refreshModules;
    }

    // ================================================================== list
    const listState = { pageNumber: 1, pageSize: 20, total: 0, cloneSource: null };

    async function loadList(root) {
        const filters = WF.forms.read(qs('[data-role="filters"]', root));
        const result = await WF.api.searchWorkflows(Object.assign({}, filters, { pageNumber: listState.pageNumber, pageSize: listState.pageSize }));
        listState.total = result.totalCount;
        const body = clear(qs('[data-role="rows"]', root));
        if (!result.items.length) {
            body.appendChild(el('tr', {}, el('td', { attrs: { colspan: 8 }, class: 'text-muted', text: 'No workflow templates match the filters.' })));
        }

        const canDesign = WF.session.hasRole('WF_DESIGNER');
        result.items.forEach(t => {
            body.appendChild(el('tr', {},
                el('td', { class: 'font-monospace fw-semibold' }, el('a', { attrs: { href: `/Workflows/Designer/${t.workflowTemplateId}` }, text: t.templateCode })),
                el('td', {}, t.workflowName, el('div', { class: 'small text-muted wf-truncate', text: t.description || '' })),
                el('td', { class: 'small', text: `${t.sourceSystemCode} / ${t.moduleCode}` }),
                el('td', {}, `v${t.latestVersionNo} `, WF.ui.statusBadge(t.latestVersionStatus)),
                el('td', { text: t.publishedVersionNo ? `v${t.publishedVersionNo}` : '-' }),
                el('td', {}, WF.ui.statusBadge(t.status)),
                el('td', { class: 'small text-nowrap', text: WF.ui.formatDate(t.modifiedOn || t.createdOn) }),
                el('td', { class: 'text-end text-nowrap' },
                    el('a', { class: 'btn btn-sm btn-outline-primary me-1', attrs: { href: `/Workflows/Designer/${t.workflowTemplateId}`, title: 'Designer' } }, icon('bi-diagram-2')),
                    el('a', { class: 'btn btn-sm btn-outline-secondary me-1', attrs: { href: `/Workflows/History/${t.workflowTemplateId}`, title: 'Versions' } }, icon('bi-clock-history')),
                    canDesign ? el('button', { class: 'btn btn-sm btn-outline-secondary', attrs: { type: 'button', title: 'Clone' }, on: { click: () => openClone(root, t) } }, icon('bi-files')) : null)));
        });

        const from = result.totalCount === 0 ? 0 : (listState.pageNumber - 1) * listState.pageSize + 1;
        const to = Math.min(listState.pageNumber * listState.pageSize, result.totalCount);
        qs('[data-role="summary"]', root).textContent = `${from}-${to} of ${result.totalCount}`;
        qs('[data-action="prev"]', root).disabled = listState.pageNumber <= 1;
        qs('[data-action="next"]', root).disabled = to >= result.totalCount;
    }

    async function openClone(root, template) {
        listState.cloneSource = template;
        const form = qs('[data-role="clone-form"]', root);
        form.reset();
        WF.ui.clearError(qs('[data-role="clone-errors"]', form));
        qs('[data-role="clone-source"]', form).textContent = `${template.templateCode} (latest v${template.latestVersionNo})`;
        qs('[name="newTemplateCode"]', form).value = `${template.templateCode}_COPY`.slice(0, 50);
        qs('[name="workflowName"]', form).value = `${template.workflowName} (copy)`.slice(0, 200);
        const systems = await sourceSystems();
        const ssSelect = qs('[name="sourceSystemId"]', form);
        const modSelect = qs('[name="moduleId"]', form);
        WF.forms.fillSelect(ssSelect, systems, s => s.sourceSystemId, s => s.systemCode);
        ssSelect.value = String(template.sourceSystemId);
        const refresh = () => {
            const ss = systems.find(s => String(s.sourceSystemId) === ssSelect.value);
            WF.forms.fillSelect(modSelect, ss ? ss.modules : [], m => m.moduleId, m => m.moduleCode);
        };
        ssSelect.onchange = refresh;
        refresh();
        modSelect.value = String(template.moduleId);
        window.bootstrap.Modal.getOrCreateInstance(qs('#clone-modal')).show();
    }

    WF.pages['workflow-list'] = {
        async init(root) {
            const systems = await sourceSystems();
            bindSourceModuleSelects(qs('#f-ss', root), qs('#f-mod', root), systems, 'All', false);

            const filters = qs('[data-role="filters"]', root);
            filters.addEventListener('submit', evt => { evt.preventDefault(); listState.pageNumber = 1; loadList(root).catch(e => WF.ui.showError(null, e)); });
            qs('[data-action="prev"]', root).addEventListener('click', () => { listState.pageNumber--; loadList(root).catch(e => WF.ui.showError(null, e)); });
            qs('[data-action="next"]', root).addEventListener('click', () => { listState.pageNumber++; loadList(root).catch(e => WF.ui.showError(null, e)); });

            qs('[data-action="import"]', root).addEventListener('change', async evt => {
                const file = evt.target.files[0];
                evt.target.value = '';
                if (!file) { return; }
                if (file.size > 1_900_000) { WF.ui.toast('The file is too large (max ~1.9 MB).', 'danger'); return; }
                try {
                    const json = JSON.parse(await file.text());
                    const created = await WF.api.importWorkflow(json);
                    WF.ui.toast(`Imported ${created.template.templateCode} as draft v1.`);
                    window.location.href = `/Workflows/Designer/${created.template.workflowTemplateId}`;
                } catch (e) {
                    WF.ui.showError(null, e instanceof SyntaxError ? new Error(`Invalid JSON file: ${e.message}`) : e);
                }
            });

            const cloneForm = qs('[data-role="clone-form"]', root);
            cloneForm.addEventListener('submit', async evt => {
                evt.preventDefault();
                const data = WF.forms.read(cloneForm);
                await WF.ui.busy(cloneForm.querySelector('button[type="submit"]'), async () => {
                    try {
                        const created = await WF.api.cloneWorkflow(listState.cloneSource.workflowTemplateId, {
                            newTemplateCode: data.newTemplateCode,
                            workflowName: data.workflowName,
                            sourceSystemId: data.sourceSystemId ? Number(data.sourceSystemId) : null,
                            moduleId: data.moduleId ? Number(data.moduleId) : null,
                            fromVersionNo: data.fromVersionNo
                        });
                        window.location.href = `/Workflows/Designer/${created.template.workflowTemplateId}`;
                    } catch (e) {
                        WF.ui.showError(qs('[data-role="clone-errors"]', cloneForm), e);
                    }
                });
            });

            await loadList(root);
        }
    };

    // ================================================================== create
    WF.pages['workflow-create'] = {
        async init(root) {
            const form = qs('[data-role="form"]', root);
            const systems = await sourceSystems();
            bindSourceModuleSelects(qs('#w-ss', form), qs('#w-mod', form), systems, 'Select...', true);

            form.addEventListener('submit', async evt => {
                evt.preventDefault();
                const data = WF.forms.read(form);
                await WF.ui.busy(form.querySelector('button[type="submit"]'), async () => {
                    try {
                        const created = await WF.api.createWorkflow({
                            sourceSystemId: Number(data.sourceSystemId || 0),
                            moduleId: Number(data.moduleId || 0),
                            templateCode: (data.templateCode || '').toUpperCase(),
                            workflowName: data.workflowName,
                            description: data.description,
                            changeNotes: data.changeNotes,
                            addStartAndEnd: data.addStartAndEnd
                        });
                        window.location.href = `/Workflows/Designer/${created.template.workflowTemplateId}`;
                    } catch (e) {
                        WF.ui.showError(qs('[data-role="errors"]', form), e);
                    }
                });
            });
        }
    };

    // ================================================================== edit
    WF.pages['workflow-edit'] = {
        async init(root) {
            const workflowId = Number(root.dataset.workflowId);
            const form = qs('[data-role="form"]', root);
            let detail = await WF.workflowContext.load(workflowId);

            const bind = d => {
                const t = d.template;
                const draft = d.versions.find(v => v.status === 'Draft' || v.status === 'Validated');
                WF.forms.fill(form, { workflowName: t.workflowName, description: t.description, changeNotes: draft ? draft.changeNotes : '' });
                qs('[data-bind="sourceSystemCode"]', root).textContent = t.sourceSystemCode;
                qs('[data-bind="moduleCode"]', root).textContent = t.moduleCode;
                qs('[data-bind="created"]', root).textContent = `${WF.ui.formatDate(t.createdOn)} by ${t.createdBy}`;
                qs('[data-bind="clonedFrom"]', root).textContent = t.clonedFromTemplateId ? `Template #${t.clonedFromTemplateId}` : '-';
                qs('[name="changeNotes"]', form).disabled = !draft;
                const toggle = qs('[data-action="toggle-status"]', root);
                toggle.textContent = t.status === 'Active' ? 'Deactivate' : 'Activate';
                toggle.className = `btn ${t.status === 'Active' ? 'btn-outline-danger' : 'btn-outline-success'}`;
            };
            bind(detail);

            form.addEventListener('submit', async evt => {
                evt.preventDefault();
                const data = WF.forms.read(form);
                await WF.ui.busy(form.querySelector('button[type="submit"]'), async () => {
                    try {
                        detail = await WF.api.updateWorkflow(workflowId, {
                            workflowName: data.workflowName, description: data.description, changeNotes: data.changeNotes,
                            rowVersion: detail.template.rowVersion
                        });
                        WF.workflowContext.bindHeader(detail);
                        bind(detail);
                        WF.ui.toast('Workflow details saved.');
                    } catch (e) {
                        WF.ui.showError(qs('[data-role="errors"]', form), e);
                    }
                });
            });

            const cloneForm = qs('[data-role="clone-form"]', root);
            qs('[name="newTemplateCode"]', cloneForm).value = `${detail.template.templateCode}_COPY`.slice(0, 50);
            qs('[name="workflowName"]', cloneForm).value = `${detail.template.workflowName} (copy)`.slice(0, 200);
            cloneForm.addEventListener('submit', async evt => {
                evt.preventDefault();
                const data = WF.forms.read(cloneForm);
                try {
                    const created = await WF.api.cloneWorkflow(workflowId, { newTemplateCode: data.newTemplateCode, workflowName: data.workflowName, fromVersionNo: data.fromVersionNo });
                    window.location.href = `/Workflows/Designer/${created.template.workflowTemplateId}`;
                } catch (e) {
                    WF.ui.showError(qs('[data-role="clone-errors"]', cloneForm), e);
                }
            });

            const toggle = qs('[data-action="toggle-status"]', root);
            toggle.addEventListener('click', async () => {
                const reason = qs('[data-role="status-reason"]', root).value.trim();
                const target = detail.template.status === 'Active' ? 'Inactive' : 'Active';
                if (!(await WF.ui.confirm('Change status', `Set ${detail.template.templateCode} to ${target}?`, target === 'Inactive' ? 'Deactivate' : 'Activate'))) { return; }
                try {
                    await WF.api.changeStatus(workflowId, { status: target, reason });
                    detail = await WF.workflowContext.load(workflowId);
                    bind(detail);
                    WF.ui.toast(`Workflow is now ${target}.`);
                } catch (e) {
                    WF.ui.showError(qs('[data-role="errors"]', form), e);
                }
            });
        }
    };
})(window.WF);
