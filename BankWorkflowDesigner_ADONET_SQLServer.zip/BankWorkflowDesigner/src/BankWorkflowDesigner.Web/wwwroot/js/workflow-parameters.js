/* =============================================================================
   workflow-parameters.js - workflow-level parameters, the reusable source-to-target
   mapping editor (used by activity configuration) and the mapping overview.
   ============================================================================= */
(function (WF) {
    'use strict';
    const { el, qs, clear, icon } = WF.dom;

    const DATA_TYPES = ['String', 'Integer', 'Decimal', 'Boolean', 'Date', 'DateTime', 'Json', 'Array', 'File'];
    const SOURCE_TYPES = ['None', 'Literal', 'WorkflowInput', 'ActivityOutput', 'ConnectionProfile', 'SystemVariable'];
    const SYSTEM_VARIABLES = ['sys.workflowId', 'sys.runId', 'sys.initiator', 'sys.now', 'sys.businessDate', 'sys.templateCode', 'sys.version', 'sys.sourceSystem'];

    /** Activities that can run before `activityKey` (walks connections backwards, ignoring rejection loop-backs). */
    function upstreamKeys(graph, activityKey) {
        const reverse = {};
        graph.connections.filter(c => c.connectionType !== 'Rejection').forEach(c => {
            (reverse[c.toActivityKey] = reverse[c.toActivityKey] || []).push(c.fromActivityKey);
        });
        const seen = new Set([activityKey]);
        const queue = [activityKey];
        while (queue.length) {
            (reverse[queue.shift()] || []).forEach(k => { if (!seen.has(k)) { seen.add(k); queue.push(k); } });
        }
        seen.delete(activityKey);
        return seen;
    }

    function outputOptions(graph, keys) {
        const options = [];
        graph.activities.filter(a => keys === null || keys.has(a.activityKey)).forEach(a => {
            a.parameters.filter(p => p.direction === 'Output').forEach(p => {
                options.push({ value: `${a.activityKey}.${p.name}`, text: `${a.displayName} (${a.activityKey}).${p.name} : ${p.dataType}` });
            });
        });
        return options;
    }

    /**
     * Mapping editor: source-type select + reference control.
     * ctx = { graph, ownerKey (null = workflow output), profiles }
     */
    function createMappingEditor(parameter, ctx, readOnly) {
        const wrapper = el('div', { class: 'd-flex gap-1' });
        const typeSelect = el('select', { class: 'form-select form-select-sm', attrs: { 'aria-label': 'Mapping source type', disabled: readOnly } },
            SOURCE_TYPES.map(s => el('option', { value: s, text: s })));
        typeSelect.value = parameter.sourceType || 'None';
        const refHolder = el('div', { class: 'flex-grow-1' });
        let refControl = null;

        const render = () => {
            clear(refHolder);
            const type = typeSelect.value;
            const current = parameter.sourceReference || '';
            let options = null;
            if (type === 'WorkflowInput') {
                options = ctx.graph.parameters.filter(p => p.direction === 'Input').map(p => ({ value: p.name, text: `${p.name} : ${p.dataType}` }));
            } else if (type === 'ActivityOutput') {
                options = outputOptions(ctx.graph, ctx.ownerKey ? upstreamKeys(ctx.graph, ctx.ownerKey) : null);
            } else if (type === 'ConnectionProfile') {
                options = (ctx.profiles || []).filter(p => p.isActive).map(p => ({ value: p.profileCode, text: `${p.profileCode} (${p.profileType})` }));
            } else if (type === 'SystemVariable') {
                options = SYSTEM_VARIABLES.map(v => ({ value: v, text: v }));
            }

            if (options) {
                refControl = el('select', { class: 'form-select form-select-sm', attrs: { 'aria-label': 'Source reference', disabled: readOnly } },
                    el('option', { value: '', text: options.length ? 'Select...' : '(nothing available)' }),
                    options.map(o => el('option', { value: o.value, text: o.text })));
                if (current && !options.some(o => o.value === current)) {
                    refControl.appendChild(el('option', { value: current, text: `${current} (not available)` }));
                }
                refControl.value = current;
            } else {
                refControl = el('input', { class: 'form-control form-control-sm font-monospace', value: type === 'Literal' ? current : '',
                    attrs: { 'aria-label': 'Literal value', disabled: readOnly || type === 'None', placeholder: type === 'Literal' ? 'literal value' : 'n/a', maxlength: 500 } });
            }

            refHolder.appendChild(refControl);
        };

        typeSelect.addEventListener('change', () => { parameter.sourceReference = null; render(); });
        render();
        wrapper.appendChild(typeSelect);
        wrapper.appendChild(refHolder);

        return {
            element: wrapper,
            read() {
                const type = typeSelect.value;
                const value = refControl && !refControl.disabled ? refControl.value.trim() : '';
                return { sourceType: type, sourceReference: type === 'None' || value === '' ? null : value };
            }
        };
    }

    /** Editable parameter rows for an activity (inputs & outputs with mapping). */
    function createActivityParameterTable(tbody, parameters, ctx, readOnly) {
        const rows = [];

        const addRow = p => {
            const name = el('input', { class: 'form-control form-control-sm font-monospace wf-col-name', value: p.name || '', attrs: { maxlength: 100, required: true, disabled: readOnly, 'aria-label': 'Parameter name' } });
            const type = el('select', { class: 'form-select form-select-sm', attrs: { disabled: readOnly, 'aria-label': 'Data type' } }, DATA_TYPES.map(t => el('option', { value: t, text: t })));
            type.value = p.dataType || 'String';
            const mandatory = el('input', { class: 'form-check-input', attrs: { type: 'checkbox', disabled: readOnly, 'aria-label': 'Mandatory' }, checked: !!p.isMandatory });
            const mapping = p.direction === 'Input' ? createMappingEditor(p, ctx, readOnly) : null;
            const def = el('input', { class: 'form-control form-control-sm', value: p.defaultValue || '', attrs: { maxlength: 4000, disabled: readOnly || p.direction === 'Output', 'aria-label': 'Default value' } });
            const schema = el('input', { class: 'form-control form-control-sm font-monospace', value: p.jsonSchema || '', attrs: { disabled: readOnly, placeholder: '{"type":"object"}', 'aria-label': 'JSON schema' } });
            const tr = el('tr', {},
                el('td', {}, el('span', { class: `badge ${p.direction === 'Input' ? 'text-bg-primary' : 'text-bg-success'}`, text: p.direction === 'Input' ? 'IN' : 'OUT' })),
                el('td', {}, name),
                el('td', {}, type),
                el('td', { class: 'text-center' }, mandatory),
                el('td', { attrs: { colspan: 2 }, class: 'wf-col-ref' }, mapping ? mapping.element : el('span', { class: 'small text-muted', text: 'produced by the activity' })),
                el('td', {}, def),
                el('td', {}, schema),
                el('td', { class: 'text-end' }, readOnly ? null : el('button', { class: 'btn btn-sm btn-outline-danger', attrs: { type: 'button', title: 'Remove parameter' },
                    on: { click: () => { tr.remove(); rows.splice(rows.indexOf(entry), 1); } } }, icon('bi-x'))));
            const entry = {
                read: () => Object.assign({
                    direction: p.direction,
                    name: name.value.trim(),
                    dataType: type.value,
                    isMandatory: mandatory.checked,
                    defaultValue: p.direction === 'Input' && def.value.trim() !== '' ? def.value : null,
                    jsonSchema: schema.value.trim() || null,
                    description: p.description || null,
                    sortOrder: rows.indexOf(entry)
                }, mapping ? mapping.read() : { sourceType: 'None', sourceReference: null })
            };
            rows.push(entry);
            tbody.appendChild(tr);
        };

        clear(tbody);
        parameters.slice().sort((a, b) => (a.direction === b.direction ? a.sortOrder - b.sortOrder : a.direction === 'Input' ? -1 : 1)).forEach(addRow);

        return {
            add: direction => addRow({ direction, name: '', dataType: 'String', isMandatory: false, sourceType: 'None' }),
            read: () => rows.map(r => r.read())
        };
    }

    WF.parameters = { DATA_TYPES, SOURCE_TYPES, SYSTEM_VARIABLES, upstreamKeys, createMappingEditor, createActivityParameterTable };

    // ================================================================== Parameters & Mapping page
    const page = { workflowId: 0, detail: null, profiles: [], editing: null, mappingEditor: null };

    function describeSource(p) {
        if (!p.sourceType || p.sourceType === 'None') { return p.defaultValue ? `default: ${p.defaultValue}` : '-'; }
        return `${p.sourceType}: ${p.sourceReference || '?'}`;
    }

    function render(root) {
        const graph = page.detail.graph;
        const editable = WF.workflowContext.isEditable(page.detail);
        const inputs = clear(qs('[data-role="inputs"]', root));
        const outputs = clear(qs('[data-role="outputs"]', root));

        const actions = p => editable ? el('td', { class: 'text-end text-nowrap' },
            el('button', { class: 'btn btn-sm btn-outline-primary me-1', attrs: { type: 'button', title: 'Edit' }, on: { click: () => openModal(root, p) } }, icon('bi-pencil')),
            el('button', { class: 'btn btn-sm btn-outline-danger', attrs: { type: 'button', title: 'Delete' }, on: { click: () => remove(root, p) } }, icon('bi-trash')))
            : el('td');

        graph.parameters.filter(p => p.direction === 'Input').forEach(p => inputs.appendChild(el('tr', {},
            el('td', { class: 'font-monospace', text: p.name }), el('td', { text: p.dataType }), el('td', { text: p.isMandatory ? 'Yes' : '' }),
            el('td', { class: 'small', text: p.defaultValue || '' }), el('td', { class: 'small', text: p.jsonSchema ? 'yes' : '' }), actions(p))));
        graph.parameters.filter(p => p.direction === 'Output').forEach(p => outputs.appendChild(el('tr', {},
            el('td', { class: 'font-monospace', text: p.name }), el('td', { text: p.dataType }), el('td', { text: p.isMandatory ? 'Yes' : '' }),
            el('td', { class: 'small font-monospace', text: describeSource(p) }), actions(p))));
        if (!inputs.children.length) { inputs.appendChild(el('tr', {}, el('td', { attrs: { colspan: 6 }, class: 'text-muted small', text: 'No inputs defined.' }))); }
        if (!outputs.children.length) { outputs.appendChild(el('tr', {}, el('td', { attrs: { colspan: 5 }, class: 'text-muted small', text: 'No outputs defined.' }))); }

        const overview = clear(qs('[data-role="mapping-overview"]', root));
        graph.activities.forEach(a => {
            a.parameters.filter(p => p.direction === 'Input').forEach(p => {
                const unmapped = p.isMandatory && (!p.sourceType || p.sourceType === 'None') && !p.defaultValue;
                overview.appendChild(el('tr', {},
                    el('td', {}, el('a', { attrs: { href: `/Workflows/Activity/${page.workflowId}?activityId=${a.activityId}` }, text: a.displayName }),
                        el('div', { class: 'small text-muted font-monospace', text: a.activityKey })),
                    el('td', { class: 'font-monospace', text: p.name }),
                    el('td', { text: p.dataType }),
                    el('td', { class: 'small font-monospace', text: describeSource(p) }),
                    el('td', {}, unmapped ? el('span', { class: 'badge text-bg-danger', text: 'unmapped' }) : el('span', { class: 'badge text-bg-success', text: 'ok' }))));
            });
        });
        if (!overview.children.length) { overview.appendChild(el('tr', {}, el('td', { attrs: { colspan: 5 }, class: 'text-muted small', text: 'No activity inputs yet.' }))); }
        WF.ui.setReadOnly(root, !editable);
    }

    function openModal(root, parameter, direction) {
        page.editing = parameter;
        const form = qs('[data-role="param-form"]', root);
        form.reset();
        WF.ui.clearError(qs('[data-role="param-errors"]', form));
        WF.forms.fillSelect(qs('#p-type', form), DATA_TYPES, t => t, t => t);
        const p = parameter || { direction, dataType: 'String', isMandatory: false, sortOrder: page.detail.graph.parameters.length, sourceType: 'None' };
        WF.forms.fill(form, p);
        qs('[data-role="param-title"]', root).textContent = parameter ? `Edit ${parameter.name}` : `New workflow ${direction.toLowerCase()}`;

        const syncDirection = () => {
            const isOutput = qs('#p-dir', form).value === 'Output';
            qs('[data-role="mapping-group"]', form).classList.toggle('d-none', !isOutput);
            qs('[data-role="default-group"]', form).classList.toggle('d-none', isOutput);
            const holder = clear(qs('[data-role="mapping"]', form));
            page.mappingEditor = isOutput ? createMappingEditor(Object.assign({}, p), { graph: page.detail.graph, ownerKey: null, profiles: page.profiles }, false) : null;
            if (page.mappingEditor) { holder.appendChild(page.mappingEditor.element); }
        };
        qs('#p-dir', form).onchange = syncDirection;
        syncDirection();
        window.bootstrap.Modal.getOrCreateInstance(qs('#param-modal')).show();
    }

    async function remove(root, p) {
        if (!(await WF.ui.confirm('Delete parameter', `Delete workflow ${p.direction.toLowerCase()} '${p.name}'?`, 'Delete'))) { return; }
        try {
            await WF.api.deleteParameter(page.workflowId, p.parameterId);
            await reload(root);
            WF.ui.toast('Parameter deleted.');
        } catch (e) { WF.ui.showError(null, e); }
    }

    async function reload(root) {
        page.detail = await WF.workflowContext.load(page.workflowId);
        render(root);
    }

    WF.pages.parameters = {
        async init(root) {
            page.workflowId = Number(root.dataset.workflowId);
            const [detail, profiles] = await Promise.all([WF.workflowContext.load(page.workflowId), WF.api.connectionProfiles()]);
            page.detail = detail;
            page.profiles = profiles;
            render(root);

            root.querySelectorAll('[data-action="add"]').forEach(btn => btn.addEventListener('click', () => openModal(root, null, btn.dataset.direction)));

            const form = qs('[data-role="param-form"]', root);
            form.addEventListener('submit', async evt => {
                evt.preventDefault();
                const data = WF.forms.read(form);
                const mapping = page.mappingEditor ? page.mappingEditor.read() : { sourceType: 'None', sourceReference: null };
                const body = {
                    direction: data.direction, name: data.name, dataType: data.dataType, isMandatory: data.isMandatory,
                    defaultValue: data.direction === 'Input' ? data.defaultValue : null,
                    jsonSchema: data.jsonSchema, description: data.description, sortOrder: data.sortOrder || 0,
                    sourceType: mapping.sourceType, sourceReference: mapping.sourceReference
                };
                await WF.ui.busy(form.querySelector('button[type="submit"]'), async () => {
                    try {
                        if (page.editing) {
                            body.rowVersion = page.editing.rowVersion;
                            await WF.api.updateParameter(page.workflowId, page.editing.parameterId, body);
                        } else {
                            await WF.api.addParameter(page.workflowId, body);
                        }
                        window.bootstrap.Modal.getOrCreateInstance(qs('#param-modal')).hide();
                        await reload(root);
                        WF.ui.toast('Parameter saved.');
                    } catch (e) {
                        WF.ui.showError(qs('[data-role="param-errors"]', form), e);
                    }
                });
            });
        }
    };
})(window.WF);
