/* =============================================================================
   site.js - shared UI helpers, safe DOM builder, session bootstrap and page dispatch.
   Security: all dynamic text is written with textContent (never innerHTML) to prevent XSS.
   ============================================================================= */
(function (window, document) {
    'use strict';

    const WF = window.WF = window.WF || {};
    WF.pages = WF.pages || {};

    function meta(name) {
        const el = document.querySelector(`meta[name="${name}"]`);
        return el ? el.getAttribute('content') : '';
    }

    WF.config = {
        apiBaseUrl: (meta('wf-api-base-url') || '').replace(/\/+$/, ''),
        authMode: meta('wf-auth-mode') || 'Windows'
    };

    // ------------------------------------------------------------------ DOM builder
    /**
     * el('button', { class: 'btn', text: 'Save', attrs: { type: 'button' }, dataset: { id: 1 }, on: { click: fn } }, child1, child2)
     */
    function el(tag, props, ...children) {
        const isSvg = ['svg', 'path', 'g', 'text', 'marker', 'defs', 'title', 'tspan'].includes(tag);
        const node = isSvg ? document.createElementNS('http://www.w3.org/2000/svg', tag) : document.createElement(tag);
        props = props || {};
        if (props.class) { node.setAttribute('class', props.class); }
        if (props.text !== undefined && props.text !== null) { node.textContent = String(props.text); }
        if (props.attrs) {
            Object.entries(props.attrs).forEach(([k, v]) => {
                if (v === false || v === null || v === undefined) { return; }
                if (k === 'style') { throw new Error('Inline styles are not allowed (CSP).'); }
                node.setAttribute(k, v === true ? '' : String(v));
            });
        }
        if (props.dataset) { Object.entries(props.dataset).forEach(([k, v]) => { if (v !== undefined && v !== null) { node.dataset[k] = String(v); } }); }
        if (props.value !== undefined && props.value !== null) { node.value = props.value; }
        if (props.checked !== undefined) { node.checked = !!props.checked; }
        if (props.on) { Object.entries(props.on).forEach(([evt, fn]) => node.addEventListener(evt, fn)); }
        children.flat().forEach(child => {
            if (child === null || child === undefined || child === false) { return; }
            node.appendChild(child instanceof Node ? child : document.createTextNode(String(child)));
        });
        return node;
    }

    function clear(node) { while (node && node.firstChild) { node.removeChild(node.firstChild); } return node; }
    function qs(selector, root) { return (root || document).querySelector(selector); }
    function qsa(selector, root) { return Array.from((root || document).querySelectorAll(selector)); }
    function icon(name, extra) { return el('i', { class: `bi ${name}${extra ? ' ' + extra : ''}`, attrs: { 'aria-hidden': 'true' } }); }

    WF.dom = { el, clear, qs, qsa, icon };

    // ------------------------------------------------------------------ formatting
    function formatDate(value) {
        if (!value) { return ''; }
        const d = new Date(value);
        if (isNaN(d.getTime())) { return String(value); }
        const pad = n => String(n).padStart(2, '0');
        return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`;
    }

    function statusBadge(status) {
        return el('span', { class: `badge wf-status-badge ${status || ''}`, text: status || '-' });
    }

    function debounce(fn, ms) {
        let t = null;
        return function (...args) { clearTimeout(t); t = setTimeout(() => fn.apply(this, args), ms); };
    }

    // ------------------------------------------------------------------ toasts, errors, confirm
    function toast(message, variant) {
        const container = qs('#wf-toasts');
        if (!container || !window.bootstrap) { return; }
        const t = el('div', { class: `toast align-items-center text-bg-${variant || 'success'} border-0`, attrs: { role: 'status', 'aria-live': 'polite', 'aria-atomic': 'true' } },
            el('div', { class: 'd-flex' },
                el('div', { class: 'toast-body', text: message }),
                el('button', { class: 'btn-close btn-close-white me-2 m-auto', attrs: { type: 'button', 'data-bs-dismiss': 'toast', 'aria-label': 'Close' } })));
        container.appendChild(t);
        const instance = new window.bootstrap.Toast(t, { delay: variant === 'danger' ? 8000 : 3500 });
        t.addEventListener('hidden.bs.toast', () => t.remove());
        instance.show();
    }

    function showError(container, error) {
        if (!container) { toast(error && error.message ? error.message : String(error), 'danger'); return; }
        clear(container);
        const alert = el('div', { class: 'alert alert-danger small', attrs: { role: 'alert' } },
            el('div', { class: 'fw-semibold' }, icon('bi-exclamation-triangle-fill'), ' ', error && error.message ? error.message : String(error)));
        if (error && error.errors) {
            const list = el('ul', { class: 'mb-0 mt-1' });
            Object.entries(error.errors).forEach(([field, messages]) => {
                (messages || []).forEach(m => list.appendChild(el('li', {}, el('code', { text: field }), ': ', m)));
            });
            alert.appendChild(list);
        }
        if (error && error.traceId) { alert.appendChild(el('div', { class: 'text-muted mt-1', text: `Trace id: ${error.traceId}` })); }
        container.appendChild(alert);
        container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    function clearError(container) { clear(container); }

    function confirmDialog(title, message, okText) {
        return new Promise(resolve => {
            const modalEl = qs('#wf-confirm-modal');
            if (!modalEl || !window.bootstrap) { resolve(window.confirm(message)); return; }
            qs('[data-role="title"]', modalEl).textContent = title;
            qs('[data-role="body"]', modalEl).textContent = message;
            const ok = qs('[data-role="ok"]', modalEl);
            ok.textContent = okText || 'Confirm';
            const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
            let result = false;
            const onOk = () => { result = true; modal.hide(); };
            ok.addEventListener('click', onOk, { once: true });
            modalEl.addEventListener('hidden.bs.modal', () => { ok.removeEventListener('click', onOk); resolve(result); }, { once: true });
            modal.show();
        });
    }

    async function busy(button, fn) {
        if (!button) { return fn(); }
        const original = Array.from(button.childNodes).map(n => n.cloneNode(true));
        button.disabled = true;
        clear(button).appendChild(el('span', { class: 'spinner-border spinner-border-sm', attrs: { role: 'status', 'aria-hidden': 'true' } }));
        button.appendChild(document.createTextNode(' Working...'));
        try {
            return await fn();
        } finally {
            clear(button);
            original.forEach(n => button.appendChild(n));
            button.disabled = false;
        }
    }

    WF.ui = { toast, showError, clearError, confirm: confirmDialog, busy, formatDate, statusBadge, debounce };

    // ------------------------------------------------------------------ forms
    function readForm(form) {
        const data = {};
        qsa('input[name], select[name], textarea[name]', form).forEach(input => {
            const name = input.name;
            if (input.type === 'checkbox') { data[name] = input.checked; return; }
            if (input.type === 'number') { data[name] = input.value === '' ? null : Number(input.value); return; }
            const v = input.value.trim();
            data[name] = v === '' ? null : v;
        });
        return data;
    }

    function fillForm(form, values) {
        qsa('input[name], select[name], textarea[name]', form).forEach(input => {
            if (!(input.name in values)) { return; }
            const v = values[input.name];
            if (input.type === 'checkbox') { input.checked = !!v; } else { input.value = v === null || v === undefined ? '' : String(v); }
        });
    }

    function fillSelect(select, items, valueFn, textFn, placeholder) {
        const current = select.value;
        clear(select);
        if (placeholder !== undefined) { select.appendChild(el('option', { value: '', text: placeholder })); }
        items.forEach(item => select.appendChild(el('option', { value: String(valueFn(item)), text: textFn(item) })));
        if (current && Array.from(select.options).some(o => o.value === current)) { select.value = current; }
    }

    WF.forms = { read: readForm, fill: fillForm, fillSelect };

    // ------------------------------------------------------------------ session & roles
    WF.session = { user: null, roles: [], hasRole(role) { return this.roles.includes(role); }, hasAnyRole(list) { return list.some(r => this.roles.includes(r)); } };

    function applyRoleVisibility(root) {
        qsa('[data-requires-role]', root).forEach(node => {
            const roles = node.getAttribute('data-requires-role').split(',').map(r => r.trim());
            const allowed = WF.session.hasAnyRole(roles);
            node.classList.toggle('d-none', !allowed);
        });
    }

    /** Disables every [data-edit-only] control when the workflow version is not editable. */
    function setReadOnly(root, readOnly) {
        qsa('[data-edit-only]', root).forEach(node => {
            if ('disabled' in node) { node.disabled = !!readOnly; }
            node.classList.toggle('disabled', !!readOnly);
        });
    }

    WF.ui.applyRoleVisibility = applyRoleVisibility;
    WF.ui.setReadOnly = setReadOnly;

    async function initDevUserSwitcher() {
        if (WF.config.authMode.toLowerCase() !== 'development') { return; }
        try {
            const users = await WF.api.devUsers();
            const wrapper = qs('#wf-dev-user-switcher');
            const select = qs('#wf-dev-user');
            fillSelect(select, users, u => u.userName, u => `${u.userName} (${u.roles.join(', ')})`);
            select.value = WF.api.getDevUser() || (users[0] && users[0].userName) || '';
            select.addEventListener('change', () => { WF.api.setDevUser(select.value); window.location.reload(); });
            wrapper.classList.remove('d-none');
        } catch (e) {
            console.warn('Development users unavailable', e);
        }
    }

    async function initSession() {
        try {
            const me = await WF.api.me();
            WF.session.user = me.userName;
            WF.session.roles = me.roles || [];
            const nameEl = qs('#wf-current-user [data-role="name"]');
            if (nameEl) { nameEl.textContent = me.userName; }
            const rolesEl = qs('#wf-current-roles');
            if (rolesEl) {
                clear(rolesEl);
                WF.session.roles.forEach(r => rolesEl.appendChild(el('span', { class: 'badge text-bg-light me-1', text: r.replace('WF_', '') })));
            }
        } catch (e) {
            const nameEl = qs('#wf-current-user [data-role="name"]');
            if (nameEl) { nameEl.textContent = 'not signed in'; }
            toast(`Cannot reach the Workflow API (${WF.config.apiBaseUrl}): ${e.message}`, 'danger');
        }
        applyRoleVisibility(document);
    }

    // ------------------------------------------------------------------ workflow page context (header, read-only banner)
    WF.workflowContext = {
        detail: null,

        async load(workflowId, versionNo) {
            const detail = await WF.api.getWorkflow(workflowId, versionNo);
            this.detail = detail;
            this.bindHeader(detail);
            return detail;
        },

        isEditable(detail) {
            const d = detail || this.detail;
            return !!d && d.template.status === 'Active' && ['Draft', 'Validated'].includes(d.graph.version.status) &&
                d.graph.version.versionNo === d.template.latestVersionNo && WF.session.hasRole('WF_DESIGNER');
        },

        bindHeader(detail) {
            const t = detail.template;
            const v = detail.graph.version;
            qsa('[data-bind="templateCode"]').forEach(n => { n.textContent = t.templateCode; });
            qsa('[data-bind="workflowName"]').forEach(n => { n.textContent = t.workflowName; });
            qsa('[data-bind="versionBadge"]').forEach(n => { n.textContent = `v${v.versionNo} ${v.status}`; n.className = `badge wf-status-badge ms-2 ${v.status}`; });
            qsa('[data-bind="inactiveBadge"]').forEach(n => n.classList.toggle('d-none', t.status === 'Active'));
            document.title = `${t.templateCode} - Workflow Designer`;

            const banner = qs('[data-bind="readonlyBanner"]');
            if (banner) {
                const editableStatus = ['Draft', 'Validated'].includes(v.status) && v.versionNo === t.latestVersionNo;
                const readonly = !editableStatus || t.status !== 'Active';
                banner.classList.toggle('d-none', !readonly);
                banner.classList.toggle('d-flex', readonly);
                const text = qs('[data-bind="readonlyText"]', banner);
                if (t.status !== 'Active') {
                    text.textContent = 'This workflow template is deactivated. Re-activate it before making changes.';
                } else if (v.versionNo !== t.latestVersionNo) {
                    text.textContent = `You are viewing historical version ${v.versionNo} (read-only). Latest is v${t.latestVersionNo}.`;
                } else {
                    text.textContent = `Version ${v.versionNo} is ${v.status} and immutable. Create a new draft version to make changes.`;
                }
                const btn = qs('[data-action="create-version"]', banner);
                const hasOpenDraft = detail.versions.some(x => x.status === 'Draft' || x.status === 'Validated');
                btn.classList.toggle('d-none', hasOpenDraft || t.status !== 'Active' || !WF.session.hasRole('WF_DESIGNER'));
                if (!btn.dataset.bound) {
                    btn.dataset.bound = '1';
                    btn.addEventListener('click', () => busy(btn, async () => {
                        try {
                            const created = await WF.api.createVersion(t.workflowTemplateId, { changeNotes: `New version based on v${t.publishedVersionNo || t.latestVersionNo}` });
                            toast(`Draft version ${created.graph.version.versionNo} created.`);
                            window.location.href = `/Workflows/Designer/${t.workflowTemplateId}`;
                        } catch (e) { showError(null, e); }
                    }));
                }
            }
        }
    };

    // ------------------------------------------------------------------ bootstrap
    document.addEventListener('DOMContentLoaded', async () => {
        await initDevUserSwitcher();
        await initSession();
        const page = qs('#wf-page');
        if (!page) { return; }
        const handler = WF.pages[page.dataset.page];
        if (handler && typeof handler.init === 'function') {
            try {
                await handler.init(page);
                applyRoleVisibility(page);
            } catch (e) {
                console.error(e);
                showError(qs('[data-role="errors"]', page), e);
            }
        }
    });
})(window, document);
