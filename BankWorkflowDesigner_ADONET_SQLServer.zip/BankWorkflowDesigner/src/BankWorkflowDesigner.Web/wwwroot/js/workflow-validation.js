/* =============================================================================
   workflow-validation.js - Validation report, Publish and Version History pages.
   ============================================================================= */
(function (WF, window) {
    'use strict';
    const { el, qs, clear, icon } = WF.dom;

    function showJson(root, title, text) {
        let pretty = text;
        try { pretty = JSON.stringify(JSON.parse(text), null, 2); } catch { /* raw */ }
        qs('[data-role="json-title"]', root).textContent = title;
        qs('[data-role="json"]', root).textContent = pretty;
        window.bootstrap.Modal.getOrCreateInstance(qs('#json-modal')).show();
    }

    function bindCopy(root) {
        const btn = qs('[data-action="copy-json"]', root);
        if (btn) {
            btn.addEventListener('click', async () => {
                try { await navigator.clipboard.writeText(qs('[data-role="json"]', root).textContent); WF.ui.toast('Copied.'); } catch { WF.ui.toast('Copy failed.', 'warning'); }
            });
        }
    }

    function renderReport(root, report, workflowId, detail) {
        const body = clear(qs('[data-role="issues"]', root));
        const keyToId = {};
        (detail ? detail.graph.activities : []).forEach(a => { keyToId[a.activityKey] = a.activityId; });

        if (!report.issues.length) {
            body.appendChild(el('tr', {}, el('td', { attrs: { colspan: 5 }, class: 'text-success' }, icon('bi-check-circle-fill'), ' No issues found.')));
        }

        report.issues
            .slice()
            .sort((a, b) => (a.severity === b.severity ? 0 : a.severity === 'Error' ? -1 : 1))
            .forEach(i => body.appendChild(el('tr', {},
                el('td', {}, el('span', { class: `badge ${i.severity === 'Error' ? 'text-bg-danger' : i.severity === 'Warning' ? 'text-bg-warning' : 'text-bg-info'}`, text: i.severity })),
                el('td', { class: 'font-monospace small', text: i.code }),
                el('td', {}, i.activityKey && keyToId[i.activityKey]
                    ? el('a', { attrs: { href: `/Workflows/Activity/${workflowId}?activityId=${keyToId[i.activityKey]}` }, text: i.activityKey })
                    : el('span', { class: 'text-muted', text: i.activityKey || 'workflow' })),
                el('td', { class: 'small font-monospace', text: i.field || '' }),
                el('td', { text: i.message }))));

        const summary = clear(qs('[data-role="summary"]', root));
        summary.appendChild(report.isValid
            ? el('span', { class: 'text-success fw-semibold' }, icon('bi-check-circle-fill'), ` Version ${report.versionNo} is valid`)
            : el('span', { class: 'text-danger fw-semibold' }, icon('bi-x-circle-fill'), ` Version ${report.versionNo}: ${report.errorCount} error(s)`));
        summary.appendChild(el('div', { class: 'text-muted', text: `${report.warningCount} warning(s) - validated ${WF.ui.formatDate(report.validatedOn)} UTC by ${report.validatedBy || '?'}` }));
    }

    // ================================================================== Validate page
    WF.pages.validate = {
        async init(root) {
            const workflowId = Number(root.dataset.workflowId);
            let detail = await WF.workflowContext.load(workflowId);
            bindCopy(root);

            if (detail.graph.version.validationResultJson) {
                try { renderReport(root, JSON.parse(detail.graph.version.validationResultJson), workflowId, detail); } catch { /* ignore */ }
            }

            qs('[data-action="validate"]', root).addEventListener('click', evt => WF.ui.busy(evt.currentTarget, async () => {
                try {
                    const report = await WF.api.validateWorkflow(workflowId);
                    detail = await WF.workflowContext.load(workflowId);
                    renderReport(root, report, workflowId, detail);
                } catch (e) { WF.ui.showError(null, e); }
            }));

            qs('[data-action="preview-json"]', root).addEventListener('click', async () => {
                try { showJson(root, 'Definition preview (not published)', await WF.api.previewDefinition(workflowId)); } catch (e) { WF.ui.showError(null, e); }
            });
        }
    };

    // ================================================================== Publish page
    function renderPublishState(root, detail) {
        const draft = detail.versions.find(v => v.status === 'Draft' || v.status === 'Validated');
        const t = detail.template;
        const set = (name, value) => { qs(`[data-bind="${name}"]`, root).textContent = value; };
        set('draftVersion', draft ? `v${draft.versionNo}` : 'No open draft');
        set('draftStatus', draft ? draft.status : '-');
        set('draftCreatedBy', draft ? `${draft.createdBy} (${WF.ui.formatDate(draft.createdOn)})` : '-');
        set('draftModifiedBy', draft && draft.modifiedBy ? `${draft.modifiedBy} (${WF.ui.formatDate(draft.modifiedOn)})` : '-');
        set('lastValidation', draft && draft.validatedOn ? `${WF.ui.formatDate(draft.validatedOn)} by ${draft.validatedBy}` : 'never');
        set('currentPublished', t.publishedVersionNo ? `v${t.publishedVersionNo}` : 'none');

        const me = (WF.session.user || '').toUpperCase();
        const checks = [
            { ok: !!draft, text: 'An open draft version exists' },
            { ok: t.status === 'Active', text: 'Template is active' },
            { ok: !!draft && draft.status === 'Validated', text: 'Draft has been validated without errors (re-checked on publish)' },
            { ok: !!draft && (draft.createdBy || '').toUpperCase() !== me && (draft.modifiedBy || '').toUpperCase() !== me, text: 'You did not create or last modify this draft (four-eyes)' },
            { ok: WF.session.hasRole('WF_PUBLISHER'), text: 'You hold the publisher role' }
        ];
        const list = clear(qs('[data-role="checklist"]', root));
        checks.forEach(c => list.appendChild(el('li', { class: c.ok ? 'text-success' : 'text-danger' }, icon(c.ok ? 'bi-check-circle-fill' : 'bi-x-circle'), ` ${c.text}`)));

        const button = qs('[data-action="publish"]', root);
        button.disabled = !(draft && t.status === 'Active' && WF.session.hasRole('WF_PUBLISHER'));
        button.dataset.versionNo = draft ? String(draft.versionNo) : '';

        const result = clear(qs('[data-role="result"]', root));
        if (t.publishedVersionNo) {
            const published = detail.versions.find(v => v.versionNo === t.publishedVersionNo);
            result.appendChild(el('dl', { class: 'row mb-2' },
                el('dt', { class: 'col-5', text: 'Version' }), el('dd', { class: 'col-7', text: `v${t.publishedVersionNo}` }),
                el('dt', { class: 'col-5', text: 'Published by' }), el('dd', { class: 'col-7', text: published ? `${published.publishedBy} (${WF.ui.formatDate(published.publishedOn)})` : '' }),
                el('dt', { class: 'col-5', text: 'SHA-256' }), el('dd', { class: 'col-7 font-monospace text-break', text: published ? published.definitionHash : '' }),
                el('dt', { class: 'col-5', text: 'Consumer API' }), el('dd', { class: 'col-7 font-monospace text-break', text: `GET ${WF.config.apiBaseUrl}/api/definitions/${t.templateCode}` })));
            result.appendChild(el('a', { class: 'btn btn-sm btn-outline-secondary', attrs: { href: `/Workflows/History/${t.workflowTemplateId}` } }, icon('bi-clock-history'), ' View definitions'));
        } else {
            result.appendChild(el('span', { class: 'text-muted', text: 'Nothing published yet.' }));
        }
    }

    WF.pages.publish = {
        async init(root) {
            const workflowId = Number(root.dataset.workflowId);
            let detail = await WF.workflowContext.load(workflowId);
            renderPublishState(root, detail);

            const button = qs('[data-action="publish"]', root);
            button.addEventListener('click', async () => {
                const versionNo = Number(button.dataset.versionNo);
                if (!(await WF.ui.confirm('Publish workflow', `Publish ${detail.template.templateCode} v${versionNo}? Published versions are immutable and become available to the Temporal execution service.`, 'Publish'))) { return; }
                await WF.ui.busy(button, async () => {
                    const errors = qs('[data-role="errors"]', root);
                    WF.ui.clearError(errors);
                    try {
                        const result = await WF.api.publishWorkflow(workflowId, { versionNo, comments: qs('#pub-comments', root).value.trim() || null });
                        WF.ui.toast(`Published ${result.templateCode} v${result.versionNo}.`);
                        detail = await WF.workflowContext.load(workflowId);
                    } catch (e) {
                        WF.ui.showError(errors, e);
                    }
                });
                renderPublishState(root, detail);
            });
        }
    };

    // ================================================================== History page
    WF.pages.history = {
        async init(root) {
            const workflowId = Number(root.dataset.workflowId);
            bindCopy(root);
            const detail = await WF.workflowContext.load(workflowId);
            const [audit] = await Promise.all([WF.api.getAudit(workflowId)]);

            const body = clear(qs('[data-role="versions"]', root));
            detail.versions.forEach(v => {
                const actions = el('td', { class: 'text-end text-nowrap' },
                    el('a', { class: 'btn btn-sm btn-outline-primary me-1', attrs: { href: `/Workflows/Designer/${workflowId}?version=${v.versionNo}`, title: 'Open in designer' } }, icon('bi-diagram-2')));
                if (v.status === 'Published' || v.status === 'Superseded') {
                    actions.appendChild(el('button', { class: 'btn btn-sm btn-outline-secondary', attrs: { type: 'button', title: 'View published definition' }, on: {
                        click: async () => {
                            try { showJson(root, `${detail.template.templateCode} v${v.versionNo} (${v.status})`, await WF.api.getDefinition(workflowId, v.versionNo)); } catch (e) { WF.ui.showError(null, e); }
                        }
                    } }, icon('bi-filetype-json')));
                }
                body.appendChild(el('tr', {},
                    el('td', { class: 'fw-semibold', text: `v${v.versionNo}` }),
                    el('td', {}, WF.ui.statusBadge(v.status)),
                    el('td', { text: v.basedOnVersionNo ? `v${v.basedOnVersionNo}` : '-' }),
                    el('td', { class: 'small', text: `${v.createdBy} ${WF.ui.formatDate(v.createdOn)}` }),
                    el('td', { class: 'small', text: v.modifiedBy ? `${v.modifiedBy} ${WF.ui.formatDate(v.modifiedOn)}` : '' }),
                    el('td', { class: 'small', text: v.validatedOn ? `${v.validatedBy} ${WF.ui.formatDate(v.validatedOn)}` : '' }),
                    el('td', { class: 'small', text: v.publishedOn ? `${v.publishedBy} ${WF.ui.formatDate(v.publishedOn)}` : '' }),
                    el('td', { class: 'small font-monospace', text: v.definitionHash ? `${v.definitionHash.slice(0, 12)}...` : '', attrs: { title: v.definitionHash || '' } }),
                    el('td', { class: 'small wf-truncate', text: v.changeNotes || '' }),
                    actions));
            });

            const hasDraft = detail.versions.some(v => v.status === 'Draft' || v.status === 'Validated');
            const newVersion = qs('[data-action="new-version"]', root);
            newVersion.disabled = hasDraft || detail.template.status !== 'Active';
            newVersion.title = hasDraft ? 'An open draft already exists' : '';
            newVersion.addEventListener('click', () => WF.ui.busy(newVersion, async () => {
                try {
                    const created = await WF.api.createVersion(workflowId, { changeNotes: qs('[data-role="new-version-notes"]', root).value.trim() || null });
                    window.location.href = `/Workflows/Designer/${workflowId}?version=${created.graph.version.versionNo}`;
                } catch (e) { WF.ui.showError(null, e); }
            }));

            const auditBody = clear(qs('[data-role="audit"]', root));
            audit.forEach(a => auditBody.appendChild(el('tr', {},
                el('td', { class: 'text-nowrap small', text: WF.ui.formatDate(a.actionOn) }),
                el('td', { class: 'small', text: a.userName }),
                el('td', {}, el('span', { class: 'badge text-bg-light', text: a.action })),
                el('td', { class: 'small font-monospace', text: (a.correlationId || '').slice(0, 12) }),
                el('td', { class: 'small font-monospace text-break', text: a.details || '' }))));
            if (!audit.length) { auditBody.appendChild(el('tr', {}, el('td', { attrs: { colspan: 5 }, class: 'text-muted', text: 'No audit entries.' }))); }
        }
    };
})(window.WF, window);
