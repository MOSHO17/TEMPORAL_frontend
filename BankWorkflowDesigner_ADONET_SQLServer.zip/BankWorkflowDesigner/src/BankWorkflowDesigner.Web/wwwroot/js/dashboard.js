/* dashboard.js - counters and recent audit activity */
(function (WF) {
    'use strict';
    const { el, qs, qsa, clear } = WF.dom;

    WF.pages.dashboard = {
        async init(root) {
            const data = await WF.api.dashboard();
            qsa('[data-counter]', root).forEach(node => { node.textContent = String(data[node.dataset.counter] ?? 0); });

            const body = clear(qs('[data-role="recent"]', root));
            if (!data.recentActivity.length) {
                body.appendChild(el('tr', {}, el('td', { attrs: { colspan: 5 }, class: 'text-muted', text: 'No activity yet.' })));
                return;
            }

            data.recentActivity.forEach(a => {
                const entityCell = a.entityType === 'WorkflowTemplate'
                    ? el('a', { attrs: { href: `/Workflows/History/${encodeURIComponent(a.entityId)}` }, text: `Workflow #${a.entityId}` })
                    : document.createTextNode(`${a.entityType} #${a.entityId}`);
                body.appendChild(el('tr', {},
                    el('td', { class: 'text-nowrap', text: WF.ui.formatDate(a.actionOn) }),
                    el('td', { text: a.userName }),
                    el('td', {}, entityCell),
                    el('td', {}, el('span', { class: 'badge text-bg-light', text: a.action })),
                    el('td', { class: 'small text-muted wf-truncate', text: a.details || '' })));
            });
        }
    };
})(window.WF);
