/* =============================================================================
   workflow-scheduler.js - scheduler metadata (Quartz.NET execution is out of scope).
   Only approved Oracle query references can be selected; SQL text is never entered.
   ============================================================================= */
(function (WF, window) {
    'use strict';
    const { el, qs, clear, icon } = WF.dom;

    const TIME_ZONES = ['India Standard Time', 'Asia/Kolkata', 'UTC', 'GMT Standard Time', 'Singapore Standard Time', 'Arabian Standard Time', 'Eastern Standard Time'];
    const CRON_PRESETS = [
        { label: 'Weekdays 06:00', cron: '0 0 6 ? * MON-FRI' },
        { label: 'Every day 01:30', cron: '0 30 1 * * ?' },
        { label: 'Every hour at :15', cron: '0 15 * * * ?' },
        { label: 'Every 30 minutes', cron: '0 0/30 * * * ?' },
        { label: '1st of month 07:00', cron: '0 0 7 1 * ?' },
        { label: 'Last day of month 22:00', cron: '0 0 22 L * ?' }
    ];

    // ================================================================== list
    WF.pages['scheduler-list'] = {
        async init(root) {
            const items = await WF.api.getSchedulers();
            const body = clear(qs('[data-role="rows"]', root));
            if (!items.length) {
                body.appendChild(el('tr', {}, el('td', { attrs: { colspan: 9 }, class: 'text-muted', text: 'No schedules configured.' })));
            }

            items.forEach(s => body.appendChild(el('tr', {},
                el('td', { class: 'font-monospace fw-semibold', text: s.schedulerCode }),
                el('td', {}, s.schedulerName, el('div', { class: 'small text-muted', text: s.description || '' })),
                el('td', { class: 'font-monospace small', text: s.approvedQueryCode }),
                el('td', { class: 'font-monospace small', text: s.cronExpression }),
                el('td', { class: 'small', text: s.timeZoneId }),
                el('td', {}, el('a', { attrs: { href: `/Workflows/Designer/${s.targetWorkflowTemplateId}` }, text: s.targetTemplateCode })),
                el('td', { class: 'small', text: s.targetVersionPolicy === 'Pinned' ? `Pinned v${s.pinnedVersionNo}` : 'Latest published' }),
                el('td', {}, el('span', { class: `badge ${s.isActive ? 'text-bg-success' : 'text-bg-secondary'}`, text: s.isActive ? 'Active' : 'Inactive' })),
                el('td', { class: 'text-end' }, el('a', { class: 'btn btn-sm btn-outline-primary', attrs: { href: `/Schedulers/Edit/${s.schedulerConfigId}` } }, icon('bi-pencil'))))));
        }
    };

    // ================================================================== edit
    function toLocalInput(value) { return value ? String(value).slice(0, 16) : ''; }
    function fromLocalInput(value) { return value ? `${value}:00Z` : null; }

    WF.pages['scheduler-edit'] = {
        async init(root) {
            const form = qs('[data-role="form"]', root);
            const errors = qs('[data-role="errors"]', form);
            const schedulerId = root.dataset.schedulerId ? Number(root.dataset.schedulerId) : null;

            const [systems, queries, existing] = await Promise.all([
                WF.api.getSourceSystems(), WF.api.approvedQueries(), schedulerId ? WF.api.getScheduler(schedulerId) : Promise.resolve(null)]);

            const ssSelect = qs('#s-ss', form);
            const querySelect = qs('#s-query', form);
            const targetSelect = qs('#s-target', form);
            WF.forms.fillSelect(ssSelect, systems.filter(s => s.status === 'Active' || (existing && s.sourceSystemId === existing.sourceSystemId)),
                s => s.sourceSystemId, s => `${s.systemCode} - ${s.applicationName}`, 'Select...');
            WF.forms.fillSelect(qs('#s-tz', form), TIME_ZONES, t => t, t => t);

            const presets = qs('[data-role="cron-presets"]', form);
            CRON_PRESETS.forEach(p => presets.appendChild(el('li', {}, el('a', { class: 'dropdown-item small', attrs: { href: '#' }, on: {
                click: evt => { evt.preventDefault(); qs('#s-cron', form).value = p.cron; checkCron(); }
            } }, `${p.label}  `, el('code', { text: p.cron })))));

            const refreshForSourceSystem = async () => {
                const ssId = Number(ssSelect.value || 0);
                WF.forms.fillSelect(querySelect, queries.filter(q => q.isActive && (!q.sourceSystemId || q.sourceSystemId === ssId)),
                    q => q.approvedQueryId, q => `${q.queryCode} - ${q.queryName}`, 'Select...');
                if (!ssId) { WF.forms.fillSelect(targetSelect, [], x => x, x => x, 'Select...'); return; }
                const templates = await WF.api.searchWorkflows({ sourceSystemId: ssId, pageSize: 200 });
                WF.forms.fillSelect(targetSelect, templates.items.filter(t => t.status === 'Active'),
                    t => t.workflowTemplateId, t => `${t.templateCode} - ${t.workflowName}${t.publishedVersionNo ? ` (v${t.publishedVersionNo} published)` : ' (not published)'}`, 'Select...');
            };

            const showQueryInfo = () => {
                const q = queries.find(x => String(x.approvedQueryId) === querySelect.value);
                const info = qs('[data-role="query-info"]', form);
                info.textContent = q ? `${q.description || ''} Bind variables: ${q.parameterNames.length ? q.parameterNames.join(', ') : 'none'}. Data source: ${q.dataSourceProfileCode}.` : '';
                const params = qs('#s-params', form);
                if (q && (params.value.trim() === '' || params.value.trim() === '{}') && q.parameterNames.length) {
                    const template = {};
                    q.parameterNames.forEach(n => { template[n] = ''; });
                    params.value = JSON.stringify(template, null, 2);
                }
            };

            const cronResult = qs('[data-role="cron-result"]', form);
            const checkCron = WF.ui.debounce(async () => {
                const value = qs('#s-cron', form).value.trim();
                if (!value) { cronResult.textContent = 'sec min hour day-of-month month day-of-week [year]'; cronResult.className = 'form-text'; return; }
                try {
                    const r = await WF.api.validateCron(value);
                    cronResult.textContent = r.isValid ? r.description : r.error;
                    cronResult.className = `form-text ${r.isValid ? 'text-success' : 'text-danger'}`;
                } catch (e) { cronResult.textContent = e.message; cronResult.className = 'form-text text-danger'; }
            }, 400);

            const policy = qs('#s-policy', form);
            const syncPolicy = () => { qs('#s-pinned', form).disabled = policy.value !== 'Pinned'; };

            ssSelect.addEventListener('change', refreshForSourceSystem);
            querySelect.addEventListener('change', showQueryInfo);
            qs('#s-cron', form).addEventListener('input', checkCron);
            policy.addEventListener('change', syncPolicy);

            if (existing) {
                ssSelect.value = String(existing.sourceSystemId);
                await refreshForSourceSystem();
                WF.forms.fill(form, Object.assign({}, existing, {
                    effectiveFrom: toLocalInput(existing.effectiveFrom), effectiveTo: toLocalInput(existing.effectiveTo)
                }));
                qs('#s-code', form).readOnly = true;
                try { qs('#s-params', form).value = JSON.stringify(JSON.parse(existing.executionParametersJson), null, 2); } catch { /* keep */ }
                showQueryInfo();
                checkCron();
            } else {
                qs('#s-tz', form).value = 'India Standard Time';
            }
            syncPolicy();

            form.addEventListener('submit', async evt => {
                evt.preventDefault();
                WF.ui.clearError(errors);
                const data = WF.forms.read(form);
                const body = {
                    schedulerCode: (data.schedulerCode || '').toUpperCase(),
                    sourceSystemId: Number(data.sourceSystemId || 0),
                    schedulerName: data.schedulerName,
                    description: data.description,
                    approvedQueryId: Number(data.approvedQueryId || 0),
                    cronExpression: data.cronExpression,
                    timeZoneId: data.timeZoneId,
                    targetWorkflowTemplateId: Number(data.targetWorkflowTemplateId || 0),
                    targetVersionPolicy: data.targetVersionPolicy,
                    pinnedVersionNo: data.targetVersionPolicy === 'Pinned' ? data.pinnedVersionNo : null,
                    executionParametersJson: data.executionParametersJson || '{}',
                    misfirePolicy: data.misfirePolicy,
                    maxConcurrentRuns: data.maxConcurrentRuns || 1,
                    effectiveFrom: fromLocalInput(data.effectiveFrom),
                    effectiveTo: fromLocalInput(data.effectiveTo),
                    isActive: data.isActive,
                    rowVersion: existing ? existing.rowVersion : null
                };
                await WF.ui.busy(form.querySelector('button[type="submit"]'), async () => {
                    try {
                        if (existing) { await WF.api.updateScheduler(existing.schedulerConfigId, body); } else { await WF.api.createScheduler(body); }
                        WF.ui.toast('Schedule saved.');
                        window.location.href = '/Schedulers';
                    } catch (e) { WF.ui.showError(errors, e); }
                });
            });
        }
    };
})(window.WF, window);
