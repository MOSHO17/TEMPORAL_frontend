/* source-systems.js - source system, module and authorised-user maintenance */
(function (WF) {
    'use strict';
    const { el, qs, qsa, clear, icon } = WF.dom;
    const ACCESS_ROLES = ['Administrator', 'Designer', 'Reviewer', 'Publisher', 'Viewer'];

    let editing = null;

    function moduleRow(m) {
        const tr = el('tr', {},
            el('td', {}, el('input', { class: 'form-control form-control-sm', value: m.moduleCode || '', attrs: { 'data-field': 'moduleCode', maxlength: 50, required: true, readonly: !!m.moduleId } })),
            el('td', {}, el('input', { class: 'form-control form-control-sm', value: m.moduleName || '', attrs: { 'data-field': 'moduleName', maxlength: 200, required: true } })),
            el('td', {}, el('input', { class: 'form-control form-control-sm', value: m.description || '', attrs: { 'data-field': 'description', maxlength: 1000 } })),
            el('td', {}, statusSelect(m.status || 'Active')),
            el('td', { class: 'text-end' }, m.moduleId ? el('span', { class: 'small text-muted', text: 'saved' })
                : el('button', { class: 'btn btn-sm btn-outline-danger', attrs: { type: 'button', title: 'Remove' }, on: { click: () => tr.remove() } }, icon('bi-x'))));
        return tr;
    }

    function statusSelect(value) {
        const s = el('select', { class: 'form-select form-select-sm', attrs: { 'data-field': 'status' } },
            el('option', { text: 'Active', value: 'Active' }), el('option', { text: 'Inactive', value: 'Inactive' }));
        s.value = value;
        return s;
    }

    function userRow(u) {
        const role = el('select', { class: 'form-select form-select-sm', attrs: { 'data-field': 'accessRole' } }, ACCESS_ROLES.map(r => el('option', { value: r, text: r })));
        role.value = u.accessRole || 'Viewer';
        const tr = el('tr', {},
            el('td', {}, el('input', { class: 'form-control form-control-sm font-monospace', value: u.userPrincipal || '', attrs: { 'data-field': 'userPrincipal', maxlength: 256, required: true, placeholder: 'BANK\\user or user@bank.com' } })),
            el('td', {}, el('input', { class: 'form-control form-control-sm', value: u.displayName || '', attrs: { 'data-field': 'displayName', maxlength: 200 } })),
            el('td', {}, role),
            el('td', {}, el('input', { class: 'form-check-input', attrs: { type: 'checkbox', 'data-field': 'isActive' }, checked: u.isActive !== false })),
            el('td', { class: 'text-end' }, el('button', { class: 'btn btn-sm btn-outline-danger', attrs: { type: 'button', title: 'Remove' }, on: { click: () => tr.remove() } }, icon('bi-x'))));
        return tr;
    }

    function readRows(tbody) {
        return qsa('tr', tbody).map(tr => {
            const row = {};
            qsa('[data-field]', tr).forEach(input => {
                row[input.dataset.field] = input.type === 'checkbox' ? input.checked : (input.value.trim() || null);
            });
            return row;
        });
    }

    function openModal(root, ss) {
        editing = ss;
        const form = qs('[data-role="form"]', root);
        WF.ui.clearError(qs('[data-role="errors"]', form));
        form.reset();
        qs('[data-role="title"]', root).textContent = ss ? `Edit ${ss.systemCode}` : 'Register source system';
        WF.forms.fill(form, ss || { status: 'Active' });
        qs('#ss-code', form).readOnly = !!ss;
        const modules = clear(qs('[data-role="modules"]', form));
        const users = clear(qs('[data-role="users"]', form));
        (ss ? ss.modules : [{}]).forEach(m => modules.appendChild(moduleRow(m)));
        (ss ? ss.authorizedUsers : []).forEach(u => users.appendChild(userRow(u)));
        window.bootstrap.Modal.getOrCreateInstance(qs('#ss-modal')).show();
    }

    async function load(root) {
        const systems = await WF.api.getSourceSystems();
        const body = clear(qs('[data-role="rows"]', root));
        if (!systems.length) {
            body.appendChild(el('tr', {}, el('td', { attrs: { colspan: 7 }, class: 'text-muted', text: 'No source systems registered (or you are not authorised for any).' })));
            return;
        }

        const isAdmin = WF.session.hasRole('WF_SOURCE_ADMIN');
        systems.forEach(ss => {
            body.appendChild(el('tr', {},
                el('td', { class: 'fw-semibold font-monospace', text: ss.systemCode }),
                el('td', {}, ss.applicationName, el('div', { class: 'small text-muted', text: ss.description || '' })),
                el('td', {}, ss.modules.map(m => el('span', { class: `badge me-1 ${m.status === 'Active' ? 'text-bg-primary' : 'text-bg-secondary'}`, text: m.moduleCode }))),
                el('td', { class: 'small' }, ss.authorizedUsers.filter(u => u.isActive).map(u => el('div', {}, `${u.userPrincipal} `, el('span', { class: 'badge text-bg-light', text: u.accessRole })))),
                el('td', { class: 'small font-monospace', text: ss.defaultTaskQueue }),
                el('td', {}, WF.ui.statusBadge(ss.status)),
                el('td', { class: 'text-end' }, isAdmin
                    ? el('button', { class: 'btn btn-sm btn-outline-primary', attrs: { type: 'button' }, on: { click: async () => openModal(root, await WF.api.getSourceSystem(ss.sourceSystemId)) } }, icon('bi-pencil'), ' Edit')
                    : null)));
        });
    }

    WF.pages['source-systems'] = {
        async init(root) {
            qs('[data-action="new"]', root).addEventListener('click', () => openModal(root, null));
            qs('[data-action="add-module"]', root).addEventListener('click', () => qs('[data-role="modules"]', root).appendChild(moduleRow({})));
            qs('[data-action="add-user"]', root).addEventListener('click', () => qs('[data-role="users"]', root).appendChild(userRow({})));

            const form = qs('[data-role="form"]', root);
            form.addEventListener('submit', async evt => {
                evt.preventDefault();
                const errors = qs('[data-role="errors"]', form);
                const data = WF.forms.read(form);
                const body = {
                    applicationName: data.applicationName,
                    description: data.description,
                    defaultTaskQueue: data.defaultTaskQueue,
                    status: data.status,
                    modules: readRows(qs('[data-role="modules"]', form)),
                    authorizedUsers: readRows(qs('[data-role="users"]', form))
                };
                await WF.ui.busy(form.querySelector('button[type="submit"]'), async () => {
                    try {
                        if (editing) {
                            body.rowVersion = editing.rowVersion;
                            await WF.api.updateSourceSystem(editing.sourceSystemId, body);
                        } else {
                            body.systemCode = data.systemCode;
                            await WF.api.createSourceSystem(body);
                        }
                        window.bootstrap.Modal.getOrCreateInstance(qs('#ss-modal')).hide();
                        WF.ui.toast('Source system saved.');
                        await load(root);
                    } catch (e) {
                        WF.ui.showError(errors, e);
                    }
                });
            });

            await load(root);
        }
    };
})(window.WF);
