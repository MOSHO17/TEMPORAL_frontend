/* =============================================================================
   workflow-designer.js - dependency-free drag-and-drop workflow designer.
   - Toolbox (HTML5 drag & drop) -> POST activity
   - Node drag (pointer events) -> debounced PUT layout
   - Port drag between nodes -> connection dialog -> POST connection
   - Selection + properties panel -> PUT activity / PUT connection / DELETE
   - Validate -> highlights nodes with issues; Definition preview
   Every change is persisted immediately through workflow-api.js; the server is the source of truth.
   ============================================================================= */
(function (WF, window, document) {
    'use strict';
    const { el, qs, qsa, clear, icon } = WF.dom;

    const NODE_W = 190;
    const NODE_H = 66;
    const GRID = 10;
    const CATEGORY_ORDER = ['Control', 'HumanTask', 'Integration', 'File', 'Scheduler'];
    const CATEGORY_LABEL = { Control: 'Flow control', HumanTask: 'Human tasks', Integration: 'Integration', File: 'Files', Scheduler: 'Scheduler' };

    const S = {
        root: null, workflowId: 0, versionNo: null, detail: null, graph: null, catalog: null, profiles: [], queries: [],
        editable: false, zoom: 1, selected: null, issuesByKey: {}, pendingConnection: null, movedKeys: new Set(),
        canvas: null, nodesLayer: null, edgeLayer: null, dragEdge: null, scroll: null
    };

    const snap = v => Math.max(0, Math.round(v / GRID) * GRID);
    const byKey = key => S.graph.activities.find(a => a.activityKey === key);
    const descriptorOf = activity => S.catalog.map[activity.activityType];

    function setSaveState(text, variant) {
        const node = qs('[data-role="save-state"]', S.root);
        node.textContent = text || '';
        node.className = `ms-auto small ${variant ? 'text-' + variant : 'text-muted'}`;
    }

    function canvasPoint(evt) {
        const rect = S.canvas.getBoundingClientRect();
        return { x: (evt.clientX - rect.left) / S.zoom, y: (evt.clientY - rect.top) / S.zoom };
    }

    // ================================================================== toolbox
    function renderToolbox() {
        const box = clear(qs('[data-role="toolbox"]', S.root));
        CATEGORY_ORDER.forEach(category => {
            const items = S.catalog.list.filter(d => d.category === category);
            if (!items.length) { return; }
            box.appendChild(el('div', { class: 'wf-toolbox-group', text: CATEGORY_LABEL[category] }));
            items.forEach(d => {
                const item = el('div', {
                    class: `wf-toolbox-item ${WF.catalog.colorClass(d)}`,
                    attrs: { draggable: S.editable ? 'true' : 'false', title: d.description, role: 'button', tabindex: 0, 'aria-label': `Add ${d.displayName}` },
                    dataset: { type: d.type }
                }, icon(d.icon), el('span', { text: d.displayName }));
                item.addEventListener('dragstart', evt => {
                    if (!S.editable) { evt.preventDefault(); return; }
                    evt.dataTransfer.setData('application/x-wf-activity', d.type);
                    evt.dataTransfer.setData('text/plain', d.type);
                    evt.dataTransfer.effectAllowed = 'copy';
                });
                // Keyboard accessibility: Enter adds the activity at the visible top-left of the canvas.
                item.addEventListener('keydown', evt => {
                    if (evt.key === 'Enter' && S.editable) {
                        addActivity(d.type, { x: S.scroll.scrollLeft / S.zoom + 60, y: S.scroll.scrollTop / S.zoom + 60 });
                    }
                });
                if (!S.editable) { item.classList.add('opacity-50'); }
                box.appendChild(item);
            });
        });
    }

    function uniqueKey(type) {
        const base = type.charAt(0).toLowerCase() + type.slice(1);
        const existing = new Set(S.graph.activities.map(a => a.activityKey));
        if (!existing.has(base)) { return base; }
        let i = 2;
        while (existing.has(`${base}${i}`)) { i++; }
        return `${base}${i}`;
    }

    async function addActivity(type, point) {
        const descriptor = S.catalog.map[type];
        const body = {
            activityKey: uniqueKey(type),
            activityType: type,
            displayName: descriptor.displayName,
            positionX: snap(point.x - NODE_W / 2),
            positionY: snap(point.y - NODE_H / 2)
        };
        try {
            setSaveState('Saving...');
            const created = await WF.api.addActivity(S.workflowId, body);
            S.graph.activities.push(created);
            markChanged();
            renderAll();
            select({ type: 'node', key: created.activityKey });
            setSaveState('Saved', 'success');
        } catch (e) {
            setSaveState('Save failed', 'danger');
            WF.ui.showError(null, e);
        }
    }

    // ================================================================== nodes
    function renderNodes() {
        clear(S.nodesLayer);
        S.graph.activities.forEach(a => {
            const d = descriptorOf(a);
            const issues = S.issuesByKey[a.activityKey] || [];
            const errors = issues.filter(i => i.severity === 'Error').length;
            const warnings = issues.length - errors;
            const node = el('div', {
                class: `wf-node ${WF.catalog.colorClass(d)}${d.category === 'Control' ? ' wf-control' : ''}${errors ? ' has-error' : warnings ? ' has-warning' : ''}`,
                attrs: { role: 'button', tabindex: 0, 'aria-label': `${a.displayName} (${d.displayName})`, title: `${a.displayName}\n${a.activityKey} - ${d.displayName}` },
                dataset: { key: a.activityKey }
            },
                el('i', { class: `bi ${d.icon} wf-node-icon`, attrs: { 'aria-hidden': 'true' } }),
                el('div', { class: 'wf-node-title', text: a.displayName }),
                el('div', { class: 'wf-node-meta', text: `${a.activityKey} · ${d.displayName}` }),
                errors || warnings ? el('span', { class: `badge rounded-pill wf-badge-issues ${errors ? 'text-bg-danger' : 'text-bg-warning'}`, text: String(errors || warnings) }) : null,
                S.editable && a.activityType !== 'End' ? el('div', { class: 'wf-port', attrs: { title: 'Drag to connect' }, dataset: { port: 'out' } }) : null);
            node.style.left = `${a.positionX}px`;
            node.style.top = `${a.positionY}px`;
            if (S.selected && S.selected.type === 'node' && S.selected.key === a.activityKey) { node.classList.add('selected'); }

            node.addEventListener('pointerdown', evt => onNodePointerDown(evt, a, node));
            node.addEventListener('dblclick', () => { if (a.activityType !== 'Start' && a.activityType !== 'End') { window.location.href = `/Workflows/Activity/${S.workflowId}?activityId=${a.activityId}`; } });
            node.addEventListener('keydown', evt => { if (evt.key === 'Enter') { select({ type: 'node', key: a.activityKey }); } });
            S.nodesLayer.appendChild(node);
        });
    }

    function onNodePointerDown(evt, activity, node) {
        if (evt.button !== 0) { return; }
        evt.stopPropagation();
        if (evt.target.dataset.port === 'out') { startConnectionDrag(evt, activity); return; }
        select({ type: 'node', key: activity.activityKey });
        if (!S.editable) { return; }

        const start = canvasPoint(evt);
        const origin = { x: activity.positionX, y: activity.positionY };
        let moved = false;
        node.setPointerCapture(evt.pointerId);

        const onMove = e => {
            const p = canvasPoint(e);
            const nx = snap(origin.x + p.x - start.x);
            const ny = snap(origin.y + p.y - start.y);
            if (nx === activity.positionX && ny === activity.positionY) { return; }
            moved = true;
            activity.positionX = nx;
            activity.positionY = ny;
            node.style.left = `${nx}px`;
            node.style.top = `${ny}px`;
            renderEdges();
        };
        const onUp = () => {
            node.removeEventListener('pointermove', onMove);
            node.removeEventListener('pointerup', onUp);
            node.removeEventListener('pointercancel', onUp);
            if (moved) { S.movedKeys.add(activity.activityKey); saveLayoutDebounced(); }
        };
        node.addEventListener('pointermove', onMove);
        node.addEventListener('pointerup', onUp);
        node.addEventListener('pointercancel', onUp);
    }

    const saveLayoutDebounced = WF.ui.debounce(saveLayout, 600);

    async function saveLayout() {
        if (!S.movedKeys.size) { return; }
        const positions = Array.from(S.movedKeys).map(k => byKey(k)).filter(Boolean)
            .map(a => ({ activityKey: a.activityKey, positionX: a.positionX, positionY: a.positionY }));
        S.movedKeys.clear();
        try {
            setSaveState('Saving layout...');
            await WF.api.saveLayout(S.workflowId, positions);
            setSaveState('Layout saved', 'success');
        } catch (e) {
            setSaveState('Layout not saved', 'danger');
            WF.ui.showError(null, e);
        }
    }

    // ================================================================== connections
    function anchor(a, side) {
        switch (side) {
            case 'right': return { x: a.positionX + NODE_W, y: a.positionY + NODE_H / 2 };
            case 'left': return { x: a.positionX, y: a.positionY + NODE_H / 2 };
            default: return { x: a.positionX + NODE_W / 2, y: a.positionY + NODE_H };
        }
    }

    function edgePath(from, to) {
        const forward = to.positionX >= from.positionX + NODE_W + 20;
        if (forward) {
            const s = anchor(from, 'right');
            const t = anchor(to, 'left');
            const dx = Math.max(40, (t.x - s.x) / 2);
            return `M ${s.x} ${s.y} C ${s.x + dx} ${s.y}, ${t.x - dx} ${t.y}, ${t.x} ${t.y}`;
        }
        // Backward / vertical links (e.g. rejection loops) are routed underneath both nodes.
        const s = anchor(from, 'bottom');
        const t = anchor(to, 'bottom');
        const lowY = Math.max(s.y, t.y) + 60;
        return `M ${s.x} ${s.y} C ${s.x} ${lowY}, ${t.x} ${lowY}, ${t.x} ${t.y}`;
    }

    function edgeLabel(c) {
        if (c.label) { return c.label; }
        if (c.connectionType === 'Conditional') { return c.isDefault ? 'default' : (c.conditionExpression || '?'); }
        if (c.connectionType === 'Rejection') { return 'rejected'; }
        if (c.connectionType === 'Error') { return 'on error'; }
        return '';
    }

    function renderEdges() {
        clear(S.edgeLayer);
        S.graph.connections.forEach(c => {
            const from = byKey(c.fromActivityKey);
            const to = byKey(c.toActivityKey);
            if (!from || !to) { return; }
            const d = edgePath(from, to);
            const selected = S.selected && S.selected.type === 'edge' && S.selected.id === c.connectionId;
            const group = el('g', { dataset: { connectionId: c.connectionId } });
            const hit = el('path', { class: 'wf-edge-hit', attrs: { d } });
            const path = el('path', { class: `wf-edge ${c.connectionType}${selected ? ' selected' : ''}`, attrs: { d, 'marker-end': 'url(#wf-arrow)' } });
            group.appendChild(el('title', { text: `${c.connectionType}: ${c.fromActivityKey} -> ${c.toActivityKey}${c.conditionExpression ? '\n' + c.conditionExpression : ''}` }));
            group.appendChild(hit);
            group.appendChild(path);
            const text = edgeLabel(c);
            S.edgeLayer.appendChild(group);
            if (text) {
                let x, y;
                try {
                    const len = path.getTotalLength();
                    const mid = path.getPointAtLength(len / 2);
                    x = mid.x; y = mid.y - 6;
                } catch {
                    x = (from.positionX + to.positionX) / 2 + NODE_W / 2; y = (from.positionY + to.positionY) / 2;
                }
                group.appendChild(el('text', { class: 'wf-edge-label', attrs: { x, y, 'text-anchor': 'middle' }, text: text.length > 34 ? `${text.slice(0, 32)}...` : text }));
            }
            group.addEventListener('pointerdown', evt => { evt.stopPropagation(); select({ type: 'edge', id: c.connectionId }); });
        });
    }

    function startConnectionDrag(evt, fromActivity) {
        evt.preventDefault();
        const start = anchor(fromActivity, 'right');
        S.dragEdge.classList.remove('d-none');
        const move = e => {
            const p = canvasPoint(e);
            S.dragEdge.setAttribute('d', `M ${start.x} ${start.y} L ${p.x} ${p.y}`);
            qsa('.wf-node.wf-connect-target', S.nodesLayer).forEach(n => n.classList.remove('wf-connect-target'));
            const target = document.elementFromPoint(e.clientX, e.clientY);
            const node = target && target.closest ? target.closest('.wf-node') : null;
            if (node && node.dataset.key !== fromActivity.activityKey) { node.classList.add('wf-connect-target'); }
        };
        const up = e => {
            document.removeEventListener('pointermove', move);
            document.removeEventListener('pointerup', up);
            S.dragEdge.classList.add('d-none');
            qsa('.wf-node.wf-connect-target', S.nodesLayer).forEach(n => n.classList.remove('wf-connect-target'));
            const target = document.elementFromPoint(e.clientX, e.clientY);
            const node = target && target.closest ? target.closest('.wf-node') : null;
            if (node && node.dataset.key !== fromActivity.activityKey) {
                openConnectionDialog(fromActivity, byKey(node.dataset.key));
            }
        };
        document.addEventListener('pointermove', move);
        document.addEventListener('pointerup', up);
    }

    function defaultConnectionType(from) {
        if (from.activityType === 'ParallelSplit') { return 'Parallel'; }
        if (from.activityType === 'Decision') { return 'Conditional'; }
        return 'Sequence';
    }

    function openConnectionDialog(from, to) {
        S.pendingConnection = { from, to };
        const form = qs('[data-role="connection-form"]', S.root);
        form.reset();
        WF.ui.clearError(qs('[data-role="connection-errors"]', form));
        qs('[data-role="connection-from"]', form).textContent = `${from.displayName} (${from.activityKey})`;
        qs('[data-role="connection-to"]', form).textContent = `${to.displayName} (${to.activityKey})`;
        const type = qs('#cn-type', form);
        type.value = defaultConnectionType(from);
        const approval = descriptorOf(from).isApproval;
        qsa('option', type).forEach(o => {
            o.disabled = (o.value === 'Rejection' && !approval) || (o.value === 'Parallel' && from.activityType !== 'ParallelSplit');
        });
        const cond = qs('#cn-cond', form);
        cond.placeholder = approval ? `activities.${from.activityKey}.outcome == 'Approved'` : "workflow.input.amount > 500000";
        const sync = () => qs('[data-role="condition-group"]', form).classList.toggle('d-none', type.value !== 'Conditional');
        type.onchange = sync;
        sync();
        window.bootstrap.Modal.getOrCreateInstance(qs('#connection-modal')).show();
    }

    async function submitConnection(evt) {
        evt.preventDefault();
        const form = evt.target;
        const data = WF.forms.read(form);
        const { from, to } = S.pendingConnection;
        const body = {
            fromActivityKey: from.activityKey, toActivityKey: to.activityKey, connectionType: data.connectionType,
            conditionExpression: data.connectionType === 'Conditional' ? data.conditionExpression : null,
            isDefault: data.connectionType === 'Conditional' && data.isDefault, label: data.label, priority: data.priority || 0
        };
        try {
            const created = await WF.api.addConnection(S.workflowId, body);
            S.graph.connections.push(created);
            window.bootstrap.Modal.getOrCreateInstance(qs('#connection-modal')).hide();
            markChanged();
            renderEdges();
            select({ type: 'edge', id: created.connectionId });
            setSaveState('Connection saved', 'success');
        } catch (e) {
            WF.ui.showError(qs('[data-role="connection-errors"]', form), e);
        }
    }

    // ================================================================== selection & properties panel
    function select(selection) {
        S.selected = selection;
        qsa('.wf-node', S.nodesLayer).forEach(n => n.classList.toggle('selected', !!selection && selection.type === 'node' && n.dataset.key === selection.key));
        renderEdges();
        renderProperties();
    }

    function renderProperties() {
        const panel = clear(qs('[data-role="properties"]', S.root));
        if (!S.selected) { panel.appendChild(el('p', { class: 'text-muted small mb-0', text: 'Nothing selected.' })); return; }
        if (S.selected.type === 'node') { renderNodeProperties(panel, byKey(S.selected.key)); } else { renderEdgeProperties(panel, S.graph.connections.find(c => c.connectionId === S.selected.id)); }
    }

    function renderNodeProperties(panel, a) {
        if (!a) { return; }
        const d = descriptorOf(a);
        const ro = !S.editable;
        const errors = el('div');
        const key = el('input', { class: 'form-control form-control-sm font-monospace', value: a.activityKey, attrs: { maxlength: 100, disabled: ro, id: 'pp-key' } });
        const name = el('input', { class: 'form-control form-control-sm', value: a.displayName, attrs: { maxlength: 200, disabled: ro, id: 'pp-name' } });
        const desc = el('textarea', { class: 'form-control form-control-sm', attrs: { rows: 2, maxlength: 1000, disabled: ro, id: 'pp-desc' } });
        desc.value = a.description || '';
        const configHolder = el('div');
        const configEditor = WF.activities.renderConfigFields(configHolder, d, a.config, { profiles: S.profiles, queries: S.queries, sourceSystemId: S.detail.template.sourceSystemId }, ro);

        panel.appendChild(el('div', { class: 'd-flex align-items-center gap-2 mb-2' }, icon(d.icon), el('strong', { text: d.displayName })));
        panel.appendChild(el('p', { class: 'small text-muted', text: d.description }));
        panel.appendChild(errors);
        panel.appendChild(el('div', { class: 'mb-2' }, el('label', { class: 'form-label small mb-0', attrs: { for: 'pp-key' }, text: 'Activity key' }), key));
        panel.appendChild(el('div', { class: 'mb-2' }, el('label', { class: 'form-label small mb-0', attrs: { for: 'pp-name' }, text: 'Display name' }), name));
        panel.appendChild(el('div', { class: 'mb-2' }, el('label', { class: 'form-label small mb-0', attrs: { for: 'pp-desc' }, text: 'Description' }), desc));
        panel.appendChild(el('div', { class: 'small fw-semibold mt-2 mb-1', text: 'Settings' }));
        panel.appendChild(configHolder);

        const issues = S.issuesByKey[a.activityKey] || [];
        if (issues.length) {
            panel.appendChild(el('div', { class: 'small fw-semibold mt-3', text: 'Validation issues' }));
            panel.appendChild(el('ul', { class: 'small ps-3 mb-0' }, issues.map(i => el('li', { class: i.severity === 'Error' ? 'text-danger' : 'text-warning-emphasis', text: `[${i.code}] ${i.message}` }))));
        }

        const buttons = el('div', { class: 'd-flex flex-wrap gap-1 mt-3' });
        if (!ro) {
            buttons.appendChild(el('button', { class: 'btn btn-sm btn-primary', attrs: { type: 'button' }, on: {
                click: async evt => {
                    await WF.ui.busy(evt.currentTarget, async () => {
                        try {
                            const updated = await WF.api.updateActivity(S.workflowId, a.activityId, WF.api.toActivityRequest(a, {
                                activityKey: key.value.trim(), displayName: name.value.trim(), description: desc.value.trim() || null, config: configEditor.read()
                            }));
                            replaceActivity(a, updated);
                            WF.ui.toast('Activity saved.');
                        } catch (e) { WF.ui.showError(errors, e); }
                    });
                }
            } }, icon('bi-save'), ' Save'));
        }
        if (a.activityType !== 'Start' && a.activityType !== 'End') {
            buttons.appendChild(el('a', { class: 'btn btn-sm btn-outline-secondary', attrs: { href: `/Workflows/Activity/${S.workflowId}?activityId=${a.activityId}` } }, icon('bi-sliders'), ' Full configuration'));
        }
        if (d.isApproval) {
            buttons.appendChild(el('a', { class: 'btn btn-sm btn-outline-primary', attrs: { href: `/Workflows/Approval/${S.workflowId}?activityId=${a.activityId}` } }, icon('bi-people'), ' Approval'));
        }
        if (!ro) {
            buttons.appendChild(el('button', { class: 'btn btn-sm btn-outline-danger ms-auto', attrs: { type: 'button', title: 'Delete activity' }, on: { click: deleteSelected } }, icon('bi-trash')));
        }
        panel.appendChild(buttons);
    }

    function replaceActivity(old, updated) {
        const i = S.graph.activities.indexOf(old);
        S.graph.activities[i] = updated;
        if (old.activityKey !== updated.activityKey) {
            S.graph.connections.forEach(c => {
                if (c.fromActivityKey === old.activityKey) { c.fromActivityKey = updated.activityKey; }
                if (c.toActivityKey === old.activityKey) { c.toActivityKey = updated.activityKey; }
            });
        }
        S.selected = { type: 'node', key: updated.activityKey };
        markChanged();
        renderAll();
    }

    function renderEdgeProperties(panel, c) {
        if (!c) { return; }
        const ro = !S.editable;
        const errors = el('div');
        const from = byKey(c.fromActivityKey);
        const type = el('select', { class: 'form-select form-select-sm', attrs: { disabled: ro, id: 'pe-type' } },
            ['Sequence', 'Conditional', 'Parallel', 'Rejection', 'Error'].map(t => el('option', { value: t, text: t })));
        type.value = c.connectionType;
        const cond = el('input', { class: 'form-control form-control-sm font-monospace', value: c.conditionExpression || '', attrs: { maxlength: 1000, disabled: ro, id: 'pe-cond' } });
        const isDefault = el('input', { class: 'form-check-input', attrs: { type: 'checkbox', disabled: ro, id: 'pe-default' }, checked: c.isDefault });
        const label = el('input', { class: 'form-control form-control-sm', value: c.label || '', attrs: { maxlength: 200, disabled: ro, id: 'pe-label' } });
        const priority = el('input', { class: 'form-control form-control-sm', value: c.priority, attrs: { type: 'number', min: 0, max: 1000, disabled: ro, id: 'pe-prio' } });
        const condGroup = el('div', { class: 'mb-2' },
            el('label', { class: 'form-label small mb-0', attrs: { for: 'pe-cond' }, text: 'Condition' }), cond,
            el('div', { class: 'form-check mt-1' }, isDefault, el('label', { class: 'form-check-label small', attrs: { for: 'pe-default' }, text: 'Default branch' })),
            el('div', { class: 'form-text', text: "e.g. activities.checker.outcome == 'Approved' && workflow.input.amount <= 1000000" }));
        const sync = () => condGroup.classList.toggle('d-none', type.value !== 'Conditional');
        type.addEventListener('change', sync);
        sync();

        panel.appendChild(el('div', { class: 'mb-2 small' }, el('strong', { text: 'Connection' }), el('div', { class: 'font-monospace', text: `${c.fromActivityKey} → ${c.toActivityKey}` })));
        panel.appendChild(errors);
        panel.appendChild(el('div', { class: 'mb-2' }, el('label', { class: 'form-label small mb-0', attrs: { for: 'pe-type' }, text: 'Type' }), type));
        panel.appendChild(condGroup);
        panel.appendChild(el('div', { class: 'mb-2' }, el('label', { class: 'form-label small mb-0', attrs: { for: 'pe-label' }, text: 'Label' }), label));
        panel.appendChild(el('div', { class: 'mb-2' }, el('label', { class: 'form-label small mb-0', attrs: { for: 'pe-prio' }, text: 'Priority (evaluation order)' }), priority));
        if (from && descriptorOf(from).isApproval) {
            panel.appendChild(el('p', { class: 'small text-muted', text: 'From an approval activity: a Sequence connection is followed on approval; a Rejection connection on rejection.' }));
        }

        if (!ro) {
            panel.appendChild(el('div', { class: 'd-flex gap-1' },
                el('button', { class: 'btn btn-sm btn-primary', attrs: { type: 'button' }, on: {
                    click: async evt => {
                        await WF.ui.busy(evt.currentTarget, async () => {
                            try {
                                const updated = await WF.api.updateConnection(S.workflowId, c.connectionId, {
                                    fromActivityKey: c.fromActivityKey, toActivityKey: c.toActivityKey, connectionType: type.value,
                                    conditionExpression: type.value === 'Conditional' ? (cond.value.trim() || null) : null,
                                    isDefault: type.value === 'Conditional' && isDefault.checked, label: label.value.trim() || null, priority: Number(priority.value || 0)
                                });
                                S.graph.connections[S.graph.connections.indexOf(c)] = updated;
                                markChanged();
                                select({ type: 'edge', id: updated.connectionId });
                                WF.ui.toast('Connection saved.');
                            } catch (e) { WF.ui.showError(errors, e); }
                        });
                    }
                } }, icon('bi-save'), ' Save'),
                el('button', { class: 'btn btn-sm btn-outline-danger ms-auto', attrs: { type: 'button' }, on: { click: deleteSelected } }, icon('bi-trash'), ' Delete')));
        }
    }

    async function deleteSelected() {
        if (!S.editable || !S.selected) { return; }
        try {
            if (S.selected.type === 'node') {
                const a = byKey(S.selected.key);
                if (!a || !(await WF.ui.confirm('Delete activity', `Delete '${a.displayName}' and all its connections?`, 'Delete'))) { return; }
                await WF.api.deleteActivity(S.workflowId, a.activityId);
                S.graph.activities = S.graph.activities.filter(x => x !== a);
                S.graph.connections = S.graph.connections.filter(c => c.fromActivityKey !== a.activityKey && c.toActivityKey !== a.activityKey);
            } else {
                await WF.api.deleteConnection(S.workflowId, S.selected.id);
                S.graph.connections = S.graph.connections.filter(c => c.connectionId !== S.selected.id);
            }
            S.selected = null;
            markChanged();
            renderAll();
            setSaveState('Deleted', 'success');
        } catch (e) {
            WF.ui.showError(null, e);
        }
    }

    // ================================================================== validation, preview, layout, zoom
    function markChanged() {
        // Any change makes a previous validation result stale.
        if (Object.keys(S.issuesByKey).length) {
            S.issuesByKey = {};
            const bar = clear(qs('[data-role="issues-bar"]', S.root));
            bar.appendChild(el('span', { class: 'text-muted', text: 'The workflow changed - run validation again.' }));
        }
    }

    async function validate(button) {
        await WF.ui.busy(button, async () => {
            try {
                const report = await WF.api.validateWorkflow(S.workflowId);
                S.issuesByKey = {};
                report.issues.forEach(i => { const k = i.activityKey || '__workflow__'; (S.issuesByKey[k] = S.issuesByKey[k] || []).push(i); });
                S.detail = await WF.workflowContext.load(S.workflowId, S.versionNo);
                S.graph.version = S.detail.graph.version;
                renderAll();
                renderIssuesBar(report);
            } catch (e) { WF.ui.showError(null, e); }
        });
    }

    function renderIssuesBar(report) {
        const bar = clear(qs('[data-role="issues-bar"]', S.root));
        const summary = report.isValid
            ? el('span', { class: 'text-success fw-semibold' }, icon('bi-check-circle-fill'), ` Valid - ${report.warningCount} warning(s). `)
            : el('span', { class: 'text-danger fw-semibold' }, icon('bi-x-circle-fill'), ` ${report.errorCount} error(s), ${report.warningCount} warning(s). `);
        bar.appendChild(summary);
        bar.appendChild(el('a', { attrs: { href: `/Workflows/Validate/${S.workflowId}` }, text: 'Full report' }));
        const list = el('ul', { class: 'list-unstyled mb-0 mt-1 wf-issue-list' });
        report.issues.slice(0, 50).forEach(i => list.appendChild(el('li', {},
            el('span', { class: `badge me-1 ${i.severity === 'Error' ? 'text-bg-danger' : 'text-bg-warning'}`, text: i.severity }),
            i.activityKey ? el('a', { attrs: { href: '#', role: 'button' }, text: i.activityKey, on: { click: e => { e.preventDefault(); select({ type: 'node', key: i.activityKey }); scrollToNode(i.activityKey); } } }) : el('span', { text: 'workflow' }),
            `: ${i.message}`)));
        bar.appendChild(list);
    }

    function scrollToNode(key) {
        const a = byKey(key);
        if (!a) { return; }
        S.scroll.scrollTo({ left: Math.max(0, a.positionX * S.zoom - 200), top: Math.max(0, a.positionY * S.zoom - 150), behavior: 'smooth' });
    }

    async function previewJson() {
        try {
            const text = await WF.api.previewDefinition(S.workflowId);
            showJson('Definition preview (not published)', text);
        } catch (e) { WF.ui.showError(null, e); }
    }

    function showJson(title, text) {
        let pretty = text;
        try { pretty = JSON.stringify(JSON.parse(text), null, 2); } catch { /* keep raw */ }
        qs('[data-role="json-title"]', S.root).textContent = title;
        qs('[data-role="json"]', S.root).textContent = pretty;
        window.bootstrap.Modal.getOrCreateInstance(qs('#json-modal')).show();
    }

    async function autoLayout() {
        const start = S.graph.activities.find(a => a.activityType === 'Start');
        const outgoing = {};
        S.graph.connections.filter(c => c.connectionType !== 'Rejection' && c.connectionType !== 'Error')
            .forEach(c => (outgoing[c.fromActivityKey] = outgoing[c.fromActivityKey] || []).push(c.toActivityKey));
        const layer = {};
        if (start) {
            layer[start.activityKey] = 0;
            const queue = [start.activityKey];
            let guard = 0;
            while (queue.length && guard++ < 10000) {
                const k = queue.shift();
                (outgoing[k] || []).forEach(n => {
                    if (layer[n] === undefined || (layer[n] <= layer[k] && layer[n] < 50)) {
                        if (layer[n] === undefined) { queue.push(n); }
                        layer[n] = Math.max(layer[n] || 0, layer[k] + 1);
                    }
                });
            }
        }
        const maxLayer = Math.max(0, ...Object.values(layer));
        const rows = {};
        S.graph.activities.forEach(a => {
            const l = layer[a.activityKey] !== undefined ? layer[a.activityKey] : maxLayer + 1;
            rows[l] = rows[l] || 0;
            a.positionX = 40 + l * 240;
            a.positionY = 60 + rows[l] * 120;
            rows[l]++;
            S.movedKeys.add(a.activityKey);
        });
        renderAll();
        await saveLayout();
    }

    function setZoom(z) {
        S.zoom = Math.min(1.5, Math.max(0.4, Math.round(z * 10) / 10));
        S.canvas.style.transform = `scale(${S.zoom})`;
        qs('[data-role="zoom-label"]', S.root).textContent = `${Math.round(S.zoom * 100)}%`;
    }

    function renderAll() {
        renderNodes();
        renderEdges();
        renderProperties();
    }

    // ================================================================== init
    WF.pages.designer = {
        async init(root) {
            S.root = root;
            S.workflowId = Number(root.dataset.workflowId);
            S.versionNo = root.dataset.version ? Number(root.dataset.version) : null;
            S.canvas = qs('[data-role="canvas"]', root);
            S.nodesLayer = qs('[data-role="nodes"]', root);
            S.edgeLayer = qs('[data-role="edge-layer"]', root);
            S.dragEdge = qs('[data-role="drag-edge"]', root);
            S.scroll = qs('[data-role="scroll"]', root);

            const [detail, catalog, profiles, queries] = await Promise.all([
                WF.workflowContext.load(S.workflowId, S.versionNo), WF.catalog.load(), WF.api.connectionProfiles(), WF.api.approvedQueries()]);
            S.detail = detail;
            S.graph = detail.graph;
            S.catalog = catalog;
            S.profiles = profiles;
            S.queries = queries;
            S.editable = WF.workflowContext.isEditable(detail);
            S.canvas.classList.toggle('wf-readonly', !S.editable);
            WF.ui.setReadOnly(root, !S.editable);

            // Restore last validation report of this version (if any).
            if (detail.graph.version.validationResultJson) {
                try {
                    const stored = JSON.parse(detail.graph.version.validationResultJson);
                    const issues = stored.issues || stored.Issues || [];
                    issues.forEach(i => { const k = i.activityKey || '__workflow__'; (S.issuesByKey[k] = S.issuesByKey[k] || []).push(i); });
                } catch { /* ignore */ }
            }

            renderToolbox();
            renderAll();

            // Drop from toolbox
            S.scroll.addEventListener('dragover', evt => { if (S.editable) { evt.preventDefault(); evt.dataTransfer.dropEffect = 'copy'; S.canvas.classList.add('wf-drop-target'); } });
            S.scroll.addEventListener('dragleave', () => S.canvas.classList.remove('wf-drop-target'));
            S.scroll.addEventListener('drop', evt => {
                evt.preventDefault();
                S.canvas.classList.remove('wf-drop-target');
                const type = evt.dataTransfer.getData('application/x-wf-activity');
                if (S.editable && type && S.catalog.map[type]) { addActivity(type, canvasPoint(evt)); }
            });

            // Clicking empty canvas clears the selection
            S.scroll.addEventListener('pointerdown', evt => {
                if (evt.target.closest('.wf-node') || evt.target.closest('g[data-connection-id]')) { return; }
                select(null);
            });

            S.scroll.addEventListener('keydown', evt => {
                if ((evt.key === 'Delete' || evt.key === 'Backspace') && !['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) {
                    evt.preventDefault();
                    deleteSelected();
                }
            });

            qs('[data-role="connection-form"]', root).addEventListener('submit', submitConnection);
            qs('[data-action="zoom-in"]', root).addEventListener('click', () => setZoom(S.zoom + 0.1));
            qs('[data-action="zoom-out"]', root).addEventListener('click', () => setZoom(S.zoom - 0.1));
            qs('[data-action="zoom-reset"]', root).addEventListener('click', () => setZoom(1));
            qs('[data-action="auto-layout"]', root).addEventListener('click', autoLayout);
            qs('[data-action="delete-selected"]', root).addEventListener('click', deleteSelected);
            qs('[data-action="validate"]', root).addEventListener('click', evt => validate(evt.currentTarget));
            qs('[data-action="preview-json"]', root).addEventListener('click', previewJson);
            qs('[data-action="copy-json"]', root).addEventListener('click', async () => {
                try { await navigator.clipboard.writeText(qs('[data-role="json"]', root).textContent); WF.ui.toast('Copied.'); } catch { WF.ui.toast('Copy failed.', 'warning'); }
            });

            const validateBtn = qs('[data-action="validate"]', root);
            validateBtn.classList.toggle('d-none', !WF.session.hasAnyRole(['WF_DESIGNER', 'WF_REVIEWER', 'WF_PUBLISHER']));

            setSaveState(S.editable ? 'All changes are saved automatically.' : 'Read-only');
            window.addEventListener('beforeunload', () => { if (S.movedKeys.size) { saveLayout(); } });
        }
    };
})(window.WF, window, document);
