using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;

namespace BankWorkflowDesigner.Web.Controllers;

/// <summary>
/// Page controllers only render view shells. No business logic and no data access here -
/// the JavaScript in wwwroot/js calls BankWorkflowDesigner.Api for everything.
/// </summary>
public sealed class HomeController : Controller
{
    public IActionResult Index() => View();

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error() => View(model: Activity.Current?.Id ?? HttpContext.TraceIdentifier);
}

public sealed class SourceSystemsController : Controller
{
    public IActionResult Index() => View();
}

public sealed class WorkflowsController : Controller
{
    public IActionResult Index() => View();

    public IActionResult Create() => View();

    public IActionResult Edit(int id) => View(id);

    public IActionResult Designer(int id, int? version)
    {
        ViewData["Version"] = version;
        return View(id);
    }

    public IActionResult Activity(int id, int activityId)
    {
        ViewData["ActivityId"] = activityId;
        return View(id);
    }

    public IActionResult Parameters(int id) => View(id);

    public IActionResult Approval(int id, int? activityId)
    {
        ViewData["ActivityId"] = activityId;
        return View(id);
    }

    public IActionResult Validate(int id) => View(id);

    public IActionResult History(int id) => View(id);

    public IActionResult Publish(int id) => View(id);
}

public sealed class SchedulersController : Controller
{
    public IActionResult Index() => View();

    public IActionResult Edit(int? id) => View(id);
}
