using Microsoft.Extensions.Options;

namespace BankWorkflowDesigner.Web;

public sealed class FrontEndOptions
{
    public const string SectionName = "FrontEnd";

    /// <summary>Base URL of BankWorkflowDesigner.Api, e.g. https://wf-designer-api.bank.local</summary>
    public string ApiBaseUrl { get; set; } = "https://localhost:7101";

    /// <summary>Windows (IIS integrated) or Development (no page-level authentication; the API authenticates).</summary>
    public string AuthenticationMode { get; set; } = "Windows";

    /// <summary>Environment banner text (e.g. DEV / UAT). Empty = hidden.</summary>
    public string EnvironmentBanner { get; set; } = string.Empty;
}

/// <summary>
/// Strict security headers. The CSP forbids inline script and inline style, so the views contain no inline
/// JavaScript and all dynamic content is inserted with textContent (see wwwroot/js/site.js) - an XSS defence in depth.
/// </summary>
public sealed class SecurityHeadersMiddleware
{
    private readonly RequestDelegate _next;
    private readonly string _csp;

    public SecurityHeadersMiddleware(RequestDelegate next, IOptions<FrontEndOptions> options)
    {
        _next = next;
        var api = options.Value.ApiBaseUrl.TrimEnd('/');
        _csp = string.Join("; ",
            "default-src 'self'",
            $"connect-src 'self' {api}",
            "script-src 'self'",
            "style-src 'self'",
            "img-src 'self' data:",
            "font-src 'self'",
            "object-src 'none'",
            "base-uri 'self'",
            "form-action 'self'",
            "frame-ancestors 'none'");
    }

    public async Task InvokeAsync(HttpContext context)
    {
        context.Response.OnStarting(() =>
        {
            var headers = context.Response.Headers;
            headers["Content-Security-Policy"] = _csp;
            headers["X-Content-Type-Options"] = "nosniff";
            headers["X-Frame-Options"] = "DENY";
            headers["Referrer-Policy"] = "same-origin";
            headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()";
            return Task.CompletedTask;
        });

        await _next(context);
    }
}
