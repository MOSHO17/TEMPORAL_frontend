using BankWorkflowDesigner.Domain.Dtos;
using BankWorkflowDesigner.Domain.Entities;
using BankWorkflowDesigner.Domain.Enums;

namespace BankWorkflowDesigner.Application.Abstractions;

/// <summary>Identity of the caller, resolved from AD / IAM by the API host.</summary>
public interface ICurrentUser
{
    string UserName { get; }
    bool IsAuthenticated { get; }
    IReadOnlyCollection<string> Roles { get; }
    bool IsInRole(string role);
    string? CorrelationId { get; }
    string? ClientIp { get; }
}

public interface IClock
{
    DateTime UtcNow { get; }
}

public sealed class SystemClock : IClock
{
    public DateTime UtcNow => DateTime.UtcNow;
}

/// <summary>Context passed to repositories so every mutating stored procedure can write the audit trail in the same transaction.</summary>
public sealed record AuditContext(string UserName, string? CorrelationId, string? ClientIp);

// --------------------------------------------------------------------- Repositories

public interface ISourceSystemRepository
{
    Task<IReadOnlyList<SourceSystem>> GetAllAsync(CancellationToken ct);
    Task<SourceSystem?> GetByIdAsync(int sourceSystemId, CancellationToken ct);
    Task<SourceSystem?> GetByCodeAsync(string systemCode, CancellationToken ct);
    Task<int> CreateAsync(SourceSystem sourceSystem, AuditContext audit, CancellationToken ct);
    Task UpdateAsync(SourceSystem sourceSystem, AuditContext audit, CancellationToken ct);

    /// <summary>Active access roles the principal holds on the source system (empty when not authorised).</summary>
    Task<IReadOnlyList<SourceSystemAccessRole>> GetUserAccessRolesAsync(int sourceSystemId, string userPrincipal, CancellationToken ct);

    /// <summary>Ids of all active source systems the principal is authorised for.</summary>
    Task<IReadOnlyList<int>> GetAuthorizedSourceSystemIdsAsync(string userPrincipal, CancellationToken ct);
}

public interface IWorkflowRepository
{
    Task<PagedResult<WorkflowTemplate>> SearchAsync(WorkflowQuery query, IReadOnlyCollection<int>? allowedSourceSystemIds, CancellationToken ct);
    Task<WorkflowTemplate?> GetTemplateAsync(int workflowTemplateId, CancellationToken ct);
    Task<WorkflowTemplate?> GetTemplateByCodeAsync(string templateCode, CancellationToken ct);
    Task<IReadOnlyList<WorkflowVersion>> GetVersionsAsync(int workflowTemplateId, CancellationToken ct);

    /// <summary>Loads the full graph of a version. Null versionNo = latest version.</summary>
    Task<WorkflowGraph?> GetGraphAsync(int workflowTemplateId, int? versionNo, CancellationToken ct);

    /// <summary>Creates template + version 1 (Draft) with the supplied initial graph, in one transaction.</summary>
    Task<int> CreateAsync(WorkflowTemplate template, string? changeNotes, WorkflowGraph initialGraph, AuditContext audit, CancellationToken ct);

    Task UpdateHeaderAsync(int workflowTemplateId, string workflowName, string? description, string? changeNotes, string rowVersion, AuditContext audit, CancellationToken ct);

    /// <summary>Creates a new Draft version as a deep copy of <paramref name="basedOnVersionNo"/>. Returns the new version number.</summary>
    Task<int> CreateVersionAsync(int workflowTemplateId, int basedOnVersionNo, string? changeNotes, AuditContext audit, CancellationToken ct);

    /// <summary>Deep-copies a version into a brand new template (version 1, Draft). Returns the new template id.</summary>
    Task<int> CloneAsync(int workflowTemplateId, int fromVersionNo, string newTemplateCode, string workflowName, int sourceSystemId, int moduleId, AuditContext audit, CancellationToken ct);

    Task SaveValidationAsync(int workflowVersionId, bool isValid, string reportJson, AuditContext audit, CancellationToken ct);

    Task<PublishResult> PublishAsync(int workflowVersionId, string expectedVersionRowVersion, string definitionJson, string definitionHash, string? comments, AuditContext audit, CancellationToken ct);

    Task SetTemplateStatusAsync(int workflowTemplateId, TemplateStatus status, string reason, AuditContext audit, CancellationToken ct);

    /// <summary>Returns the stored (immutable) definition JSON of a published version. Null versionNo = current published version.</summary>
    Task<string?> GetPublishedDefinitionAsync(int workflowTemplateId, int? versionNo, CancellationToken ct);

    Task<DashboardSummary> GetDashboardAsync(IReadOnlyCollection<int>? allowedSourceSystemIds, CancellationToken ct);
}

public interface IActivityRepository
{
    Task<WorkflowActivity> AddAsync(int workflowVersionId, WorkflowActivity activity, AuditContext audit, CancellationToken ct);
    Task<WorkflowActivity> UpdateAsync(int workflowVersionId, WorkflowActivity activity, bool replaceParameters, AuditContext audit, CancellationToken ct);
    Task DeleteAsync(int workflowVersionId, int activityId, AuditContext audit, CancellationToken ct);
    Task UpdateLayoutAsync(int workflowVersionId, IReadOnlyList<ActivityPositionRequest> positions, AuditContext audit, CancellationToken ct);
    Task SaveApprovalAsync(int workflowVersionId, int activityId, ApprovalConfiguration configuration, AuditContext audit, CancellationToken ct);

    Task<ActivityConnection> AddConnectionAsync(int workflowVersionId, ActivityConnection connection, AuditContext audit, CancellationToken ct);
    Task<ActivityConnection> UpdateConnectionAsync(int workflowVersionId, ActivityConnection connection, AuditContext audit, CancellationToken ct);
    Task DeleteConnectionAsync(int workflowVersionId, int connectionId, AuditContext audit, CancellationToken ct);
}

public interface IParameterRepository
{
    Task<WorkflowParameter> AddAsync(int workflowVersionId, WorkflowParameter parameter, AuditContext audit, CancellationToken ct);
    Task<WorkflowParameter> UpdateAsync(int workflowVersionId, WorkflowParameter parameter, AuditContext audit, CancellationToken ct);
    Task DeleteAsync(int workflowVersionId, int parameterId, AuditContext audit, CancellationToken ct);
}

public interface ISchedulerRepository
{
    Task<IReadOnlyList<SchedulerConfiguration>> GetAllAsync(IReadOnlyCollection<int>? allowedSourceSystemIds, CancellationToken ct);
    Task<SchedulerConfiguration?> GetByIdAsync(int schedulerConfigId, CancellationToken ct);
    Task<int> CreateAsync(SchedulerConfiguration configuration, AuditContext audit, CancellationToken ct);
    Task UpdateAsync(SchedulerConfiguration configuration, AuditContext audit, CancellationToken ct);
}

public interface IReferenceDataRepository
{
    Task<IReadOnlyList<ConnectionProfile>> GetConnectionProfilesAsync(CancellationToken ct);
    Task<IReadOnlyList<ApprovedOracleQuery>> GetApprovedQueriesAsync(CancellationToken ct);
}

public interface IAuditRepository
{
    Task<IReadOnlyList<AuditLogEntry>> GetAsync(string? entityType, string? entityId, int maxRows, CancellationToken ct);
}
