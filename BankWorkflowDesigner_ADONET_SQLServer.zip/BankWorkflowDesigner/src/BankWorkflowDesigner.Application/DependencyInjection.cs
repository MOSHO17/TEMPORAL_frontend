using BankWorkflowDesigner.Application.Abstractions;
using BankWorkflowDesigner.Application.Definitions;
using BankWorkflowDesigner.Application.Services;
using BankWorkflowDesigner.Application.Validation;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace BankWorkflowDesigner.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddApplicationServices(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<WorkflowSecurityOptions>(configuration.GetSection(WorkflowSecurityOptions.SectionName));

        services.AddSingleton<IClock, SystemClock>();
        services.AddSingleton<IWorkflowValidator, WorkflowValidator>();
        services.AddSingleton<IWorkflowDefinitionBuilder, WorkflowDefinitionBuilder>();

        services.AddScoped<IAccessGuard, AccessGuard>();
        services.AddScoped<ISourceSystemService, SourceSystemService>();
        services.AddScoped<IWorkflowService, WorkflowService>();
        services.AddScoped<IActivityService, ActivityService>();
        services.AddScoped<IParameterService, ParameterService>();
        services.AddScoped<ISchedulerService, SchedulerService>();
        services.AddScoped<IReferenceDataService, ReferenceDataService>();
        return services;
    }
}
