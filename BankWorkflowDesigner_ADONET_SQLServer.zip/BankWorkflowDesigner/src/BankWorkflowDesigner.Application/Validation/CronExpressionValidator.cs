using System.Text.RegularExpressions;
using BankWorkflowDesigner.Domain.Dtos;

namespace BankWorkflowDesigner.Application.Validation;

/// <summary>
/// Structural validator for Quartz.NET cron expressions:
/// <c>Seconds Minutes Hours Day-of-month Month Day-of-week [Year]</c>.
/// Only validates - the scheduler itself (Quartz.NET) is out of scope of this portal.
/// </summary>
public static class CronExpressionValidator
{
    private static readonly string[] MonthNames = { "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC" };
    private static readonly string[] DayNames = { "SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT" };
    private static readonly Regex AllowedChars = new("^[0-9A-Za-z*?/,\\-#LW ]+$", RegexOptions.Compiled);

    private sealed record FieldSpec(string Name, int Min, int Max, string[]? Names, bool AllowQuestion, bool AllowL, bool AllowW, bool AllowHash);

    private static readonly FieldSpec[] Fields =
    {
        new("seconds", 0, 59, null, false, false, false, false),
        new("minutes", 0, 59, null, false, false, false, false),
        new("hours", 0, 23, null, false, false, false, false),
        new("day-of-month", 1, 31, null, true, true, true, false),
        new("month", 1, 12, MonthNames, false, false, false, false),
        new("day-of-week", 1, 7, DayNames, true, true, false, true),
        new("year", 1970, 2199, null, false, false, false, false)
    };

    public static CronValidationResult Validate(string? expression)
    {
        if (string.IsNullOrWhiteSpace(expression))
        {
            return Fail("Cron expression is required.");
        }

        var trimmed = expression.Trim();
        if (!AllowedChars.IsMatch(trimmed))
        {
            return Fail("Cron expression contains invalid characters.");
        }

        var parts = trimmed.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length is < 6 or > 7)
        {
            return Fail("Quartz cron expressions need 6 or 7 fields: sec min hour day-of-month month day-of-week [year].");
        }

        for (var i = 0; i < parts.Length; i++)
        {
            var error = ValidateField(parts[i].ToUpperInvariant(), Fields[i]);
            if (error is not null)
            {
                return Fail($"Invalid {Fields[i].Name} field '{parts[i]}': {error}");
            }
        }

        var dom = parts[3];
        var dow = parts[5];
        if ((dom == "?") == (dow == "?"))
        {
            return Fail("Exactly one of day-of-month or day-of-week must be '?'.");
        }

        // Guard against schedules that would hammer the source database.
        if (parts[0].Contains('*') || parts[0].Contains('/') || parts[1] == "*")
        {
            return Fail("Schedules more frequent than once a minute are not permitted for Oracle query tasks.");
        }

        return new CronValidationResult { IsValid = true, Description = Describe(parts) };
    }

    private static string? ValidateField(string value, FieldSpec spec)
    {
        if (value == "?")
        {
            return spec.AllowQuestion ? null : "'?' is not allowed here.";
        }

        foreach (var item in value.Split(','))
        {
            if (item.Length == 0)
            {
                return "empty list element.";
            }

            var error = ValidateItem(item, spec);
            if (error is not null)
            {
                return error;
            }
        }

        return null;
    }

    private static string? ValidateItem(string item, FieldSpec spec)
    {
        if (spec.AllowL && item is "L" or "LW" && (item != "LW" || spec.AllowW))
        {
            return null;
        }

        if (spec.AllowL && item.EndsWith('L') && item.Length > 1)
        {
            // e.g. 6L (last Friday) or L-3 handled below
            return ParseValue(item[..^1], spec, out _);
        }

        if (spec.AllowL && item.StartsWith("L-", StringComparison.Ordinal))
        {
            return int.TryParse(item[2..], out var offset) && offset is >= 1 and <= 30 ? null : "invalid L-offset.";
        }

        if (spec.AllowW && item.EndsWith('W') && item.Length > 1)
        {
            return ParseValue(item[..^1], spec, out _);
        }

        if (spec.AllowHash && item.Contains('#'))
        {
            var hashParts = item.Split('#');
            if (hashParts.Length != 2)
            {
                return "invalid '#' usage.";
            }

            var error = ParseValue(hashParts[0], spec, out _);
            if (error is not null)
            {
                return error;
            }

            return int.TryParse(hashParts[1], out var nth) && nth is >= 1 and <= 5 ? null : "nth day must be 1-5.";
        }

        var stepParts = item.Split('/');
        if (stepParts.Length > 2)
        {
            return "invalid step.";
        }

        if (stepParts.Length == 2)
        {
            if (!int.TryParse(stepParts[1], out var step) || step < 1 || step > spec.Max)
            {
                return "invalid step value.";
            }
        }

        var range = stepParts[0];
        if (range == "*")
        {
            return null;
        }

        var rangeParts = range.Split('-');
        if (rangeParts.Length > 2)
        {
            return "invalid range.";
        }

        var firstError = ParseValue(rangeParts[0], spec, out var from);
        if (firstError is not null)
        {
            return firstError;
        }

        if (rangeParts.Length == 2)
        {
            var secondError = ParseValue(rangeParts[1], spec, out var to);
            if (secondError is not null)
            {
                return secondError;
            }

            if (to < from && spec.Names is null)
            {
                return "range end is before start.";
            }
        }

        return null;
    }

    private static string? ParseValue(string text, FieldSpec spec, out int value)
    {
        value = 0;
        if (spec.Names is not null)
        {
            var index = Array.IndexOf(spec.Names, text);
            if (index >= 0)
            {
                value = index + 1;
                return null;
            }
        }

        if (!int.TryParse(text, out value))
        {
            return $"'{text}' is not a number.";
        }

        return value < spec.Min || value > spec.Max ? $"{value} is outside {spec.Min}-{spec.Max}." : null;
    }

    private static string Describe(string[] parts)
    {
        var time = parts[2].All(char.IsDigit) && parts[1].All(char.IsDigit)
            ? $"at {int.Parse(parts[2]):00}:{int.Parse(parts[1]):00}"
            : $"minutes '{parts[1]}', hours '{parts[2]}'";
        var days = parts[3] == "?"
            ? parts[5] == "*" ? "every day" : $"on day-of-week '{parts[5]}'"
            : parts[3] == "*" ? "every day" : $"on day-of-month '{parts[3]}'";
        var months = parts[4] == "*" ? "every month" : $"in month '{parts[4]}'";
        return $"Runs {time}, {days}, {months}.";
    }

    private static CronValidationResult Fail(string error) => new() { IsValid = false, Error = error };
}
