using System.Text.RegularExpressions;

namespace BankWorkflowDesigner.Application.Validation;

/// <summary>
/// Detects secrets and free-form SQL in configuration values.
/// Workflow definitions must only carry references (connection profiles, approved query codes) - never
/// passwords, keys, tokens or executable SQL.
/// </summary>
public static class ContentSafetyScanner
{
    private static readonly Regex SensitiveNameRegex = new(
        "(password|passwd|pwd|secret|apikey|api_key|accesskey|access_key|privatekey|private_key|token|credential|connectionstring|conn_str|clientsecret|client_secret)",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex[] SecretValuePatterns =
    {
        new("(password|pwd|passwd)\\s*[=:]", RegexOptions.IgnoreCase | RegexOptions.Compiled),
        new("(client_secret|clientsecret|api[_-]?key|access[_-]?key|secret[_-]?key)\\s*[=:]", RegexOptions.IgnoreCase | RegexOptions.Compiled),
        new("-----BEGIN [A-Z ]*PRIVATE KEY-----", RegexOptions.Compiled),
        new("\\bAKIA[0-9A-Z]{16}\\b", RegexOptions.Compiled),
        new("\\beyJ[A-Za-z0-9_\\-]{10,}\\.eyJ[A-Za-z0-9_\\-]{10,}\\.[A-Za-z0-9_\\-]{10,}", RegexOptions.Compiled),
        new("\\bBearer\\s+[A-Za-z0-9_\\-\\.=]{20,}", RegexOptions.IgnoreCase | RegexOptions.Compiled),
        new("\\b(sftp|ftp|https?|jdbc:[a-z]+)://[^/\\s:@]+:[^/\\s@]+@", RegexOptions.IgnoreCase | RegexOptions.Compiled)
    };

    private static readonly Regex[] SqlPatterns =
    {
        new("\\bselect\\b[\\s\\S]+\\bfrom\\b", RegexOptions.IgnoreCase | RegexOptions.Compiled),
        new("\\b(insert\\s+into|delete\\s+from|merge\\s+into|truncate\\s+table)\\b", RegexOptions.IgnoreCase | RegexOptions.Compiled),
        new("\\bupdate\\b\\s+[\\w\\.\\[\\]\"]+\\s+\\bset\\b", RegexOptions.IgnoreCase | RegexOptions.Compiled),
        new("\\b(drop|alter|create)\\s+(table|view|procedure|function|package|trigger|user|index|sequence)\\b", RegexOptions.IgnoreCase | RegexOptions.Compiled),
        new("\\b(exec|execute)\\s+(immediate\\b|sp_|xp_|[\\w\\.]+\\s*\\()", RegexOptions.IgnoreCase | RegexOptions.Compiled),
        new("\\bgrant\\s+\\w+\\s+on\\b", RegexOptions.IgnoreCase | RegexOptions.Compiled),
        new("\\bbegin\\b[\\s\\S]*\\bend\\s*;", RegexOptions.IgnoreCase | RegexOptions.Compiled)
    };

    public static bool IsSensitiveName(string? name) => !string.IsNullOrEmpty(name) && SensitiveNameRegex.IsMatch(name);

    public static bool ContainsSecret(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return false;
        }

        return SecretValuePatterns.Any(p => p.IsMatch(value));
    }

    public static bool ContainsSql(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return false;
        }

        return SqlPatterns.Any(p => p.IsMatch(value));
    }

    /// <summary>Returns a description of the problem, or null when the value is safe.</summary>
    public static string? Inspect(string? name, string? value)
    {
        if (ContainsSecret(value))
        {
            return "Value appears to contain a password, key or token. Store secrets in the vault and reference them through a connection profile.";
        }

        if (ContainsSql(value))
        {
            return "Free-form SQL is not permitted in workflow configuration. Reference a governed approved query instead.";
        }

        if (IsSensitiveName(name) && !string.IsNullOrWhiteSpace(value))
        {
            return $"'{name}' looks like a secret. Secret values must not be stored in workflow definitions - use a connection profile reference.";
        }

        return null;
    }
}
