using System.Globalization;
using System.Text.RegularExpressions;
using BankWorkflowDesigner.Domain.Catalog;
using BankWorkflowDesigner.Domain.Dtos;
using BankWorkflowDesigner.Domain.Entities;
using BankWorkflowDesigner.Domain.Enums;

namespace BankWorkflowDesigner.Application.Validation;

/// <summary>Reference data needed to validate a workflow.</summary>
public sealed class WorkflowValidationContext
{
    public IReadOnlyList<ConnectionProfile> ConnectionProfiles { get; init; } = Array.Empty<ConnectionProfile>();
    public IReadOnlyList<ApprovedOracleQuery> ApprovedQueries { get; init; } = Array.Empty<ApprovedOracleQuery>();
}

public interface IWorkflowValidator
{
    List<ValidationIssue> Validate(WorkflowGraph graph, WorkflowValidationContext context);
}

/// <summary>
/// Structural and semantic validation of a workflow graph. Pure (no I/O) so it is fully unit-testable.
/// Every publish re-runs this validator - a stale validation result is never trusted.
/// </summary>
public sealed class WorkflowValidator : IWorkflowValidator
{
    private static readonly Regex KeyRegex = new("^[a-zA-Z][a-zA-Z0-9_]{0,99}$", RegexOptions.Compiled);

    public List<ValidationIssue> Validate(WorkflowGraph graph, WorkflowValidationContext context)
    {
        var issues = new List<ValidationIssue>();
        var activities = graph.Activities;
        var byKey = new Dictionary<string, WorkflowActivity>(StringComparer.Ordinal);

        // ------------------------------------------------------------ keys
        foreach (var activity in activities)
        {
            if (!KeyRegex.IsMatch(activity.ActivityKey))
            {
                issues.Add(ValidationIssue.Error("ACTIVITY_KEY_INVALID", $"Activity key '{activity.ActivityKey}' is invalid.", activity.ActivityKey));
            }

            if (!byKey.TryAdd(activity.ActivityKey, activity))
            {
                issues.Add(ValidationIssue.Error("ACTIVITY_KEY_DUPLICATE", $"Activity key '{activity.ActivityKey}' is used more than once.", activity.ActivityKey));
            }
        }

        var starts = activities.Where(a => a.ActivityType == ActivityType.Start).ToList();
        var ends = activities.Where(a => a.ActivityType == ActivityType.End).ToList();

        if (starts.Count != 1)
        {
            issues.Add(ValidationIssue.Error("START_COUNT", $"A workflow must have exactly one Start node (found {starts.Count})."));
        }

        if (ends.Count == 0)
        {
            issues.Add(ValidationIssue.Error("END_MISSING", "A workflow must have at least one End / Terminate node."));
        }

        if (!activities.Any(a => !ActivityCatalog.Get(a.ActivityType).IsControlNode))
        {
            issues.Add(ValidationIssue.Error("NO_BUSINESS_ACTIVITY", "The workflow has no business activities."));
        }

        // ------------------------------------------------------------ connections
        var validConnections = new List<ActivityConnection>();
        var seenEdges = new HashSet<(string, string, ConnectionType)>();
        foreach (var c in graph.Connections)
        {
            var ok = true;
            if (!byKey.ContainsKey(c.FromActivityKey))
            {
                issues.Add(ValidationIssue.Error("CONNECTION_SOURCE_MISSING", $"Connection source '{c.FromActivityKey}' does not exist."));
                ok = false;
            }

            if (!byKey.ContainsKey(c.ToActivityKey))
            {
                issues.Add(ValidationIssue.Error("CONNECTION_TARGET_MISSING", $"Connection target '{c.ToActivityKey}' does not exist."));
                ok = false;
            }

            if (c.FromActivityKey == c.ToActivityKey)
            {
                issues.Add(ValidationIssue.Error("CONNECTION_SELF", $"Activity '{c.FromActivityKey}' cannot connect to itself.", c.FromActivityKey));
                ok = false;
            }

            if (!seenEdges.Add((c.FromActivityKey, c.ToActivityKey, c.ConnectionType)))
            {
                issues.Add(ValidationIssue.Error("CONNECTION_DUPLICATE", $"Duplicate {c.ConnectionType} connection {c.FromActivityKey} -> {c.ToActivityKey}.", c.FromActivityKey));
            }

            if (c.ConnectionType == ConnectionType.Conditional && !c.IsDefault)
            {
                var parsed = ExpressionValidator.Validate(c.ConditionExpression);
                foreach (var e in parsed.Errors)
                {
                    issues.Add(ValidationIssue.Error("CONDITION_INVALID", $"Condition on {c.FromActivityKey} -> {c.ToActivityKey}: {e}", c.FromActivityKey, "conditionExpression"));
                }
            }
            else if (!string.IsNullOrWhiteSpace(c.ConditionExpression) && c.ConnectionType != ConnectionType.Conditional)
            {
                issues.Add(ValidationIssue.Warning("CONDITION_IGNORED", $"Condition on {c.ConnectionType} connection {c.FromActivityKey} -> {c.ToActivityKey} is ignored.", c.FromActivityKey));
            }

            if (ok)
            {
                validConnections.Add(c);
            }
        }

        var outgoing = validConnections.ToLookup(c => c.FromActivityKey);
        var incoming = validConnections.ToLookup(c => c.ToActivityKey);

        foreach (var activity in activities)
        {
            ValidateFlowRules(activity, outgoing[activity.ActivityKey].ToList(), incoming[activity.ActivityKey].ToList(), byKey, issues);
        }

        // ------------------------------------------------------------ reachability, termination and loops
        if (starts.Count == 1)
        {
            var reachable = Traverse(starts[0].ActivityKey, key => outgoing[key].Select(c => c.ToActivityKey)
                .Concat(ErrorRoute(byKey, key)));
            foreach (var activity in activities.Where(a => !reachable.Contains(a.ActivityKey)))
            {
                issues.Add(ValidationIssue.Error("UNREACHABLE", $"Activity '{activity.DisplayName}' ({activity.ActivityKey}) is not reachable from Start.", activity.ActivityKey));
            }
        }

        if (ends.Count > 0)
        {
            var canTerminate = new HashSet<string>(StringComparer.Ordinal);
            foreach (var end in ends)
            {
                canTerminate.UnionWith(Traverse(end.ActivityKey, key => incoming[key].Select(c => c.FromActivityKey)));
            }

            foreach (var activity in activities.Where(a => !canTerminate.Contains(a.ActivityKey) && a.ActivityType != ActivityType.End))
            {
                issues.Add(ValidationIssue.Error("NO_PATH_TO_END", $"Activity '{activity.DisplayName}' ({activity.ActivityKey}) has no path to an End node.", activity.ActivityKey));
            }
        }

        DetectIllegalLoops(activities, validConnections, issues);
        ValidateParallelBlocks(activities, outgoing, issues);

        // ------------------------------------------------------------ parameters & configuration
        var ancestors = BuildAncestorMap(activities, validConnections);
        var workflowInputs = ValidateWorkflowParameters(graph, byKey, context, issues);

        foreach (var activity in activities)
        {
            var descriptor = ActivityCatalog.Get(activity.ActivityType);
            ValidatePolicies(activity, descriptor, byKey, issues);
            ValidateConfig(activity, descriptor, context, issues);
            ValidateActivityParameters(activity, byKey, ancestors, workflowInputs, context, issues);
            ValidateExpressionReferences(activity, byKey, ancestors, workflowInputs, issues);

            if (descriptor.IsApproval)
            {
                ValidateApproval(activity, descriptor, byKey, ancestors, outgoing[activity.ActivityKey].ToList(), issues);
            }
            else if (activity.Approval is not null)
            {
                issues.Add(ValidationIssue.Warning("APPROVAL_IGNORED", "Approval configuration is ignored for non-approval activities.", activity.ActivityKey));
            }
        }

        foreach (var c in validConnections.Where(c => c.ConnectionType == ConnectionType.Conditional && !string.IsNullOrWhiteSpace(c.ConditionExpression)))
        {
            var parsed = ExpressionValidator.Validate(c.ConditionExpression);
            foreach (var reference in parsed.References)
            {
                CheckReference(reference, c.FromActivityKey, includeSelf: true, byKey, ancestors, workflowInputs, issues, "conditionExpression");
            }
        }

        return issues;
    }

    // ================================================================ flow rules

    private static IEnumerable<string> ErrorRoute(Dictionary<string, WorkflowActivity> byKey, string key)
    {
        if (byKey.TryGetValue(key, out var a) && a.ErrorHandling == ErrorHandlingStrategy.RouteToActivity && !string.IsNullOrEmpty(a.ErrorRouteActivityKey))
        {
            yield return a.ErrorRouteActivityKey!;
        }

        if (byKey.TryGetValue(key, out var b) && b.ActivityType is not ActivityType.End && IsApprovalWithRejectionTarget(b, out var target))
        {
            yield return target!;
        }
    }

    private static bool IsApprovalWithRejectionTarget(WorkflowActivity activity, out string? target)
    {
        target = null;
        if (ActivityCatalog.IsApproval(activity.ActivityType) &&
            activity.Approval is { RejectionRouting: RejectionRouting.ToActivity } approval &&
            !string.IsNullOrEmpty(approval.RejectionTargetActivityKey))
        {
            target = approval.RejectionTargetActivityKey;
            return true;
        }

        return false;
    }

    private static void ValidateFlowRules(
        WorkflowActivity activity,
        List<ActivityConnection> outs,
        List<ActivityConnection> ins,
        Dictionary<string, WorkflowActivity> byKey,
        List<ValidationIssue> issues)
    {
        var key = activity.ActivityKey;
        var isApproval = ActivityCatalog.IsApproval(activity.ActivityType);
        var normal = outs.Where(c => c.ConnectionType is ConnectionType.Sequence or ConnectionType.Conditional or ConnectionType.Parallel).ToList();

        foreach (var c in outs.Where(c => c.ConnectionType == ConnectionType.Rejection && !isApproval))
        {
            issues.Add(ValidationIssue.Error("REJECTION_SOURCE", $"Rejection connection from '{key}' is only allowed on approval activities.", key));
        }

        foreach (var c in outs.Where(c => c.ConnectionType == ConnectionType.Parallel && activity.ActivityType != ActivityType.ParallelSplit))
        {
            issues.Add(ValidationIssue.Error("PARALLEL_SOURCE", $"Parallel connection from '{key}' must start at a Parallel Split.", key));
        }

        var errorEdges = outs.Where(c => c.ConnectionType == ConnectionType.Error).ToList();
        if (errorEdges.Count > 1)
        {
            issues.Add(ValidationIssue.Error("ERROR_ROUTE_MULTIPLE", $"'{key}' has more than one Error connection.", key));
        }

        if (errorEdges.Count == 1)
        {
            if (activity.ErrorHandling != ErrorHandlingStrategy.RouteToActivity)
            {
                issues.Add(ValidationIssue.Error("ERROR_ROUTE_STRATEGY", $"'{key}' has an Error connection but its error handling is {activity.ErrorHandling}. Set it to RouteToActivity.", key, "errorHandling"));
            }
            else if (!string.IsNullOrEmpty(activity.ErrorRouteActivityKey) && activity.ErrorRouteActivityKey != errorEdges[0].ToActivityKey)
            {
                issues.Add(ValidationIssue.Error("ERROR_ROUTE_MISMATCH", $"'{key}' error route '{activity.ErrorRouteActivityKey}' differs from its Error connection target '{errorEdges[0].ToActivityKey}'.", key));
            }
        }

        switch (activity.ActivityType)
        {
            case ActivityType.Start:
                if (ins.Count > 0)
                {
                    issues.Add(ValidationIssue.Error("START_INCOMING", "Start node cannot have incoming connections.", key));
                }

                if (outs.Count != 1 || outs[0].ConnectionType != ConnectionType.Sequence)
                {
                    issues.Add(ValidationIssue.Error("START_OUTGOING", "Start node must have exactly one outgoing Sequence connection.", key));
                }

                return;

            case ActivityType.End:
                if (outs.Count > 0)
                {
                    issues.Add(ValidationIssue.Error("END_OUTGOING", "End node cannot have outgoing connections.", key));
                }

                if (ins.Count == 0)
                {
                    issues.Add(ValidationIssue.Error("END_INCOMING", "End node has no incoming connection.", key));
                }

                return;

            case ActivityType.Decision:
                if (normal.Count < 2)
                {
                    issues.Add(ValidationIssue.Error("DECISION_BRANCHES", "Decision needs at least two outgoing Conditional connections.", key));
                }

                if (normal.Any(c => c.ConnectionType != ConnectionType.Conditional))
                {
                    issues.Add(ValidationIssue.Error("DECISION_TYPE", "All outgoing connections of a Decision must be Conditional.", key));
                }

                ValidateConditionalSet(key, normal.Where(c => c.ConnectionType == ConnectionType.Conditional).ToList(), issues, requireDefaultWarning: true);
                return;

            case ActivityType.ParallelSplit:
                if (normal.Count < 2 || normal.Any(c => c.ConnectionType != ConnectionType.Parallel))
                {
                    issues.Add(ValidationIssue.Error("SPLIT_BRANCHES", "Parallel Split needs at least two outgoing Parallel connections (and no other types).", key));
                }

                return;

            case ActivityType.ParallelJoin:
                if (ins.Count(c => c.ConnectionType != ConnectionType.Rejection) < 2)
                {
                    issues.Add(ValidationIssue.Error("JOIN_INCOMING", "Parallel Join needs at least two incoming branches.", key));
                }

                if (normal.Count != 1 || normal[0].ConnectionType != ConnectionType.Sequence)
                {
                    issues.Add(ValidationIssue.Error("JOIN_OUTGOING", "Parallel Join must have exactly one outgoing Sequence connection.", key));
                }

                return;
        }

        // Business activities
        if (normal.Count == 0 && activity.ErrorHandling != ErrorHandlingStrategy.Terminate)
        {
            issues.Add(ValidationIssue.Error("DEAD_END", $"Activity '{activity.DisplayName}' has no outgoing connection.", key));
            return;
        }

        var sequences = normal.Count(c => c.ConnectionType == ConnectionType.Sequence);
        var conditionals = normal.Where(c => c.ConnectionType == ConnectionType.Conditional).ToList();
        if (sequences > 1)
        {
            issues.Add(ValidationIssue.Error("AMBIGUOUS_SEQUENCE", $"'{key}' has {sequences} Sequence connections. Use a Decision, Conditional connections or a Parallel Split.", key));
        }

        if (sequences > 0 && conditionals.Count > 0)
        {
            issues.Add(ValidationIssue.Error("MIXED_TRANSITIONS", $"'{key}' mixes Sequence and Conditional connections. Mark one conditional branch as default instead.", key));
        }

        if (conditionals.Count > 0)
        {
            ValidateConditionalSet(key, conditionals, issues, requireDefaultWarning: true);
        }

        if (isApproval && outs.Count(c => c.ConnectionType == ConnectionType.Rejection) > 1)
        {
            issues.Add(ValidationIssue.Error("REJECTION_MULTIPLE", $"'{key}' has more than one Rejection connection.", key));
        }
    }

    private static void ValidateConditionalSet(string key, List<ActivityConnection> conditionals, List<ValidationIssue> issues, bool requireDefaultWarning)
    {
        var defaults = conditionals.Count(c => c.IsDefault);
        if (defaults > 1)
        {
            issues.Add(ValidationIssue.Error("DEFAULT_MULTIPLE", $"'{key}' has more than one default branch.", key));
        }

        foreach (var c in conditionals.Where(c => !c.IsDefault && string.IsNullOrWhiteSpace(c.ConditionExpression)))
        {
            issues.Add(ValidationIssue.Error("CONDITION_MISSING", $"Conditional connection {c.FromActivityKey} -> {c.ToActivityKey} has no condition and is not the default branch.", key));
        }

        if (requireDefaultWarning && defaults == 0 && conditionals.Count > 0)
        {
            issues.Add(ValidationIssue.Warning("DEFAULT_MISSING", $"'{key}' has no default branch - the workflow fails at runtime if no condition matches.", key));
        }
    }

    private static HashSet<string> Traverse(string start, Func<string, IEnumerable<string>> next)
    {
        var visited = new HashSet<string>(StringComparer.Ordinal) { start };
        var queue = new Queue<string>();
        queue.Enqueue(start);
        while (queue.Count > 0)
        {
            foreach (var n in next(queue.Dequeue()))
            {
                if (visited.Add(n))
                {
                    queue.Enqueue(n);
                }
            }
        }

        return visited;
    }

    /// <summary>Cycles are allowed only when they pass through a Rejection (or Error) route - otherwise the workflow can loop forever.</summary>
    private static void DetectIllegalLoops(List<WorkflowActivity> activities, List<ActivityConnection> connections, List<ValidationIssue> issues)
    {
        var forward = connections
            .Where(c => c.ConnectionType is ConnectionType.Sequence or ConnectionType.Conditional or ConnectionType.Parallel)
            .ToLookup(c => c.FromActivityKey, c => c.ToActivityKey);

        var state = new Dictionary<string, int>(StringComparer.Ordinal); // 0 = new, 1 = on stack, 2 = done
        var reported = new HashSet<string>(StringComparer.Ordinal);

        foreach (var activity in activities)
        {
            if (state.GetValueOrDefault(activity.ActivityKey) != 0)
            {
                continue;
            }

            // Iterative DFS to avoid stack overflow on large graphs.
            var stack = new Stack<(string Key, IEnumerator<string> Children)>();
            state[activity.ActivityKey] = 1;
            stack.Push((activity.ActivityKey, forward[activity.ActivityKey].GetEnumerator()));
            while (stack.Count > 0)
            {
                var (key, children) = stack.Peek();
                if (children.MoveNext())
                {
                    var child = children.Current;
                    var childState = state.GetValueOrDefault(child);
                    if (childState == 1)
                    {
                        if (reported.Add(child))
                        {
                            issues.Add(ValidationIssue.Error("ILLEGAL_LOOP",
                                $"Loop detected through '{child}' <- '{key}' without a Rejection route. Loops are only allowed as rejection loops.", child));
                        }
                    }
                    else if (childState == 0)
                    {
                        state[child] = 1;
                        stack.Push((child, forward[child].GetEnumerator()));
                    }
                }
                else
                {
                    state[key] = 2;
                    stack.Pop();
                }
            }
        }
    }

    private static void ValidateParallelBlocks(List<WorkflowActivity> activities, ILookup<string, ActivityConnection> outgoing, List<ValidationIssue> issues)
    {
        var joins = activities.Where(a => a.ActivityType == ActivityType.ParallelJoin).Select(a => a.ActivityKey).ToHashSet(StringComparer.Ordinal);
        foreach (var split in activities.Where(a => a.ActivityType == ActivityType.ParallelSplit))
        {
            foreach (var branch in outgoing[split.ActivityKey].Where(c => c.ConnectionType == ConnectionType.Parallel))
            {
                var reach = Traverse(branch.ToActivityKey, key => joins.Contains(key)
                    ? Enumerable.Empty<string>()
                    : outgoing[key].Where(c => c.ConnectionType is ConnectionType.Sequence or ConnectionType.Conditional or ConnectionType.Parallel).Select(c => c.ToActivityKey));
                if (!reach.Overlaps(joins))
                {
                    issues.Add(ValidationIssue.Error("PARALLEL_BRANCH_UNJOINED",
                        $"Parallel branch '{split.ActivityKey}' -> '{branch.ToActivityKey}' never reaches a Parallel Join.", split.ActivityKey));
                }
            }
        }
    }

    /// <summary>For every activity, the set of activities that can run before it (excluding rejection loop-backs).</summary>
    private static Dictionary<string, HashSet<string>> BuildAncestorMap(List<WorkflowActivity> activities, List<ActivityConnection> connections)
    {
        var reverse = connections
            .Where(c => c.ConnectionType != ConnectionType.Rejection)
            .ToLookup(c => c.ToActivityKey, c => c.FromActivityKey);

        var map = new Dictionary<string, HashSet<string>>(StringComparer.Ordinal);
        foreach (var activity in activities)
        {
            var set = Traverse(activity.ActivityKey, key => reverse[key]);
            set.Remove(activity.ActivityKey);
            map[activity.ActivityKey] = set;
        }

        return map;
    }

    // ================================================================ policies & config

    private static void ValidatePolicies(WorkflowActivity activity, ActivityDescriptor descriptor, Dictionary<string, WorkflowActivity> byKey, List<ValidationIssue> issues)
    {
        var key = activity.ActivityKey;
        if (string.IsNullOrWhiteSpace(activity.DisplayName))
        {
            issues.Add(ValidationIssue.Error("NAME_REQUIRED", "Display name is required.", key, "displayName"));
        }

        if (activity.TimeoutSeconds <= 0)
        {
            issues.Add(ValidationIssue.Error("TIMEOUT_INVALID", "Timeout must be greater than zero.", key, "timeoutSeconds"));
        }

        if (activity.RetryMaxAttempts is < 1 or > 100)
        {
            issues.Add(ValidationIssue.Error("RETRY_ATTEMPTS", "Retry maximum attempts must be between 1 and 100.", key, "retryMaxAttempts"));
        }

        if (activity.RetryInitialIntervalSeconds > activity.RetryMaxIntervalSeconds)
        {
            issues.Add(ValidationIssue.Error("RETRY_INTERVAL", "Retry initial interval cannot exceed the maximum interval.", key, "retryInitialIntervalSeconds"));
        }

        if (activity.RetryBackoffCoefficient < 1)
        {
            issues.Add(ValidationIssue.Error("RETRY_BACKOFF", "Retry backoff coefficient must be at least 1.0.", key, "retryBackoffCoefficient"));
        }

        if (descriptor.IsHumanTask && activity.RetryMaxAttempts > 1)
        {
            issues.Add(ValidationIssue.Warning("HUMAN_TASK_RETRY", "Human tasks are normally not retried; consider maximum attempts = 1.", key, "retryMaxAttempts"));
        }

        if (activity.ErrorHandling == ErrorHandlingStrategy.RouteToActivity)
        {
            if (string.IsNullOrEmpty(activity.ErrorRouteActivityKey))
            {
                issues.Add(ValidationIssue.Error("ERROR_ROUTE_MISSING", "Error handling 'RouteToActivity' requires an error route activity.", key, "errorRouteActivityKey"));
            }
            else if (!byKey.ContainsKey(activity.ErrorRouteActivityKey) || activity.ErrorRouteActivityKey == key)
            {
                issues.Add(ValidationIssue.Error("ERROR_ROUTE_INVALID", $"Error route activity '{activity.ErrorRouteActivityKey}' does not exist or is the activity itself.", key, "errorRouteActivityKey"));
            }
        }
        else if (!string.IsNullOrEmpty(activity.ErrorRouteActivityKey))
        {
            issues.Add(ValidationIssue.Warning("ERROR_ROUTE_IGNORED", "Error route activity is ignored unless error handling is 'RouteToActivity'.", key, "errorRouteActivityKey"));
        }

        if (!string.IsNullOrWhiteSpace(activity.ExecutionCondition))
        {
            if (descriptor.IsControlNode)
            {
                issues.Add(ValidationIssue.Error("CONDITION_ON_CONTROL", "Execution conditions are not supported on control nodes.", key, "executionCondition"));
            }

            foreach (var error in ExpressionValidator.Validate(activity.ExecutionCondition).Errors)
            {
                issues.Add(ValidationIssue.Error("EXECUTION_CONDITION_INVALID", $"Execution condition: {error}", key, "executionCondition"));
            }
        }

        foreach (var error in activity.NonRetryableErrors.Where(e => !Regex.IsMatch(e, "^[A-Za-z][A-Za-z0-9_.]{0,199}$")))
        {
            issues.Add(ValidationIssue.Error("NON_RETRYABLE_INVALID", $"Non-retryable error type '{error}' is invalid.", key, "nonRetryableErrors"));
        }
    }

    private static void ValidateConfig(WorkflowActivity activity, ActivityDescriptor descriptor, WorkflowValidationContext context, List<ValidationIssue> issues)
    {
        var key = activity.ActivityKey;
        var fields = descriptor.ConfigFields.ToDictionary(f => f.Key, StringComparer.OrdinalIgnoreCase);

        foreach (var entry in activity.Config)
        {
            if (!fields.ContainsKey(entry.Key))
            {
                issues.Add(ValidationIssue.Error("CONFIG_UNKNOWN", $"Configuration key '{entry.Key}' is not supported for {descriptor.DisplayName}.", key, entry.Key));
            }
        }

        foreach (var field in descriptor.ConfigFields)
        {
            activity.Config.TryGetValue(field.Key, out var value);
            if (string.IsNullOrWhiteSpace(value))
            {
                if (field.Required)
                {
                    issues.Add(ValidationIssue.Error("CONFIG_REQUIRED", $"'{field.Label}' is required.", key, field.Key));
                }

                continue;
            }

            var secretOrSql = field.FieldType == ConfigFieldType.TextArea
                ? (ContentSafetyScanner.ContainsSecret(value) ? "Value appears to contain a secret." : null)
                : ContentSafetyScanner.Inspect(null, value);
            if (secretOrSql is not null)
            {
                issues.Add(ValidationIssue.Error("CONFIG_UNSAFE", $"'{field.Label}': {secretOrSql}", key, field.Key));
                continue;
            }

            if (field.Pattern is not null && !Regex.IsMatch(value, field.Pattern))
            {
                issues.Add(ValidationIssue.Error("CONFIG_PATTERN", $"'{field.Label}' has an invalid format.", key, field.Key));
            }

            switch (field.FieldType)
            {
                case ConfigFieldType.Select when !field.Options.Contains(value, StringComparer.Ordinal):
                    issues.Add(ValidationIssue.Error("CONFIG_OPTION", $"'{field.Label}' must be one of: {string.Join(", ", field.Options)}.", key, field.Key));
                    break;

                case ConfigFieldType.Boolean when value is not ("true" or "false"):
                    issues.Add(ValidationIssue.Error("CONFIG_BOOLEAN", $"'{field.Label}' must be true or false.", key, field.Key));
                    break;

                case ConfigFieldType.Number:
                    if (!int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var number) ||
                        (field.Min.HasValue && number < field.Min) || (field.Max.HasValue && number > field.Max))
                    {
                        issues.Add(ValidationIssue.Error("CONFIG_NUMBER", $"'{field.Label}' must be a whole number between {field.Min} and {field.Max}.", key, field.Key));
                    }

                    break;

                case ConfigFieldType.Role when !Regex.IsMatch(value, "^[A-Za-z0-9_\\-.]{2,100}$"):
                    issues.Add(ValidationIssue.Error("CONFIG_ROLE", $"'{field.Label}' is not a valid role code.", key, field.Key));
                    break;

                case ConfigFieldType.ConnectionProfile:
                    var profile = context.ConnectionProfiles.FirstOrDefault(p => string.Equals(p.ProfileCode, value, StringComparison.OrdinalIgnoreCase));
                    if (profile is null || !profile.IsActive)
                    {
                        issues.Add(ValidationIssue.Error("PROFILE_UNKNOWN", $"Connection profile '{value}' does not exist or is inactive.", key, field.Key));
                    }
                    else if (field.ProfileType.HasValue && profile.ProfileType != field.ProfileType)
                    {
                        issues.Add(ValidationIssue.Error("PROFILE_TYPE", $"Connection profile '{value}' is a {profile.ProfileType} profile; {field.ProfileType} expected.", key, field.Key));
                    }

                    break;

                case ConfigFieldType.ApprovedQuery:
                    var query = context.ApprovedQueries.FirstOrDefault(q => string.Equals(q.QueryCode, value, StringComparison.OrdinalIgnoreCase));
                    if (query is null || !query.IsActive)
                    {
                        issues.Add(ValidationIssue.Error("QUERY_NOT_APPROVED", $"'{value}' is not an active approved Oracle query.", key, field.Key));
                    }
                    else
                    {
                        ValidateBindParameters(activity, query, issues);
                    }

                    break;
            }
        }
    }

    private static void ValidateBindParameters(WorkflowActivity activity, ApprovedOracleQuery query, List<ValidationIssue> issues)
    {
        if (query.ParameterNames.Count == 0)
        {
            return;
        }

        var bind = activity.Parameters.FirstOrDefault(p => p.Direction == ParameterDirection.Input && p.Name == "bindParameters");
        if (bind is null || (bind.SourceType == MappingSourceType.None && string.IsNullOrWhiteSpace(bind.DefaultValue)))
        {
            issues.Add(ValidationIssue.Error("BIND_PARAMETERS_MISSING",
                $"Approved query '{query.QueryCode}' expects bind variables ({string.Join(", ", query.ParameterNames)}); map the 'bindParameters' input.", activity.ActivityKey));
        }
    }

    // ================================================================ parameters

    private static Dictionary<string, WorkflowParameter> ValidateWorkflowParameters(
        WorkflowGraph graph, Dictionary<string, WorkflowActivity> byKey, WorkflowValidationContext context, List<ValidationIssue> issues)
    {
        var inputs = new Dictionary<string, WorkflowParameter>(StringComparer.Ordinal);
        var outputs = new HashSet<string>(StringComparer.Ordinal);

        foreach (var p in graph.Parameters.OrderBy(p => p.SortOrder))
        {
            var field = $"workflow.{p.Direction.ToString().ToLowerInvariant()}.{p.Name}";
            var set = p.Direction == ParameterDirection.Input ? inputs.Keys.ToHashSet() : outputs;
            if (!KeyRegex.IsMatch(p.Name))
            {
                issues.Add(ValidationIssue.Error("PARAM_NAME_INVALID", $"Workflow parameter name '{p.Name}' is invalid.", null, field));
            }

            if (set.Contains(p.Name))
            {
                issues.Add(ValidationIssue.Error("PARAM_DUPLICATE", $"Workflow {p.Direction} parameter '{p.Name}' is defined more than once.", null, field));
                continue;
            }

            if (p.Direction == ParameterDirection.Input)
            {
                inputs[p.Name] = p;
                if (p.SourceType != MappingSourceType.None)
                {
                    issues.Add(ValidationIssue.Error("WORKFLOW_INPUT_SOURCE", $"Workflow input '{p.Name}' is supplied by the caller and cannot have a mapping source.", null, field));
                }
            }
            else
            {
                outputs.Add(p.Name);
                if (p.SourceType == MappingSourceType.None)
                {
                    issues.Add(p.IsMandatory
                        ? ValidationIssue.Error("WORKFLOW_OUTPUT_UNMAPPED", $"Mandatory workflow output '{p.Name}' is not mapped.", null, field)
                        : ValidationIssue.Warning("WORKFLOW_OUTPUT_UNMAPPED", $"Workflow output '{p.Name}' is not mapped and will be empty.", null, field));
                }
            }

            ValidateCommonParameter(p, null, field, issues);
        }

        // Workflow outputs may reference any activity (they are resolved at completion).
        var allActivities = byKey.Keys.ToHashSet(StringComparer.Ordinal);
        var everything = byKey.Keys.ToDictionary(k => k, _ => allActivities, StringComparer.Ordinal);
        everything["__workflow__"] = allActivities;
        foreach (var p in graph.Parameters.Where(p => p.Direction == ParameterDirection.Output))
        {
            ValidateSource(p, "__workflow__", byKey, everything, inputs, context, $"workflow.output.{p.Name}", issues);
        }

        return inputs;
    }

    private static void ValidateActivityParameters(
        WorkflowActivity activity,
        Dictionary<string, WorkflowActivity> byKey,
        Dictionary<string, HashSet<string>> ancestors,
        Dictionary<string, WorkflowParameter> workflowInputs,
        WorkflowValidationContext context,
        List<ValidationIssue> issues)
    {
        var descriptor = ActivityCatalog.Get(activity.ActivityType);
        var seen = new HashSet<(ParameterDirection, string)>();
        foreach (var p in activity.Parameters)
        {
            var field = $"{p.Direction.ToString().ToLowerInvariant()}.{p.Name}";
            if (!KeyRegex.IsMatch(p.Name))
            {
                issues.Add(ValidationIssue.Error("PARAM_NAME_INVALID", $"Parameter name '{p.Name}' is invalid.", activity.ActivityKey, field));
            }

            if (!seen.Add((p.Direction, p.Name)))
            {
                issues.Add(ValidationIssue.Error("PARAM_DUPLICATE", $"{p.Direction} parameter '{p.Name}' is defined more than once.", activity.ActivityKey, field));
                continue;
            }

            ValidateCommonParameter(p, activity.ActivityKey, field, issues);

            if (p.Direction == ParameterDirection.Output)
            {
                if (p.SourceType != MappingSourceType.None)
                {
                    issues.Add(ValidationIssue.Error("OUTPUT_SOURCE", $"Output parameter '{p.Name}' is produced by the activity and cannot have a mapping source.", activity.ActivityKey, field));
                }

                continue;
            }

            if (p.IsMandatory && p.SourceType == MappingSourceType.None && string.IsNullOrWhiteSpace(p.DefaultValue))
            {
                issues.Add(ValidationIssue.Error("INPUT_UNMAPPED", $"Mandatory input '{p.Name}' has no mapping and no default value.", activity.ActivityKey, field));
            }

            ValidateSource(p, activity.ActivityKey, byKey, ancestors, workflowInputs, context, field, issues);
        }

        foreach (var required in descriptor.DefaultInputs.Where(t => t.IsMandatory))
        {
            if (!activity.Parameters.Any(p => p.Direction == ParameterDirection.Input && p.Name == required.Name))
            {
                issues.Add(ValidationIssue.Error("INPUT_MISSING", $"{descriptor.DisplayName} requires input parameter '{required.Name}'.", activity.ActivityKey, $"input.{required.Name}"));
            }
        }

        foreach (var required in descriptor.DefaultOutputs.Where(t => t.IsMandatory))
        {
            if (!activity.Parameters.Any(p => p.Direction == ParameterDirection.Output && p.Name == required.Name))
            {
                issues.Add(ValidationIssue.Error("OUTPUT_MISSING", $"{descriptor.DisplayName} must expose output parameter '{required.Name}'.", activity.ActivityKey, $"output.{required.Name}"));
            }
        }
    }

    private static void ValidateCommonParameter(ParameterBase p, string? activityKey, string field, List<ValidationIssue> issues)
    {
        var typeError = ParameterValueValidator.ValidateValue(p.DataType, p.DefaultValue);
        if (typeError is not null)
        {
            issues.Add(ValidationIssue.Error("DEFAULT_TYPE", $"Default of '{p.Name}': {typeError}", activityKey, field));
        }

        var schemaError = ParameterValueValidator.ValidateJsonSchema(p.JsonSchema);
        if (schemaError is not null)
        {
            issues.Add(ValidationIssue.Error("JSON_SCHEMA_INVALID", $"'{p.Name}': {schemaError}", activityKey, field));
        }
        else
        {
            var conformError = ParameterValueValidator.ValidateAgainstSchema(p.JsonSchema, p.DefaultValue);
            if (conformError is not null)
            {
                issues.Add(ValidationIssue.Error("DEFAULT_SCHEMA", $"Default of '{p.Name}': {conformError}", activityKey, field));
            }
        }

        var literal = p.SourceType == MappingSourceType.Literal ? p.SourceReference : null;
        foreach (var value in new[] { p.DefaultValue, literal })
        {
            var unsafeReason = ContentSafetyScanner.Inspect(p.Name, value);
            if (unsafeReason is not null)
            {
                issues.Add(ValidationIssue.Error("PARAM_UNSAFE", $"'{p.Name}': {unsafeReason}", activityKey, field));
                break;
            }
        }
    }

    private static void ValidateSource(
        ParameterBase p,
        string ownerKey,
        Dictionary<string, WorkflowActivity> byKey,
        Dictionary<string, HashSet<string>> ancestors,
        Dictionary<string, WorkflowParameter> workflowInputs,
        WorkflowValidationContext context,
        string field,
        List<ValidationIssue> issues)
    {
        var activityKey = ownerKey == "__workflow__" ? null : ownerKey;
        var reference = p.SourceReference?.Trim();

        switch (p.SourceType)
        {
            case MappingSourceType.None:
                return;

            case MappingSourceType.Literal:
                if (reference is null)
                {
                    issues.Add(ValidationIssue.Error("LITERAL_MISSING", $"'{p.Name}' is mapped to a literal but no value is given.", activityKey, field));
                    return;
                }

                var literalError = ParameterValueValidator.ValidateValue(p.DataType, reference)
                                   ?? ParameterValueValidator.ValidateAgainstSchema(p.JsonSchema, reference);
                if (literalError is not null)
                {
                    issues.Add(ValidationIssue.Error("LITERAL_TYPE", $"Literal for '{p.Name}': {literalError}", activityKey, field));
                }

                return;

            case MappingSourceType.WorkflowInput:
                if (string.IsNullOrEmpty(reference) || !workflowInputs.TryGetValue(reference, out var input))
                {
                    issues.Add(ValidationIssue.Error("SOURCE_INPUT_UNKNOWN", $"'{p.Name}' maps from unknown workflow input '{reference}'.", activityKey, field));
                }
                else if (!ParameterValueValidator.AreCompatible(input.DataType, p.DataType))
                {
                    issues.Add(ValidationIssue.Warning("TYPE_MISMATCH", $"'{p.Name}' ({p.DataType}) maps from workflow input '{reference}' ({input.DataType}).", activityKey, field));
                }

                return;

            case MappingSourceType.ActivityOutput:
                var parts = reference?.Split('.') ?? Array.Empty<string>();
                if (parts.Length != 2)
                {
                    issues.Add(ValidationIssue.Error("SOURCE_FORMAT", $"'{p.Name}' activity-output reference must be 'activityKey.parameterName'.", activityKey, field));
                    return;
                }

                if (!byKey.TryGetValue(parts[0], out var sourceActivity))
                {
                    issues.Add(ValidationIssue.Error("SOURCE_ACTIVITY_UNKNOWN", $"'{p.Name}' maps from unknown activity '{parts[0]}'.", activityKey, field));
                    return;
                }

                if (!ancestors.TryGetValue(ownerKey, out var upstream) || !upstream.Contains(parts[0]))
                {
                    issues.Add(ValidationIssue.Error("SOURCE_NOT_UPSTREAM", $"'{p.Name}' maps from '{parts[0]}', which does not run before this activity.", activityKey, field));
                    return;
                }

                var sourceParam = sourceActivity.Parameters.FirstOrDefault(sp => sp.Direction == ParameterDirection.Output && sp.Name == parts[1]);
                if (sourceParam is null)
                {
                    issues.Add(ValidationIssue.Error("SOURCE_OUTPUT_UNKNOWN", $"'{p.Name}' maps from '{reference}', but '{parts[0]}' has no output '{parts[1]}'.", activityKey, field));
                }
                else if (!ParameterValueValidator.AreCompatible(sourceParam.DataType, p.DataType))
                {
                    issues.Add(ValidationIssue.Warning("TYPE_MISMATCH", $"'{p.Name}' ({p.DataType}) maps from '{reference}' ({sourceParam.DataType}).", activityKey, field));
                }

                return;

            case MappingSourceType.ConnectionProfile:
                var profile = context.ConnectionProfiles.FirstOrDefault(cp => string.Equals(cp.ProfileCode, reference, StringComparison.OrdinalIgnoreCase));
                if (profile is null || !profile.IsActive)
                {
                    issues.Add(ValidationIssue.Error("PROFILE_UNKNOWN", $"'{p.Name}' references unknown or inactive connection profile '{reference}'.", activityKey, field));
                }

                return;

            case MappingSourceType.SystemVariable:
                var parsed = string.IsNullOrEmpty(reference) ? null : ExpressionValidator.ParseReference(reference, out _);
                if (parsed?.Kind != "systemVariable")
                {
                    issues.Add(ValidationIssue.Error("SYSTEM_VARIABLE_UNKNOWN", $"'{p.Name}' references unknown system variable '{reference}'.", activityKey, field));
                }

                return;
        }
    }

    private static void ValidateExpressionReferences(
        WorkflowActivity activity,
        Dictionary<string, WorkflowActivity> byKey,
        Dictionary<string, HashSet<string>> ancestors,
        Dictionary<string, WorkflowParameter> workflowInputs,
        List<ValidationIssue> issues)
    {
        if (string.IsNullOrWhiteSpace(activity.ExecutionCondition))
        {
            return;
        }

        foreach (var reference in ExpressionValidator.Validate(activity.ExecutionCondition).References)
        {
            CheckReference(reference, activity.ActivityKey, includeSelf: false, byKey, ancestors, workflowInputs, issues, "executionCondition");
        }
    }

    private static void CheckReference(
        ExpressionReference reference,
        string ownerKey,
        bool includeSelf,
        Dictionary<string, WorkflowActivity> byKey,
        Dictionary<string, HashSet<string>> ancestors,
        Dictionary<string, WorkflowParameter> workflowInputs,
        List<ValidationIssue> issues,
        string field)
    {
        switch (reference.Kind)
        {
            case "workflowInput" when !workflowInputs.ContainsKey(reference.Name):
                issues.Add(ValidationIssue.Error("EXPRESSION_INPUT_UNKNOWN", $"Expression references unknown workflow input '{reference.Name}'.", ownerKey, field));
                break;

            case "activityOutput":
                if (!byKey.TryGetValue(reference.ActivityKey!, out var source))
                {
                    issues.Add(ValidationIssue.Error("EXPRESSION_ACTIVITY_UNKNOWN", $"Expression references unknown activity '{reference.ActivityKey}'.", ownerKey, field));
                    break;
                }

                var isUpstream = (includeSelf && reference.ActivityKey == ownerKey) ||
                                 (ancestors.TryGetValue(ownerKey, out var set) && set.Contains(reference.ActivityKey!));
                if (!isUpstream)
                {
                    issues.Add(ValidationIssue.Error("EXPRESSION_NOT_UPSTREAM", $"Expression references '{reference.ActivityKey}', which does not run before '{ownerKey}'.", ownerKey, field));
                    break;
                }

                if (!source.Parameters.Any(p => p.Direction == ParameterDirection.Output && p.Name == reference.Name))
                {
                    issues.Add(ValidationIssue.Error("EXPRESSION_OUTPUT_UNKNOWN", $"Activity '{reference.ActivityKey}' has no output '{reference.Name}'.", ownerKey, field));
                }

                break;
        }
    }

    // ================================================================ approvals

    private static void ValidateApproval(
        WorkflowActivity activity,
        ActivityDescriptor descriptor,
        Dictionary<string, WorkflowActivity> byKey,
        Dictionary<string, HashSet<string>> ancestors,
        List<ActivityConnection> outs,
        List<ValidationIssue> issues)
    {
        var key = activity.ActivityKey;
        var approval = activity.Approval;
        if (approval is null)
        {
            issues.Add(ValidationIssue.Error("APPROVAL_MISSING", $"{descriptor.DisplayName} '{activity.DisplayName}' has no approval configuration.", key, "approval"));
            return;
        }

        if (approval.Levels.Count < descriptor.MinApprovalLevels)
        {
            issues.Add(ValidationIssue.Error("APPROVAL_LEVELS_MIN", $"{descriptor.DisplayName} requires at least {descriptor.MinApprovalLevels} approval level(s).", key, "approval.levels"));
        }

        if (activity.ActivityType is ActivityType.Checker or ActivityType.Approver && approval.Levels.Count > 1)
        {
            issues.Add(ValidationIssue.Warning("APPROVAL_LEVELS_SINGLE", $"{descriptor.DisplayName} normally has one level; use Multilevel Approver for several levels.", key, "approval.levels"));
        }

        var levelNumbers = approval.Levels.Select(l => l.LevelNo).OrderBy(n => n).ToList();
        if (levelNumbers.Count > 0 && !levelNumbers.SequenceEqual(Enumerable.Range(1, levelNumbers.Count)))
        {
            issues.Add(ValidationIssue.Error("APPROVAL_LEVEL_SEQUENCE", "Approval level numbers must be contiguous starting at 1.", key, "approval.levels"));
        }

        foreach (var level in approval.Levels)
        {
            var field = $"approval.levels[{level.LevelNo}]";
            if (level.Roles.Count == 0)
            {
                issues.Add(ValidationIssue.Error("APPROVAL_LEVEL_ROLES", $"Approval level {level.LevelNo} has no roles.", key, field));
            }

            if (level.Roles.Select(r => r.RoleCode).Distinct(StringComparer.OrdinalIgnoreCase).Count() != level.Roles.Count)
            {
                issues.Add(ValidationIssue.Error("APPROVAL_ROLE_DUPLICATE", $"Approval level {level.LevelNo} lists a role more than once.", key, field));
            }

            if (level.ExecutionMode == LevelExecutionMode.Parallel && level.MinApprovals > level.Roles.Count)
            {
                issues.Add(ValidationIssue.Error("APPROVAL_MIN_APPROVALS", $"Level {level.LevelNo} requires {level.MinApprovals} approvals but only has {level.Roles.Count} parallel group(s).", key, field));
            }

            if (level.SlaHours.HasValue && level.SlaHours > approval.SlaHours)
            {
                issues.Add(ValidationIssue.Warning("APPROVAL_LEVEL_SLA", $"Level {level.LevelNo} SLA exceeds the overall SLA.", key, field));
            }

            if (descriptor.RequiredLevelMode.HasValue && level.ExecutionMode != descriptor.RequiredLevelMode)
            {
                issues.Add(ValidationIssue.Error("APPROVAL_LEVEL_MODE", $"{descriptor.DisplayName} requires {descriptor.RequiredLevelMode} levels (level {level.LevelNo} is {level.ExecutionMode}).", key, field));
            }
        }

        if (activity.ActivityType == ActivityType.ParallelApprover && !approval.Levels.Any(l => l.Roles.Count >= 2))
        {
            issues.Add(ValidationIssue.Error("APPROVAL_PARALLEL_GROUPS", "Parallel Approver needs at least one level with two or more approver groups.", key, "approval.levels"));
        }

        if (activity.ActivityType == ActivityType.SequentialApprover && approval.Levels.Sum(l => l.Roles.Count) < 2)
        {
            issues.Add(ValidationIssue.Error("APPROVAL_SEQUENTIAL_APPROVERS", "Sequential Approver needs at least two approvers in sequence.", key, "approval.levels"));
        }

        if (approval.ApprovalPolicy == ApprovalPolicy.Quorum && (!approval.QuorumCount.HasValue || approval.QuorumCount < 1))
        {
            issues.Add(ValidationIssue.Error("APPROVAL_QUORUM", "Quorum policy requires a quorum count.", key, "approval.quorumCount"));
        }

        if (approval.EscalationAfterHours.HasValue && string.IsNullOrWhiteSpace(approval.EscalationRole))
        {
            issues.Add(ValidationIssue.Error("APPROVAL_ESCALATION_ROLE", "Escalation requires an escalation role.", key, "approval.escalationRole"));
        }

        if (!approval.EnforceMakerCheckerSegregation)
        {
            issues.Add(ValidationIssue.Warning("SEGREGATION_DISABLED", "Maker-checker segregation is disabled; the maker could approve their own request.", key, "approval.enforceMakerCheckerSegregation"));
        }

        var rejectionEdge = outs.FirstOrDefault(c => c.ConnectionType == ConnectionType.Rejection);
        switch (approval.RejectionRouting)
        {
            case RejectionRouting.ToActivity:
                var target = approval.RejectionTargetActivityKey ?? rejectionEdge?.ToActivityKey;
                if (string.IsNullOrEmpty(target) || !byKey.ContainsKey(target))
                {
                    issues.Add(ValidationIssue.Error("REJECTION_TARGET", "Rejection routing 'ToActivity' needs an existing target activity (or a Rejection connection).", key, "approval.rejectionTargetActivityKey"));
                }
                else if (rejectionEdge is not null && !string.IsNullOrEmpty(approval.RejectionTargetActivityKey) && rejectionEdge.ToActivityKey != approval.RejectionTargetActivityKey)
                {
                    issues.Add(ValidationIssue.Error("REJECTION_TARGET_MISMATCH", "Rejection target differs from the Rejection connection target.", key, "approval.rejectionTargetActivityKey"));
                }

                break;

            case RejectionRouting.ToMaker:
                var hasMaker = ancestors.TryGetValue(key, out var up) && up.Any(k => byKey[k].ActivityType == ActivityType.Maker);
                if (!hasMaker)
                {
                    issues.Add(ValidationIssue.Error("REJECTION_NO_MAKER", "Rejection routing 'ToMaker' requires a Maker activity before this approval.", key, "approval.rejectionRouting"));
                }

                if (rejectionEdge is not null && byKey[rejectionEdge.ToActivityKey].ActivityType != ActivityType.Maker)
                {
                    issues.Add(ValidationIssue.Error("REJECTION_EDGE_NOT_MAKER", "Rejection connection must point to a Maker when routing is 'ToMaker'.", key));
                }

                break;

            case RejectionRouting.ToPreviousLevel when approval.Levels.Count < 2:
                issues.Add(ValidationIssue.Warning("REJECTION_PREVIOUS_LEVEL", "'ToPreviousLevel' on a single-level approval behaves like 'Terminate' at level 1.", key, "approval.rejectionRouting"));
                break;

            case RejectionRouting.Terminate when rejectionEdge is not null:
                issues.Add(ValidationIssue.Warning("REJECTION_EDGE_IGNORED", "Rejection connection is ignored because routing is 'Terminate'.", key));
                break;
        }
    }
}
