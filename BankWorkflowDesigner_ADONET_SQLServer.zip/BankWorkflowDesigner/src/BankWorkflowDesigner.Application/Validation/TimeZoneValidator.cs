namespace BankWorkflowDesigner.Application.Validation;

/// <summary>
/// Accepts Windows (e.g. "India Standard Time") and IANA (e.g. "Asia/Kolkata") time-zone ids on any host OS.
/// Windows ids cannot be resolved on Linux hosts without ICU, so common aliases are mapped explicitly.
/// </summary>
public static class TimeZoneValidator
{
    private static readonly Dictionary<string, string> Aliases = new(StringComparer.OrdinalIgnoreCase)
    {
        ["India Standard Time"] = "Asia/Kolkata",
        ["UTC"] = "Etc/UTC",
        ["GMT Standard Time"] = "Europe/London",
        ["Singapore Standard Time"] = "Asia/Singapore",
        ["Arabian Standard Time"] = "Asia/Dubai",
        ["Eastern Standard Time"] = "America/New_York",
        ["China Standard Time"] = "Asia/Shanghai",
        ["Tokyo Standard Time"] = "Asia/Tokyo",
        ["W. Europe Standard Time"] = "Europe/Berlin",
        ["Pacific Standard Time"] = "America/Los_Angeles"
    };

    public static bool IsKnown(string? timeZoneId)
    {
        if (string.IsNullOrWhiteSpace(timeZoneId))
        {
            return false;
        }

        if (TryFind(timeZoneId))
        {
            return true;
        }

        if (Aliases.TryGetValue(timeZoneId, out var iana) && TryFind(iana))
        {
            return true;
        }

        var windows = Aliases.FirstOrDefault(a => string.Equals(a.Value, timeZoneId, StringComparison.OrdinalIgnoreCase)).Key;
        return windows is not null && TryFind(windows);
    }

    private static bool TryFind(string id)
    {
        try
        {
            TimeZoneInfo.FindSystemTimeZoneById(id);
            return true;
        }
        catch (Exception ex) when (ex is TimeZoneNotFoundException or InvalidTimeZoneException)
        {
            return false;
        }
    }
}
