using System.Globalization;
using System.Text.Json;
using BankWorkflowDesigner.Domain.Enums;

namespace BankWorkflowDesigner.Application.Validation;

public static class ParameterValueValidator
{
    private static readonly string[] DateFormats = { "yyyy-MM-dd" };

    private static readonly HashSet<string> JsonSchemaTypes = new(StringComparer.Ordinal)
    {
        "string", "integer", "number", "boolean", "object", "array", "null"
    };

    /// <summary>Checks that a literal/default value can be converted to the declared data type.</summary>
    public static string? ValidateValue(ParameterDataType dataType, string? value)
    {
        if (value is null)
        {
            return null;
        }

        switch (dataType)
        {
            case ParameterDataType.Integer:
                return long.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out _)
                    ? null : $"'{Truncate(value)}' is not a valid Integer.";
            case ParameterDataType.Decimal:
                return decimal.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out _)
                    ? null : $"'{Truncate(value)}' is not a valid Decimal (use '.' as decimal separator).";
            case ParameterDataType.Boolean:
                return value is "true" or "false"
                    ? null : $"'{Truncate(value)}' is not a valid Boolean (use true or false).";
            case ParameterDataType.Date:
                return DateTime.TryParseExact(value, DateFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out _)
                    ? null : $"'{Truncate(value)}' is not a valid Date (yyyy-MM-dd).";
            case ParameterDataType.DateTime:
                return DateTimeOffset.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out _) && value.Contains('T')
                    ? null : $"'{Truncate(value)}' is not a valid ISO-8601 DateTime.";
            case ParameterDataType.Json:
                return TryParseJson(value, out _) ? null : "Value is not valid JSON.";
            case ParameterDataType.Array:
                return TryParseJson(value, out var kind) && kind == JsonValueKind.Array ? null : "Value is not a valid JSON array.";
            default:
                return null;
        }
    }

    /// <summary>Validates that the text is a JSON Schema object with a supported "type".</summary>
    public static string? ValidateJsonSchema(string? schema)
    {
        if (string.IsNullOrWhiteSpace(schema))
        {
            return null;
        }

        try
        {
            using var doc = JsonDocument.Parse(schema);
            if (doc.RootElement.ValueKind != JsonValueKind.Object)
            {
                return "JSON schema must be a JSON object.";
            }

            if (doc.RootElement.TryGetProperty("type", out var type))
            {
                if (type.ValueKind == JsonValueKind.String && !JsonSchemaTypes.Contains(type.GetString()!))
                {
                    return $"JSON schema type '{type.GetString()}' is not supported.";
                }

                if (type.ValueKind != JsonValueKind.String && type.ValueKind != JsonValueKind.Array)
                {
                    return "JSON schema 'type' must be a string or array.";
                }
            }

            return null;
        }
        catch (JsonException ex)
        {
            return $"JSON schema is not valid JSON: {ex.Message}";
        }
    }

    /// <summary>Very small structural check of a value against the schema's "type" and "required" keywords.</summary>
    public static string? ValidateAgainstSchema(string? schema, string? value)
    {
        if (string.IsNullOrWhiteSpace(schema) || value is null)
        {
            return null;
        }

        try
        {
            using var schemaDoc = JsonDocument.Parse(schema);
            if (!schemaDoc.RootElement.TryGetProperty("type", out var typeElement) || typeElement.ValueKind != JsonValueKind.String)
            {
                return null;
            }

            var type = typeElement.GetString();
            if (type is "object" or "array")
            {
                if (!TryParseJson(value, out var kind))
                {
                    return $"Value must be JSON {type}.";
                }

                if (type == "object" && kind != JsonValueKind.Object)
                {
                    return "Value must be a JSON object per schema.";
                }

                if (type == "array" && kind != JsonValueKind.Array)
                {
                    return "Value must be a JSON array per schema.";
                }

                if (type == "object" && schemaDoc.RootElement.TryGetProperty("required", out var required) && required.ValueKind == JsonValueKind.Array)
                {
                    using var valueDoc = JsonDocument.Parse(value);
                    foreach (var req in required.EnumerateArray())
                    {
                        var name = req.GetString();
                        if (name is not null && !valueDoc.RootElement.TryGetProperty(name, out _))
                        {
                            return $"Value is missing required property '{name}' defined by schema.";
                        }
                    }
                }
            }
            else if (type == "integer")
            {
                return ValidateValue(ParameterDataType.Integer, value);
            }
            else if (type == "number")
            {
                return ValidateValue(ParameterDataType.Decimal, value);
            }
            else if (type == "boolean")
            {
                return ValidateValue(ParameterDataType.Boolean, value);
            }

            return null;
        }
        catch (JsonException)
        {
            return null;
        }
    }

    /// <summary>Whether a value of <paramref name="source"/> type can be assigned to <paramref name="target"/>.</summary>
    public static bool AreCompatible(ParameterDataType source, ParameterDataType target)
    {
        if (source == target || target == ParameterDataType.String || target == ParameterDataType.Json)
        {
            return true;
        }

        return (source, target) switch
        {
            (ParameterDataType.Integer, ParameterDataType.Decimal) => true,
            (ParameterDataType.Date, ParameterDataType.DateTime) => true,
            (ParameterDataType.Array, ParameterDataType.Json) => true,
            (ParameterDataType.String, ParameterDataType.File) => true,
            (ParameterDataType.File, ParameterDataType.String) => true,
            _ => false
        };
    }

    private static bool TryParseJson(string value, out JsonValueKind kind)
    {
        try
        {
            using var doc = JsonDocument.Parse(value);
            kind = doc.RootElement.ValueKind;
            return true;
        }
        catch (JsonException)
        {
            kind = JsonValueKind.Undefined;
            return false;
        }
    }

    private static string Truncate(string value) => value.Length <= 40 ? value : value[..40] + "...";
}
