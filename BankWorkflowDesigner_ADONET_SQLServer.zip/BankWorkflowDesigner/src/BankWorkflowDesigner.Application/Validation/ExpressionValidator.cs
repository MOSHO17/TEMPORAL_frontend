using System.Text.RegularExpressions;

namespace BankWorkflowDesigner.Application.Validation;

/// <summary>A reference to data found in a condition expression.</summary>
public sealed record ExpressionReference(string Kind, string? ActivityKey, string Name, string RawPath);

public sealed class ExpressionParseResult
{
    public List<string> Errors { get; } = new();
    public List<ExpressionReference> References { get; } = new();
    public bool IsValid => Errors.Count == 0;
}

/// <summary>
/// Validates the restricted, side-effect free condition language used on connections and activity guards.
/// <para>Grammar (informal):</para>
/// <code>
/// expr    := or
/// or      := and ( '||' and )*
/// and     := unary ( '&amp;&amp;' unary )*
/// unary   := '!' unary | compare
/// compare := operand ( ('=='|'!='|'&gt;'|'&lt;'|'&gt;='|'&lt;=') operand )?
/// operand := reference | 'string' | number | true | false | null | '(' expr ')' | func '(' args ')'
/// reference := workflow.input.NAME | activities.KEY.output.NAME | activities.KEY.outcome | sys.NAME
/// func    := contains | startsWith | endsWith | isEmpty | length
/// </code>
/// No assignment, no method invocation on objects, no arbitrary code - the execution service can evaluate it safely.
/// </summary>
public static class ExpressionValidator
{
    public const int MaxLength = 1000;

    public static readonly IReadOnlySet<string> SystemVariables = new HashSet<string>(StringComparer.Ordinal)
    {
        "workflowId", "runId", "initiator", "now", "businessDate", "templateCode", "version", "sourceSystem"
    };

    private static readonly HashSet<string> Functions = new(StringComparer.Ordinal)
    {
        "contains", "startsWith", "endsWith", "isEmpty", "length"
    };

    private static readonly Regex KeyRegex = new("^[a-zA-Z][a-zA-Z0-9_]{0,99}$", RegexOptions.Compiled);

    private enum TokenKind { Identifier, String, Number, Operator, LParen, RParen, Comma, End }

    private readonly record struct Token(TokenKind Kind, string Text, int Position);

    public static ExpressionParseResult Validate(string? expression)
    {
        var result = new ExpressionParseResult();
        if (string.IsNullOrWhiteSpace(expression))
        {
            result.Errors.Add("Expression is empty.");
            return result;
        }

        if (expression.Length > MaxLength)
        {
            result.Errors.Add($"Expression exceeds {MaxLength} characters.");
            return result;
        }

        List<Token> tokens;
        try
        {
            tokens = Tokenize(expression);
        }
        catch (FormatException ex)
        {
            result.Errors.Add(ex.Message);
            return result;
        }

        var parser = new Parser(tokens, result);
        try
        {
            parser.ParseExpression();
            if (parser.Current.Kind != TokenKind.End)
            {
                result.Errors.Add($"Unexpected token '{parser.Current.Text}' at position {parser.Current.Position + 1}.");
            }
        }
        catch (FormatException ex)
        {
            result.Errors.Add(ex.Message);
        }

        return result;
    }

    /// <summary>Parses a single reference path such as activities.checker.output.outcome.</summary>
    public static ExpressionReference? ParseReference(string path, out string? error)
    {
        error = null;
        var parts = path.Split('.');
        if (parts.Length == 3 && parts[0] == "workflow" && parts[1] == "input" && KeyRegex.IsMatch(parts[2]))
        {
            return new ExpressionReference("workflowInput", null, parts[2], path);
        }

        if (parts.Length == 4 && parts[0] == "activities" && parts[2] == "output" && KeyRegex.IsMatch(parts[1]) && KeyRegex.IsMatch(parts[3]))
        {
            return new ExpressionReference("activityOutput", parts[1], parts[3], path);
        }

        if (parts.Length == 3 && parts[0] == "activities" && parts[2] == "outcome" && KeyRegex.IsMatch(parts[1]))
        {
            return new ExpressionReference("activityOutput", parts[1], "outcome", path);
        }

        if (parts.Length == 2 && parts[0] == "sys")
        {
            if (SystemVariables.Contains(parts[1]))
            {
                return new ExpressionReference("systemVariable", null, parts[1], path);
            }

            error = $"Unknown system variable '{path}'. Allowed: {string.Join(", ", SystemVariables.Select(v => "sys." + v))}.";
            return null;
        }

        error = $"Invalid reference '{path}'. Use workflow.input.<name>, activities.<key>.output.<name>, activities.<key>.outcome or sys.<name>.";
        return null;
    }

    private static List<Token> Tokenize(string text)
    {
        var tokens = new List<Token>();
        var i = 0;
        while (i < text.Length)
        {
            var c = text[i];
            if (char.IsWhiteSpace(c))
            {
                i++;
                continue;
            }

            var start = i;
            if (char.IsLetter(c) || c == '_')
            {
                while (i < text.Length && (char.IsLetterOrDigit(text[i]) || text[i] == '_' || text[i] == '.'))
                {
                    i++;
                }

                tokens.Add(new Token(TokenKind.Identifier, text[start..i], start));
                continue;
            }

            if (char.IsDigit(c) || (c == '-' && i + 1 < text.Length && char.IsDigit(text[i + 1]) && PreviousAllowsUnaryMinus(tokens)))
            {
                i++;
                while (i < text.Length && (char.IsDigit(text[i]) || text[i] == '.'))
                {
                    i++;
                }

                var number = text[start..i];
                if (!decimal.TryParse(number, System.Globalization.NumberStyles.Number, System.Globalization.CultureInfo.InvariantCulture, out _))
                {
                    throw new FormatException($"Invalid number '{number}' at position {start + 1}.");
                }

                tokens.Add(new Token(TokenKind.Number, number, start));
                continue;
            }

            if (c == '\'' || c == '"')
            {
                var quote = c;
                i++;
                while (i < text.Length && text[i] != quote)
                {
                    if (text[i] == '\\' && i + 1 < text.Length)
                    {
                        i++;
                    }

                    i++;
                }

                if (i >= text.Length)
                {
                    throw new FormatException($"Unterminated string literal starting at position {start + 1}.");
                }

                i++;
                tokens.Add(new Token(TokenKind.String, text[start..i], start));
                continue;
            }

            if (c == '(') { tokens.Add(new Token(TokenKind.LParen, "(", i++)); continue; }
            if (c == ')') { tokens.Add(new Token(TokenKind.RParen, ")", i++)); continue; }
            if (c == ',') { tokens.Add(new Token(TokenKind.Comma, ",", i++)); continue; }

            var two = i + 1 < text.Length ? text.Substring(i, 2) : string.Empty;
            if (two is "==" or "!=" or ">=" or "<=" or "&&" or "||")
            {
                tokens.Add(new Token(TokenKind.Operator, two, i));
                i += 2;
                continue;
            }

            if (c is '>' or '<' or '!')
            {
                tokens.Add(new Token(TokenKind.Operator, c.ToString(), i++));
                continue;
            }

            throw new FormatException($"Character '{c}' at position {i + 1} is not allowed in expressions.");
        }

        tokens.Add(new Token(TokenKind.End, "<end>", text.Length));
        return tokens;
    }

    private static bool PreviousAllowsUnaryMinus(List<Token> tokens) =>
        tokens.Count == 0 || tokens[^1].Kind is TokenKind.Operator or TokenKind.LParen or TokenKind.Comma;

    private sealed class Parser
    {
        private readonly List<Token> _tokens;
        private readonly ExpressionParseResult _result;
        private int _index;
        private int _depth;

        public Parser(List<Token> tokens, ExpressionParseResult result)
        {
            _tokens = tokens;
            _result = result;
        }

        public Token Current => _tokens[_index];

        public void ParseExpression()
        {
            if (++_depth > 32)
            {
                throw new FormatException("Expression is nested too deeply.");
            }

            ParseAnd();
            while (Current.Kind == TokenKind.Operator && Current.Text == "||")
            {
                _index++;
                ParseAnd();
            }

            _depth--;
        }

        private void ParseAnd()
        {
            ParseUnary();
            while (Current.Kind == TokenKind.Operator && Current.Text == "&&")
            {
                _index++;
                ParseUnary();
            }
        }

        private void ParseUnary()
        {
            if (Current.Kind == TokenKind.Operator && Current.Text == "!")
            {
                _index++;
                ParseUnary();
                return;
            }

            ParseCompare();
        }

        private void ParseCompare()
        {
            ParseOperand();
            if (Current.Kind == TokenKind.Operator && Current.Text is "==" or "!=" or ">" or "<" or ">=" or "<=")
            {
                _index++;
                ParseOperand();
            }
        }

        private void ParseOperand()
        {
            var token = Current;
            switch (token.Kind)
            {
                case TokenKind.String:
                case TokenKind.Number:
                    _index++;
                    return;

                case TokenKind.LParen:
                    _index++;
                    ParseExpression();
                    Expect(TokenKind.RParen, ")");
                    return;

                case TokenKind.Identifier:
                    _index++;
                    if (token.Text is "true" or "false" or "null")
                    {
                        return;
                    }

                    if (Current.Kind == TokenKind.LParen)
                    {
                        if (!Functions.Contains(token.Text))
                        {
                            throw new FormatException($"Function '{token.Text}' is not allowed. Allowed: {string.Join(", ", Functions)}.");
                        }

                        _index++;
                        if (Current.Kind != TokenKind.RParen)
                        {
                            ParseExpression();
                            while (Current.Kind == TokenKind.Comma)
                            {
                                _index++;
                                ParseExpression();
                            }
                        }

                        Expect(TokenKind.RParen, ")");
                        return;
                    }

                    var reference = ParseReference(token.Text, out var error);
                    if (reference is null)
                    {
                        _result.Errors.Add(error!);
                    }
                    else
                    {
                        _result.References.Add(reference);
                    }

                    return;

                default:
                    throw new FormatException($"Unexpected token '{token.Text}' at position {token.Position + 1}.");
            }
        }

        private void Expect(TokenKind kind, string text)
        {
            if (Current.Kind != kind)
            {
                throw new FormatException($"Expected '{text}' at position {Current.Position + 1} but found '{Current.Text}'.");
            }

            _index++;
        }
    }
}
