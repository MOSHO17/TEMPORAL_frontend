using System.Text.Json;
using BankWorkflowDesigner.Application.Abstractions;
using BankWorkflowDesigner.Application.Definitions;
using BankWorkflowDesigner.Application.Validation;
using BankWorkflowDesigner.Domain.Catalog;
using BankWorkflowDesigner.Domain.Dtos;
using BankWorkflowDesigner.Domain.Entities;
using BankWorkflowDesigner.Domain.Enums;
using BankWorkflowDesigner.Domain.Exceptions;
using Microsoft.Extensions.Options;

namespace BankWorkflowDesigner.Application.Services;

public interface IWorkflowService
{
    Task<PagedResult<WorkflowTemplate>> SearchAsync(WorkflowQuery query, CancellationToken ct);
    Task<WorkflowDetailResponse> GetDetailAsync(int workflowTemplateId, int? versionNo, CancellationToken ct);
    Task<WorkflowDetailResponse> CreateAsync(CreateWorkflowRequest request, CancellationToken ct);
    Task<WorkflowDetailResponse> ImportAsync(WorkflowImportRequest request, CancellationToken ct);
    Task<WorkflowDetailResponse> UpdateAsync(int workflowTemplateId, UpdateWorkflowRequest request, CancellationToken ct);
    Task<WorkflowDetailResponse> CloneAsync(int workflowTemplateId, CloneWorkflowRequest request, CancellationToken ct);
    Task<WorkflowDetailResponse> CreateVersionAsync(int workflowTemplateId, CreateVersionRequest request, CancellationToken ct);
    Task<ValidationReport> ValidateAsync(int workflowTemplateId, CancellationToken ct);
    Task<PublishResult> PublishAsync(int workflowTemplateId, PublishWorkflowRequest request, CancellationToken ct);
    Task<WorkflowTemplate> ChangeStatusAsync(int workflowTemplateId, ChangeWorkflowStatusRequest request, CancellationToken ct);
    Task<string> GetPublishedDefinitionAsync(int workflowTemplateId, int? versionNo, CancellationToken ct);
    Task<string> GetPublishedDefinitionByCodeAsync(string templateCode, int? versionNo, CancellationToken ct);
    Task<string> PreviewDefinitionAsync(int workflowTemplateId, CancellationToken ct);
    Task<IReadOnlyList<WorkflowVersion>> GetVersionHistoryAsync(int workflowTemplateId, CancellationToken ct);
    Task<DashboardSummary> GetDashboardAsync(CancellationToken ct);
    Task<IReadOnlyList<AuditLogEntry>> GetAuditTrailAsync(int workflowTemplateId, CancellationToken ct);
}

public sealed class WorkflowService : IWorkflowService
{
    private readonly IWorkflowRepository _workflows;
    private readonly ISourceSystemRepository _sourceSystems;
    private readonly IReferenceDataRepository _referenceData;
    private readonly IWorkflowValidator _validator;
    private readonly IWorkflowDefinitionBuilder _builder;
    private readonly IAccessGuard _guard;
    private readonly ICurrentUser _user;
    private readonly IClock _clock;
    private readonly IAuditRepository _audit;
    private readonly WorkflowSecurityOptions _securityOptions;

    public WorkflowService(
        IWorkflowRepository workflows,
        ISourceSystemRepository sourceSystems,
        IReferenceDataRepository referenceData,
        IWorkflowValidator validator,
        IWorkflowDefinitionBuilder builder,
        IAccessGuard guard,
        ICurrentUser user,
        IClock clock,
        IAuditRepository audit,
        IOptions<WorkflowSecurityOptions> securityOptions)
    {
        _workflows = workflows;
        _sourceSystems = sourceSystems;
        _referenceData = referenceData;
        _validator = validator;
        _builder = builder;
        _guard = guard;
        _user = user;
        _clock = clock;
        _audit = audit;
        _securityOptions = securityOptions.Value;
    }

    public async Task<PagedResult<WorkflowTemplate>> SearchAsync(WorkflowQuery query, CancellationToken ct)
    {
        query.PageNumber = Math.Max(1, query.PageNumber);
        query.PageSize = Math.Clamp(query.PageSize, 1, 200);
        var visible = await _guard.GetVisibleSourceSystemIdsAsync(ct);
        return await _workflows.SearchAsync(query, visible, ct);
    }

    public async Task<WorkflowDetailResponse> GetDetailAsync(int workflowTemplateId, int? versionNo, CancellationToken ct)
    {
        var template = await GetTemplateWithAccessAsync(workflowTemplateId, ct);
        var graph = await _workflows.GetGraphAsync(workflowTemplateId, versionNo, ct)
                    ?? throw new NotFoundException($"Version {versionNo} of workflow {template.TemplateCode} was not found.");
        var versions = await _workflows.GetVersionsAsync(workflowTemplateId, ct);
        return new WorkflowDetailResponse { Template = template, Versions = versions, Graph = graph };
    }

    public async Task<WorkflowDetailResponse> CreateAsync(CreateWorkflowRequest request, CancellationToken ct)
    {
        await EnsureSourceAndModuleAsync(request.SourceSystemId, request.ModuleId, ct);
        await _guard.EnsureSourceSystemAccessAsync(request.SourceSystemId, ct, SourceSystemAccessRole.Designer);
        await EnsureCodeAvailableAsync(request.TemplateCode, ct);

        var graph = new WorkflowGraph();
        if (request.AddStartAndEnd)
        {
            graph.Activities.Add(NewControlNode(ActivityType.Start, "start", "Start", 60, 220));
            graph.Activities.Add(NewControlNode(ActivityType.End, "end", "End", 760, 220));
        }

        var template = new WorkflowTemplate
        {
            TemplateCode = request.TemplateCode.Trim(),
            SourceSystemId = request.SourceSystemId,
            ModuleId = request.ModuleId,
            WorkflowName = request.WorkflowName.Trim(),
            Description = request.Description?.Trim()
        };

        var id = await _workflows.CreateAsync(template, request.ChangeNotes, graph, _guard.Audit, ct);
        return await GetDetailAsync(id, null, ct);
    }

    public async Task<WorkflowDetailResponse> ImportAsync(WorkflowImportRequest request, CancellationToken ct)
    {
        var sourceSystem = await _sourceSystems.GetByCodeAsync(request.SourceSystemCode, ct)
                           ?? throw new BusinessValidationException("sourceSystemCode", $"Source system '{request.SourceSystemCode}' does not exist.");
        var module = sourceSystem.Modules.FirstOrDefault(m => string.Equals(m.ModuleCode, request.ModuleCode, StringComparison.OrdinalIgnoreCase))
                     ?? throw new BusinessValidationException("moduleCode", $"Module '{request.ModuleCode}' does not exist in {sourceSystem.SystemCode}.");
        await EnsureSourceAndModuleAsync(sourceSystem.SourceSystemId, module.ModuleId, ct);
        await _guard.EnsureSourceSystemAccessAsync(sourceSystem.SourceSystemId, ct, SourceSystemAccessRole.Designer);
        await EnsureCodeAvailableAsync(request.TemplateCode, ct);

        var errors = new Dictionary<string, List<string>>();
        var graph = new WorkflowGraph();
        foreach (var activityRequest in request.Activities)
        {
            try
            {
                graph.Activities.Add(ActivityMapper.ToActivity(activityRequest, null));
            }
            catch (BusinessValidationException ex)
            {
                foreach (var (key, messages) in ex.Errors)
                {
                    foreach (var message in messages)
                    {
                        ActivityMapper.Add(errors, $"activities.{activityRequest.ActivityKey}.{key}", message);
                    }
                }
            }
        }

        foreach (var dup in request.Activities.GroupBy(a => a.ActivityKey, StringComparer.Ordinal).Where(g => g.Count() > 1))
        {
            ActivityMapper.Add(errors, "activities", $"Duplicate activity key '{dup.Key}'.");
        }

        var keys = request.Activities.Select(a => a.ActivityKey).ToHashSet(StringComparer.Ordinal);
        foreach (var c in request.Connections)
        {
            if (!keys.Contains(c.FromActivityKey) || !keys.Contains(c.ToActivityKey))
            {
                ActivityMapper.Add(errors, "connections", $"Connection {c.FromActivityKey} -> {c.ToActivityKey} references an unknown activity.");
                continue;
            }

            graph.Connections.Add(ActivityMapper.ToConnection(c));
        }

        foreach (var p in request.Parameters)
        {
            try
            {
                graph.Parameters.Add(ActivityMapper.ToWorkflowParameter(p));
            }
            catch (BusinessValidationException ex)
            {
                foreach (var (key, messages) in ex.Errors)
                {
                    foreach (var message in messages)
                    {
                        ActivityMapper.Add(errors, key, message);
                    }
                }
            }
        }

        foreach (var dup in request.Parameters.GroupBy(p => (p.Direction, p.Name)).Where(g => g.Count() > 1))
        {
            ActivityMapper.Add(errors, "parameters", $"Duplicate workflow {dup.Key.Direction} parameter '{dup.Key.Name}'.");
        }

        ActivityMapper.ThrowIfAny(errors);

        var template = new WorkflowTemplate
        {
            TemplateCode = request.TemplateCode.Trim(),
            SourceSystemId = sourceSystem.SourceSystemId,
            ModuleId = module.ModuleId,
            WorkflowName = request.WorkflowName.Trim(),
            Description = request.Description?.Trim()
        };

        var id = await _workflows.CreateAsync(template, "Imported", graph, _guard.Audit, ct);
        return await GetDetailAsync(id, null, ct);
    }

    public async Task<WorkflowDetailResponse> UpdateAsync(int workflowTemplateId, UpdateWorkflowRequest request, CancellationToken ct)
    {
        var template = await GetTemplateWithAccessAsync(workflowTemplateId, ct, SourceSystemAccessRole.Designer);
        EnsureActive(template);
        await _workflows.UpdateHeaderAsync(workflowTemplateId, request.WorkflowName.Trim(), request.Description?.Trim(),
            request.ChangeNotes?.Trim(), request.RowVersion, _guard.Audit, ct);
        return await GetDetailAsync(workflowTemplateId, null, ct);
    }

    public async Task<WorkflowDetailResponse> CloneAsync(int workflowTemplateId, CloneWorkflowRequest request, CancellationToken ct)
    {
        var source = await GetTemplateWithAccessAsync(workflowTemplateId, ct);
        var targetSystem = request.SourceSystemId ?? source.SourceSystemId;
        var targetModule = request.ModuleId ?? (request.SourceSystemId is null ? source.ModuleId : 0);
        if (targetModule == 0)
        {
            throw new BusinessValidationException("moduleId", "A module is required when cloning into another source system.");
        }

        await EnsureSourceAndModuleAsync(targetSystem, targetModule, ct);
        await _guard.EnsureSourceSystemAccessAsync(targetSystem, ct, SourceSystemAccessRole.Designer);
        await EnsureCodeAvailableAsync(request.NewTemplateCode, ct);

        var fromVersion = request.FromVersionNo ?? source.LatestVersionNo;
        if (fromVersion < 1 || fromVersion > source.LatestVersionNo)
        {
            throw new BusinessValidationException("fromVersionNo", $"Version {fromVersion} does not exist.");
        }

        var newId = await _workflows.CloneAsync(workflowTemplateId, fromVersion, request.NewTemplateCode.Trim(), request.WorkflowName.Trim(),
            targetSystem, targetModule, _guard.Audit, ct);
        return await GetDetailAsync(newId, null, ct);
    }

    public async Task<WorkflowDetailResponse> CreateVersionAsync(int workflowTemplateId, CreateVersionRequest request, CancellationToken ct)
    {
        var template = await GetTemplateWithAccessAsync(workflowTemplateId, ct, SourceSystemAccessRole.Designer);
        EnsureActive(template);

        var versions = await _workflows.GetVersionsAsync(workflowTemplateId, ct);
        if (versions.Any(v => v.IsEditable))
        {
            var draft = versions.First(v => v.IsEditable);
            throw new ConflictException($"Version {draft.VersionNo} is still an open draft. Publish or continue editing it.", "DRAFT_EXISTS");
        }

        var basedOn = request.BasedOnVersionNo ?? template.PublishedVersionNo ?? template.LatestVersionNo;
        if (versions.All(v => v.VersionNo != basedOn))
        {
            throw new BusinessValidationException("basedOnVersionNo", $"Version {basedOn} does not exist.");
        }

        var newVersion = await _workflows.CreateVersionAsync(workflowTemplateId, basedOn, request.ChangeNotes?.Trim(), _guard.Audit, ct);
        return await GetDetailAsync(workflowTemplateId, newVersion, ct);
    }

    public async Task<ValidationReport> ValidateAsync(int workflowTemplateId, CancellationToken ct)
    {
        var template = await GetTemplateWithAccessAsync(workflowTemplateId, ct,
            SourceSystemAccessRole.Designer, SourceSystemAccessRole.Reviewer, SourceSystemAccessRole.Publisher);
        var graph = await GetLatestGraphAsync(template, ct);

        var report = await RunValidationAsync(graph, ct);
        if (graph.Version.IsEditable)
        {
            await _workflows.SaveValidationAsync(graph.Version.WorkflowVersionId, report.IsValid,
                JsonSerializer.Serialize(report, DefinitionJson.Canonical), _guard.Audit, ct);
        }

        return report;
    }

    public async Task<PublishResult> PublishAsync(int workflowTemplateId, PublishWorkflowRequest request, CancellationToken ct)
    {
        var template = await GetTemplateWithAccessAsync(workflowTemplateId, ct, SourceSystemAccessRole.Publisher);
        EnsureActive(template);
        var graph = await GetLatestGraphAsync(template, ct);

        if (!graph.Version.IsEditable)
        {
            throw new ConflictException($"Latest version {graph.Version.VersionNo} is {graph.Version.Status}; there is no draft to publish.", "NO_DRAFT");
        }

        if (graph.Version.VersionNo != request.VersionNo)
        {
            throw new ConflictException($"You reviewed version {request.VersionNo} but the current draft is version {graph.Version.VersionNo}. Reload before publishing.", "VERSION_MISMATCH");
        }

        if (_securityOptions.EnforcePublishSegregation)
        {
            var editors = new[] { graph.Version.CreatedBy, graph.Version.ModifiedBy }
                .Where(u => !string.IsNullOrEmpty(u))
                .Select(u => u!.ToUpperInvariant())
                .ToHashSet();
            if (editors.Contains(_user.UserName.ToUpperInvariant()))
            {
                throw new ForbiddenException("Four-eyes rule: you created or last modified this draft, so another publisher must publish it.");
            }
        }

        // Never trust a stored validation result - validate the exact graph being published.
        var report = await RunValidationAsync(graph, ct);
        if (!report.IsValid)
        {
            throw new BusinessValidationException(
                $"Version {graph.Version.VersionNo} has {report.ErrorCount} validation error(s) and cannot be published.",
                report.Issues.Where(i => i.Severity == IssueSeverity.Error)
                    .GroupBy(i => i.ActivityKey ?? "workflow")
                    .ToDictionary(g => g.Key, g => g.Select(i => $"[{i.Code}] {i.Message}").ToArray()));
        }

        var publishedOn = _clock.UtcNow;
        var definition = _builder.Build(graph, _user.UserName, publishedOn);
        var (json, hash) = _builder.Serialize(definition);

        return await _workflows.PublishAsync(graph.Version.WorkflowVersionId, graph.Version.RowVersion ?? string.Empty,
            json, hash, request.Comments?.Trim(), _guard.Audit, ct);
    }

    public async Task<WorkflowTemplate> ChangeStatusAsync(int workflowTemplateId, ChangeWorkflowStatusRequest request, CancellationToken ct)
    {
        var template = await GetTemplateWithAccessAsync(workflowTemplateId, ct, SourceSystemAccessRole.Publisher);
        if (template.Status == request.Status)
        {
            throw new ConflictException($"Workflow is already {request.Status}.", "STATUS_UNCHANGED");
        }

        await _workflows.SetTemplateStatusAsync(workflowTemplateId, request.Status, request.Reason.Trim(), _guard.Audit, ct);
        return (await _workflows.GetTemplateAsync(workflowTemplateId, ct))!;
    }

    public async Task<string> GetPublishedDefinitionAsync(int workflowTemplateId, int? versionNo, CancellationToken ct)
    {
        var template = await GetTemplateWithAccessAsync(workflowTemplateId, ct);
        return await LoadDefinitionAsync(template, versionNo, ct);
    }

    public async Task<string> GetPublishedDefinitionByCodeAsync(string templateCode, int? versionNo, CancellationToken ct)
    {
        var template = await _workflows.GetTemplateByCodeAsync(templateCode, ct)
                       ?? throw new NotFoundException($"Workflow template '{templateCode}' was not found.");
        await _guard.EnsureSourceSystemAccessAsync(template.SourceSystemId, ct);
        return await LoadDefinitionAsync(template, versionNo, ct);
    }

    public async Task<string> PreviewDefinitionAsync(int workflowTemplateId, CancellationToken ct)
    {
        var template = await GetTemplateWithAccessAsync(workflowTemplateId, ct);
        var graph = await GetLatestGraphAsync(template, ct);
        var definition = _builder.Build(graph, null, null);
        return _builder.Serialize(definition).Json;
    }

    public async Task<IReadOnlyList<WorkflowVersion>> GetVersionHistoryAsync(int workflowTemplateId, CancellationToken ct)
    {
        await GetTemplateWithAccessAsync(workflowTemplateId, ct);
        return await _workflows.GetVersionsAsync(workflowTemplateId, ct);
    }

    public async Task<DashboardSummary> GetDashboardAsync(CancellationToken ct)
    {
        var visible = await _guard.GetVisibleSourceSystemIdsAsync(ct);
        return await _workflows.GetDashboardAsync(visible, ct);
    }

    public async Task<IReadOnlyList<AuditLogEntry>> GetAuditTrailAsync(int workflowTemplateId, CancellationToken ct)
    {
        await GetTemplateWithAccessAsync(workflowTemplateId, ct);
        return await _audit.GetAsync("WorkflowTemplate", workflowTemplateId.ToString(System.Globalization.CultureInfo.InvariantCulture), 500, ct);
    }

    // ------------------------------------------------------------------ helpers

    internal async Task<WorkflowTemplate> GetTemplateWithAccessAsync(int workflowTemplateId, CancellationToken ct, params SourceSystemAccessRole[] roles)
    {
        var template = await _workflows.GetTemplateAsync(workflowTemplateId, ct)
                       ?? throw new NotFoundException($"Workflow template {workflowTemplateId} was not found.");
        await _guard.EnsureSourceSystemAccessAsync(template.SourceSystemId, ct, roles);
        return template;
    }

    private async Task<WorkflowGraph> GetLatestGraphAsync(WorkflowTemplate template, CancellationToken ct) =>
        await _workflows.GetGraphAsync(template.WorkflowTemplateId, null, ct)
        ?? throw new NotFoundException($"Workflow {template.TemplateCode} has no versions.");

    private async Task<ValidationReport> RunValidationAsync(WorkflowGraph graph, CancellationToken ct)
    {
        var context = new WorkflowValidationContext
        {
            ConnectionProfiles = await _referenceData.GetConnectionProfilesAsync(ct),
            ApprovedQueries = await _referenceData.GetApprovedQueriesAsync(ct)
        };

        return new ValidationReport
        {
            WorkflowTemplateId = graph.Template.WorkflowTemplateId,
            VersionNo = graph.Version.VersionNo,
            Issues = _validator.Validate(graph, context),
            ValidatedOn = _clock.UtcNow,
            ValidatedBy = _user.UserName
        };
    }

    private async Task<string> LoadDefinitionAsync(WorkflowTemplate template, int? versionNo, CancellationToken ct)
    {
        if (versionNo is null && template.Status == TemplateStatus.Inactive)
        {
            throw new ConflictException(
                $"Workflow '{template.TemplateCode}' is deactivated; new instances must not be started. Request an explicit version for running instances.",
                "TEMPLATE_INACTIVE");
        }

        return await _workflows.GetPublishedDefinitionAsync(template.WorkflowTemplateId, versionNo, ct)
               ?? throw new NotFoundException(versionNo is null
                   ? $"Workflow '{template.TemplateCode}' has no published version."
                   : $"Version {versionNo} of '{template.TemplateCode}' is not published.");
    }

    private async Task EnsureSourceAndModuleAsync(int sourceSystemId, int moduleId, CancellationToken ct)
    {
        var sourceSystem = await _sourceSystems.GetByIdAsync(sourceSystemId, ct)
                           ?? throw new BusinessValidationException("sourceSystemId", $"Source system {sourceSystemId} does not exist.");
        if (sourceSystem.Status != EntityStatus.Active)
        {
            throw new BusinessValidationException("sourceSystemId", $"Source system {sourceSystem.SystemCode} is inactive.");
        }

        var module = sourceSystem.Modules.FirstOrDefault(m => m.ModuleId == moduleId)
                     ?? throw new BusinessValidationException("moduleId", $"Module {moduleId} does not belong to {sourceSystem.SystemCode}.");
        if (module.Status != EntityStatus.Active)
        {
            throw new BusinessValidationException("moduleId", $"Module {module.ModuleCode} is inactive.");
        }
    }

    private async Task EnsureCodeAvailableAsync(string templateCode, CancellationToken ct)
    {
        if (await _workflows.GetTemplateByCodeAsync(templateCode.Trim(), ct) is not null)
        {
            throw new ConflictException($"Template code '{templateCode}' already exists.", "DUPLICATE_CODE");
        }
    }

    private static void EnsureActive(WorkflowTemplate template)
    {
        if (template.Status != TemplateStatus.Active)
        {
            throw new ConflictException($"Workflow '{template.TemplateCode}' is deactivated. Reactivate it before making changes.", "TEMPLATE_INACTIVE");
        }
    }

    private static WorkflowActivity NewControlNode(ActivityType type, string key, string name, int x, int y)
    {
        var descriptor = ActivityCatalog.Get(type);
        return new WorkflowActivity
        {
            ActivityKey = key,
            ActivityType = type,
            DisplayName = name,
            PositionX = x,
            PositionY = y,
            TimeoutSeconds = descriptor.DefaultTimeoutSeconds,
            RetryMaxAttempts = descriptor.DefaultRetryAttempts,
            Config = descriptor.ConfigFields.Where(f => f.DefaultValue is not null)
                .ToDictionary(f => f.Key, f => (string?)f.DefaultValue, StringComparer.OrdinalIgnoreCase)
        };
    }
}
