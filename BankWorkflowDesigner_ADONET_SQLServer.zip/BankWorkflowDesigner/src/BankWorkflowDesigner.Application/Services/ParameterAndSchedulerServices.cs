using System.Text.Json;
using BankWorkflowDesigner.Application.Abstractions;
using BankWorkflowDesigner.Application.Validation;
using BankWorkflowDesigner.Domain.Catalog;
using BankWorkflowDesigner.Domain.Dtos;
using BankWorkflowDesigner.Domain.Entities;
using BankWorkflowDesigner.Domain.Enums;
using BankWorkflowDesigner.Domain.Exceptions;

namespace BankWorkflowDesigner.Application.Services;

// ============================================================================ Parameters

public interface IParameterService
{
    Task<WorkflowParameter> AddAsync(int workflowTemplateId, WorkflowParameterRequest request, CancellationToken ct);
    Task<WorkflowParameter> UpdateAsync(int workflowTemplateId, int parameterId, WorkflowParameterRequest request, CancellationToken ct);
    Task DeleteAsync(int workflowTemplateId, int parameterId, CancellationToken ct);
}

public sealed class ParameterService : IParameterService
{
    private readonly IWorkflowRepository _workflows;
    private readonly IParameterRepository _parameters;
    private readonly IAccessGuard _guard;

    public ParameterService(IWorkflowRepository workflows, IParameterRepository parameters, IAccessGuard guard)
    {
        _workflows = workflows;
        _parameters = parameters;
        _guard = guard;
    }

    public async Task<WorkflowParameter> AddAsync(int workflowTemplateId, WorkflowParameterRequest request, CancellationToken ct)
    {
        var graph = await DraftGraphAsync(workflowTemplateId, ct);
        var parameter = ActivityMapper.ToWorkflowParameter(request);
        EnsureUnique(graph, parameter, null);
        return await _parameters.AddAsync(graph.Version.WorkflowVersionId, parameter, _guard.Audit, ct);
    }

    public async Task<WorkflowParameter> UpdateAsync(int workflowTemplateId, int parameterId, WorkflowParameterRequest request, CancellationToken ct)
    {
        var graph = await DraftGraphAsync(workflowTemplateId, ct);
        if (graph.Parameters.All(p => p.ParameterId != parameterId))
        {
            throw new NotFoundException($"Parameter {parameterId} was not found in the current draft.");
        }

        if (string.IsNullOrEmpty(request.RowVersion))
        {
            throw new BusinessValidationException("rowVersion", "RowVersion is required for updates.");
        }

        var parameter = ActivityMapper.ToWorkflowParameter(request);
        parameter.ParameterId = parameterId;
        EnsureUnique(graph, parameter, parameterId);
        return await _parameters.UpdateAsync(graph.Version.WorkflowVersionId, parameter, _guard.Audit, ct);
    }

    public async Task DeleteAsync(int workflowTemplateId, int parameterId, CancellationToken ct)
    {
        var graph = await DraftGraphAsync(workflowTemplateId, ct);
        if (graph.Parameters.All(p => p.ParameterId != parameterId))
        {
            throw new NotFoundException($"Parameter {parameterId} was not found in the current draft.");
        }

        await _parameters.DeleteAsync(graph.Version.WorkflowVersionId, parameterId, _guard.Audit, ct);
    }

    private static void EnsureUnique(WorkflowGraph graph, WorkflowParameter parameter, int? excludeId)
    {
        if (graph.Parameters.Any(p => p.ParameterId != excludeId && p.Direction == parameter.Direction && p.Name == parameter.Name))
        {
            throw new ConflictException($"Workflow {parameter.Direction} parameter '{parameter.Name}' already exists.", "DUPLICATE_PARAMETER");
        }
    }

    private async Task<WorkflowGraph> DraftGraphAsync(int workflowTemplateId, CancellationToken ct)
    {
        var template = await _workflows.GetTemplateAsync(workflowTemplateId, ct)
                       ?? throw new NotFoundException($"Workflow template {workflowTemplateId} was not found.");
        await _guard.EnsureSourceSystemAccessAsync(template.SourceSystemId, ct, SourceSystemAccessRole.Designer);
        if (template.Status != TemplateStatus.Active)
        {
            throw new ConflictException($"Workflow '{template.TemplateCode}' is deactivated.", "TEMPLATE_INACTIVE");
        }

        var graph = await _workflows.GetGraphAsync(workflowTemplateId, null, ct) ?? throw new NotFoundException("Workflow has no versions.");
        if (!graph.Version.IsEditable)
        {
            throw new ImmutableVersionException();
        }

        return graph;
    }
}

// ============================================================================ Scheduler configuration

public interface ISchedulerService
{
    Task<IReadOnlyList<SchedulerConfiguration>> GetAllAsync(CancellationToken ct);
    Task<SchedulerConfiguration> GetByIdAsync(int schedulerConfigId, CancellationToken ct);
    Task<SchedulerConfiguration> CreateAsync(SchedulerConfigRequest request, CancellationToken ct);
    Task<SchedulerConfiguration> UpdateAsync(int schedulerConfigId, SchedulerConfigRequest request, CancellationToken ct);
    CronValidationResult ValidateCron(string expression);
}

/// <summary>
/// Maintains scheduler metadata only. Execution (Quartz.NET) is performed by a separate service
/// that reads these records. Only approved Oracle query references are accepted - never SQL text.
/// </summary>
public sealed class SchedulerService : ISchedulerService
{
    private readonly ISchedulerRepository _repository;
    private readonly IWorkflowRepository _workflows;
    private readonly IReferenceDataRepository _referenceData;
    private readonly IAccessGuard _guard;

    public SchedulerService(ISchedulerRepository repository, IWorkflowRepository workflows, IReferenceDataRepository referenceData, IAccessGuard guard)
    {
        _repository = repository;
        _workflows = workflows;
        _referenceData = referenceData;
        _guard = guard;
    }

    public async Task<IReadOnlyList<SchedulerConfiguration>> GetAllAsync(CancellationToken ct)
    {
        var visible = await _guard.GetVisibleSourceSystemIdsAsync(ct);
        return await _repository.GetAllAsync(visible, ct);
    }

    public async Task<SchedulerConfiguration> GetByIdAsync(int schedulerConfigId, CancellationToken ct)
    {
        var config = await _repository.GetByIdAsync(schedulerConfigId, ct)
                     ?? throw new NotFoundException($"Scheduler configuration {schedulerConfigId} was not found.");
        await _guard.EnsureSourceSystemAccessAsync(config.SourceSystemId, ct);
        return config;
    }

    public async Task<SchedulerConfiguration> CreateAsync(SchedulerConfigRequest request, CancellationToken ct)
    {
        var entity = await BuildAsync(request, ct);
        var id = await _repository.CreateAsync(entity, _guard.Audit, ct);
        return (await _repository.GetByIdAsync(id, ct))!;
    }

    public async Task<SchedulerConfiguration> UpdateAsync(int schedulerConfigId, SchedulerConfigRequest request, CancellationToken ct)
    {
        var existing = await _repository.GetByIdAsync(schedulerConfigId, ct)
                       ?? throw new NotFoundException($"Scheduler configuration {schedulerConfigId} was not found.");
        await _guard.EnsureSourceSystemAccessAsync(existing.SourceSystemId, ct, SourceSystemAccessRole.Designer);
        if (!string.Equals(existing.SchedulerCode, request.SchedulerCode, StringComparison.Ordinal))
        {
            throw new BusinessValidationException("schedulerCode", "Scheduler code cannot be changed.");
        }

        if (string.IsNullOrEmpty(request.RowVersion))
        {
            throw new BusinessValidationException("rowVersion", "RowVersion is required for updates.");
        }

        var entity = await BuildAsync(request, ct, isUpdate: true);
        entity.SchedulerConfigId = schedulerConfigId;
        entity.RowVersion = request.RowVersion;
        await _repository.UpdateAsync(entity, _guard.Audit, ct);
        return (await _repository.GetByIdAsync(schedulerConfigId, ct))!;
    }

    public CronValidationResult ValidateCron(string expression) => CronExpressionValidator.Validate(expression);

    private async Task<SchedulerConfiguration> BuildAsync(SchedulerConfigRequest request, CancellationToken ct, bool isUpdate = false)
    {
        await _guard.EnsureSourceSystemAccessAsync(request.SourceSystemId, ct, SourceSystemAccessRole.Designer);
        var errors = new Dictionary<string, List<string>>();

        var cron = CronExpressionValidator.Validate(request.CronExpression);
        if (!cron.IsValid)
        {
            ActivityMapper.Add(errors, "cronExpression", cron.Error!);
        }

        if (!TimeZoneValidator.IsKnown(request.TimeZoneId))
        {
            ActivityMapper.Add(errors, "timeZoneId", $"Unknown time zone '{request.TimeZoneId}'. Use a Windows id (e.g. India Standard Time) or an IANA id (e.g. Asia/Kolkata).");
        }

        var query = (await _referenceData.GetApprovedQueriesAsync(ct)).FirstOrDefault(q => q.ApprovedQueryId == request.ApprovedQueryId);
        if (query is null || !query.IsActive)
        {
            ActivityMapper.Add(errors, "approvedQueryId", "Only active, governance-approved Oracle queries can be scheduled.");
        }
        else if (query.SourceSystemId.HasValue && query.SourceSystemId != request.SourceSystemId)
        {
            ActivityMapper.Add(errors, "approvedQueryId", $"Approved query '{query.QueryCode}' belongs to another source system.");
        }

        var template = await _workflows.GetTemplateAsync(request.TargetWorkflowTemplateId, ct);
        if (template is null)
        {
            ActivityMapper.Add(errors, "targetWorkflowTemplateId", "Target workflow template does not exist.");
        }
        else
        {
            if (template.SourceSystemId != request.SourceSystemId)
            {
                ActivityMapper.Add(errors, "targetWorkflowTemplateId", "Target workflow belongs to another source system.");
            }

            if (template.Status != TemplateStatus.Active)
            {
                ActivityMapper.Add(errors, "targetWorkflowTemplateId", "Target workflow is deactivated.");
            }

            if (request.TargetVersionPolicy == TargetVersionPolicy.Pinned)
            {
                var versions = await _workflows.GetVersionsAsync(template.WorkflowTemplateId, ct);
                if (request.PinnedVersionNo is null || versions.All(v => v.VersionNo != request.PinnedVersionNo || v.Status is not (VersionStatus.Published or VersionStatus.Superseded)))
                {
                    ActivityMapper.Add(errors, "pinnedVersionNo", "Pinned version must be a published (or superseded) version of the target workflow.");
                }
            }
            else if (template.PublishedVersionNo is null)
            {
                ActivityMapper.Add(errors, "targetWorkflowTemplateId", "Target workflow has no published version yet.");
            }
        }

        if (request.EffectiveFrom.HasValue && request.EffectiveTo.HasValue && request.EffectiveTo <= request.EffectiveFrom)
        {
            ActivityMapper.Add(errors, "effectiveTo", "Effective-to must be after effective-from.");
        }

        ValidateExecutionParameters(request.ExecutionParametersJson, query, errors);
        ActivityMapper.ThrowIfAny(errors);

        return new SchedulerConfiguration
        {
            SchedulerCode = request.SchedulerCode.Trim(),
            SourceSystemId = request.SourceSystemId,
            SchedulerName = request.SchedulerName.Trim(),
            Description = request.Description?.Trim(),
            ApprovedQueryId = request.ApprovedQueryId,
            CronExpression = string.Join(' ', request.CronExpression.Split(' ', StringSplitOptions.RemoveEmptyEntries)),
            TimeZoneId = request.TimeZoneId,
            TargetWorkflowTemplateId = request.TargetWorkflowTemplateId,
            TargetVersionPolicy = request.TargetVersionPolicy,
            PinnedVersionNo = request.TargetVersionPolicy == TargetVersionPolicy.Pinned ? request.PinnedVersionNo : null,
            ExecutionParametersJson = NormalizeJson(request.ExecutionParametersJson),
            MisfirePolicy = request.MisfirePolicy,
            MaxConcurrentRuns = request.MaxConcurrentRuns,
            EffectiveFrom = request.EffectiveFrom,
            EffectiveTo = request.EffectiveTo,
            IsActive = request.IsActive
        };
    }

    private static void ValidateExecutionParameters(string json, ApprovedOracleQuery? query, Dictionary<string, List<string>> errors)
    {
        try
        {
            using var doc = JsonDocument.Parse(string.IsNullOrWhiteSpace(json) ? "{}" : json);
            if (doc.RootElement.ValueKind != JsonValueKind.Object)
            {
                ActivityMapper.Add(errors, "executionParametersJson", "Execution parameters must be a JSON object.");
                return;
            }

            foreach (var property in doc.RootElement.EnumerateObject())
            {
                var text = property.Value.ValueKind == JsonValueKind.String ? property.Value.GetString() : property.Value.GetRawText();
                var unsafeReason = ContentSafetyScanner.Inspect(property.Name, text);
                if (unsafeReason is not null)
                {
                    ActivityMapper.Add(errors, $"executionParametersJson.{property.Name}", unsafeReason);
                }
            }

            if (query is not null)
            {
                var names = doc.RootElement.EnumerateObject().Select(p => p.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
                var missing = query.ParameterNames.Where(n => !names.Contains(n)).ToList();
                if (missing.Count > 0)
                {
                    ActivityMapper.Add(errors, "executionParametersJson", $"Missing bind variables for approved query '{query.QueryCode}': {string.Join(", ", missing)}.");
                }
            }
        }
        catch (JsonException ex)
        {
            ActivityMapper.Add(errors, "executionParametersJson", $"Invalid JSON: {ex.Message}");
        }
    }

    private static string NormalizeJson(string json)
    {
        using var doc = JsonDocument.Parse(string.IsNullOrWhiteSpace(json) ? "{}" : json);
        return JsonSerializer.Serialize(doc.RootElement);
    }
}

// ============================================================================ Reference data & audit

public interface IReferenceDataService
{
    IReadOnlyCollection<ActivityDescriptor> GetActivityCatalog();
    Task<IReadOnlyList<ConnectionProfile>> GetConnectionProfilesAsync(CancellationToken ct);
    Task<IReadOnlyList<ApprovedOracleQuery>> GetApprovedQueriesAsync(CancellationToken ct);
    Task<IReadOnlyList<AuditLogEntry>> GetAuditAsync(string? entityType, string? entityId, int maxRows, CancellationToken ct);
}

public sealed class ReferenceDataService : IReferenceDataService
{
    private readonly IReferenceDataRepository _repository;
    private readonly IAuditRepository _audit;

    public ReferenceDataService(IReferenceDataRepository repository, IAuditRepository audit)
    {
        _repository = repository;
        _audit = audit;
    }

    public IReadOnlyCollection<ActivityDescriptor> GetActivityCatalog() => ActivityCatalog.All;

    public Task<IReadOnlyList<ConnectionProfile>> GetConnectionProfilesAsync(CancellationToken ct) => _repository.GetConnectionProfilesAsync(ct);

    public Task<IReadOnlyList<ApprovedOracleQuery>> GetApprovedQueriesAsync(CancellationToken ct) => _repository.GetApprovedQueriesAsync(ct);

    public Task<IReadOnlyList<AuditLogEntry>> GetAuditAsync(string? entityType, string? entityId, int maxRows, CancellationToken ct) =>
        _audit.GetAsync(entityType, entityId, Math.Clamp(maxRows, 1, 1000), ct);
}
