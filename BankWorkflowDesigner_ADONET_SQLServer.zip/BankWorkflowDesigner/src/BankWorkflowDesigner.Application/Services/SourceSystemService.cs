using BankWorkflowDesigner.Application.Abstractions;
using BankWorkflowDesigner.Domain.Dtos;
using BankWorkflowDesigner.Domain.Entities;
using BankWorkflowDesigner.Domain.Exceptions;

namespace BankWorkflowDesigner.Application.Services;

public interface ISourceSystemService
{
    Task<IReadOnlyList<SourceSystem>> GetAllAsync(CancellationToken ct);
    Task<SourceSystem> GetByIdAsync(int sourceSystemId, CancellationToken ct);
    Task<SourceSystem> CreateAsync(CreateSourceSystemRequest request, CancellationToken ct);
    Task<SourceSystem> UpdateAsync(int sourceSystemId, UpdateSourceSystemRequest request, CancellationToken ct);
}

public sealed class SourceSystemService : ISourceSystemService
{
    private readonly ISourceSystemRepository _repository;
    private readonly IAccessGuard _guard;

    public SourceSystemService(ISourceSystemRepository repository, IAccessGuard guard)
    {
        _repository = repository;
        _guard = guard;
    }

    public async Task<IReadOnlyList<SourceSystem>> GetAllAsync(CancellationToken ct)
    {
        var all = await _repository.GetAllAsync(ct);
        var visible = await _guard.GetVisibleSourceSystemIdsAsync(ct);
        return visible is null ? all : all.Where(s => visible.Contains(s.SourceSystemId)).ToList();
    }

    public async Task<SourceSystem> GetByIdAsync(int sourceSystemId, CancellationToken ct)
    {
        var sourceSystem = await _repository.GetByIdAsync(sourceSystemId, ct)
                           ?? throw new NotFoundException($"Source system {sourceSystemId} was not found.");
        await _guard.EnsureSourceSystemAccessAsync(sourceSystemId, ct);
        return sourceSystem;
    }

    public async Task<SourceSystem> CreateAsync(CreateSourceSystemRequest request, CancellationToken ct)
    {
        ValidateChildren(request.Modules, request.AuthorizedUsers);
        if (await _repository.GetByCodeAsync(request.SystemCode, ct) is not null)
        {
            throw new ConflictException($"Source system code '{request.SystemCode}' already exists.", "DUPLICATE_CODE");
        }

        var entity = new SourceSystem
        {
            SystemCode = request.SystemCode.Trim(),
            ApplicationName = request.ApplicationName.Trim(),
            Description = request.Description?.Trim(),
            DefaultTaskQueue = string.IsNullOrWhiteSpace(request.DefaultTaskQueue)
                ? $"{request.SystemCode.Trim().ToLowerInvariant()}-workflows"
                : request.DefaultTaskQueue.Trim(),
            Status = request.Status,
            Modules = MapModules(request.Modules),
            AuthorizedUsers = MapUsers(request.AuthorizedUsers)
        };

        var id = await _repository.CreateAsync(entity, _guard.Audit, ct);
        return await _repository.GetByIdAsync(id, ct) ?? throw new NotFoundException("Created source system could not be reloaded.");
    }

    public async Task<SourceSystem> UpdateAsync(int sourceSystemId, UpdateSourceSystemRequest request, CancellationToken ct)
    {
        ValidateChildren(request.Modules, request.AuthorizedUsers);
        var existing = await _repository.GetByIdAsync(sourceSystemId, ct)
                       ?? throw new NotFoundException($"Source system {sourceSystemId} was not found.");

        var removedModules = existing.Modules
            .Where(m => !request.Modules.Any(r => string.Equals(r.ModuleCode, m.ModuleCode, StringComparison.OrdinalIgnoreCase)))
            .Select(m => m.ModuleCode)
            .ToList();
        if (removedModules.Count > 0)
        {
            throw new BusinessValidationException("modules",
                $"Modules cannot be deleted (they may be referenced by workflows); set them Inactive instead: {string.Join(", ", removedModules)}.");
        }

        existing.ApplicationName = request.ApplicationName.Trim();
        existing.Description = request.Description?.Trim();
        existing.DefaultTaskQueue = string.IsNullOrWhiteSpace(request.DefaultTaskQueue) ? existing.DefaultTaskQueue : request.DefaultTaskQueue.Trim();
        existing.Status = request.Status;
        existing.Modules = MapModules(request.Modules);
        existing.AuthorizedUsers = MapUsers(request.AuthorizedUsers);
        existing.RowVersion = request.RowVersion;

        await _repository.UpdateAsync(existing, _guard.Audit, ct);
        return await _repository.GetByIdAsync(sourceSystemId, ct) ?? throw new NotFoundException("Updated source system could not be reloaded.");
    }

    private static void ValidateChildren(List<ModuleRequest> modules, List<SourceSystemUserRequest> users)
    {
        var errors = new Dictionary<string, string[]>();
        var dupModules = modules.GroupBy(m => m.ModuleCode, StringComparer.OrdinalIgnoreCase).Where(g => g.Count() > 1).Select(g => g.Key).ToList();
        if (dupModules.Count > 0)
        {
            errors["modules"] = new[] { $"Duplicate module codes: {string.Join(", ", dupModules)}." };
        }

        if (modules.Count == 0)
        {
            errors["modules"] = new[] { "At least one module is required." };
        }

        var dupUsers = users.GroupBy(u => (u.UserPrincipal.ToUpperInvariant(), u.AccessRole)).Where(g => g.Count() > 1).Select(g => g.Key.Item1).ToList();
        if (dupUsers.Count > 0)
        {
            errors["authorizedUsers"] = new[] { $"Duplicate user/role entries: {string.Join(", ", dupUsers)}." };
        }

        if (errors.Count > 0)
        {
            throw new BusinessValidationException("Source system request is invalid.", errors);
        }
    }

    private static List<SourceSystemModule> MapModules(IEnumerable<ModuleRequest> modules) =>
        modules.Select(m => new SourceSystemModule
        {
            ModuleCode = m.ModuleCode.Trim(),
            ModuleName = m.ModuleName.Trim(),
            Description = m.Description?.Trim(),
            Status = m.Status
        }).ToList();

    private static List<SourceSystemUser> MapUsers(IEnumerable<SourceSystemUserRequest> users) =>
        users.Select(u => new SourceSystemUser
        {
            UserPrincipal = u.UserPrincipal.Trim(),
            DisplayName = u.DisplayName?.Trim(),
            AccessRole = u.AccessRole,
            IsActive = u.IsActive
        }).ToList();
}
