using BankWorkflowDesigner.Application.Abstractions;
using BankWorkflowDesigner.Domain.Catalog;
using BankWorkflowDesigner.Domain.Dtos;
using BankWorkflowDesigner.Domain.Entities;
using BankWorkflowDesigner.Domain.Enums;
using BankWorkflowDesigner.Domain.Exceptions;

namespace BankWorkflowDesigner.Application.Services;

public interface IActivityService
{
    Task<WorkflowActivity> AddAsync(int workflowTemplateId, ActivityRequest request, CancellationToken ct);
    Task<WorkflowActivity> UpdateAsync(int workflowTemplateId, int activityId, ActivityRequest request, CancellationToken ct);
    Task DeleteAsync(int workflowTemplateId, int activityId, CancellationToken ct);
    Task UpdateLayoutAsync(int workflowTemplateId, UpdateLayoutRequest request, CancellationToken ct);
    Task<WorkflowActivity> SaveApprovalAsync(int workflowTemplateId, int activityId, ApprovalConfigRequest request, CancellationToken ct);
    Task<ActivityConnection> AddConnectionAsync(int workflowTemplateId, ConnectionRequest request, CancellationToken ct);
    Task<ActivityConnection> UpdateConnectionAsync(int workflowTemplateId, int connectionId, ConnectionRequest request, CancellationToken ct);
    Task DeleteConnectionAsync(int workflowTemplateId, int connectionId, CancellationToken ct);
}

/// <summary>Draft-only editing of activities, connections and approval configuration.</summary>
public sealed class ActivityService : IActivityService
{
    private readonly IWorkflowRepository _workflows;
    private readonly IActivityRepository _activities;
    private readonly IAccessGuard _guard;

    public ActivityService(IWorkflowRepository workflows, IActivityRepository activities, IAccessGuard guard)
    {
        _workflows = workflows;
        _activities = activities;
        _guard = guard;
    }

    public async Task<WorkflowActivity> AddAsync(int workflowTemplateId, ActivityRequest request, CancellationToken ct)
    {
        var graph = await DraftGraphAsync(workflowTemplateId, ct);
        if (graph.Activities.Any(a => a.ActivityKey == request.ActivityKey))
        {
            throw new ConflictException($"Activity key '{request.ActivityKey}' already exists in this version.", "DUPLICATE_KEY");
        }

        if (request.ActivityType == ActivityType.Start && graph.Activities.Any(a => a.ActivityType == ActivityType.Start))
        {
            throw new ConflictException("The workflow already has a Start node.", "START_EXISTS");
        }

        var activity = ActivityMapper.ToActivity(request, null);
        return await _activities.AddAsync(graph.Version.WorkflowVersionId, activity, _guard.Audit, ct);
    }

    public async Task<WorkflowActivity> UpdateAsync(int workflowTemplateId, int activityId, ActivityRequest request, CancellationToken ct)
    {
        var graph = await DraftGraphAsync(workflowTemplateId, ct);
        var existing = FindActivity(graph, activityId);
        if (string.IsNullOrEmpty(request.RowVersion))
        {
            throw new BusinessValidationException("rowVersion", "RowVersion is required for updates.");
        }

        if (existing.ActivityType != request.ActivityType)
        {
            throw new BusinessValidationException("activityType", "The activity type cannot be changed. Delete the activity and add a new one.");
        }

        if (existing.ActivityKey != request.ActivityKey && graph.Activities.Any(a => a.ActivityKey == request.ActivityKey))
        {
            throw new ConflictException($"Activity key '{request.ActivityKey}' already exists in this version.", "DUPLICATE_KEY");
        }

        var activity = ActivityMapper.ToActivity(request, existing);
        return await _activities.UpdateAsync(graph.Version.WorkflowVersionId, activity, request.Parameters is not null, _guard.Audit, ct);
    }

    public async Task DeleteAsync(int workflowTemplateId, int activityId, CancellationToken ct)
    {
        var graph = await DraftGraphAsync(workflowTemplateId, ct);
        FindActivity(graph, activityId);
        await _activities.DeleteAsync(graph.Version.WorkflowVersionId, activityId, _guard.Audit, ct);
    }

    public async Task UpdateLayoutAsync(int workflowTemplateId, UpdateLayoutRequest request, CancellationToken ct)
    {
        var graph = await DraftGraphAsync(workflowTemplateId, ct);
        var unknown = request.Positions.Where(p => graph.Activities.All(a => a.ActivityKey != p.ActivityKey)).Select(p => p.ActivityKey).ToList();
        if (unknown.Count > 0)
        {
            throw new BusinessValidationException("positions", $"Unknown activity keys: {string.Join(", ", unknown)}.");
        }

        if (request.Positions.Count == 0)
        {
            return;
        }

        await _activities.UpdateLayoutAsync(graph.Version.WorkflowVersionId, request.Positions, _guard.Audit, ct);
    }

    public async Task<WorkflowActivity> SaveApprovalAsync(int workflowTemplateId, int activityId, ApprovalConfigRequest request, CancellationToken ct)
    {
        var graph = await DraftGraphAsync(workflowTemplateId, ct);
        var activity = FindActivity(graph, activityId);
        if (!ActivityCatalog.IsApproval(activity.ActivityType))
        {
            throw new BusinessValidationException("activityType", $"{activity.ActivityType} activities do not have approval configuration.");
        }

        var errors = new Dictionary<string, List<string>>();
        var approval = ActivityMapper.ToApproval(request, errors);
        if (approval.RejectionRouting == RejectionRouting.ToActivity &&
            approval.RejectionTargetActivityKey is not null &&
            graph.Activities.All(a => a.ActivityKey != approval.RejectionTargetActivityKey))
        {
            ActivityMapper.Add(errors, "rejectionTargetActivityKey", $"Activity '{approval.RejectionTargetActivityKey}' does not exist.");
        }

        ActivityMapper.ThrowIfAny(errors);
        approval.ActivityId = activityId;
        await _activities.SaveApprovalAsync(graph.Version.WorkflowVersionId, activityId, approval, _guard.Audit, ct);

        var reloaded = await _workflows.GetGraphAsync(workflowTemplateId, graph.Version.VersionNo, ct);
        return reloaded!.Activities.First(a => a.ActivityId == activityId);
    }

    public async Task<ActivityConnection> AddConnectionAsync(int workflowTemplateId, ConnectionRequest request, CancellationToken ct)
    {
        var graph = await DraftGraphAsync(workflowTemplateId, ct);
        var connection = ActivityMapper.ToConnection(request);
        CheckConnection(graph, connection, excludeConnectionId: null);
        return await _activities.AddConnectionAsync(graph.Version.WorkflowVersionId, connection, _guard.Audit, ct);
    }

    public async Task<ActivityConnection> UpdateConnectionAsync(int workflowTemplateId, int connectionId, ConnectionRequest request, CancellationToken ct)
    {
        var graph = await DraftGraphAsync(workflowTemplateId, ct);
        if (graph.Connections.All(c => c.ConnectionId != connectionId))
        {
            throw new NotFoundException($"Connection {connectionId} was not found in the current draft.");
        }

        var connection = ActivityMapper.ToConnection(request);
        connection.ConnectionId = connectionId;
        CheckConnection(graph, connection, connectionId);
        return await _activities.UpdateConnectionAsync(graph.Version.WorkflowVersionId, connection, _guard.Audit, ct);
    }

    public async Task DeleteConnectionAsync(int workflowTemplateId, int connectionId, CancellationToken ct)
    {
        var graph = await DraftGraphAsync(workflowTemplateId, ct);
        if (graph.Connections.All(c => c.ConnectionId != connectionId))
        {
            throw new NotFoundException($"Connection {connectionId} was not found in the current draft.");
        }

        await _activities.DeleteConnectionAsync(graph.Version.WorkflowVersionId, connectionId, _guard.Audit, ct);
    }

    // ------------------------------------------------------------------

    private async Task<WorkflowGraph> DraftGraphAsync(int workflowTemplateId, CancellationToken ct)
    {
        var template = await _workflows.GetTemplateAsync(workflowTemplateId, ct)
                       ?? throw new NotFoundException($"Workflow template {workflowTemplateId} was not found.");
        await _guard.EnsureSourceSystemAccessAsync(template.SourceSystemId, ct, SourceSystemAccessRole.Designer);
        if (template.Status != TemplateStatus.Active)
        {
            throw new ConflictException($"Workflow '{template.TemplateCode}' is deactivated.", "TEMPLATE_INACTIVE");
        }

        var graph = await _workflows.GetGraphAsync(workflowTemplateId, null, ct)
                    ?? throw new NotFoundException("Workflow has no versions.");
        if (!graph.Version.IsEditable)
        {
            throw new ImmutableVersionException(
                $"Version {graph.Version.VersionNo} is {graph.Version.Status} and immutable. Create a new version (POST /api/workflows/{workflowTemplateId}/versions) to make changes.");
        }

        return graph;
    }

    private static WorkflowActivity FindActivity(WorkflowGraph graph, int activityId) =>
        graph.Activities.FirstOrDefault(a => a.ActivityId == activityId)
        ?? throw new NotFoundException($"Activity {activityId} was not found in the current draft.");

    private static void CheckConnection(WorkflowGraph graph, ActivityConnection connection, int? excludeConnectionId)
    {
        var from = graph.Activities.FirstOrDefault(a => a.ActivityKey == connection.FromActivityKey)
                   ?? throw new BusinessValidationException("fromActivityKey", $"Activity '{connection.FromActivityKey}' does not exist.");
        var to = graph.Activities.FirstOrDefault(a => a.ActivityKey == connection.ToActivityKey)
                 ?? throw new BusinessValidationException("toActivityKey", $"Activity '{connection.ToActivityKey}' does not exist.");

        if (from.ActivityKey == to.ActivityKey)
        {
            throw new BusinessValidationException("toActivityKey", "An activity cannot connect to itself.");
        }

        if (from.ActivityType == ActivityType.End)
        {
            throw new BusinessValidationException("fromActivityKey", "End nodes cannot have outgoing connections.");
        }

        if (to.ActivityType == ActivityType.Start)
        {
            throw new BusinessValidationException("toActivityKey", "Start nodes cannot have incoming connections.");
        }

        if (connection.ConnectionType == ConnectionType.Rejection && !ActivityCatalog.IsApproval(from.ActivityType))
        {
            throw new BusinessValidationException("connectionType", "Rejection connections can only start at approval activities.");
        }

        if (connection.ConnectionType == ConnectionType.Parallel && from.ActivityType != ActivityType.ParallelSplit)
        {
            throw new BusinessValidationException("connectionType", "Parallel connections can only start at a Parallel Split.");
        }

        if (connection.ConnectionType == ConnectionType.Conditional && !connection.IsDefault)
        {
            var parsed = Validation.ExpressionValidator.Validate(connection.ConditionExpression);
            if (!parsed.IsValid)
            {
                throw new BusinessValidationException("conditionExpression", string.Join(" ", parsed.Errors));
            }
        }

        if (graph.Connections.Any(c => c.ConnectionId != excludeConnectionId &&
                                       c.FromActivityKey == connection.FromActivityKey &&
                                       c.ToActivityKey == connection.ToActivityKey &&
                                       c.ConnectionType == connection.ConnectionType))
        {
            throw new ConflictException("An identical connection already exists.", "DUPLICATE_CONNECTION");
        }
    }
}
