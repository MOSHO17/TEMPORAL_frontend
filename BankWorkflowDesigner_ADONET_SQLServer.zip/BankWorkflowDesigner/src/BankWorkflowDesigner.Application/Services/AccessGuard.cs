using BankWorkflowDesigner.Application.Abstractions;
using BankWorkflowDesigner.Domain.Enums;
using BankWorkflowDesigner.Domain.Exceptions;
using BankWorkflowDesigner.Domain.Security;

namespace BankWorkflowDesigner.Application.Services;

public sealed class WorkflowSecurityOptions
{
    public const string SectionName = "WorkflowSecurity";

    /// <summary>When true the user who last changed a draft cannot publish it (four-eyes principle).</summary>
    public bool EnforcePublishSegregation { get; set; } = true;

    /// <summary>Global source-system administrators bypass per-source-system authorisation.</summary>
    public bool AdminsBypassSourceSystemAuthorization { get; set; } = true;
}

public interface IAccessGuard
{
    /// <summary>Null = unrestricted (administrator); otherwise ids of source systems the user may see.</summary>
    Task<IReadOnlyCollection<int>?> GetVisibleSourceSystemIdsAsync(CancellationToken ct);

    /// <summary>Throws <see cref="ForbiddenException"/> when the caller is not authorised for the source system with one of the required access roles.</summary>
    Task EnsureSourceSystemAccessAsync(int sourceSystemId, CancellationToken ct, params SourceSystemAccessRole[] requiredAnyOf);

    AuditContext Audit { get; }
}

/// <summary>
/// Second authorisation layer: API policies check the caller's global role (from AD / IAM);
/// this guard checks the caller is registered as an authorised user of the specific source system.
/// </summary>
public sealed class AccessGuard : IAccessGuard
{
    private readonly ICurrentUser _user;
    private readonly ISourceSystemRepository _sourceSystems;
    private readonly Microsoft.Extensions.Options.IOptions<WorkflowSecurityOptions> _options;

    public AccessGuard(ICurrentUser user, ISourceSystemRepository sourceSystems, Microsoft.Extensions.Options.IOptions<WorkflowSecurityOptions> options)
    {
        _user = user;
        _sourceSystems = sourceSystems;
        _options = options;
    }

    public AuditContext Audit => new(_user.UserName, _user.CorrelationId, _user.ClientIp);

    private bool IsUnrestricted =>
        (_options.Value.AdminsBypassSourceSystemAuthorization && _user.IsInRole(AppRoles.SourceSystemAdmin))
        || _user.IsInRole(AppRoles.DefinitionConsumer);

    public async Task<IReadOnlyCollection<int>?> GetVisibleSourceSystemIdsAsync(CancellationToken ct)
    {
        if (IsUnrestricted)
        {
            return null;
        }

        return await _sourceSystems.GetAuthorizedSourceSystemIdsAsync(_user.UserName, ct);
    }

    public async Task EnsureSourceSystemAccessAsync(int sourceSystemId, CancellationToken ct, params SourceSystemAccessRole[] requiredAnyOf)
    {
        if (IsUnrestricted)
        {
            return;
        }

        var roles = await _sourceSystems.GetUserAccessRolesAsync(sourceSystemId, _user.UserName, ct);
        if (roles.Count == 0)
        {
            throw new ForbiddenException("You are not an authorised user of this source system.");
        }

        if (requiredAnyOf.Length > 0 &&
            !roles.Contains(SourceSystemAccessRole.Administrator) &&
            !roles.Any(requiredAnyOf.Contains))
        {
            throw new ForbiddenException($"Your access on this source system does not allow this action (requires {string.Join(" or ", requiredAnyOf)}).");
        }
    }
}
