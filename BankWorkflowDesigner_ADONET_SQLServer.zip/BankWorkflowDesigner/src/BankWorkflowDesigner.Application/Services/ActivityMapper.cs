using BankWorkflowDesigner.Application.Validation;
using BankWorkflowDesigner.Domain.Catalog;
using BankWorkflowDesigner.Domain.Dtos;
using BankWorkflowDesigner.Domain.Entities;
using BankWorkflowDesigner.Domain.Enums;
using BankWorkflowDesigner.Domain.Exceptions;

namespace BankWorkflowDesigner.Application.Services;

/// <summary>Maps API requests to domain objects and applies the save-time guards (secrets, free SQL, type safety).</summary>
internal static class ActivityMapper
{
    public static WorkflowActivity ToActivity(ActivityRequest request, WorkflowActivity? existing)
    {
        var descriptor = ActivityCatalog.Get(request.ActivityType);
        var errors = new Dictionary<string, List<string>>();

        var config = new Dictionary<string, string?>(StringComparer.OrdinalIgnoreCase);
        var fields = descriptor.ConfigFields.ToDictionary(f => f.Key, StringComparer.OrdinalIgnoreCase);
        foreach (var (key, value) in request.Config)
        {
            if (!fields.TryGetValue(key, out var field))
            {
                Add(errors, $"config.{key}", $"'{key}' is not a supported setting for {descriptor.DisplayName}.");
                continue;
            }

            var trimmed = value?.Trim();
            if (trimmed is { Length: > 4000 })
            {
                Add(errors, $"config.{key}", "Value is too long (max 4000).");
                continue;
            }

            var unsafeReason = field.FieldType == ConfigFieldType.TextArea
                ? (ContentSafetyScanner.ContainsSecret(trimmed) ? "Value appears to contain a secret." : null)
                : ContentSafetyScanner.Inspect(null, trimmed);
            if (unsafeReason is not null)
            {
                Add(errors, $"config.{key}", unsafeReason);
                continue;
            }

            config[field.Key] = string.IsNullOrEmpty(trimmed) ? null : trimmed;
        }

        // Fill catalog defaults for settings the client did not send (create only).
        if (existing is null)
        {
            foreach (var field in descriptor.ConfigFields.Where(f => f.DefaultValue is not null && !config.ContainsKey(f.Key)))
            {
                config[field.Key] = field.DefaultValue;
            }
        }

        List<ActivityParameter> parameters;
        if (request.Parameters is null)
        {
            parameters = existing?.Parameters ?? DefaultParameters(descriptor);
        }
        else
        {
            parameters = request.Parameters.Select(p => ToActivityParameter(p, errors)).ToList();
            foreach (var dup in parameters.GroupBy(p => (p.Direction, p.Name)).Where(g => g.Count() > 1))
            {
                Add(errors, "parameters", $"Duplicate {dup.Key.Direction} parameter '{dup.Key.Name}'.");
            }
        }

        if (request.ExecutionCondition is { Length: > 0 } condition)
        {
            foreach (var e in ExpressionValidator.Validate(condition).Errors)
            {
                Add(errors, "executionCondition", e);
            }
        }

        var retry = request.RetryPolicy;
        if (retry is not null && retry.InitialIntervalSeconds > retry.MaxIntervalSeconds)
        {
            Add(errors, "retryPolicy", "Initial interval cannot exceed the maximum interval.");
        }

        ApprovalConfiguration? approval = existing?.Approval;
        if (request.Approval is not null)
        {
            if (!descriptor.IsApproval)
            {
                Add(errors, "approval", $"{descriptor.DisplayName} does not support approval configuration.");
            }
            else
            {
                approval = ToApproval(request.Approval, errors);
            }
        }

        ThrowIfAny(errors);

        return new WorkflowActivity
        {
            ActivityId = existing?.ActivityId ?? 0,
            WorkflowVersionId = existing?.WorkflowVersionId ?? 0,
            ActivityKey = request.ActivityKey.Trim(),
            ActivityType = request.ActivityType,
            DisplayName = request.DisplayName.Trim(),
            Description = request.Description?.Trim(),
            PositionX = request.PositionX,
            PositionY = request.PositionY,
            TimeoutSeconds = request.TimeoutSeconds ?? existing?.TimeoutSeconds ?? descriptor.DefaultTimeoutSeconds,
            RetryMaxAttempts = retry?.MaxAttempts ?? existing?.RetryMaxAttempts ?? descriptor.DefaultRetryAttempts,
            RetryInitialIntervalSeconds = retry?.InitialIntervalSeconds ?? existing?.RetryInitialIntervalSeconds ?? 5,
            RetryBackoffCoefficient = retry?.BackoffCoefficient ?? existing?.RetryBackoffCoefficient ?? 2.0m,
            RetryMaxIntervalSeconds = retry?.MaxIntervalSeconds ?? existing?.RetryMaxIntervalSeconds ?? 300,
            NonRetryableErrors = retry?.NonRetryableErrors.Select(e => e.Trim()).Where(e => e.Length > 0).Distinct().ToList()
                                 ?? existing?.NonRetryableErrors ?? new List<string>(),
            ErrorHandling = request.ErrorHandling,
            ErrorRouteActivityKey = string.IsNullOrWhiteSpace(request.ErrorRouteActivityKey) ? null : request.ErrorRouteActivityKey.Trim(),
            ExecutionCondition = string.IsNullOrWhiteSpace(request.ExecutionCondition) ? null : request.ExecutionCondition.Trim(),
            Config = config,
            Parameters = parameters,
            Approval = descriptor.IsApproval ? approval : null,
            RowVersion = request.RowVersion ?? existing?.RowVersion
        };
    }

    public static List<ActivityParameter> DefaultParameters(ActivityDescriptor descriptor)
    {
        var order = 0;
        return descriptor.DefaultInputs.Select(t => (t, ParameterDirection.Input))
            .Concat(descriptor.DefaultOutputs.Select(t => (t, ParameterDirection.Output)))
            .Select(x => new ActivityParameter
            {
                Direction = x.Item2,
                Name = x.t.Name,
                DataType = x.t.DataType,
                IsMandatory = x.t.IsMandatory,
                Description = x.t.Description,
                SortOrder = order++
            })
            .ToList();
    }

    public static ActivityParameter ToActivityParameter(ParameterRequestBase p, Dictionary<string, List<string>> errors)
    {
        CheckParameter(p, errors);
        return new ActivityParameter
        {
            Direction = p.Direction,
            Name = p.Name.Trim(),
            DataType = p.DataType,
            IsMandatory = p.IsMandatory,
            DefaultValue = p.DefaultValue,
            JsonSchema = string.IsNullOrWhiteSpace(p.JsonSchema) ? null : p.JsonSchema.Trim(),
            Description = p.Description?.Trim(),
            SourceType = p.SourceType,
            SourceReference = string.IsNullOrWhiteSpace(p.SourceReference) ? null : p.SourceReference.Trim(),
            SortOrder = p.SortOrder
        };
    }

    public static WorkflowParameter ToWorkflowParameter(WorkflowParameterRequest p)
    {
        var errors = new Dictionary<string, List<string>>();
        CheckParameter(p, errors);
        ThrowIfAny(errors);
        return new WorkflowParameter
        {
            Direction = p.Direction,
            Name = p.Name.Trim(),
            DataType = p.DataType,
            IsMandatory = p.IsMandatory,
            DefaultValue = p.DefaultValue,
            JsonSchema = string.IsNullOrWhiteSpace(p.JsonSchema) ? null : p.JsonSchema.Trim(),
            Description = p.Description?.Trim(),
            SourceType = p.SourceType,
            SourceReference = string.IsNullOrWhiteSpace(p.SourceReference) ? null : p.SourceReference.Trim(),
            SortOrder = p.SortOrder,
            RowVersion = p.RowVersion
        };
    }

    public static ApprovalConfiguration ToApproval(ApprovalConfigRequest request, Dictionary<string, List<string>> errors)
    {
        if (request.Levels.GroupBy(l => l.LevelNo).Any(g => g.Count() > 1))
        {
            Add(errors, "approval.levels", "Level numbers must be unique.");
        }

        foreach (var level in request.Levels.Where(l => l.Roles.GroupBy(r => r.RoleCode.Trim(), StringComparer.OrdinalIgnoreCase).Any(g => g.Count() > 1)))
        {
            Add(errors, $"approval.levels[{level.LevelNo}]", $"Level {level.LevelNo} lists the same role more than once.");
        }

        if (request.EscalationRole is { Length: > 0 } role && !System.Text.RegularExpressions.Regex.IsMatch(role, "^[A-Za-z0-9_\\-.]+$"))
        {
            Add(errors, "approval.escalationRole", "Escalation role code is invalid.");
        }

        return new ApprovalConfiguration
        {
            ApprovalPolicy = request.ApprovalPolicy,
            QuorumCount = request.QuorumCount,
            RejectionRouting = request.RejectionRouting,
            RejectionTargetActivityKey = string.IsNullOrWhiteSpace(request.RejectionTargetActivityKey) ? null : request.RejectionTargetActivityKey.Trim(),
            SlaHours = request.SlaHours,
            EscalationAfterHours = request.EscalationAfterHours,
            EscalationRole = string.IsNullOrWhiteSpace(request.EscalationRole) ? null : request.EscalationRole.Trim(),
            ReminderIntervalHours = request.ReminderIntervalHours,
            AllowDelegation = request.AllowDelegation,
            EnforceMakerCheckerSegregation = request.EnforceMakerCheckerSegregation,
            Levels = request.Levels.OrderBy(l => l.LevelNo).Select(l => new ApprovalLevel
            {
                LevelNo = l.LevelNo,
                LevelName = l.LevelName.Trim(),
                ExecutionMode = l.ExecutionMode,
                MinApprovals = l.MinApprovals,
                SlaHours = l.SlaHours,
                Roles = l.Roles.Select(r => new ApprovalLevelRole
                {
                    RoleCode = r.RoleCode.Trim(),
                    GroupName = r.GroupName?.Trim(),
                    SequenceNo = r.SequenceNo
                }).ToList()
            }).ToList()
        };
    }

    public static ActivityConnection ToConnection(ConnectionRequest request) => new()
    {
        FromActivityKey = request.FromActivityKey.Trim(),
        ToActivityKey = request.ToActivityKey.Trim(),
        ConnectionType = request.ConnectionType,
        ConditionExpression = string.IsNullOrWhiteSpace(request.ConditionExpression) ? null : request.ConditionExpression.Trim(),
        IsDefault = request.ConnectionType == ConnectionType.Conditional && request.IsDefault,
        Label = request.Label?.Trim(),
        Priority = request.Priority
    };

    public static void ThrowIfAny(Dictionary<string, List<string>> errors)
    {
        if (errors.Count > 0)
        {
            throw new BusinessValidationException("The request contains invalid values.",
                errors.ToDictionary(e => e.Key, e => e.Value.ToArray()));
        }
    }

    public static void Add(Dictionary<string, List<string>> errors, string key, string message)
    {
        if (!errors.TryGetValue(key, out var list))
        {
            errors[key] = list = new List<string>();
        }

        list.Add(message);
    }

    private static void CheckParameter(ParameterRequestBase p, Dictionary<string, List<string>> errors)
    {
        var field = $"parameters.{p.Name}";
        var typeError = ParameterValueValidator.ValidateValue(p.DataType, p.DefaultValue);
        if (typeError is not null)
        {
            Add(errors, field, typeError);
        }

        var schemaError = ParameterValueValidator.ValidateJsonSchema(p.JsonSchema);
        if (schemaError is not null)
        {
            Add(errors, field, schemaError);
        }

        var literal = p.SourceType == MappingSourceType.Literal ? p.SourceReference : null;
        var unsafeReason = ContentSafetyScanner.Inspect(p.Name, p.DefaultValue) ?? ContentSafetyScanner.Inspect(p.Name, literal);
        if (unsafeReason is not null)
        {
            Add(errors, field, unsafeReason);
        }

        if (p.SourceType == MappingSourceType.Literal && literal is not null)
        {
            var literalError = ParameterValueValidator.ValidateValue(p.DataType, literal);
            if (literalError is not null)
            {
                Add(errors, field, literalError);
            }
        }

        if (p.SourceType is MappingSourceType.WorkflowInput or MappingSourceType.ActivityOutput or MappingSourceType.ConnectionProfile or MappingSourceType.SystemVariable
            && string.IsNullOrWhiteSpace(p.SourceReference))
        {
            Add(errors, field, $"A source reference is required for mapping type {p.SourceType}.");
        }
    }
}
