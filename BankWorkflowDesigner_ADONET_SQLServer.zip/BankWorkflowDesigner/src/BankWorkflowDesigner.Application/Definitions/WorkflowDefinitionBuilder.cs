using System.Security.Cryptography;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;
using BankWorkflowDesigner.Domain.Catalog;
using BankWorkflowDesigner.Domain.Definitions;
using BankWorkflowDesigner.Domain.Entities;
using BankWorkflowDesigner.Domain.Enums;

namespace BankWorkflowDesigner.Application.Definitions;

public static class DefinitionJson
{
    /// <summary>Canonical options - used for hashing and storage. Do not change without bumping SchemaVersion.</summary>
    public static readonly JsonSerializerOptions Canonical = Create(indented: false);

    public static readonly JsonSerializerOptions Indented = Create(indented: true);

    private static JsonSerializerOptions Create(bool indented)
    {
        var options = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            WriteIndented = indented,
            Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
        };
        options.Converters.Add(new JsonStringEnumConverter());
        return options;
    }
}

public interface IWorkflowDefinitionBuilder
{
    WorkflowDefinition Build(WorkflowGraph graph, string? publishedBy, DateTime? publishedOn);

    /// <summary>Serialises the definition (indented) and returns it with its SHA-256 hash.</summary>
    (string Json, string Hash) Serialize(WorkflowDefinition definition);
}

/// <summary>Transforms a validated designer graph into the Temporal execution contract.</summary>
public sealed class WorkflowDefinitionBuilder : IWorkflowDefinitionBuilder
{
    public WorkflowDefinition Build(WorkflowGraph graph, string? publishedBy, DateTime? publishedOn)
    {
        var template = graph.Template;
        var version = graph.Version;
        var sourceSystemCode = graph.SourceSystem?.SystemCode ?? template.SourceSystemCode;
        var taskQueue = string.IsNullOrWhiteSpace(graph.SourceSystem?.DefaultTaskQueue)
            ? $"{sourceSystemCode.ToLowerInvariant()}-workflows"
            : graph.SourceSystem!.DefaultTaskQueue;

        var byKey = graph.Activities.ToDictionary(a => a.ActivityKey, StringComparer.Ordinal);
        var start = graph.Activities.FirstOrDefault(a => a.ActivityType == ActivityType.Start);

        var definition = new WorkflowDefinition
        {
            DefinitionId = $"{template.TemplateCode}:v{version.VersionNo}",
            TemplateCode = template.TemplateCode,
            WorkflowName = template.WorkflowName,
            Description = template.Description,
            Version = version.VersionNo,
            SourceSystem = new DefinitionSourceSystem
            {
                Code = sourceSystemCode,
                ApplicationName = graph.SourceSystem?.ApplicationName ?? string.Empty,
                ModuleCode = graph.Module?.ModuleCode ?? template.ModuleCode,
                ModuleName = graph.Module?.ModuleName ?? string.Empty
            },
            Temporal = new DefinitionTemporalOptions
            {
                TaskQueue = taskQueue,
                WorkflowIdPattern = $"{template.TemplateCode}-{{businessKey}}"
            },
            StartActivity = start?.ActivityKey ?? string.Empty,
            Inputs = graph.Parameters.Where(p => p.Direction == ParameterDirection.Input).OrderBy(p => p.SortOrder).ThenBy(p => p.Name, StringComparer.Ordinal).Select(MapParameter).ToList(),
            Outputs = graph.Parameters.Where(p => p.Direction == ParameterDirection.Output).OrderBy(p => p.SortOrder).ThenBy(p => p.Name, StringComparer.Ordinal).Select(MapParameter).ToList(),
            Metadata = new DefinitionMetadata
            {
                PublishedBy = publishedBy,
                PublishedOn = publishedOn,
                ChangeNotes = version.ChangeNotes
            }
        };

        // Order activities by a breadth-first walk from Start for readability; unreachable ones (if any) at the end.
        var ordered = OrderActivities(graph);
        foreach (var activity in ordered)
        {
            definition.Activities.Add(MapActivity(activity, graph, byKey));
        }

        return definition;
    }

    public (string Json, string Hash) Serialize(WorkflowDefinition definition)
    {
        definition.Metadata.DefinitionHash = null;
        var canonical = JsonSerializer.Serialize(definition, DefinitionJson.Canonical);
        var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(canonical))).ToLowerInvariant();
        definition.Metadata.DefinitionHash = hash;
        return (JsonSerializer.Serialize(definition, DefinitionJson.Indented), hash);
    }

    private static List<WorkflowActivity> OrderActivities(WorkflowGraph graph)
    {
        var outgoing = graph.Connections.ToLookup(c => c.FromActivityKey);
        var byKey = graph.Activities.ToDictionary(a => a.ActivityKey, StringComparer.Ordinal);
        var result = new List<WorkflowActivity>();
        var seen = new HashSet<string>(StringComparer.Ordinal);
        var queue = new Queue<string>();
        foreach (var start in graph.Activities.Where(a => a.ActivityType == ActivityType.Start))
        {
            queue.Enqueue(start.ActivityKey);
            seen.Add(start.ActivityKey);
        }

        while (queue.Count > 0)
        {
            var key = queue.Dequeue();
            result.Add(byKey[key]);
            foreach (var next in outgoing[key].OrderBy(c => c.Priority).ThenBy(c => c.ToActivityKey, StringComparer.Ordinal))
            {
                if (byKey.ContainsKey(next.ToActivityKey) && seen.Add(next.ToActivityKey))
                {
                    queue.Enqueue(next.ToActivityKey);
                }
            }
        }

        result.AddRange(graph.Activities.Where(a => !seen.Contains(a.ActivityKey)).OrderBy(a => a.ActivityKey, StringComparer.Ordinal));
        return result;
    }

    private static DefinitionActivity MapActivity(WorkflowActivity activity, WorkflowGraph graph, Dictionary<string, WorkflowActivity> byKey)
    {
        var descriptor = ActivityCatalog.Get(activity.ActivityType);
        var outs = graph.Connections.Where(c => c.FromActivityKey == activity.ActivityKey).ToList();
        var errorEdge = outs.FirstOrDefault(c => c.ConnectionType == ConnectionType.Error);

        var mapped = new DefinitionActivity
        {
            Key = activity.ActivityKey,
            Type = activity.ActivityType.ToString(),
            Category = descriptor.Category.ToString(),
            Name = activity.DisplayName,
            Description = activity.Description,
            StartToCloseTimeoutSeconds = activity.TimeoutSeconds,
            RetryPolicy = new DefinitionRetryPolicy
            {
                MaximumAttempts = activity.RetryMaxAttempts,
                InitialIntervalSeconds = activity.RetryInitialIntervalSeconds,
                BackoffCoefficient = activity.RetryBackoffCoefficient,
                MaximumIntervalSeconds = activity.RetryMaxIntervalSeconds,
                NonRetryableErrorTypes = activity.NonRetryableErrors.ToList()
            },
            ErrorHandling = new DefinitionErrorHandling
            {
                Strategy = activity.ErrorHandling.ToString(),
                RouteTo = activity.ErrorHandling == ErrorHandlingStrategy.RouteToActivity
                    ? activity.ErrorRouteActivityKey ?? errorEdge?.ToActivityKey
                    : null
            },
            ExecutionCondition = string.IsNullOrWhiteSpace(activity.ExecutionCondition) ? null : activity.ExecutionCondition.Trim(),
            Inputs = activity.Parameters.Where(p => p.Direction == ParameterDirection.Input).OrderBy(p => p.SortOrder).ThenBy(p => p.Name, StringComparer.Ordinal).Select(MapParameter).ToList(),
            Outputs = activity.Parameters.Where(p => p.Direction == ParameterDirection.Output).OrderBy(p => p.SortOrder).ThenBy(p => p.Name, StringComparer.Ordinal).Select(MapParameter).ToList(),
            Transitions = outs
                .Where(c => c.ConnectionType != ConnectionType.Error)
                .OrderBy(c => c.ConnectionType == ConnectionType.Conditional && c.IsDefault ? 1 : 0)
                .ThenBy(c => c.Priority)
                .ThenBy(c => c.ToActivityKey, StringComparer.Ordinal)
                .Select(c => new DefinitionTransition
                {
                    To = c.ToActivityKey,
                    Type = c.ConnectionType.ToString(),
                    Condition = c.ConnectionType == ConnectionType.Conditional && !c.IsDefault ? c.ConditionExpression?.Trim() : null,
                    IsDefault = c.IsDefault,
                    Label = c.Label,
                    Priority = c.Priority
                })
                .ToList()
        };

        // Config: only catalog-known keys, with catalog defaults filled in.
        foreach (var field in descriptor.ConfigFields)
        {
            activity.Config.TryGetValue(field.Key, out var value);
            value = string.IsNullOrWhiteSpace(value) ? field.DefaultValue : value.Trim();
            if (value is not null)
            {
                mapped.Config[field.Key] = value;
            }
        }

        if (descriptor.IsApproval && activity.Approval is { } approval)
        {
            mapped.Approval = new DefinitionApproval
            {
                Policy = approval.ApprovalPolicy.ToString(),
                QuorumCount = approval.ApprovalPolicy == ApprovalPolicy.Quorum ? approval.QuorumCount : null,
                RejectionRouting = approval.RejectionRouting.ToString(),
                RejectionTarget = ResolveRejectionTarget(activity, approval, outs, graph, byKey),
                SlaHours = approval.SlaHours,
                EscalationAfterHours = approval.EscalationAfterHours,
                EscalationRole = approval.EscalationRole,
                ReminderIntervalHours = approval.ReminderIntervalHours,
                AllowDelegation = approval.AllowDelegation,
                EnforceMakerCheckerSegregation = approval.EnforceMakerCheckerSegregation,
                Levels = approval.Levels.OrderBy(l => l.LevelNo).Select(l => new DefinitionApprovalLevel
                {
                    Level = l.LevelNo,
                    Name = l.LevelName,
                    Mode = l.ExecutionMode.ToString(),
                    MinApprovals = l.MinApprovals,
                    SlaHours = l.SlaHours,
                    Roles = l.Roles.OrderBy(r => r.SequenceNo).ThenBy(r => r.RoleCode, StringComparer.Ordinal).Select(r => new DefinitionApprovalRole
                    {
                        Role = r.RoleCode,
                        Group = r.GroupName,
                        Sequence = r.SequenceNo
                    }).ToList()
                }).ToList()
            };
        }

        return mapped;
    }

    private static string? ResolveRejectionTarget(
        WorkflowActivity activity,
        ApprovalConfiguration approval,
        List<ActivityConnection> outs,
        WorkflowGraph graph,
        Dictionary<string, WorkflowActivity> byKey)
    {
        var edge = outs.FirstOrDefault(c => c.ConnectionType == ConnectionType.Rejection);
        switch (approval.RejectionRouting)
        {
            case RejectionRouting.ToActivity:
                return approval.RejectionTargetActivityKey ?? edge?.ToActivityKey;

            case RejectionRouting.ToMaker:
                if (edge is not null)
                {
                    return edge.ToActivityKey;
                }

                // Nearest upstream Maker (breadth-first, ignoring rejection loop-backs).
                var incoming = graph.Connections.Where(c => c.ConnectionType != ConnectionType.Rejection).ToLookup(c => c.ToActivityKey);
                var visited = new HashSet<string>(StringComparer.Ordinal) { activity.ActivityKey };
                var queue = new Queue<string>(new[] { activity.ActivityKey });
                while (queue.Count > 0)
                {
                    foreach (var c in incoming[queue.Dequeue()].OrderBy(c => c.FromActivityKey, StringComparer.Ordinal))
                    {
                        if (!visited.Add(c.FromActivityKey) || !byKey.TryGetValue(c.FromActivityKey, out var candidate))
                        {
                            continue;
                        }

                        if (candidate.ActivityType == ActivityType.Maker)
                        {
                            return candidate.ActivityKey;
                        }

                        queue.Enqueue(c.FromActivityKey);
                    }
                }

                return null;

            default:
                return null;
        }
    }

    private static DefinitionParameter MapParameter(ParameterBase p)
    {
        var parameter = new DefinitionParameter
        {
            Name = p.Name,
            Type = p.DataType.ToString(),
            Required = p.IsMandatory,
            DefaultValue = p.DefaultValue,
            Description = p.Description,
            Schema = ParseSchema(p.JsonSchema)
        };

        if (p.SourceType != MappingSourceType.None)
        {
            parameter.Source = p.SourceType switch
            {
                MappingSourceType.Literal => new DefinitionValueSource { Kind = "literal", Value = p.SourceReference },
                MappingSourceType.WorkflowInput => new DefinitionValueSource { Kind = "workflowInput", Parameter = p.SourceReference },
                MappingSourceType.ActivityOutput => MapActivityOutput(p.SourceReference),
                MappingSourceType.ConnectionProfile => new DefinitionValueSource { Kind = "connectionProfile", Profile = p.SourceReference },
                MappingSourceType.SystemVariable => new DefinitionValueSource { Kind = "systemVariable", Value = p.SourceReference },
                _ => null
            };
        }

        return parameter;
    }

    private static DefinitionValueSource MapActivityOutput(string? reference)
    {
        var parts = (reference ?? string.Empty).Split('.', 2);
        return new DefinitionValueSource
        {
            Kind = "activityOutput",
            Activity = parts[0],
            Parameter = parts.Length > 1 ? parts[1] : null
        };
    }

    private static object? ParseSchema(string? schema)
    {
        if (string.IsNullOrWhiteSpace(schema))
        {
            return null;
        }

        try
        {
            using var doc = JsonDocument.Parse(schema);
            return doc.RootElement.Clone();
        }
        catch (JsonException)
        {
            return null;
        }
    }
}
