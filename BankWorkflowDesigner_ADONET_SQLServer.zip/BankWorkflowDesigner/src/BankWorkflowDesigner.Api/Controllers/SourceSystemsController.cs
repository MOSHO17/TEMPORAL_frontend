using BankWorkflowDesigner.Application.Services;
using BankWorkflowDesigner.Domain.Dtos;
using BankWorkflowDesigner.Domain.Entities;
using BankWorkflowDesigner.Domain.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BankWorkflowDesigner.Api.Controllers;

/// <summary>Registration and maintenance of source systems, their modules and authorised users.</summary>
[ApiController]
[Route("api/source-systems")]
[Produces("application/json")]
[Authorize(Policy = AppPolicies.AnyWorkflowUser)]
public sealed class SourceSystemsController : ControllerBase
{
    private readonly ISourceSystemService _service;

    public SourceSystemsController(ISourceSystemService service) => _service = service;

    /// <summary>Lists the source systems visible to the caller.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(IReadOnlyList<SourceSystem>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll(CancellationToken ct) => Ok(await _service.GetAllAsync(ct));

    /// <summary>Gets one source system with modules and authorised users.</summary>
    [HttpGet("{sourceSystemId:int}")]
    [ProducesResponseType(typeof(SourceSystem), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Get(int sourceSystemId, CancellationToken ct) => Ok(await _service.GetByIdAsync(sourceSystemId, ct));

    /// <summary>Registers a new source system (source-system administrators only).</summary>
    [HttpPost]
    [Authorize(Policy = AppPolicies.ManageSourceSystems)]
    [ProducesResponseType(typeof(SourceSystem), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Create([FromBody] CreateSourceSystemRequest request, CancellationToken ct)
    {
        var created = await _service.CreateAsync(request, ct);
        return CreatedAtAction(nameof(Get), new { sourceSystemId = created.SourceSystemId }, created);
    }

    /// <summary>Updates a source system, its modules and authorised users (optimistic concurrency via rowVersion).</summary>
    [HttpPut("{sourceSystemId:int}")]
    [Authorize(Policy = AppPolicies.ManageSourceSystems)]
    [ProducesResponseType(typeof(SourceSystem), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Update(int sourceSystemId, [FromBody] UpdateSourceSystemRequest request, CancellationToken ct) =>
        Ok(await _service.UpdateAsync(sourceSystemId, request, ct));
}
