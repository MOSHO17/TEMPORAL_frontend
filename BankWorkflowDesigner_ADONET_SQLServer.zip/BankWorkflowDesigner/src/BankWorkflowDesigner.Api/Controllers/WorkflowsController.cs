using BankWorkflowDesigner.Application.Services;
using BankWorkflowDesigner.Domain.Dtos;
using BankWorkflowDesigner.Domain.Entities;
using BankWorkflowDesigner.Domain.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BankWorkflowDesigner.Api.Controllers;

/// <summary>Workflow templates: create, edit, clone, version, validate, publish and consume definitions.</summary>
[ApiController]
[Route("api/workflows")]
[Produces("application/json")]
[Authorize(Policy = AppPolicies.AnyWorkflowUser)]
public sealed class WorkflowsController : ControllerBase
{
    private readonly IWorkflowService _workflows;

    public WorkflowsController(IWorkflowService workflows) => _workflows = workflows;

    /// <summary>Searches workflow templates the caller is authorised to see.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(PagedResult<WorkflowTemplate>), StatusCodes.Status200OK)]
    public async Task<IActionResult> Search([FromQuery] WorkflowQuery query, CancellationToken ct) => Ok(await _workflows.SearchAsync(query, ct));

    /// <summary>Gets a template with its version list and the graph of one version (latest by default).</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(WorkflowDetailResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Get(int id, [FromQuery] int? version, CancellationToken ct) => Ok(await _workflows.GetDetailAsync(id, version, ct));

    /// <summary>Creates a template with version 1 as a draft.</summary>
    [HttpPost]
    [Authorize(Policy = AppPolicies.DesignWorkflows)]
    [ProducesResponseType(typeof(WorkflowDetailResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Create([FromBody] CreateWorkflowRequest request, CancellationToken ct)
    {
        var created = await _workflows.CreateAsync(request, ct);
        return CreatedAtAction(nameof(Get), new { id = created.Template.WorkflowTemplateId }, created);
    }

    /// <summary>Imports a complete template design (activities, connections, parameters) as a new draft.</summary>
    [HttpPost("import")]
    [Authorize(Policy = AppPolicies.DesignWorkflows)]
    [RequestSizeLimit(2_000_000)]
    [ProducesResponseType(typeof(WorkflowDetailResponse), StatusCodes.Status201Created)]
    public async Task<IActionResult> Import([FromBody] WorkflowImportRequest request, CancellationToken ct)
    {
        var created = await _workflows.ImportAsync(request, ct);
        return CreatedAtAction(nameof(Get), new { id = created.Template.WorkflowTemplateId }, created);
    }

    /// <summary>Updates the template header (name, description) and the draft change notes.</summary>
    [HttpPut("{id:int}")]
    [Authorize(Policy = AppPolicies.DesignWorkflows)]
    [ProducesResponseType(typeof(WorkflowDetailResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateWorkflowRequest request, CancellationToken ct) =>
        Ok(await _workflows.UpdateAsync(id, request, ct));

    /// <summary>Clones a version of this template into a brand new template (draft v1).</summary>
    [HttpPost("{id:int}/clone")]
    [Authorize(Policy = AppPolicies.DesignWorkflows)]
    [ProducesResponseType(typeof(WorkflowDetailResponse), StatusCodes.Status201Created)]
    public async Task<IActionResult> Clone(int id, [FromBody] CloneWorkflowRequest request, CancellationToken ct)
    {
        var created = await _workflows.CloneAsync(id, request, ct);
        return CreatedAtAction(nameof(Get), new { id = created.Template.WorkflowTemplateId }, created);
    }

    /// <summary>Creates a new draft version by copying an existing (usually the published) version.</summary>
    [HttpPost("{id:int}/versions")]
    [Authorize(Policy = AppPolicies.DesignWorkflows)]
    [ProducesResponseType(typeof(WorkflowDetailResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> CreateVersion(int id, [FromBody] CreateVersionRequest request, CancellationToken ct)
    {
        var detail = await _workflows.CreateVersionAsync(id, request, ct);
        return CreatedAtAction(nameof(Get), new { id, version = detail.Graph.Version.VersionNo }, detail);
    }

    /// <summary>Version history of the template (newest first).</summary>
    [HttpGet("{id:int}/versions")]
    [ProducesResponseType(typeof(IReadOnlyList<WorkflowVersion>), StatusCodes.Status200OK)]
    public async Task<IActionResult> Versions(int id, CancellationToken ct) => Ok(await _workflows.GetVersionHistoryAsync(id, ct));

    /// <summary>Validates the latest version and stores the report (draft becomes Validated when error-free).</summary>
    [HttpPost("{id:int}/validate")]
    [Authorize(Policy = AppPolicies.ReviewWorkflows)]
    [ProducesResponseType(typeof(ValidationReport), StatusCodes.Status200OK)]
    public async Task<IActionResult> Validate(int id, CancellationToken ct) => Ok(await _workflows.ValidateAsync(id, ct));

    /// <summary>Re-validates and publishes the current draft. Published versions become immutable.</summary>
    [HttpPost("{id:int}/publish")]
    [Authorize(Policy = AppPolicies.PublishWorkflows)]
    [ProducesResponseType(typeof(PublishResult), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Publish(int id, [FromBody] PublishWorkflowRequest request, CancellationToken ct) =>
        Ok(await _workflows.PublishAsync(id, request, ct));

    /// <summary>Deactivates or re-activates a template.</summary>
    [HttpPost("{id:int}/status")]
    [Authorize(Policy = AppPolicies.PublishWorkflows)]
    [ProducesResponseType(typeof(WorkflowTemplate), StatusCodes.Status200OK)]
    public async Task<IActionResult> ChangeStatus(int id, [FromBody] ChangeWorkflowStatusRequest request, CancellationToken ct) =>
        Ok(await _workflows.ChangeStatusAsync(id, request, ct));

    /// <summary>Published (immutable) Temporal definition JSON. Defaults to the current published version.</summary>
    [HttpGet("{id:int}/definition")]
    [Authorize(Policy = AppPolicies.ReadDefinitions)]
    [Produces("application/json")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Definition(int id, [FromQuery] int? version, CancellationToken ct) =>
        Content(await _workflows.GetPublishedDefinitionAsync(id, version, ct), "application/json");

    /// <summary>Preview of the definition that would be generated from the latest (draft) version. Not for execution.</summary>
    [HttpGet("{id:int}/definition/preview")]
    [Produces("application/json")]
    public async Task<IActionResult> PreviewDefinition(int id, CancellationToken ct) =>
        Content(await _workflows.PreviewDefinitionAsync(id, ct), "application/json");

    /// <summary>Configuration audit trail of the template.</summary>
    [HttpGet("{id:int}/audit")]
    [ProducesResponseType(typeof(IReadOnlyList<AuditLogEntry>), StatusCodes.Status200OK)]
    public async Task<IActionResult> Audit(int id, CancellationToken ct) => Ok(await _workflows.GetAuditTrailAsync(id, ct));
}

/// <summary>Consumption endpoint for the Temporal execution service (lookup by template code).</summary>
[ApiController]
[Route("api/definitions")]
[Produces("application/json")]
[Authorize(Policy = AppPolicies.ReadDefinitions)]
public sealed class DefinitionsController : ControllerBase
{
    private readonly IWorkflowService _workflows;

    public DefinitionsController(IWorkflowService workflows) => _workflows = workflows;

    /// <summary>Published definition by template code. Omit version for the current published version.</summary>
    [HttpGet("{templateCode}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Get(string templateCode, [FromQuery] int? version, CancellationToken ct) =>
        Content(await _workflows.GetPublishedDefinitionByCodeAsync(templateCode, version, ct), "application/json");
}
