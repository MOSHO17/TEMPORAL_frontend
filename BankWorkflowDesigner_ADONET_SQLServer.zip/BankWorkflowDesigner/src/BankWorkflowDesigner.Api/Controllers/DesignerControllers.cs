using BankWorkflowDesigner.Application.Services;
using BankWorkflowDesigner.Domain.Dtos;
using BankWorkflowDesigner.Domain.Entities;
using BankWorkflowDesigner.Domain.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BankWorkflowDesigner.Api.Controllers;

/// <summary>Activities of the current draft version.</summary>
[ApiController]
[Route("api/workflows/{id:int}")]
[Produces("application/json")]
[Authorize(Policy = AppPolicies.DesignWorkflows)]
public sealed class ActivitiesController : ControllerBase
{
    private readonly IActivityService _activities;

    public ActivitiesController(IActivityService activities) => _activities = activities;

    /// <summary>Adds an activity. Parameters default to the activity catalog when omitted.</summary>
    [HttpPost("activities")]
    [ProducesResponseType(typeof(WorkflowActivity), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Add(int id, [FromBody] ActivityRequest request, CancellationToken ct)
    {
        var activity = await _activities.AddAsync(id, request, ct);
        return StatusCode(StatusCodes.Status201Created, activity);
    }

    /// <summary>Updates an activity (optimistic concurrency via rowVersion).</summary>
    [HttpPut("activities/{activityId:int}")]
    [ProducesResponseType(typeof(WorkflowActivity), StatusCodes.Status200OK)]
    public async Task<IActionResult> Update(int id, int activityId, [FromBody] ActivityRequest request, CancellationToken ct) =>
        Ok(await _activities.UpdateAsync(id, activityId, request, ct));

    /// <summary>Deletes an activity together with its connections.</summary>
    [HttpDelete("activities/{activityId:int}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> Delete(int id, int activityId, CancellationToken ct)
    {
        await _activities.DeleteAsync(id, activityId, ct);
        return NoContent();
    }

    /// <summary>Saves the approval configuration (levels, roles, policy, rejection routing, SLA, escalation).</summary>
    [HttpPut("activities/{activityId:int}/approval")]
    [ProducesResponseType(typeof(WorkflowActivity), StatusCodes.Status200OK)]
    public async Task<IActionResult> SaveApproval(int id, int activityId, [FromBody] ApprovalConfigRequest request, CancellationToken ct) =>
        Ok(await _activities.SaveApprovalAsync(id, activityId, request, ct));

    /// <summary>Saves canvas positions of activities.</summary>
    [HttpPut("layout")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> Layout(int id, [FromBody] UpdateLayoutRequest request, CancellationToken ct)
    {
        await _activities.UpdateLayoutAsync(id, request, ct);
        return NoContent();
    }

    /// <summary>Adds a connection (sequence, conditional, parallel, rejection or error route).</summary>
    [HttpPost("connections")]
    [ProducesResponseType(typeof(ActivityConnection), StatusCodes.Status201Created)]
    public async Task<IActionResult> AddConnection(int id, [FromBody] ConnectionRequest request, CancellationToken ct)
    {
        var connection = await _activities.AddConnectionAsync(id, request, ct);
        return StatusCode(StatusCodes.Status201Created, connection);
    }

    /// <summary>Updates a connection.</summary>
    [HttpPut("connections/{connectionId:int}")]
    [ProducesResponseType(typeof(ActivityConnection), StatusCodes.Status200OK)]
    public async Task<IActionResult> UpdateConnection(int id, int connectionId, [FromBody] ConnectionRequest request, CancellationToken ct) =>
        Ok(await _activities.UpdateConnectionAsync(id, connectionId, request, ct));

    /// <summary>Deletes a connection.</summary>
    [HttpDelete("connections/{connectionId:int}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> DeleteConnection(int id, int connectionId, CancellationToken ct)
    {
        await _activities.DeleteConnectionAsync(id, connectionId, ct);
        return NoContent();
    }
}

/// <summary>Workflow-level input / output parameters of the current draft version.</summary>
[ApiController]
[Route("api/workflows/{id:int}/parameters")]
[Produces("application/json")]
[Authorize(Policy = AppPolicies.DesignWorkflows)]
public sealed class ParametersController : ControllerBase
{
    private readonly IParameterService _parameters;

    public ParametersController(IParameterService parameters) => _parameters = parameters;

    /// <summary>Adds a workflow parameter.</summary>
    [HttpPost]
    [ProducesResponseType(typeof(WorkflowParameter), StatusCodes.Status201Created)]
    public async Task<IActionResult> Add(int id, [FromBody] WorkflowParameterRequest request, CancellationToken ct)
    {
        var parameter = await _parameters.AddAsync(id, request, ct);
        return StatusCode(StatusCodes.Status201Created, parameter);
    }

    /// <summary>Updates a workflow parameter (optimistic concurrency via rowVersion).</summary>
    [HttpPut("{parameterId:int}")]
    [ProducesResponseType(typeof(WorkflowParameter), StatusCodes.Status200OK)]
    public async Task<IActionResult> Update(int id, int parameterId, [FromBody] WorkflowParameterRequest request, CancellationToken ct) =>
        Ok(await _parameters.UpdateAsync(id, parameterId, request, ct));

    /// <summary>Deletes a workflow parameter.</summary>
    [HttpDelete("{parameterId:int}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> Delete(int id, int parameterId, CancellationToken ct)
    {
        await _parameters.DeleteAsync(id, parameterId, ct);
        return NoContent();
    }
}
