using BankWorkflowDesigner.Api.Infrastructure;
using BankWorkflowDesigner.Api.Security;
using BankWorkflowDesigner.Application.Abstractions;
using BankWorkflowDesigner.Application.Services;
using BankWorkflowDesigner.Domain.Catalog;
using BankWorkflowDesigner.Domain.Dtos;
using BankWorkflowDesigner.Domain.Entities;
using BankWorkflowDesigner.Domain.Security;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace BankWorkflowDesigner.Api.Controllers;

/// <summary>Scheduler metadata (the Quartz.NET execution service is out of scope).</summary>
[ApiController]
[Route("api/schedulers")]
[Produces("application/json")]
[Authorize(Policy = AppPolicies.AnyWorkflowUser)]
public sealed class SchedulersController : ControllerBase
{
    private readonly ISchedulerService _schedulers;

    public SchedulersController(ISchedulerService schedulers) => _schedulers = schedulers;

    /// <summary>Lists scheduler configurations visible to the caller.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(IReadOnlyList<SchedulerConfiguration>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll(CancellationToken ct) => Ok(await _schedulers.GetAllAsync(ct));

    /// <summary>Gets one scheduler configuration.</summary>
    [HttpGet("{schedulerId:int}")]
    [ProducesResponseType(typeof(SchedulerConfiguration), StatusCodes.Status200OK)]
    public async Task<IActionResult> Get(int schedulerId, CancellationToken ct) => Ok(await _schedulers.GetByIdAsync(schedulerId, ct));

    /// <summary>Creates a scheduler configuration referencing an approved Oracle query.</summary>
    [HttpPost]
    [Authorize(Policy = AppPolicies.DesignWorkflows)]
    [ProducesResponseType(typeof(SchedulerConfiguration), StatusCodes.Status201Created)]
    public async Task<IActionResult> Create([FromBody] SchedulerConfigRequest request, CancellationToken ct)
    {
        var created = await _schedulers.CreateAsync(request, ct);
        return CreatedAtAction(nameof(Get), new { schedulerId = created.SchedulerConfigId }, created);
    }

    /// <summary>Updates a scheduler configuration (optimistic concurrency via rowVersion).</summary>
    [HttpPut("{schedulerId:int}")]
    [Authorize(Policy = AppPolicies.DesignWorkflows)]
    [ProducesResponseType(typeof(SchedulerConfiguration), StatusCodes.Status200OK)]
    public async Task<IActionResult> Update(int schedulerId, [FromBody] SchedulerConfigRequest request, CancellationToken ct) =>
        Ok(await _schedulers.UpdateAsync(schedulerId, request, ct));

    /// <summary>Validates a Quartz cron expression.</summary>
    [HttpPost("validate-cron")]
    [ProducesResponseType(typeof(CronValidationResult), StatusCodes.Status200OK)]
    public IActionResult ValidateCron([FromBody] CronValidationRequest request) => Ok(_schedulers.ValidateCron(request.CronExpression));
}

/// <summary>Activity catalog and governed reference data (connection profiles, approved queries).</summary>
[ApiController]
[Produces("application/json")]
[Authorize(Policy = AppPolicies.AnyWorkflowUser)]
public sealed class ReferenceDataController : ControllerBase
{
    private readonly IReferenceDataService _reference;

    public ReferenceDataController(IReferenceDataService reference) => _reference = reference;

    /// <summary>All activity types with configuration fields and default parameters.</summary>
    [HttpGet("api/catalog/activities")]
    [ProducesResponseType(typeof(IReadOnlyCollection<ActivityDescriptor>), StatusCodes.Status200OK)]
    public IActionResult Activities() => Ok(_reference.GetActivityCatalog());

    /// <summary>Connection profiles (codes only - vault references are not exposed to the browser).</summary>
    [HttpGet("api/reference/connection-profiles")]
    public async Task<IActionResult> ConnectionProfiles(CancellationToken ct) =>
        Ok((await _reference.GetConnectionProfilesAsync(ct)).Select(p => new
        {
            p.ConnectionProfileId,
            p.ProfileCode,
            p.ProfileType,
            p.Description,
            p.Environment,
            p.SourceSystemId,
            p.IsActive
        }));

    /// <summary>Governance-approved Oracle queries (references only - SQL text is never exposed or accepted).</summary>
    [HttpGet("api/reference/approved-queries")]
    [ProducesResponseType(typeof(IReadOnlyList<ApprovedOracleQuery>), StatusCodes.Status200OK)]
    public async Task<IActionResult> ApprovedQueries(CancellationToken ct) => Ok(await _reference.GetApprovedQueriesAsync(ct));

    /// <summary>Global audit trail (source-system administrators only).</summary>
    [HttpGet("api/audit")]
    [Authorize(Policy = AppPolicies.ManageSourceSystems)]
    [ProducesResponseType(typeof(IReadOnlyList<AuditLogEntry>), StatusCodes.Status200OK)]
    public async Task<IActionResult> Audit([FromQuery] string? entityType, [FromQuery] string? entityId, [FromQuery] int maxRows = 200, CancellationToken ct = default) =>
        Ok(await _reference.GetAuditAsync(entityType, entityId, maxRows, ct));
}

/// <summary>Dashboard, current user and anti-forgery token.</summary>
[ApiController]
[Produces("application/json")]
public sealed class SessionController : ControllerBase
{
    private readonly IWorkflowService _workflows;
    private readonly ICurrentUser _user;
    private readonly IAntiforgery _antiforgery;
    private readonly IOptions<AuthenticationSettings> _authSettings;

    public SessionController(IWorkflowService workflows, ICurrentUser user, IAntiforgery antiforgery, IOptions<AuthenticationSettings> authSettings)
    {
        _workflows = workflows;
        _user = user;
        _antiforgery = antiforgery;
        _authSettings = authSettings;
    }

    /// <summary>Dashboard counters and recent configuration activity.</summary>
    [HttpGet("api/dashboard")]
    [Authorize(Policy = AppPolicies.AnyWorkflowUser)]
    [ProducesResponseType(typeof(DashboardSummary), StatusCodes.Status200OK)]
    public async Task<IActionResult> Dashboard(CancellationToken ct) => Ok(await _workflows.GetDashboardAsync(ct));

    /// <summary>The authenticated caller and application roles.</summary>
    [HttpGet("api/me")]
    [Authorize]
    [ProducesResponseType(typeof(CurrentUserResponse), StatusCodes.Status200OK)]
    public IActionResult Me() => Ok(new CurrentUserResponse
    {
        UserName = _user.UserName,
        Roles = _user.Roles.ToList(),
        AuthenticationMode = _authSettings.Value.Mode
    });

    /// <summary>Development mode only: the selectable development users.</summary>
    [HttpGet("api/security/dev-users")]
    [AllowAnonymous]
    public IActionResult DevelopmentUsers() =>
        string.Equals(_authSettings.Value.Mode, "Development", StringComparison.OrdinalIgnoreCase)
            ? Ok(_authSettings.Value.DevelopmentUsers.Select(u => new { u.UserName, u.Roles }))
            : NotFound();

    /// <summary>Issues the anti-forgery token to be echoed in the X-XSRF-TOKEN header of POST/PUT/DELETE calls.</summary>
    [HttpGet("api/security/antiforgery-token")]
    [Authorize]
    public IActionResult AntiforgeryToken()
    {
        var tokens = _antiforgery.GetAndStoreTokens(HttpContext);
        return Ok(new { token = tokens.RequestToken, headerName = AntiforgerySettings.HeaderName });
    }
}
