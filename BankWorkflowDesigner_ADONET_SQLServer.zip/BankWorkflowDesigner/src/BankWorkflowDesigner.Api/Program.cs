using BankWorkflowDesigner.Api;

var app = ApiApplication.Build(args);
app.Run();

/// <summary>Entry point marker (kept public for tooling / WebApplicationFactory-based tests).</summary>
public partial class Program
{
}
