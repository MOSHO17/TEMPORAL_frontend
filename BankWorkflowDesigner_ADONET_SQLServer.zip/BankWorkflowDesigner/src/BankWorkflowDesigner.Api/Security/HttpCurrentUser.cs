using System.Security.Claims;
using BankWorkflowDesigner.Api.Infrastructure;
using BankWorkflowDesigner.Application.Abstractions;
using BankWorkflowDesigner.Domain.Security;

namespace BankWorkflowDesigner.Api.Security;

/// <summary>Resolves the caller from the authenticated HTTP context.</summary>
public sealed class HttpCurrentUser : ICurrentUser
{
    private readonly IHttpContextAccessor _accessor;

    public HttpCurrentUser(IHttpContextAccessor accessor) => _accessor = accessor;

    private ClaimsPrincipal? Principal => _accessor.HttpContext?.User;

    public string UserName => Principal?.Identity?.Name ?? "anonymous";

    public bool IsAuthenticated => Principal?.Identity?.IsAuthenticated == true;

    public IReadOnlyCollection<string> Roles => AppRoles.All.Where(IsInRole).ToList();

    public bool IsInRole(string role) => Principal?.IsInRole(role) == true;

    public string? CorrelationId => _accessor.HttpContext?.Items[CorrelationIdMiddleware.ItemKey] as string;

    public string? ClientIp => _accessor.HttpContext?.Connection.RemoteIpAddress?.ToString();
}
