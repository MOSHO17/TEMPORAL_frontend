using System.Security.Claims;
using System.Text.Encodings.Web;
using BankWorkflowDesigner.Domain.Security;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;

namespace BankWorkflowDesigner.Api.Security;

public sealed class AuthenticationSettings
{
    public const string SectionName = "Authentication";

    /// <summary>Windows (AD via IIS / HTTP.sys integrated auth), Jwt (enterprise IAM / OIDC bearer tokens) or Development.</summary>
    public string Mode { get; set; } = "Windows";

    public JwtSettings Jwt { get; set; } = new();

    /// <summary>Maps application roles to AD groups / IAM role claims, e.g. "WF_DESIGNER": ["BANK\\WF-Designers"].</summary>
    public Dictionary<string, string[]> RoleMappings { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    public List<DevelopmentUser> DevelopmentUsers { get; set; } = new();

    /// <summary>Safety switch: Development mode is refused outside the Development environment unless explicitly allowed (e.g. SIT test rigs).</summary>
    public bool AllowDevelopmentModeOutsideDevelopment { get; set; }
}

public sealed class JwtSettings
{
    public string Authority { get; set; } = string.Empty;
    public string Audience { get; set; } = string.Empty;
    public bool RequireHttpsMetadata { get; set; } = true;
    public string RoleClaimType { get; set; } = "roles";
    public string NameClaimType { get; set; } = "preferred_username";
}

public sealed class DevelopmentUser
{
    public string UserName { get; set; } = string.Empty;
    public string[] Roles { get; set; } = Array.Empty<string>();
}

public static class AuthenticationSetup
{
    public const string DevelopmentScheme = "Development";
    public const string DevelopmentUserHeader = "X-Dev-User";
    public const string WindowsScheme = "Windows";

    public static IServiceCollection AddEnterpriseAuthentication(this IServiceCollection services, IConfiguration configuration, IHostEnvironment environment)
    {
        var settings = configuration.GetSection(AuthenticationSettings.SectionName).Get<AuthenticationSettings>() ?? new AuthenticationSettings();
        services.Configure<AuthenticationSettings>(configuration.GetSection(AuthenticationSettings.SectionName));

        switch (settings.Mode.ToUpperInvariant())
        {
            case "DEVELOPMENT":
                if (!environment.IsDevelopment() && !settings.AllowDevelopmentModeOutsideDevelopment)
                {
                    throw new InvalidOperationException("Development authentication is not allowed outside the Development environment.");
                }

                services.AddAuthentication(DevelopmentScheme)
                    .AddScheme<AuthenticationSchemeOptions, DevelopmentAuthenticationHandler>(DevelopmentScheme, _ => { });
                break;

            case "JWT":
                services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                    .AddJwtBearer(options =>
                    {
                        options.Authority = settings.Jwt.Authority;
                        options.Audience = settings.Jwt.Audience;
                        options.RequireHttpsMetadata = settings.Jwt.RequireHttpsMetadata;
                        options.MapInboundClaims = false;
                        options.TokenValidationParameters.RoleClaimType = settings.Jwt.RoleClaimType;
                        options.TokenValidationParameters.NameClaimType = settings.Jwt.NameClaimType;
                        options.TokenValidationParameters.ValidateIssuer = true;
                        options.TokenValidationParameters.ValidateAudience = true;
                        options.TokenValidationParameters.ValidateLifetime = true;
                        options.TokenValidationParameters.ClockSkew = TimeSpan.FromMinutes(2);
                    });
                break;

            case "WINDOWS":
                // Integrated Windows (Kerberos/NTLM) authentication performed by IIS; the API reads the forwarded identity.
                services.AddAuthentication(Microsoft.AspNetCore.Server.IISIntegration.IISDefaults.AuthenticationScheme);
                break;

            default:
                throw new InvalidOperationException($"Unknown authentication mode '{settings.Mode}'. Use Windows, Jwt or Development.");
        }

        services.AddTransient<IClaimsTransformation, RoleMappingClaimsTransformation>();

        services.AddAuthorization(options =>
        {
            options.FallbackPolicy = new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build();
            options.AddPolicy(AppPolicies.AnyWorkflowUser, p => p.RequireRole(AppRoles.All));
            options.AddPolicy(AppPolicies.ManageSourceSystems, p => p.RequireRole(AppRoles.SourceSystemAdmin));
            options.AddPolicy(AppPolicies.DesignWorkflows, p => p.RequireRole(AppRoles.Designer));
            options.AddPolicy(AppPolicies.ReviewWorkflows, p => p.RequireRole(AppRoles.Reviewer, AppRoles.Designer, AppRoles.Publisher));
            options.AddPolicy(AppPolicies.PublishWorkflows, p => p.RequireRole(AppRoles.Publisher));
            options.AddPolicy(AppPolicies.ReadDefinitions, p => p.RequireRole(AppRoles.All));
        });

        return services;
    }

    /// <summary>
    /// Fail fast with a clear message when Windows authentication is configured but the app is not hosted by IIS
    /// (the "Windows" scheme is only registered by the IIS in-process / out-of-process integration).
    /// </summary>
    public static void EnsureSchemeAvailable(IServiceProvider services, IConfiguration configuration)
    {
        var mode = configuration[$"{AuthenticationSettings.SectionName}:Mode"] ?? "Windows";
        if (!string.Equals(mode, "Windows", StringComparison.OrdinalIgnoreCase))
        {
            return;
        }

        var provider = services.GetRequiredService<IAuthenticationSchemeProvider>();
        if (provider.GetSchemeAsync(WindowsScheme).GetAwaiter().GetResult() is null)
        {
            throw new InvalidOperationException(
                "Authentication:Mode is 'Windows' but the application is not hosted in IIS with Windows Authentication enabled. " +
                "Host the API in IIS (see README), or set Authentication:Mode to 'Jwt' (enterprise IAM) or 'Development' (local only).");
        }
    }
}

/// <summary>
/// Development-only authentication. The caller selects one of the pre-configured users with the X-Dev-User header;
/// roles always come from configuration, never from the request.
/// </summary>
public sealed class DevelopmentAuthenticationHandler : AuthenticationHandler<AuthenticationSchemeOptions>
{
    private readonly IOptionsMonitor<AuthenticationSettings> _settings;

    public DevelopmentAuthenticationHandler(
        IOptionsMonitor<AuthenticationSchemeOptions> options,
        ILoggerFactory logger,
        UrlEncoder encoder,
        IOptionsMonitor<AuthenticationSettings> settings)
        : base(options, logger, encoder)
    {
        _settings = settings;
    }

    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        var users = _settings.CurrentValue.DevelopmentUsers;
        if (users.Count == 0)
        {
            return Task.FromResult(AuthenticateResult.Fail("No development users configured."));
        }

        var requested = Request.Headers[AuthenticationSetup.DevelopmentUserHeader].ToString();
        if (string.IsNullOrWhiteSpace(requested))
        {
            requested = Request.Cookies["wf-dev-user"] ?? string.Empty;
        }

        var user = string.IsNullOrWhiteSpace(requested)
            ? users[0]
            : users.FirstOrDefault(u => string.Equals(u.UserName, requested, StringComparison.OrdinalIgnoreCase));

        if (user is null)
        {
            return Task.FromResult(AuthenticateResult.Fail($"Unknown development user '{requested}'."));
        }

        var claims = new List<Claim> { new(ClaimTypes.Name, user.UserName), new(ClaimTypes.NameIdentifier, user.UserName) };
        claims.AddRange(user.Roles.Select(r => new Claim(ClaimTypes.Role, r)));
        var identity = new ClaimsIdentity(claims, Scheme.Name);
        return Task.FromResult(AuthenticateResult.Success(new AuthenticationTicket(new ClaimsPrincipal(identity), Scheme.Name)));
    }
}

/// <summary>Adds application role claims based on configured AD group / IAM role mappings.</summary>
public sealed class RoleMappingClaimsTransformation : IClaimsTransformation
{
    private readonly IOptionsMonitor<AuthenticationSettings> _settings;

    public RoleMappingClaimsTransformation(IOptionsMonitor<AuthenticationSettings> settings) => _settings = settings;

    public Task<ClaimsPrincipal> TransformAsync(ClaimsPrincipal principal)
    {
        if (principal.Identity is not ClaimsIdentity { IsAuthenticated: true } identity ||
            identity.HasClaim(c => c.Type == "wf:roles-mapped"))
        {
            return Task.FromResult(principal);
        }

        var clone = principal.Clone();
        var cloneIdentity = (ClaimsIdentity)clone.Identity!;
        foreach (var (appRole, externalGroups) in _settings.CurrentValue.RoleMappings)
        {
            if (clone.IsInRole(appRole))
            {
                continue;
            }

            // IsInRole resolves Windows groups (by name) as well as role claims from IAM tokens.
            if (externalGroups.Any(g => principal.IsInRole(g) || principal.HasClaim("groups", g)))
            {
                cloneIdentity.AddClaim(new Claim(cloneIdentity.RoleClaimType, appRole));
            }
        }

        cloneIdentity.AddClaim(new Claim("wf:roles-mapped", "1"));
        return Task.FromResult(clone);
    }
}
