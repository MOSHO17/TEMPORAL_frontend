using System.Reflection;
using System.Text.Json.Serialization;
using BankWorkflowDesigner.Api.Infrastructure;
using BankWorkflowDesigner.Api.Security;
using BankWorkflowDesigner.Application;
using BankWorkflowDesigner.Application.Abstractions;
using BankWorkflowDesigner.Infrastructure;
using Microsoft.AspNetCore.Mvc;
using Microsoft.OpenApi.Models;

namespace BankWorkflowDesigner.Api;

/// <summary>
/// Builds the API host. Kept separate from Program.Main so integration tests can build the exact same
/// pipeline and swap the SQL Server repositories for in-memory fakes.
/// </summary>
public static class ApiApplication
{
    public const string CorsPolicy = "WorkflowDesignerWeb";

    public static WebApplication Build(string[] args, Action<WebApplicationBuilder>? configureBuilder = null, Action<IServiceCollection>? overrideServices = null)
    {
        var builder = WebApplication.CreateBuilder(args);
        configureBuilder?.Invoke(builder);

        var services = builder.Services;
        var configuration = builder.Configuration;

        services.AddHttpContextAccessor();
        services.AddScoped<ICurrentUser, HttpCurrentUser>();

        services.AddApplicationServices(configuration);
        services.AddSqlServerInfrastructure(configuration);
        services.AddEnterpriseAuthentication(configuration, builder.Environment);

        services.Configure<AntiforgerySettings>(configuration.GetSection(AntiforgerySettings.SectionName));
        services.AddAntiforgery(options =>
        {
            options.HeaderName = AntiforgerySettings.HeaderName;
            options.Cookie.Name = "wf-api-xsrf";
            options.Cookie.HttpOnly = true;
            options.Cookie.SameSite = SameSiteMode.Strict;
            options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
            options.SuppressXFrameOptionsHeader = true;
        });

        services.AddScoped<ApiAntiforgeryFilter>();
        services.AddControllers(options =>
            {
                options.Filters.AddService<ApiAntiforgeryFilter>();
            })
            // Explicit so controllers are found regardless of the entry assembly (e.g. integration-test hosts).
            .AddApplicationPart(typeof(ApiApplication).Assembly)
            .AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
                options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.Never;
            })
            .ConfigureApiBehaviorOptions(options =>
            {
                options.InvalidModelStateResponseFactory = context =>
                {
                    var errors = context.ModelState
                        .Where(e => e.Value?.Errors.Count > 0)
                        .ToDictionary(
                            e => string.IsNullOrEmpty(e.Key) ? "request" : char.ToLowerInvariant(e.Key[0]) + e.Key[1..],
                            e => e.Value!.Errors.Select(x => string.IsNullOrEmpty(x.ErrorMessage) ? "Invalid value." : x.ErrorMessage).ToArray());
                    var body = ErrorWriter.Create(context.HttpContext, 400, "VALIDATION_FAILED", "One or more fields are invalid.", errors);
                    return new BadRequestObjectResult(body) { ContentTypes = { "application/problem+json" } };
                };
            });

        var allowedOrigins = configuration.GetSection("Cors:AllowedOrigins").Get<string[]>() ?? Array.Empty<string>();
        services.AddCors(options => options.AddPolicy(CorsPolicy, policy => policy
            .WithOrigins(allowedOrigins)
            .AllowCredentials()
            .WithMethods("GET", "POST", "PUT", "DELETE")
            .WithHeaders("Content-Type", "Accept", AntiforgerySettings.HeaderName, AuthenticationSetup.DevelopmentUserHeader, CorrelationIdMiddleware.HeaderName, "If-Match")
            .WithExposedHeaders(CorrelationIdMiddleware.HeaderName)
            .SetPreflightMaxAge(TimeSpan.FromMinutes(10))));

        services.AddHealthChecks().AddCheck<SqlServerHealthCheck>("sqlserver", tags: new[] { "ready" });

        services.AddEndpointsApiExplorer();
        services.AddSwaggerGen(options =>
        {
            options.SwaggerDoc("v1", new OpenApiInfo
            {
                Title = "Bank Workflow Designer API",
                Version = "v1",
                Description = "Create, configure, validate, version and publish workflow templates for the Temporal execution service."
            });

            var xml = Path.Combine(AppContext.BaseDirectory, $"{Assembly.GetExecutingAssembly().GetName().Name}.xml");
            if (File.Exists(xml))
            {
                options.IncludeXmlComments(xml);
            }

            options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
            {
                Type = SecuritySchemeType.Http,
                Scheme = "bearer",
                BearerFormat = "JWT",
                Description = "IAM access token (Authentication:Mode = Jwt)."
            });
            options.AddSecurityDefinition("DevUser", new OpenApiSecurityScheme
            {
                Type = SecuritySchemeType.ApiKey,
                In = ParameterLocation.Header,
                Name = AuthenticationSetup.DevelopmentUserHeader,
                Description = "Development only: alice.designer, rita.reviewer, bob.publisher, dev.admin, temporal.svc"
            });
            options.AddSecurityRequirement(new OpenApiSecurityRequirement
            {
                [new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" } }] = Array.Empty<string>(),
                [new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "DevUser" } }] = Array.Empty<string>()
            });
        });

        overrideServices?.Invoke(services);

        var app = builder.Build();
        AuthenticationSetup.EnsureSchemeAvailable(app.Services, configuration);

        app.UseMiddleware<CorrelationIdMiddleware>();
        app.UseMiddleware<SecurityHeadersMiddleware>();
        app.UseMiddleware<ExceptionHandlingMiddleware>();

        if (!app.Environment.IsDevelopment())
        {
            app.UseHsts();
        }

        if (configuration.GetValue("Swagger:Enabled", app.Environment.IsDevelopment()))
        {
            app.UseSwagger();
            app.UseSwaggerUI(options =>
            {
                options.SwaggerEndpoint("/swagger/v1/swagger.json", "Bank Workflow Designer API v1");
                options.DocumentTitle = "Bank Workflow Designer API";
            });
        }

        app.UseRouting();
        // Consistent JSON for 401/403/404/405 produced by the authentication / authorization / routing middleware.
        // Registered before UseAuthentication so it wraps the short-circuiting middleware.
        app.Use(async (context, next) =>
        {
            await next();
            if (!context.Response.HasStarted && context.Response.ContentLength is null && string.IsNullOrEmpty(context.Response.ContentType))
            {
                switch (context.Response.StatusCode)
                {
                    case 401:
                        await ErrorWriter.WriteAsync(context, 401, "UNAUTHENTICATED", "Authentication is required.", null);
                        break;
                    case 403:
                        await ErrorWriter.WriteAsync(context, 403, "FORBIDDEN", "You do not have the role required for this operation.", null);
                        break;
                    case 404 when context.Request.Path.StartsWithSegments("/api"):
                        await ErrorWriter.WriteAsync(context, 404, "NOT_FOUND", "Resource not found.", null);
                        break;
                    case 405:
                        await ErrorWriter.WriteAsync(context, 405, "METHOD_NOT_ALLOWED", "HTTP method not allowed.", null);
                        break;
                }
            }
        });

        app.UseCors(CorsPolicy);
        app.UseAuthentication();
        app.UseAuthorization();

        app.MapControllers();
        app.MapHealthChecks("/health/live", new Microsoft.AspNetCore.Diagnostics.HealthChecks.HealthCheckOptions { Predicate = _ => false }).AllowAnonymous();
        app.MapHealthChecks("/health/ready", new Microsoft.AspNetCore.Diagnostics.HealthChecks.HealthCheckOptions { Predicate = c => c.Tags.Contains("ready") }).AllowAnonymous();

        return app;
    }
}
