using BankWorkflowDesigner.Infrastructure.Data;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace BankWorkflowDesigner.Api.Infrastructure;

/// <summary>Readiness probe: verifies a SQL Server connection can be opened.</summary>
public sealed class SqlServerHealthCheck : IHealthCheck
{
    private readonly IServiceProvider _services;

    public SqlServerHealthCheck(IServiceProvider services) => _services = services;

    public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            var factory = _services.GetService<ISqlConnectionFactory>();
            if (factory is null)
            {
                return HealthCheckResult.Healthy("No SQL connection factory registered (test host).");
            }

            await using var connection = await factory.OpenAsync(cancellationToken);
            return HealthCheckResult.Healthy();
        }
        catch (Exception ex)
        {
            return HealthCheckResult.Unhealthy("SQL Server is not reachable.", ex);
        }
    }
}
