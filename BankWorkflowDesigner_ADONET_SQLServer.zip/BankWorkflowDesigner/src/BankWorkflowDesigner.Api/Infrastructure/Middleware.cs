using System.Text.Json;
using BankWorkflowDesigner.Domain.Dtos;
using BankWorkflowDesigner.Domain.Exceptions;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace BankWorkflowDesigner.Api.Infrastructure;

/// <summary>Propagates / creates an X-Correlation-Id for every request (stored in the audit trail).</summary>
public sealed class CorrelationIdMiddleware
{
    public const string HeaderName = "X-Correlation-Id";
    public const string ItemKey = "CorrelationId";
    private readonly RequestDelegate _next;

    public CorrelationIdMiddleware(RequestDelegate next) => _next = next;

    public async Task InvokeAsync(HttpContext context)
    {
        var incoming = context.Request.Headers[HeaderName].ToString();
        var correlationId = !string.IsNullOrWhiteSpace(incoming) && incoming.Length <= 100 && incoming.All(c => char.IsLetterOrDigit(c) || c is '-' or '_' or '.')
            ? incoming
            : Guid.NewGuid().ToString("N");

        context.Items[ItemKey] = correlationId;
        context.TraceIdentifier = correlationId;
        context.Response.OnStarting(() =>
        {
            context.Response.Headers[HeaderName] = correlationId;
            return Task.CompletedTask;
        });

        await _next(context);
    }
}

/// <summary>Adds defensive HTTP security headers to every API response.</summary>
public sealed class SecurityHeadersMiddleware
{
    private readonly RequestDelegate _next;

    public SecurityHeadersMiddleware(RequestDelegate next) => _next = next;

    public async Task InvokeAsync(HttpContext context)
    {
        context.Response.OnStarting(() =>
        {
            var headers = context.Response.Headers;
            headers["X-Content-Type-Options"] = "nosniff";
            headers["X-Frame-Options"] = "DENY";
            headers["Referrer-Policy"] = "no-referrer";
            headers["Cache-Control"] = "no-store";
            if (!context.Request.Path.StartsWithSegments("/swagger"))
            {
                headers["Content-Security-Policy"] = "default-src 'none'; frame-ancestors 'none'";
            }

            return Task.CompletedTask;
        });

        await _next(context);
    }
}

/// <summary>Maps exceptions to the consistent <see cref="ErrorResponse"/> payload.</summary>
public sealed class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionHandlingMiddleware> _logger;
    private readonly IHostEnvironment _environment;

    public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger, IHostEnvironment environment)
    {
        _next = next;
        _logger = logger;
        _environment = environment;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (DomainException ex)
        {
            _logger.LogInformation("Business rule {Code} on {Path}: {Message}", ex.Code, context.Request.Path, ex.Message);
            var errors = ex is BusinessValidationException validation && validation.Errors.Count > 0
                ? validation.Errors.ToDictionary(e => e.Key, e => e.Value)
                : null;
            await ErrorWriter.WriteAsync(context, ex.HttpStatus, ex.Code, ex.Message, errors);
        }
        catch (OperationCanceledException) when (context.RequestAborted.IsCancellationRequested)
        {
            // Client disconnected - nothing to write.
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unhandled error on {Method} {Path}", context.Request.Method, context.Request.Path);
            var detail = _environment.IsDevelopment() ? ex.Message : "An unexpected error occurred. Quote the trace id when contacting support.";
            await ErrorWriter.WriteAsync(context, StatusCodes.Status500InternalServerError, "INTERNAL_ERROR", detail, null);
        }
    }
}

public static class ErrorWriter
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    public static ErrorResponse Create(HttpContext context, int status, string code, string detail, IDictionary<string, string[]>? errors) => new()
    {
        Type = $"https://httpstatuses.io/{status}",
        Title = ReasonPhrase(status),
        Status = status,
        Code = code,
        Detail = detail,
        TraceId = context.TraceIdentifier,
        Errors = errors is null ? null : new Dictionary<string, string[]>(errors)
    };

    public static async Task WriteAsync(HttpContext context, int status, string code, string detail, IDictionary<string, string[]>? errors)
    {
        if (context.Response.HasStarted)
        {
            return;
        }

        context.Response.Clear();
        context.Response.StatusCode = status;
        context.Response.ContentType = "application/problem+json";
        await context.Response.WriteAsync(JsonSerializer.Serialize(Create(context, status, code, detail, errors), JsonOptions));
    }

    private static string ReasonPhrase(int status) => status switch
    {
        400 => "Bad Request",
        401 => "Unauthorized",
        403 => "Forbidden",
        404 => "Not Found",
        409 => "Conflict",
        415 => "Unsupported Media Type",
        _ => status >= 500 ? "Server Error" : "Error"
    };
}

public sealed class AntiforgerySettings
{
    public const string SectionName = "Antiforgery";
    public bool Enabled { get; set; } = true;
    public const string HeaderName = "X-XSRF-TOKEN";
}

/// <summary>
/// CSRF protection for cookie / Windows-authenticated browser calls: every state-changing request must echo
/// the token issued by GET /api/security/antiforgery-token in the X-XSRF-TOKEN header.
/// Bearer-token callers (service-to-service) are exempt because browsers never attach bearer tokens automatically.
/// </summary>
public sealed class ApiAntiforgeryFilter : IAsyncAuthorizationFilter
{
    private readonly IAntiforgery _antiforgery;
    private readonly Microsoft.Extensions.Options.IOptions<AntiforgerySettings> _settings;

    public ApiAntiforgeryFilter(IAntiforgery antiforgery, Microsoft.Extensions.Options.IOptions<AntiforgerySettings> settings)
    {
        _antiforgery = antiforgery;
        _settings = settings;
    }

    public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
    {
        var request = context.HttpContext.Request;
        if (!_settings.Value.Enabled || HttpMethods.IsGet(request.Method) || HttpMethods.IsHead(request.Method) || HttpMethods.IsOptions(request.Method))
        {
            return;
        }

        if (request.Headers.Authorization.ToString().StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
        {
            return;
        }

        if (context.ActionDescriptor.EndpointMetadata.OfType<IgnoreAntiforgeryTokenAttribute>().Any())
        {
            return;
        }

        try
        {
            await _antiforgery.ValidateRequestAsync(context.HttpContext);
        }
        catch (AntiforgeryValidationException)
        {
            context.Result = new ObjectResult(ErrorWriter.Create(context.HttpContext, 400, "ANTIFORGERY_FAILED",
                "Missing or invalid anti-forgery token. Reload the page and try again.", null))
            {
                StatusCode = 400,
                ContentTypes = { "application/problem+json" }
            };
        }
    }
}
