namespace BankWorkflowDesigner.Domain.Exceptions;

/// <summary>Base class for all expected business errors. Mapped to HTTP responses by the API error middleware.</summary>
public abstract class DomainException : Exception
{
    protected DomainException(string code, string message, int httpStatus) : base(message)
    {
        Code = code;
        HttpStatus = httpStatus;
    }

    public string Code { get; }
    public int HttpStatus { get; }
}

public sealed class NotFoundException : DomainException
{
    public NotFoundException(string message) : base("NOT_FOUND", message, 404) { }
}

public sealed class BusinessValidationException : DomainException
{
    public BusinessValidationException(string message, IDictionary<string, string[]>? errors = null)
        : base("VALIDATION_FAILED", message, 400)
    {
        Errors = errors is null
            ? new Dictionary<string, string[]>()
            : new Dictionary<string, string[]>(errors);
    }

    public BusinessValidationException(string field, string message)
        : this(message, new Dictionary<string, string[]> { [field] = new[] { message } }) { }

    public IReadOnlyDictionary<string, string[]> Errors { get; }
}

public sealed class ConflictException : DomainException
{
    public ConflictException(string message, string code = "CONFLICT") : base(code, message, 409) { }
}

public sealed class ConcurrencyException : DomainException
{
    public ConcurrencyException(string message = "The record was modified by another user. Reload and try again.")
        : base("CONCURRENCY_CONFLICT", message, 409) { }
}

public sealed class ImmutableVersionException : DomainException
{
    public ImmutableVersionException(string message = "Published or superseded workflow versions are immutable. Create a new version to make changes.")
        : base("VERSION_IMMUTABLE", message, 409) { }
}

public sealed class ForbiddenException : DomainException
{
    public ForbiddenException(string message) : base("FORBIDDEN", message, 403) { }
}
