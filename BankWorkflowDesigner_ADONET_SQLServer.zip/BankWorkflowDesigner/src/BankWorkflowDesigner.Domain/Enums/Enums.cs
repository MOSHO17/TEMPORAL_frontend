namespace BankWorkflowDesigner.Domain.Enums;

/// <summary>All node types that can be placed on the designer canvas.</summary>
public enum ActivityType
{
    // Control-flow nodes
    Start,
    End,
    Decision,
    ParallelSplit,
    ParallelJoin,

    // Human-task activities
    Maker,
    Checker,
    Approver,
    MultilevelApprover,
    SequentialApprover,
    ParallelApprover,

    // Integration activities
    SftpFilePush,
    SftpFilePull,
    ApiDataPush,
    ApiDataPull,

    // File activities
    FileGeneration,
    FileReading,

    // Scheduler activity
    ScheduledOracleQuery
}

public enum ActivityCategory
{
    Control,
    HumanTask,
    Integration,
    File,
    Scheduler
}

public enum ConnectionType
{
    /// <summary>Normal sequential transition.</summary>
    Sequence,
    /// <summary>Transition taken only when the condition expression evaluates true.</summary>
    Conditional,
    /// <summary>Branch of a parallel split.</summary>
    Parallel,
    /// <summary>Loop-back route taken when an approval activity is rejected.</summary>
    Rejection,
    /// <summary>Route taken when the source activity fails after all retries.</summary>
    Error
}

public enum VersionStatus
{
    Draft,
    Validated,
    Published,
    Superseded,
    Deactivated
}

public enum TemplateStatus
{
    Active,
    Inactive
}

public enum EntityStatus
{
    Active,
    Inactive
}

public enum ParameterDirection
{
    Input,
    Output
}

public enum ParameterDataType
{
    String,
    Integer,
    Decimal,
    Boolean,
    Date,
    DateTime,
    Json,
    Array,
    File
}

public enum MappingSourceType
{
    /// <summary>No mapping - value comes from the default value (or is an output).</summary>
    None,
    /// <summary>Constant literal value.</summary>
    Literal,
    /// <summary>A workflow-level input parameter.</summary>
    WorkflowInput,
    /// <summary>An output parameter of an upstream activity.</summary>
    ActivityOutput,
    /// <summary>A reference to a secured connection profile (never the secret itself).</summary>
    ConnectionProfile,
    /// <summary>Runtime system variable, e.g. sys.workflowId, sys.now, sys.initiator.</summary>
    SystemVariable
}

public enum ErrorHandlingStrategy
{
    FailWorkflow,
    Continue,
    RouteToActivity,
    Terminate
}

public enum ApprovalPolicy
{
    AnyOne,
    All,
    Majority,
    Quorum
}

public enum RejectionRouting
{
    ToMaker,
    ToPreviousLevel,
    ToActivity,
    Terminate
}

public enum LevelExecutionMode
{
    Sequential,
    Parallel
}

public enum SourceSystemAccessRole
{
    Administrator,
    Designer,
    Reviewer,
    Publisher,
    Viewer
}

public enum ConnectionProfileType
{
    Sftp,
    Api,
    Oracle
}

public enum TargetVersionPolicy
{
    LatestPublished,
    Pinned
}

public enum MisfirePolicy
{
    FireNow,
    DoNothing,
    FireOnceNow
}
