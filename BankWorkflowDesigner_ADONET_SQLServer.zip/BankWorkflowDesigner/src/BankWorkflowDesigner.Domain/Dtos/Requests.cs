using System.ComponentModel.DataAnnotations;
using BankWorkflowDesigner.Domain.Enums;

namespace BankWorkflowDesigner.Domain.Dtos;

internal static class Patterns
{
    public const string Code = "^[A-Z][A-Z0-9_\\-]{1,49}$";
    public const string CodeMessage = "Use 2-50 characters: uppercase letters, digits, '_' or '-', starting with a letter.";
    public const string Key = "^[a-zA-Z][a-zA-Z0-9_]{0,99}$";
    public const string KeyMessage = "Use letters, digits or '_' starting with a letter (max 100).";
}

// ---------------------------------------------------------------- Source systems

public sealed class ModuleRequest
{
    [Required, RegularExpression(Patterns.Code, ErrorMessage = Patterns.CodeMessage)]
    public string ModuleCode { get; set; } = string.Empty;

    [Required, StringLength(200, MinimumLength = 2)]
    public string ModuleName { get; set; } = string.Empty;

    [StringLength(1000)]
    public string? Description { get; set; }

    public EntityStatus Status { get; set; } = EntityStatus.Active;
}

public sealed class SourceSystemUserRequest
{
    [Required, StringLength(256, MinimumLength = 2)]
    [RegularExpression("^[A-Za-z0-9._@\\\\\\-]+$", ErrorMessage = "Principal may contain letters, digits, '.', '_', '-', '@' and '\\'.")]
    public string UserPrincipal { get; set; } = string.Empty;

    [StringLength(200)]
    public string? DisplayName { get; set; }

    public SourceSystemAccessRole AccessRole { get; set; } = SourceSystemAccessRole.Viewer;

    public bool IsActive { get; set; } = true;
}

public sealed class CreateSourceSystemRequest
{
    [Required, RegularExpression(Patterns.Code, ErrorMessage = Patterns.CodeMessage)]
    public string SystemCode { get; set; } = string.Empty;

    [Required, StringLength(200, MinimumLength = 2)]
    public string ApplicationName { get; set; } = string.Empty;

    [StringLength(1000)]
    public string? Description { get; set; }

    [StringLength(200)]
    [RegularExpression("^[a-zA-Z0-9._\\-]*$", ErrorMessage = "Task queue may contain letters, digits, '.', '_' and '-'.")]
    public string? DefaultTaskQueue { get; set; }

    public EntityStatus Status { get; set; } = EntityStatus.Active;

    public List<ModuleRequest> Modules { get; set; } = new();

    public List<SourceSystemUserRequest> AuthorizedUsers { get; set; } = new();
}

public sealed class UpdateSourceSystemRequest
{
    [Required, StringLength(200, MinimumLength = 2)]
    public string ApplicationName { get; set; } = string.Empty;

    [StringLength(1000)]
    public string? Description { get; set; }

    [StringLength(200)]
    [RegularExpression("^[a-zA-Z0-9._\\-]*$", ErrorMessage = "Task queue may contain letters, digits, '.', '_' and '-'.")]
    public string? DefaultTaskQueue { get; set; }

    public EntityStatus Status { get; set; } = EntityStatus.Active;

    public List<ModuleRequest> Modules { get; set; } = new();

    public List<SourceSystemUserRequest> AuthorizedUsers { get; set; } = new();

    [Required]
    public string RowVersion { get; set; } = string.Empty;
}

// ---------------------------------------------------------------- Workflow templates

public sealed class CreateWorkflowRequest
{
    [Range(1, int.MaxValue)]
    public int SourceSystemId { get; set; }

    [Range(1, int.MaxValue)]
    public int ModuleId { get; set; }

    [Required, RegularExpression(Patterns.Code, ErrorMessage = Patterns.CodeMessage)]
    public string TemplateCode { get; set; } = string.Empty;

    [Required, StringLength(200, MinimumLength = 3)]
    public string WorkflowName { get; set; } = string.Empty;

    [StringLength(2000)]
    public string? Description { get; set; }

    [StringLength(2000)]
    public string? ChangeNotes { get; set; }

    /// <summary>When true a Start and End node are created automatically.</summary>
    public bool AddStartAndEnd { get; set; } = true;
}

public sealed class UpdateWorkflowRequest
{
    [Required, StringLength(200, MinimumLength = 3)]
    public string WorkflowName { get; set; } = string.Empty;

    [StringLength(2000)]
    public string? Description { get; set; }

    [StringLength(2000)]
    public string? ChangeNotes { get; set; }

    /// <summary>Row version of the template header as last read by the client.</summary>
    [Required]
    public string RowVersion { get; set; } = string.Empty;
}

public sealed class CloneWorkflowRequest
{
    [Required, RegularExpression(Patterns.Code, ErrorMessage = Patterns.CodeMessage)]
    public string NewTemplateCode { get; set; } = string.Empty;

    [Required, StringLength(200, MinimumLength = 3)]
    public string WorkflowName { get; set; } = string.Empty;

    /// <summary>Target source system; defaults to the source template's system.</summary>
    public int? SourceSystemId { get; set; }

    public int? ModuleId { get; set; }

    /// <summary>Version to clone; defaults to the latest version.</summary>
    public int? FromVersionNo { get; set; }
}

public sealed class CreateVersionRequest
{
    /// <summary>Version to copy; defaults to the latest published version, or latest version if none published.</summary>
    public int? BasedOnVersionNo { get; set; }

    [StringLength(2000)]
    public string? ChangeNotes { get; set; }
}

public sealed class PublishWorkflowRequest
{
    /// <summary>Draft version number the publisher reviewed. Guards against publishing something else.</summary>
    [Range(1, int.MaxValue)]
    public int VersionNo { get; set; }

    [StringLength(2000)]
    public string? Comments { get; set; }
}

public sealed class ChangeWorkflowStatusRequest
{
    public TemplateStatus Status { get; set; }

    [Required, StringLength(1000, MinimumLength = 5)]
    public string Reason { get; set; } = string.Empty;
}

// ---------------------------------------------------------------- Activities

public sealed class RetryPolicyRequest
{
    [Range(1, 100)]
    public int MaxAttempts { get; set; } = 3;

    [Range(1, 86400)]
    public int InitialIntervalSeconds { get; set; } = 5;

    [Range(typeof(decimal), "1.0", "10.0")]
    public decimal BackoffCoefficient { get; set; } = 2.0m;

    [Range(1, 86400)]
    public int MaxIntervalSeconds { get; set; } = 300;

    public List<string> NonRetryableErrors { get; set; } = new();
}

public class ParameterRequestBase
{
    public ParameterDirection Direction { get; set; } = ParameterDirection.Input;

    [Required, RegularExpression(Patterns.Key, ErrorMessage = Patterns.KeyMessage)]
    public string Name { get; set; } = string.Empty;

    public ParameterDataType DataType { get; set; } = ParameterDataType.String;

    public bool IsMandatory { get; set; }

    [StringLength(4000)]
    public string? DefaultValue { get; set; }

    [StringLength(8000)]
    public string? JsonSchema { get; set; }

    [StringLength(1000)]
    public string? Description { get; set; }

    public MappingSourceType SourceType { get; set; } = MappingSourceType.None;

    [StringLength(500)]
    public string? SourceReference { get; set; }

    [Range(0, 10000)]
    public int SortOrder { get; set; }
}

public sealed class ActivityParameterRequest : ParameterRequestBase
{
}

public sealed class WorkflowParameterRequest : ParameterRequestBase
{
    /// <summary>Required for updates.</summary>
    public string? RowVersion { get; set; }
}

public sealed class ApprovalLevelRoleRequest
{
    [Required, StringLength(100, MinimumLength = 2)]
    [RegularExpression("^[A-Za-z0-9_\\-.]+$", ErrorMessage = "Role code may contain letters, digits, '_', '-' and '.'.")]
    public string RoleCode { get; set; } = string.Empty;

    [StringLength(200)]
    public string? GroupName { get; set; }

    [Range(0, 100)]
    public int SequenceNo { get; set; }
}

public sealed class ApprovalLevelRequest
{
    [Range(1, 20)]
    public int LevelNo { get; set; } = 1;

    [Required, StringLength(200, MinimumLength = 2)]
    public string LevelName { get; set; } = string.Empty;

    public LevelExecutionMode ExecutionMode { get; set; } = LevelExecutionMode.Sequential;

    [Range(1, 50)]
    public int MinApprovals { get; set; } = 1;

    [Range(1, 8760)]
    public int? SlaHours { get; set; }

    public List<ApprovalLevelRoleRequest> Roles { get; set; } = new();
}

public sealed class ApprovalConfigRequest
{
    public ApprovalPolicy ApprovalPolicy { get; set; } = ApprovalPolicy.AnyOne;

    [Range(1, 50)]
    public int? QuorumCount { get; set; }

    public RejectionRouting RejectionRouting { get; set; } = RejectionRouting.ToMaker;

    [RegularExpression(Patterns.Key, ErrorMessage = Patterns.KeyMessage)]
    public string? RejectionTargetActivityKey { get; set; }

    [Range(1, 8760)]
    public int SlaHours { get; set; } = 24;

    [Range(1, 8760)]
    public int? EscalationAfterHours { get; set; }

    [StringLength(100)]
    public string? EscalationRole { get; set; }

    [Range(1, 720)]
    public int? ReminderIntervalHours { get; set; }

    public bool AllowDelegation { get; set; }

    public bool EnforceMakerCheckerSegregation { get; set; } = true;

    public List<ApprovalLevelRequest> Levels { get; set; } = new();
}

public sealed class ActivityRequest
{
    [Required, RegularExpression(Patterns.Key, ErrorMessage = Patterns.KeyMessage)]
    public string ActivityKey { get; set; } = string.Empty;

    public ActivityType ActivityType { get; set; }

    [Required, StringLength(200, MinimumLength = 2)]
    public string DisplayName { get; set; } = string.Empty;

    [StringLength(1000)]
    public string? Description { get; set; }

    [Range(0, 20000)]
    public int PositionX { get; set; }

    [Range(0, 20000)]
    public int PositionY { get; set; }

    /// <summary>Start-to-close timeout. Null = catalog default for the activity type.</summary>
    [Range(1, 31536000)]
    public int? TimeoutSeconds { get; set; }

    /// <summary>Null = catalog default retry policy for the activity type.</summary>
    public RetryPolicyRequest? RetryPolicy { get; set; }

    public ErrorHandlingStrategy ErrorHandling { get; set; } = ErrorHandlingStrategy.FailWorkflow;

    [RegularExpression(Patterns.Key, ErrorMessage = Patterns.KeyMessage)]
    public string? ErrorRouteActivityKey { get; set; }

    [StringLength(1000)]
    public string? ExecutionCondition { get; set; }

    public Dictionary<string, string?> Config { get; set; } = new();

    /// <summary>
    /// Complete parameter set of the activity. On create, null means "use catalog defaults".
    /// On update, null means "keep existing parameters".
    /// </summary>
    public List<ActivityParameterRequest>? Parameters { get; set; }

    /// <summary>Optional inline approval configuration (approval activities only).</summary>
    public ApprovalConfigRequest? Approval { get; set; }

    /// <summary>Required for updates.</summary>
    public string? RowVersion { get; set; }
}

public sealed class ActivityPositionRequest
{
    [Required]
    public string ActivityKey { get; set; } = string.Empty;

    [Range(0, 20000)]
    public int PositionX { get; set; }

    [Range(0, 20000)]
    public int PositionY { get; set; }
}

public sealed class UpdateLayoutRequest
{
    public List<ActivityPositionRequest> Positions { get; set; } = new();
}

public sealed class ConnectionRequest
{
    [Required, RegularExpression(Patterns.Key, ErrorMessage = Patterns.KeyMessage)]
    public string FromActivityKey { get; set; } = string.Empty;

    [Required, RegularExpression(Patterns.Key, ErrorMessage = Patterns.KeyMessage)]
    public string ToActivityKey { get; set; } = string.Empty;

    public ConnectionType ConnectionType { get; set; } = ConnectionType.Sequence;

    [StringLength(1000)]
    public string? ConditionExpression { get; set; }

    public bool IsDefault { get; set; }

    [StringLength(200)]
    public string? Label { get; set; }

    [Range(0, 1000)]
    public int Priority { get; set; }
}

// ---------------------------------------------------------------- Import (used for sample templates)

public sealed class WorkflowImportRequest
{
    [Required, RegularExpression(Patterns.Code, ErrorMessage = Patterns.CodeMessage)]
    public string SourceSystemCode { get; set; } = string.Empty;

    [Required, RegularExpression(Patterns.Code, ErrorMessage = Patterns.CodeMessage)]
    public string ModuleCode { get; set; } = string.Empty;

    [Required, RegularExpression(Patterns.Code, ErrorMessage = Patterns.CodeMessage)]
    public string TemplateCode { get; set; } = string.Empty;

    [Required, StringLength(200, MinimumLength = 3)]
    public string WorkflowName { get; set; } = string.Empty;

    [StringLength(2000)]
    public string? Description { get; set; }

    public List<WorkflowParameterRequest> Parameters { get; set; } = new();

    public List<ActivityRequest> Activities { get; set; } = new();

    public List<ConnectionRequest> Connections { get; set; } = new();
}

// ---------------------------------------------------------------- Scheduler

public sealed class SchedulerConfigRequest
{
    [Required, RegularExpression(Patterns.Code, ErrorMessage = Patterns.CodeMessage)]
    public string SchedulerCode { get; set; } = string.Empty;

    [Range(1, int.MaxValue)]
    public int SourceSystemId { get; set; }

    [Required, StringLength(200, MinimumLength = 3)]
    public string SchedulerName { get; set; } = string.Empty;

    [StringLength(1000)]
    public string? Description { get; set; }

    [Range(1, int.MaxValue)]
    public int ApprovedQueryId { get; set; }

    [Required, StringLength(120)]
    public string CronExpression { get; set; } = string.Empty;

    [Required, StringLength(100)]
    public string TimeZoneId { get; set; } = "India Standard Time";

    [Range(1, int.MaxValue)]
    public int TargetWorkflowTemplateId { get; set; }

    public TargetVersionPolicy TargetVersionPolicy { get; set; } = TargetVersionPolicy.LatestPublished;

    [Range(1, int.MaxValue)]
    public int? PinnedVersionNo { get; set; }

    [StringLength(8000)]
    public string ExecutionParametersJson { get; set; } = "{}";

    public MisfirePolicy MisfirePolicy { get; set; } = MisfirePolicy.DoNothing;

    [Range(1, 10)]
    public int MaxConcurrentRuns { get; set; } = 1;

    public DateTime? EffectiveFrom { get; set; }

    public DateTime? EffectiveTo { get; set; }

    public bool IsActive { get; set; } = true;

    /// <summary>Required for updates.</summary>
    public string? RowVersion { get; set; }
}

public sealed class CronValidationRequest
{
    [Required, StringLength(120)]
    public string CronExpression { get; set; } = string.Empty;
}
