using BankWorkflowDesigner.Domain.Entities;

namespace BankWorkflowDesigner.Domain.Dtos;

/// <summary>Consistent error payload returned by every API endpoint (RFC 7807 compatible fields).</summary>
public sealed class ErrorResponse
{
    public string Type { get; set; } = "about:blank";
    public string Title { get; set; } = string.Empty;
    public int Status { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Detail { get; set; } = string.Empty;
    public string? TraceId { get; set; }
    public Dictionary<string, string[]>? Errors { get; set; }
}

public sealed class PagedResult<T>
{
    public IReadOnlyList<T> Items { get; set; } = Array.Empty<T>();
    public int TotalCount { get; set; }
    public int PageNumber { get; set; }
    public int PageSize { get; set; }
}

public sealed class WorkflowQuery
{
    public int? SourceSystemId { get; set; }
    public int? ModuleId { get; set; }
    public string? Search { get; set; }
    public string? Status { get; set; }
    public int PageNumber { get; set; } = 1;
    public int PageSize { get; set; } = 25;
}

public sealed class WorkflowDetailResponse
{
    public WorkflowTemplate Template { get; set; } = new();
    public IReadOnlyList<WorkflowVersion> Versions { get; set; } = Array.Empty<WorkflowVersion>();
    public WorkflowGraph Graph { get; set; } = new();
}

public enum IssueSeverity
{
    Error,
    Warning,
    Info
}

public sealed class ValidationIssue
{
    public IssueSeverity Severity { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
    public string? ActivityKey { get; set; }
    public string? Field { get; set; }

    public static ValidationIssue Error(string code, string message, string? activityKey = null, string? field = null) =>
        new() { Severity = IssueSeverity.Error, Code = code, Message = message, ActivityKey = activityKey, Field = field };

    public static ValidationIssue Warning(string code, string message, string? activityKey = null, string? field = null) =>
        new() { Severity = IssueSeverity.Warning, Code = code, Message = message, ActivityKey = activityKey, Field = field };
}

public sealed class ValidationReport
{
    public int WorkflowTemplateId { get; set; }
    public int VersionNo { get; set; }
    public bool IsValid => ErrorCount == 0;
    public int ErrorCount => Issues.Count(i => i.Severity == IssueSeverity.Error);
    public int WarningCount => Issues.Count(i => i.Severity == IssueSeverity.Warning);
    public List<ValidationIssue> Issues { get; set; } = new();
    public DateTime ValidatedOn { get; set; }
    public string? ValidatedBy { get; set; }
}

public sealed class PublishResult
{
    public int WorkflowTemplateId { get; set; }
    public string TemplateCode { get; set; } = string.Empty;
    public int VersionNo { get; set; }
    public string DefinitionHash { get; set; } = string.Empty;
    public DateTime PublishedOn { get; set; }
    public string PublishedBy { get; set; } = string.Empty;
}

public sealed class CronValidationResult
{
    public bool IsValid { get; set; }
    public string? Error { get; set; }
    public string? Description { get; set; }
}

public sealed class DashboardSummary
{
    public int SourceSystemCount { get; set; }
    public int TemplateCount { get; set; }
    public int DraftVersionCount { get; set; }
    public int PublishedTemplateCount { get; set; }
    public int InactiveTemplateCount { get; set; }
    public int SchedulerCount { get; set; }
    public IReadOnlyList<AuditLogEntry> RecentActivity { get; set; } = Array.Empty<AuditLogEntry>();
}

public sealed class CurrentUserResponse
{
    public string UserName { get; set; } = string.Empty;
    public IReadOnlyList<string> Roles { get; set; } = Array.Empty<string>();
    public string AuthenticationMode { get; set; } = string.Empty;
}
