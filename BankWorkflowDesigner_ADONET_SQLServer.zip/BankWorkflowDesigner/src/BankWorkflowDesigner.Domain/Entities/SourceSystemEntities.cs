using BankWorkflowDesigner.Domain.Enums;

namespace BankWorkflowDesigner.Domain.Entities;

public abstract class AuditableEntity
{
    public string CreatedBy { get; set; } = string.Empty;
    public DateTime CreatedOn { get; set; }
    public string? ModifiedBy { get; set; }
    public DateTime? ModifiedOn { get; set; }

    /// <summary>SQL Server rowversion encoded as Base64 - used for optimistic concurrency.</summary>
    public string? RowVersion { get; set; }
}

public sealed class SourceSystem : AuditableEntity
{
    public int SourceSystemId { get; set; }
    public string SystemCode { get; set; } = string.Empty;
    public string ApplicationName { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string DefaultTaskQueue { get; set; } = string.Empty;
    public EntityStatus Status { get; set; } = EntityStatus.Active;
    public List<SourceSystemModule> Modules { get; set; } = new();
    public List<SourceSystemUser> AuthorizedUsers { get; set; } = new();
}

public sealed class SourceSystemModule : AuditableEntity
{
    public int ModuleId { get; set; }
    public int SourceSystemId { get; set; }
    public string ModuleCode { get; set; } = string.Empty;
    public string ModuleName { get; set; } = string.Empty;
    public string? Description { get; set; }
    public EntityStatus Status { get; set; } = EntityStatus.Active;
}

public sealed class SourceSystemUser
{
    public int SourceSystemUserId { get; set; }
    public int SourceSystemId { get; set; }
    /// <summary>AD / IAM principal, e.g. BANK\\jdoe or jdoe@bank.com.</summary>
    public string UserPrincipal { get; set; } = string.Empty;
    public string? DisplayName { get; set; }
    public SourceSystemAccessRole AccessRole { get; set; }
    public bool IsActive { get; set; } = true;
    public string CreatedBy { get; set; } = string.Empty;
    public DateTime CreatedOn { get; set; }
}

public sealed class ConnectionProfile
{
    public int ConnectionProfileId { get; set; }
    public string ProfileCode { get; set; } = string.Empty;
    public ConnectionProfileType ProfileType { get; set; }
    public string? Description { get; set; }
    /// <summary>Reference to the secret in the enterprise vault (CyberArk / Azure Key Vault / HashiCorp). Never the secret itself.</summary>
    public string SecretStoreReference { get; set; } = string.Empty;
    public string? Environment { get; set; }
    public int? SourceSystemId { get; set; }
    public bool IsActive { get; set; } = true;
}

public sealed class ApprovedOracleQuery
{
    public int ApprovedQueryId { get; set; }
    public string QueryCode { get; set; } = string.Empty;
    public string QueryName { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int? SourceSystemId { get; set; }
    /// <summary>Oracle connection profile the governed query executes against.</summary>
    public string DataSourceProfileCode { get; set; } = string.Empty;
    /// <summary>Bind-variable names the query expects (JSON array of strings).</summary>
    public List<string> ParameterNames { get; set; } = new();
    public string? ApprovedBy { get; set; }
    public DateTime? ApprovedOn { get; set; }
    public bool IsActive { get; set; } = true;
}

public sealed class AuditLogEntry
{
    public long AuditLogId { get; set; }
    public string EntityType { get; set; } = string.Empty;
    public string EntityId { get; set; } = string.Empty;
    public string Action { get; set; } = string.Empty;
    public string UserName { get; set; } = string.Empty;
    public DateTime ActionOn { get; set; }
    public string? CorrelationId { get; set; }
    public string? ClientIp { get; set; }
    public string? Details { get; set; }
}
