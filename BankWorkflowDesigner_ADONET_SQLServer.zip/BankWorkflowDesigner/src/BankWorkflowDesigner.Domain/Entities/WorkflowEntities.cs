using BankWorkflowDesigner.Domain.Enums;

namespace BankWorkflowDesigner.Domain.Entities;

public sealed class WorkflowTemplate : AuditableEntity
{
    public int WorkflowTemplateId { get; set; }
    public string TemplateCode { get; set; } = string.Empty;
    public int SourceSystemId { get; set; }
    public string SourceSystemCode { get; set; } = string.Empty;
    public int ModuleId { get; set; }
    public string ModuleCode { get; set; } = string.Empty;
    public string WorkflowName { get; set; } = string.Empty;
    public string? Description { get; set; }
    public TemplateStatus Status { get; set; } = TemplateStatus.Active;
    public int LatestVersionNo { get; set; }
    public int? PublishedVersionNo { get; set; }
    public int? ClonedFromTemplateId { get; set; }

    /// <summary>Status of the latest version (convenience for list screens).</summary>
    public VersionStatus? LatestVersionStatus { get; set; }
}

public sealed class WorkflowVersion : AuditableEntity
{
    public int WorkflowVersionId { get; set; }
    public int WorkflowTemplateId { get; set; }
    public int VersionNo { get; set; }
    public VersionStatus Status { get; set; } = VersionStatus.Draft;
    public string? ChangeNotes { get; set; }
    public int? BasedOnVersionNo { get; set; }
    public string? ValidationResultJson { get; set; }
    public DateTime? ValidatedOn { get; set; }
    public string? ValidatedBy { get; set; }
    public string? DefinitionJson { get; set; }
    public string? DefinitionHash { get; set; }
    public DateTime? PublishedOn { get; set; }
    public string? PublishedBy { get; set; }

    public bool IsEditable => Status is VersionStatus.Draft or VersionStatus.Validated;
}

public sealed class WorkflowActivity
{
    public int ActivityId { get; set; }
    public int WorkflowVersionId { get; set; }
    /// <summary>Stable identifier used in the generated definition and in mappings (e.g. "checkerReview").</summary>
    public string ActivityKey { get; set; } = string.Empty;
    public ActivityType ActivityType { get; set; }
    public string DisplayName { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int PositionX { get; set; }
    public int PositionY { get; set; }

    public int TimeoutSeconds { get; set; } = 3600;
    public int RetryMaxAttempts { get; set; } = 3;
    public int RetryInitialIntervalSeconds { get; set; } = 5;
    public decimal RetryBackoffCoefficient { get; set; } = 2.0m;
    public int RetryMaxIntervalSeconds { get; set; } = 300;
    public List<string> NonRetryableErrors { get; set; } = new();

    public ErrorHandlingStrategy ErrorHandling { get; set; } = ErrorHandlingStrategy.FailWorkflow;
    public string? ErrorRouteActivityKey { get; set; }

    /// <summary>Optional guard - activity executes only when the expression is true, otherwise it is skipped.</summary>
    public string? ExecutionCondition { get; set; }

    /// <summary>Activity-type specific settings (see ActivityCatalog config fields).</summary>
    public Dictionary<string, string?> Config { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    public List<ActivityParameter> Parameters { get; set; } = new();
    public ApprovalConfiguration? Approval { get; set; }

    public string? RowVersion { get; set; }
    public string? ModifiedBy { get; set; }
    public DateTime? ModifiedOn { get; set; }
}

public sealed class ActivityConnection
{
    public int ConnectionId { get; set; }
    public int WorkflowVersionId { get; set; }
    public string FromActivityKey { get; set; } = string.Empty;
    public string ToActivityKey { get; set; } = string.Empty;
    public ConnectionType ConnectionType { get; set; } = ConnectionType.Sequence;
    public string? ConditionExpression { get; set; }
    /// <summary>For conditional branches - the branch taken when no other condition matches.</summary>
    public bool IsDefault { get; set; }
    public string? Label { get; set; }
    public int Priority { get; set; }
}

public abstract class ParameterBase
{
    public ParameterDirection Direction { get; set; }
    public string Name { get; set; } = string.Empty;
    public ParameterDataType DataType { get; set; } = ParameterDataType.String;
    public bool IsMandatory { get; set; }
    public string? DefaultValue { get; set; }
    public string? JsonSchema { get; set; }
    public string? Description { get; set; }
    public MappingSourceType SourceType { get; set; } = MappingSourceType.None;
    /// <summary>
    /// Source reference - interpretation depends on SourceType:
    /// Literal = value; WorkflowInput = input name; ActivityOutput = "activityKey.parameterName";
    /// ConnectionProfile = profile code; SystemVariable = "sys.xxx".
    /// </summary>
    public string? SourceReference { get; set; }
    public int SortOrder { get; set; }
}

public sealed class WorkflowParameter : ParameterBase
{
    public int ParameterId { get; set; }
    public int WorkflowVersionId { get; set; }
    public string? RowVersion { get; set; }
}

public sealed class ActivityParameter : ParameterBase
{
    public int ActivityParameterId { get; set; }
    public int ActivityId { get; set; }
}

public sealed class ApprovalConfiguration
{
    public int ApprovalConfigId { get; set; }
    public int ActivityId { get; set; }
    public ApprovalPolicy ApprovalPolicy { get; set; } = ApprovalPolicy.AnyOne;
    public int? QuorumCount { get; set; }
    public RejectionRouting RejectionRouting { get; set; } = RejectionRouting.ToMaker;
    public string? RejectionTargetActivityKey { get; set; }
    public int SlaHours { get; set; } = 24;
    public int? EscalationAfterHours { get; set; }
    public string? EscalationRole { get; set; }
    public int? ReminderIntervalHours { get; set; }
    public bool AllowDelegation { get; set; }
    /// <summary>Enforce that the maker of the request can never approve it.</summary>
    public bool EnforceMakerCheckerSegregation { get; set; } = true;
    public List<ApprovalLevel> Levels { get; set; } = new();
}

public sealed class ApprovalLevel
{
    public int ApprovalLevelId { get; set; }
    public int LevelNo { get; set; }
    public string LevelName { get; set; } = string.Empty;
    public LevelExecutionMode ExecutionMode { get; set; } = LevelExecutionMode.Sequential;
    public int MinApprovals { get; set; } = 1;
    public int? SlaHours { get; set; }
    public List<ApprovalLevelRole> Roles { get; set; } = new();
}

public sealed class ApprovalLevelRole
{
    public string RoleCode { get; set; } = string.Empty;
    public string? GroupName { get; set; }
    public int SequenceNo { get; set; }
}

/// <summary>Complete aggregate of one workflow version - everything required to validate and generate a definition.</summary>
public sealed class WorkflowGraph
{
    public WorkflowTemplate Template { get; set; } = new();
    public WorkflowVersion Version { get; set; } = new();
    public SourceSystem? SourceSystem { get; set; }
    public SourceSystemModule? Module { get; set; }
    public List<WorkflowActivity> Activities { get; set; } = new();
    public List<ActivityConnection> Connections { get; set; } = new();
    public List<WorkflowParameter> Parameters { get; set; } = new();
}

public sealed class SchedulerConfiguration : AuditableEntity
{
    public int SchedulerConfigId { get; set; }
    public string SchedulerCode { get; set; } = string.Empty;
    public int SourceSystemId { get; set; }
    public string SchedulerName { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int ApprovedQueryId { get; set; }
    public string? ApprovedQueryCode { get; set; }
    /// <summary>Quartz-format cron expression (sec min hour day-of-month month day-of-week [year]).</summary>
    public string CronExpression { get; set; } = string.Empty;
    public string TimeZoneId { get; set; } = "India Standard Time";
    public int TargetWorkflowTemplateId { get; set; }
    public string? TargetTemplateCode { get; set; }
    public TargetVersionPolicy TargetVersionPolicy { get; set; } = TargetVersionPolicy.LatestPublished;
    public int? PinnedVersionNo { get; set; }
    /// <summary>JSON object of execution parameters (bind variables and workflow inputs). Must never contain secrets.</summary>
    public string ExecutionParametersJson { get; set; } = "{}";
    public MisfirePolicy MisfirePolicy { get; set; } = MisfirePolicy.DoNothing;
    public int MaxConcurrentRuns { get; set; } = 1;
    public DateTime? EffectiveFrom { get; set; }
    public DateTime? EffectiveTo { get; set; }
    public bool IsActive { get; set; } = true;
}
