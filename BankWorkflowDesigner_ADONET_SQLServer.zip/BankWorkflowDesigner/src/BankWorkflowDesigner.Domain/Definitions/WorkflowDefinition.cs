namespace BankWorkflowDesigner.Domain.Definitions;

/// <summary>
/// Contract consumed by the separate Temporal execution service.
/// Property names are serialised in camelCase. Contains references only - never secrets.
/// </summary>
public sealed class WorkflowDefinition
{
    public string SchemaVersion { get; set; } = "1.0";
    public string DefinitionId { get; set; } = string.Empty;
    public string TemplateCode { get; set; } = string.Empty;
    public string WorkflowName { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int Version { get; set; }
    public DefinitionSourceSystem SourceSystem { get; set; } = new();
    public DefinitionTemporalOptions Temporal { get; set; } = new();
    public List<DefinitionParameter> Inputs { get; set; } = new();
    public List<DefinitionParameter> Outputs { get; set; } = new();
    public string StartActivity { get; set; } = string.Empty;
    public List<DefinitionActivity> Activities { get; set; } = new();
    public DefinitionMetadata Metadata { get; set; } = new();
}

public sealed class DefinitionSourceSystem
{
    public string Code { get; set; } = string.Empty;
    public string ApplicationName { get; set; } = string.Empty;
    public string ModuleCode { get; set; } = string.Empty;
    public string ModuleName { get; set; } = string.Empty;
}

public sealed class DefinitionTemporalOptions
{
    public string TaskQueue { get; set; } = string.Empty;
    /// <summary>Workflow type registered by the generic interpreter worker.</summary>
    public string WorkflowType { get; set; } = "DynamicBankWorkflow";
    public string WorkflowIdPattern { get; set; } = string.Empty;
    public int? ExecutionTimeoutSeconds { get; set; }
}

public sealed class DefinitionParameter
{
    public string Name { get; set; } = string.Empty;
    public string Type { get; set; } = "String";
    public bool Required { get; set; }
    public string? DefaultValue { get; set; }
    public object? Schema { get; set; }
    public string? Description { get; set; }
    public DefinitionValueSource? Source { get; set; }
}

public sealed class DefinitionValueSource
{
    /// <summary>literal | workflowInput | activityOutput | connectionProfile | systemVariable</summary>
    public string Kind { get; set; } = string.Empty;
    public string? Value { get; set; }
    public string? Activity { get; set; }
    public string? Parameter { get; set; }
    public string? Profile { get; set; }
}

public sealed class DefinitionRetryPolicy
{
    public int MaximumAttempts { get; set; }
    public int InitialIntervalSeconds { get; set; }
    public decimal BackoffCoefficient { get; set; }
    public int MaximumIntervalSeconds { get; set; }
    public List<string> NonRetryableErrorTypes { get; set; } = new();
}

public sealed class DefinitionErrorHandling
{
    public string Strategy { get; set; } = "FailWorkflow";
    public string? RouteTo { get; set; }
}

public sealed class DefinitionTransition
{
    public string To { get; set; } = string.Empty;
    public string Type { get; set; } = "Sequence";
    public string? Condition { get; set; }
    public bool IsDefault { get; set; }
    public string? Label { get; set; }
    public int Priority { get; set; }
}

public sealed class DefinitionApprovalLevel
{
    public int Level { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Mode { get; set; } = "Sequential";
    public int MinApprovals { get; set; }
    public int? SlaHours { get; set; }
    public List<DefinitionApprovalRole> Roles { get; set; } = new();
}

public sealed class DefinitionApprovalRole
{
    public string Role { get; set; } = string.Empty;
    public string? Group { get; set; }
    public int Sequence { get; set; }
}

public sealed class DefinitionApproval
{
    public string Policy { get; set; } = "AnyOne";
    public int? QuorumCount { get; set; }
    public string RejectionRouting { get; set; } = "ToMaker";
    public string? RejectionTarget { get; set; }
    public int SlaHours { get; set; }
    public int? EscalationAfterHours { get; set; }
    public string? EscalationRole { get; set; }
    public int? ReminderIntervalHours { get; set; }
    public bool AllowDelegation { get; set; }
    public bool EnforceMakerCheckerSegregation { get; set; }
    public List<DefinitionApprovalLevel> Levels { get; set; } = new();
}

public sealed class DefinitionActivity
{
    public string Key { get; set; } = string.Empty;
    public string Type { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int StartToCloseTimeoutSeconds { get; set; }
    public DefinitionRetryPolicy RetryPolicy { get; set; } = new();
    public DefinitionErrorHandling ErrorHandling { get; set; } = new();
    public string? ExecutionCondition { get; set; }
    public SortedDictionary<string, string?> Config { get; set; } = new(StringComparer.Ordinal);
    public List<DefinitionParameter> Inputs { get; set; } = new();
    public List<DefinitionParameter> Outputs { get; set; } = new();
    public DefinitionApproval? Approval { get; set; }
    public List<DefinitionTransition> Transitions { get; set; } = new();
}

public sealed class DefinitionMetadata
{
    public string? PublishedBy { get; set; }
    public DateTime? PublishedOn { get; set; }
    public string? ChangeNotes { get; set; }
    public string Generator { get; set; } = "BankWorkflowDesigner";
    /// <summary>SHA-256 over the canonical JSON of the definition with this field empty.</summary>
    public string? DefinitionHash { get; set; }
}
