namespace BankWorkflowDesigner.Domain.Security;

/// <summary>
/// Application roles. In production these are mapped from AD groups / IAM claims
/// (see "Security:RoleMappings" in appsettings).
/// </summary>
public static class AppRoles
{
    public const string SourceSystemAdmin = "WF_SOURCE_ADMIN";
    public const string Designer = "WF_DESIGNER";
    public const string Reviewer = "WF_REVIEWER";
    public const string Publisher = "WF_PUBLISHER";
    /// <summary>Service account role for the Temporal execution service reading published definitions.</summary>
    public const string DefinitionConsumer = "WF_DEFINITION_CONSUMER";

    public static readonly string[] All = { SourceSystemAdmin, Designer, Reviewer, Publisher, DefinitionConsumer };
}

public static class AppPolicies
{
    public const string AnyWorkflowUser = "AnyWorkflowUser";
    public const string ManageSourceSystems = "ManageSourceSystems";
    public const string DesignWorkflows = "DesignWorkflows";
    public const string ReviewWorkflows = "ReviewWorkflows";
    public const string PublishWorkflows = "PublishWorkflows";
    public const string ReadDefinitions = "ReadDefinitions";
}
