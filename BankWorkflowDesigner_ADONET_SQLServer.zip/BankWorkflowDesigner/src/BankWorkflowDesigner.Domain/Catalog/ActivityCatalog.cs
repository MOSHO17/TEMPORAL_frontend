using BankWorkflowDesigner.Domain.Enums;

namespace BankWorkflowDesigner.Domain.Catalog;

public enum ConfigFieldType
{
    Text,
    TextArea,
    Number,
    Boolean,
    Select,
    Role,
    ConnectionProfile,
    ApprovedQuery
}

public sealed class ConfigFieldDescriptor
{
    public string Key { get; init; } = string.Empty;
    public string Label { get; init; } = string.Empty;
    public ConfigFieldType FieldType { get; init; } = ConfigFieldType.Text;
    public bool Required { get; init; }
    public IReadOnlyList<string> Options { get; init; } = Array.Empty<string>();
    public ConnectionProfileType? ProfileType { get; init; }
    public string? DefaultValue { get; init; }
    /// <summary>Optional regular expression the value must match.</summary>
    public string? Pattern { get; init; }
    public string? HelpText { get; init; }
    public int? Min { get; init; }
    public int? Max { get; init; }
}

public sealed class ParameterTemplate
{
    public string Name { get; init; } = string.Empty;
    public ParameterDataType DataType { get; init; }
    public bool IsMandatory { get; init; }
    public string? Description { get; init; }
}

public sealed class ActivityDescriptor
{
    public ActivityType Type { get; init; }
    public ActivityCategory Category { get; init; }
    public string DisplayName { get; init; } = string.Empty;
    public string Description { get; init; } = string.Empty;
    public string Icon { get; init; } = "bi-square";
    public string Color { get; init; } = "#0d6efd";
    public bool IsControlNode => Category == ActivityCategory.Control;
    public bool IsApproval { get; init; }
    public bool IsHumanTask => Category == ActivityCategory.HumanTask;
    /// <summary>Minimum number of approval levels required (approval activities only).</summary>
    public int MinApprovalLevels { get; init; }
    public LevelExecutionMode? RequiredLevelMode { get; init; }
    public int DefaultTimeoutSeconds { get; init; } = 600;
    public int DefaultRetryAttempts { get; init; } = 3;
    public IReadOnlyList<ConfigFieldDescriptor> ConfigFields { get; init; } = Array.Empty<ConfigFieldDescriptor>();
    public IReadOnlyList<ParameterTemplate> DefaultInputs { get; init; } = Array.Empty<ParameterTemplate>();
    public IReadOnlyList<ParameterTemplate> DefaultOutputs { get; init; } = Array.Empty<ParameterTemplate>();
}

/// <summary>
/// Single source of truth for all activity types: UI toolbox, configuration forms,
/// default parameters and validation rules are all driven from this catalog.
/// </summary>
public static class ActivityCatalog
{
    private const string SafePathPattern = "^(?!.*\\.\\.)[A-Za-z0-9_\\-./{}]+$";
    private const string SafeFilePattern = "^(?!.*\\.\\.)[A-Za-z0-9_\\-.{}*:]+$";

    private static readonly ParameterTemplate[] ApprovalOutputs =
    {
        new() { Name = "outcome", DataType = ParameterDataType.String, IsMandatory = true, Description = "Approved | Rejected | Returned" },
        new() { Name = "comments", DataType = ParameterDataType.String, Description = "Approver comments" },
        new() { Name = "actionedBy", DataType = ParameterDataType.String, Description = "Principal who completed the task" },
        new() { Name = "actionedOn", DataType = ParameterDataType.DateTime, Description = "Completion timestamp" }
    };

    private static readonly ParameterTemplate[] ApprovalInputs =
    {
        new() { Name = "requestData", DataType = ParameterDataType.Json, IsMandatory = true, Description = "Business payload shown to the approver" }
    };

    private static readonly ConfigFieldDescriptor[] ApprovalConfigFields =
    {
        new() { Key = "formCode", Label = "Task form code", FieldType = ConfigFieldType.Text, Required = true, Pattern = "^[A-Z][A-Z0-9_\\-]{1,49}$", HelpText = "UI form rendered in the approval inbox" },
        new() { Key = "allowComments", Label = "Allow comments", FieldType = ConfigFieldType.Boolean, DefaultValue = "true" },
        new() { Key = "mandatoryRejectionComments", Label = "Comments mandatory on rejection", FieldType = ConfigFieldType.Boolean, DefaultValue = "true" }
    };

    private static readonly IReadOnlyDictionary<ActivityType, ActivityDescriptor> Descriptors = Build();

    public static IReadOnlyCollection<ActivityDescriptor> All => Descriptors.Values.ToList();

    public static ActivityDescriptor Get(ActivityType type) => Descriptors[type];

    public static bool IsApproval(ActivityType type) => Descriptors[type].IsApproval;

    private static Dictionary<ActivityType, ActivityDescriptor> Build()
    {
        var list = new List<ActivityDescriptor>
        {
            // ------------------------------------------------ Control flow
            new()
            {
                Type = ActivityType.Start, Category = ActivityCategory.Control, DisplayName = "Start",
                Description = "Entry point of the workflow. Exactly one per workflow.",
                Icon = "bi-play-circle", Color = "#198754", DefaultTimeoutSeconds = 60, DefaultRetryAttempts = 1
            },
            new()
            {
                Type = ActivityType.End, Category = ActivityCategory.Control, DisplayName = "End / Terminate",
                Description = "Terminates the workflow with the configured outcome.",
                Icon = "bi-stop-circle", Color = "#dc3545", DefaultTimeoutSeconds = 60, DefaultRetryAttempts = 1,
                ConfigFields = new[]
                {
                    new ConfigFieldDescriptor { Key = "outcome", Label = "Workflow outcome", FieldType = ConfigFieldType.Select, Required = true,
                        Options = new[] { "Completed", "Rejected", "Cancelled", "Failed" }, DefaultValue = "Completed" },
                    new ConfigFieldDescriptor { Key = "reason", Label = "Termination reason", FieldType = ConfigFieldType.Text }
                }
            },
            new()
            {
                Type = ActivityType.Decision, Category = ActivityCategory.Control, DisplayName = "Decision",
                Description = "Conditional branching. Each outgoing Conditional connection carries a condition; one may be the default.",
                Icon = "bi-signpost-split", Color = "#fd7e14", DefaultTimeoutSeconds = 60, DefaultRetryAttempts = 1
            },
            new()
            {
                Type = ActivityType.ParallelSplit, Category = ActivityCategory.Control, DisplayName = "Parallel Split",
                Description = "Starts all outgoing Parallel branches concurrently.",
                Icon = "bi-diagram-3", Color = "#6f42c1", DefaultTimeoutSeconds = 60, DefaultRetryAttempts = 1
            },
            new()
            {
                Type = ActivityType.ParallelJoin, Category = ActivityCategory.Control, DisplayName = "Parallel Join",
                Description = "Waits for parallel branches to complete.",
                Icon = "bi-bezier2", Color = "#6f42c1", DefaultTimeoutSeconds = 86400, DefaultRetryAttempts = 1,
                ConfigFields = new[]
                {
                    new ConfigFieldDescriptor { Key = "joinPolicy", Label = "Join policy", FieldType = ConfigFieldType.Select, Required = true,
                        Options = new[] { "WaitForAll", "WaitForAny" }, DefaultValue = "WaitForAll" }
                }
            },

            // ------------------------------------------------ Human tasks
            new()
            {
                Type = ActivityType.Maker, Category = ActivityCategory.HumanTask, DisplayName = "Maker",
                Description = "Initiator captures or corrects the request data.",
                Icon = "bi-pencil-square", Color = "#0d6efd", DefaultTimeoutSeconds = 604800, DefaultRetryAttempts = 1,
                ConfigFields = new[]
                {
                    new ConfigFieldDescriptor { Key = "assignedRole", Label = "Maker role", FieldType = ConfigFieldType.Role, Required = true },
                    new ConfigFieldDescriptor { Key = "formCode", Label = "Task form code", FieldType = ConfigFieldType.Text, Required = true, Pattern = "^[A-Z][A-Z0-9_\\-]{1,49}$" },
                    new ConfigFieldDescriptor { Key = "instructions", Label = "Instructions", FieldType = ConfigFieldType.TextArea }
                },
                DefaultInputs = new[] { new ParameterTemplate { Name = "requestData", DataType = ParameterDataType.Json, Description = "Pre-filled data (optional)" } },
                DefaultOutputs = new[]
                {
                    new ParameterTemplate { Name = "outcome", DataType = ParameterDataType.String, IsMandatory = true, Description = "Submitted | Cancelled" },
                    new ParameterTemplate { Name = "formData", DataType = ParameterDataType.Json, IsMandatory = true, Description = "Data captured by the maker" },
                    new ParameterTemplate { Name = "makerId", DataType = ParameterDataType.String, Description = "Principal of the maker" }
                }
            },
            new()
            {
                Type = ActivityType.Checker, Category = ActivityCategory.HumanTask, DisplayName = "Checker",
                Description = "Single-level verification of the maker's submission (maker-checker).",
                Icon = "bi-check2-square", Color = "#0d6efd", IsApproval = true, MinApprovalLevels = 1,
                DefaultTimeoutSeconds = 259200, DefaultRetryAttempts = 1,
                ConfigFields = ApprovalConfigFields, DefaultInputs = ApprovalInputs, DefaultOutputs = ApprovalOutputs
            },
            new()
            {
                Type = ActivityType.Approver, Category = ActivityCategory.HumanTask, DisplayName = "Approver",
                Description = "Single approval step by an authorised role.",
                Icon = "bi-person-check", Color = "#0d6efd", IsApproval = true, MinApprovalLevels = 1,
                DefaultTimeoutSeconds = 259200, DefaultRetryAttempts = 1,
                ConfigFields = ApprovalConfigFields, DefaultInputs = ApprovalInputs, DefaultOutputs = ApprovalOutputs
            },
            new()
            {
                Type = ActivityType.MultilevelApprover, Category = ActivityCategory.HumanTask, DisplayName = "Multilevel Approver",
                Description = "Two or more approval levels (e.g. Branch -> Zonal -> Credit Committee), escalating level by level.",
                Icon = "bi-bar-chart-steps", Color = "#0a58ca", IsApproval = true, MinApprovalLevels = 2,
                DefaultTimeoutSeconds = 604800, DefaultRetryAttempts = 1,
                ConfigFields = ApprovalConfigFields, DefaultInputs = ApprovalInputs, DefaultOutputs = ApprovalOutputs
            },
            new()
            {
                Type = ActivityType.SequentialApprover, Category = ActivityCategory.HumanTask, DisplayName = "Sequential Approver",
                Description = "Approvers act one after another in the configured order.",
                Icon = "bi-list-ol", Color = "#0a58ca", IsApproval = true, MinApprovalLevels = 1,
                RequiredLevelMode = LevelExecutionMode.Sequential,
                DefaultTimeoutSeconds = 604800, DefaultRetryAttempts = 1,
                ConfigFields = ApprovalConfigFields, DefaultInputs = ApprovalInputs, DefaultOutputs = ApprovalOutputs
            },
            new()
            {
                Type = ActivityType.ParallelApprover, Category = ActivityCategory.HumanTask, DisplayName = "Parallel Approver",
                Description = "Several approver groups act concurrently; the approval policy decides the outcome.",
                Icon = "bi-people", Color = "#0a58ca", IsApproval = true, MinApprovalLevels = 1,
                RequiredLevelMode = LevelExecutionMode.Parallel,
                DefaultTimeoutSeconds = 604800, DefaultRetryAttempts = 1,
                ConfigFields = ApprovalConfigFields, DefaultInputs = ApprovalInputs, DefaultOutputs = ApprovalOutputs
            },

            // ------------------------------------------------ Integration
            new()
            {
                Type = ActivityType.SftpFilePush, Category = ActivityCategory.Integration, DisplayName = "SFTP File Push",
                Description = "Uploads a file to a remote SFTP server using a vaulted connection profile.",
                Icon = "bi-cloud-upload", Color = "#20c997", DefaultTimeoutSeconds = 900,
                ConfigFields = new[]
                {
                    new ConfigFieldDescriptor { Key = "connectionProfile", Label = "SFTP connection profile", FieldType = ConfigFieldType.ConnectionProfile, ProfileType = ConnectionProfileType.Sftp, Required = true },
                    new ConfigFieldDescriptor { Key = "remoteDirectory", Label = "Remote directory", Required = true, Pattern = SafePathPattern, HelpText = "e.g. /inbound/agri/{yyyyMMdd}" },
                    new ConfigFieldDescriptor { Key = "remoteFileName", Label = "Remote file name pattern", Pattern = SafeFilePattern, HelpText = "Blank = keep local file name" },
                    new ConfigFieldDescriptor { Key = "overwrite", Label = "Overwrite existing file", FieldType = ConfigFieldType.Boolean, DefaultValue = "false" },
                    new ConfigFieldDescriptor { Key = "checksumAlgorithm", Label = "Checksum", FieldType = ConfigFieldType.Select, Options = new[] { "None", "MD5", "SHA256" }, DefaultValue = "SHA256" }
                },
                DefaultInputs = new[] { new ParameterTemplate { Name = "localFilePath", DataType = ParameterDataType.File, IsMandatory = true, Description = "File to upload" } },
                DefaultOutputs = new[]
                {
                    new ParameterTemplate { Name = "remoteFilePath", DataType = ParameterDataType.String },
                    new ParameterTemplate { Name = "bytesTransferred", DataType = ParameterDataType.Integer },
                    new ParameterTemplate { Name = "checksum", DataType = ParameterDataType.String }
                }
            },
            new()
            {
                Type = ActivityType.SftpFilePull, Category = ActivityCategory.Integration, DisplayName = "SFTP File Pull",
                Description = "Downloads matching files from a remote SFTP server.",
                Icon = "bi-cloud-download", Color = "#20c997", DefaultTimeoutSeconds = 900,
                ConfigFields = new[]
                {
                    new ConfigFieldDescriptor { Key = "connectionProfile", Label = "SFTP connection profile", FieldType = ConfigFieldType.ConnectionProfile, ProfileType = ConnectionProfileType.Sftp, Required = true },
                    new ConfigFieldDescriptor { Key = "remoteDirectory", Label = "Remote directory", Required = true, Pattern = SafePathPattern },
                    new ConfigFieldDescriptor { Key = "filePattern", Label = "File name pattern", Required = true, Pattern = SafeFilePattern, HelpText = "e.g. SETTLEMENT_*.csv" },
                    new ConfigFieldDescriptor { Key = "deleteAfterDownload", Label = "Delete remote file after download", FieldType = ConfigFieldType.Boolean, DefaultValue = "false" },
                    new ConfigFieldDescriptor { Key = "archiveDirectory", Label = "Remote archive directory", Pattern = SafePathPattern },
                    new ConfigFieldDescriptor { Key = "failIfNoFiles", Label = "Fail when no file found", FieldType = ConfigFieldType.Boolean, DefaultValue = "true" }
                },
                DefaultOutputs = new[]
                {
                    new ParameterTemplate { Name = "downloadedFiles", DataType = ParameterDataType.Array, IsMandatory = true },
                    new ParameterTemplate { Name = "fileCount", DataType = ParameterDataType.Integer }
                }
            },
            new()
            {
                Type = ActivityType.ApiDataPush, Category = ActivityCategory.Integration, DisplayName = "API Data Push",
                Description = "Sends data to a downstream REST API using a vaulted API connection profile.",
                Icon = "bi-box-arrow-up-right", Color = "#0dcaf0", DefaultTimeoutSeconds = 120,
                ConfigFields = new[]
                {
                    new ConfigFieldDescriptor { Key = "connectionProfile", Label = "API connection profile", FieldType = ConfigFieldType.ConnectionProfile, ProfileType = ConnectionProfileType.Api, Required = true },
                    new ConfigFieldDescriptor { Key = "httpMethod", Label = "HTTP method", FieldType = ConfigFieldType.Select, Required = true, Options = new[] { "POST", "PUT", "PATCH" }, DefaultValue = "POST" },
                    new ConfigFieldDescriptor { Key = "endpointPath", Label = "Endpoint path", Required = true, Pattern = "^/(?!.*\\.\\.)[A-Za-z0-9_\\-./{}]*$", HelpText = "Relative to the profile base URL, e.g. /v1/loans/{loanId}" },
                    new ConfigFieldDescriptor { Key = "contentType", Label = "Content type", FieldType = ConfigFieldType.Select, Options = new[] { "application/json", "application/xml" }, DefaultValue = "application/json" },
                    new ConfigFieldDescriptor { Key = "successStatusCodes", Label = "Success status codes", Pattern = "^\\d{3}(,\\d{3})*$", DefaultValue = "200,201,202" },
                    new ConfigFieldDescriptor { Key = "idempotencyKeyParameter", Label = "Idempotency key input", HelpText = "Input parameter used as Idempotency-Key header" }
                },
                DefaultInputs = new[] { new ParameterTemplate { Name = "payload", DataType = ParameterDataType.Json, IsMandatory = true } },
                DefaultOutputs = new[]
                {
                    new ParameterTemplate { Name = "statusCode", DataType = ParameterDataType.Integer },
                    new ParameterTemplate { Name = "responseBody", DataType = ParameterDataType.Json }
                }
            },
            new()
            {
                Type = ActivityType.ApiDataPull, Category = ActivityCategory.Integration, DisplayName = "API Data Pull",
                Description = "Retrieves data from an upstream REST API.",
                Icon = "bi-box-arrow-in-down-left", Color = "#0dcaf0", DefaultTimeoutSeconds = 120,
                ConfigFields = new[]
                {
                    new ConfigFieldDescriptor { Key = "connectionProfile", Label = "API connection profile", FieldType = ConfigFieldType.ConnectionProfile, ProfileType = ConnectionProfileType.Api, Required = true },
                    new ConfigFieldDescriptor { Key = "httpMethod", Label = "HTTP method", FieldType = ConfigFieldType.Select, Required = true, Options = new[] { "GET", "POST" }, DefaultValue = "GET" },
                    new ConfigFieldDescriptor { Key = "endpointPath", Label = "Endpoint path", Required = true, Pattern = "^/(?!.*\\.\\.)[A-Za-z0-9_\\-./{}]*$" },
                    new ConfigFieldDescriptor { Key = "responseFormat", Label = "Response format", FieldType = ConfigFieldType.Select, Options = new[] { "json", "xml" }, DefaultValue = "json" },
                    new ConfigFieldDescriptor { Key = "pagination", Label = "Pagination", FieldType = ConfigFieldType.Select, Options = new[] { "None", "PageNumber", "Cursor" }, DefaultValue = "None" },
                    new ConfigFieldDescriptor { Key = "maxPages", Label = "Max pages", FieldType = ConfigFieldType.Number, Min = 1, Max = 1000, DefaultValue = "1" }
                },
                DefaultInputs = new[] { new ParameterTemplate { Name = "queryParameters", DataType = ParameterDataType.Json } },
                DefaultOutputs = new[]
                {
                    new ParameterTemplate { Name = "responseData", DataType = ParameterDataType.Json, IsMandatory = true },
                    new ParameterTemplate { Name = "recordCount", DataType = ParameterDataType.Integer }
                }
            },

            // ------------------------------------------------ File
            new()
            {
                Type = ActivityType.FileGeneration, Category = ActivityCategory.File, DisplayName = "File Generation",
                Description = "Generates a CSV / Excel / PDF / fixed-width file from structured data.",
                Icon = "bi-file-earmark-plus", Color = "#6c757d", DefaultTimeoutSeconds = 900,
                ConfigFields = new[]
                {
                    new ConfigFieldDescriptor { Key = "fileFormat", Label = "File format", FieldType = ConfigFieldType.Select, Required = true, Options = new[] { "CSV", "XLSX", "PDF", "TXT", "JSON", "XML", "FIXED_WIDTH" }, DefaultValue = "CSV" },
                    new ConfigFieldDescriptor { Key = "fileNamePattern", Label = "File name pattern", Required = true, Pattern = SafeFilePattern, HelpText = "e.g. AGRI_RENEWAL_{yyyyMMdd}.csv" },
                    new ConfigFieldDescriptor { Key = "templateCode", Label = "Layout template code", HelpText = "Registered layout / report template" },
                    new ConfigFieldDescriptor { Key = "delimiter", Label = "Delimiter (CSV/TXT)", DefaultValue = "," },
                    new ConfigFieldDescriptor { Key = "includeHeader", Label = "Include header row", FieldType = ConfigFieldType.Boolean, DefaultValue = "true" },
                    new ConfigFieldDescriptor { Key = "encryption", Label = "Encryption", FieldType = ConfigFieldType.Select, Options = new[] { "None", "PGP" }, DefaultValue = "None" }
                },
                DefaultInputs = new[] { new ParameterTemplate { Name = "records", DataType = ParameterDataType.Array, IsMandatory = true } },
                DefaultOutputs = new[]
                {
                    new ParameterTemplate { Name = "generatedFilePath", DataType = ParameterDataType.File, IsMandatory = true },
                    new ParameterTemplate { Name = "recordCount", DataType = ParameterDataType.Integer }
                }
            },
            new()
            {
                Type = ActivityType.FileReading, Category = ActivityCategory.File, DisplayName = "File Reading",
                Description = "Parses a file into records, with schema validation and reject handling.",
                Icon = "bi-file-earmark-text", Color = "#6c757d", DefaultTimeoutSeconds = 900,
                ConfigFields = new[]
                {
                    new ConfigFieldDescriptor { Key = "fileFormat", Label = "File format", FieldType = ConfigFieldType.Select, Required = true, Options = new[] { "CSV", "XLSX", "TXT", "JSON", "XML", "FIXED_WIDTH" }, DefaultValue = "CSV" },
                    new ConfigFieldDescriptor { Key = "delimiter", Label = "Delimiter (CSV/TXT)", DefaultValue = "," },
                    new ConfigFieldDescriptor { Key = "hasHeader", Label = "First row is header", FieldType = ConfigFieldType.Boolean, DefaultValue = "true" },
                    new ConfigFieldDescriptor { Key = "recordSchemaCode", Label = "Record schema code", HelpText = "Registered record layout used for validation" },
                    new ConfigFieldDescriptor { Key = "maxRecords", Label = "Max records", FieldType = ConfigFieldType.Number, Min = 1, Max = 5000000, DefaultValue = "100000" },
                    new ConfigFieldDescriptor { Key = "rejectThresholdPercent", Label = "Reject threshold %", FieldType = ConfigFieldType.Number, Min = 0, Max = 100, DefaultValue = "5" }
                },
                DefaultInputs = new[] { new ParameterTemplate { Name = "filePath", DataType = ParameterDataType.File, IsMandatory = true } },
                DefaultOutputs = new[]
                {
                    new ParameterTemplate { Name = "records", DataType = ParameterDataType.Array, IsMandatory = true },
                    new ParameterTemplate { Name = "recordCount", DataType = ParameterDataType.Integer },
                    new ParameterTemplate { Name = "rejectedCount", DataType = ParameterDataType.Integer }
                }
            },

            // ------------------------------------------------ Scheduler
            new()
            {
                Type = ActivityType.ScheduledOracleQuery, Category = ActivityCategory.Scheduler, DisplayName = "Scheduled Oracle Query",
                Description = "Executes a pre-approved, governed Oracle query (by reference only - free SQL is never accepted).",
                Icon = "bi-database-gear", Color = "#b02a37", DefaultTimeoutSeconds = 1800,
                ConfigFields = new[]
                {
                    new ConfigFieldDescriptor { Key = "approvedQueryCode", Label = "Approved query", FieldType = ConfigFieldType.ApprovedQuery, Required = true },
                    new ConfigFieldDescriptor { Key = "maxRows", Label = "Max rows", FieldType = ConfigFieldType.Number, Required = true, Min = 1, Max = 1000000, DefaultValue = "10000" },
                    new ConfigFieldDescriptor { Key = "fetchSize", Label = "Fetch size", FieldType = ConfigFieldType.Number, Min = 10, Max = 10000, DefaultValue = "500" }
                },
                DefaultInputs = new[] { new ParameterTemplate { Name = "bindParameters", DataType = ParameterDataType.Json, Description = "Bind variables for the approved query" } },
                DefaultOutputs = new[]
                {
                    new ParameterTemplate { Name = "resultSet", DataType = ParameterDataType.Array, IsMandatory = true },
                    new ParameterTemplate { Name = "rowCount", DataType = ParameterDataType.Integer }
                }
            }
        };

        return list.ToDictionary(d => d.Type);
    }
}
