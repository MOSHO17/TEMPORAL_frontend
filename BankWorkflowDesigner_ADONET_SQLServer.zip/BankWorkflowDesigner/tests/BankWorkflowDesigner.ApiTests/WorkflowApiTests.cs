using System.Net;
using System.Text.Json;
using BankWorkflowDesigner.Domain.Dtos;
using BankWorkflowDesigner.Domain.Entities;
using BankWorkflowDesigner.Domain.Enums;
using Xunit;

namespace BankWorkflowDesigner.ApiTests;

public sealed class WorkflowApiTests : IClassFixture<ApiTestHost>
{
    private readonly ApiTestHost _host;

    public WorkflowApiTests(ApiTestHost host) => _host = host;

    private static WorkflowImportRequest Sample(string file, string code)
    {
        var request = JsonSerializer.Deserialize<WorkflowImportRequest>(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "samples", file)), ApiTestHost.Json)!;
        request.TemplateCode = code;
        return request;
    }

    private int ModuleId(string code) => _host.Database.SourceSystems.SelectMany(s => s.Modules).First(m => m.ModuleCode == code).ModuleId;

    private int AgriId => _host.Database.SourceSystems.First(s => s.SystemCode == "AGRI_LOS").SourceSystemId;

    // ------------------------------------------------------------------ infrastructure

    [Fact]
    public async Task Health_and_swagger_are_available()
    {
        using var client = _host.ClientFor("alice.designer");
        Assert.Equal(HttpStatusCode.OK, (await client.GetAsync("/health/live")).StatusCode);
        var swagger = await client.GetAsync("/swagger/v1/swagger.json");
        Assert.Equal(HttpStatusCode.OK, swagger.StatusCode);
        var text = await swagger.Content.ReadAsStringAsync();
        foreach (var route in new[] { "/api/source-systems", "/api/workflows", "/api/workflows/{id}", "/api/workflows/{id}/clone", "/api/workflows/{id}/versions",
                     "/api/workflows/{id}/validate", "/api/workflows/{id}/publish", "/api/workflows/{id}/definition", "/api/workflows/{id}/activities",
                     "/api/workflows/{id}/activities/{activityId}", "/api/workflows/{id}/parameters", "/api/workflows/{id}/parameters/{parameterId}" })
        {
            Assert.Contains($"\"{route}\"", text);
        }
    }

    [Fact]
    public async Task Responses_carry_security_headers_and_correlation_id()
    {
        using var client = _host.ClientFor("alice.designer");
        var response = await client.GetAsync("/api/me");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.True(response.Headers.Contains("X-Correlation-Id"));
        Assert.Equal("nosniff", response.Headers.GetValues("X-Content-Type-Options").Single());
        Assert.Equal("DENY", response.Headers.GetValues("X-Frame-Options").Single());
        var me = await client.ReadAsync<CurrentUserResponse>(response);
        Assert.Equal("alice.designer", me.UserName);
        Assert.Contains("WF_DESIGNER", me.Roles);
    }

    [Fact]
    public async Task Unknown_users_get_a_consistent_401()
    {
        using var client = _host.ClientFor("mallory");
        var response = await client.GetAsync("/api/workflows");
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
        var error = JsonSerializer.Deserialize<ErrorResponse>(await response.Content.ReadAsStringAsync(), ApiTestHost.Json)!;
        Assert.Equal("UNAUTHENTICATED", error.Code);
        Assert.NotNull(error.TraceId);
    }

    [Fact]
    public async Task State_changing_calls_require_the_antiforgery_token()
    {
        using var client = _host.ClientFor("alice.designer");
        client.SendAntiforgeryToken = false;
        var response = await client.PostAsync("/api/workflows", new CreateWorkflowRequest { SourceSystemId = AgriId, ModuleId = ModuleId("CAM_RENEWAL"), TemplateCode = "CSRF_TEST", WorkflowName = "CSRF test" });
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.Contains("ANTIFORGERY_FAILED", await response.Content.ReadAsStringAsync());
    }

    [Fact]
    public async Task Model_validation_errors_use_the_standard_error_payload()
    {
        using var client = _host.ClientFor("alice.designer");
        var response = await client.PostAsync("/api/workflows", new { sourceSystemId = 0, moduleId = 0, templateCode = "bad code!", workflowName = "x" });
        var error = await client.ReadAsync<ErrorResponse>(response, HttpStatusCode.BadRequest);
        Assert.Equal("VALIDATION_FAILED", error.Code);
        Assert.NotNull(error.Errors);
        Assert.True(error.Errors!.ContainsKey("templateCode"));
        Assert.True(error.Errors.ContainsKey("workflowName"));
    }

    // ------------------------------------------------------------------ authorization

    [Fact]
    public async Task Role_and_source_system_authorization_are_enforced()
    {
        using var alice = _host.ClientFor("alice.designer");
        using var admin = _host.ClientFor("dev.admin");
        using var tom = _host.ClientFor("tom.treasury");
        using var rita = _host.ClientFor("rita.reviewer");

        var aliceSystems = await alice.ReadAsync<List<SourceSystem>>(await alice.GetAsync("/api/source-systems"));
        Assert.Single(aliceSystems);
        Assert.Equal("AGRI_LOS", aliceSystems[0].SystemCode);
        var adminSystems = await admin.ReadAsync<List<SourceSystem>>(await admin.GetAsync("/api/source-systems"));
        Assert.True(adminSystems.Count >= 2);

        var forbidden = await alice.PostAsync("/api/source-systems", new CreateSourceSystemRequest { SystemCode = "NOPE", ApplicationName = "No", Modules = { new ModuleRequest { ModuleCode = "M1", ModuleName = "M1" } } });
        Assert.Equal(HttpStatusCode.Forbidden, forbidden.StatusCode);

        var created = await alice.ReadAsync<WorkflowDetailResponse>(await alice.PostAsync("/api/workflows",
            new CreateWorkflowRequest { SourceSystemId = AgriId, ModuleId = ModuleId("CAM_RENEWAL"), TemplateCode = "AUTHZ_TEST", WorkflowName = "Authz test" }), HttpStatusCode.Created);
        var id = created.Template.WorkflowTemplateId;

        Assert.Equal(HttpStatusCode.Forbidden, (await tom.GetAsync($"/api/workflows/{id}")).StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, (await rita.PostAsync($"/api/workflows/{id}/activities",
            new ActivityRequest { ActivityKey = "m", ActivityType = ActivityType.Maker, DisplayName = "Maker" })).StatusCode);
        Assert.Equal(HttpStatusCode.OK, (await rita.PostAsync($"/api/workflows/{id}/validate")).StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, (await alice.PostAsync($"/api/workflows/{id}/publish", new PublishWorkflowRequest { VersionNo = 1 })).StatusCode);
    }

    // ------------------------------------------------------------------ lifecycle

    [Fact]
    public async Task Import_validate_publish_consume_and_version_through_the_api()
    {
        using var alice = _host.ClientFor("alice.designer");
        using var bob = _host.ClientFor("bob.publisher");
        using var temporal = _host.ClientFor("temporal.svc");

        var imported = await alice.ReadAsync<WorkflowDetailResponse>(await alice.PostAsync("/api/workflows/import", Sample("14-cam-renewal-end-to-end.json", "API_E2E")), HttpStatusCode.Created);
        var id = imported.Template.WorkflowTemplateId;
        Assert.Equal(12, imported.Graph.Activities.Count);

        var report = await alice.ReadAsync<ValidationReport>(await alice.PostAsync($"/api/workflows/{id}/validate"));
        Assert.True(report.IsValid, string.Join(" | ", report.Issues.Select(i => i.Message)));

        var preview = await alice.GetAsync($"/api/workflows/{id}/definition/preview");
        Assert.Equal(HttpStatusCode.OK, preview.StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, (await temporal.GetAsync($"/api/workflows/{id}/definition")).StatusCode);

        var published = await bob.ReadAsync<PublishResult>(await bob.PostAsync($"/api/workflows/{id}/publish", new PublishWorkflowRequest { VersionNo = 1, Comments = "CAB-2026-001" }));
        Assert.Equal(1, published.VersionNo);

        var definitionResponse = await temporal.GetAsync("/api/definitions/API_E2E");
        Assert.Equal(HttpStatusCode.OK, definitionResponse.StatusCode);
        Assert.Equal("application/json", definitionResponse.Content.Headers.ContentType!.MediaType);
        using (var doc = JsonDocument.Parse(await definitionResponse.Content.ReadAsStringAsync()))
        {
            Assert.Equal("API_E2E:v1", doc.RootElement.GetProperty("definitionId").GetString());
            Assert.Equal("agri-los-workflows", doc.RootElement.GetProperty("temporal").GetProperty("taskQueue").GetString());
            Assert.Equal(published.DefinitionHash, doc.RootElement.GetProperty("metadata").GetProperty("definitionHash").GetString());
            Assert.Equal(12, doc.RootElement.GetProperty("activities").GetArrayLength());
        }

        Assert.Equal(HttpStatusCode.OK, (await temporal.GetAsync($"/api/workflows/{id}/definition?version=1")).StatusCode);

        // Immutable after publish
        var immutable = await alice.PostAsync($"/api/workflows/{id}/activities", new ActivityRequest { ActivityKey = "late", ActivityType = ActivityType.Maker, DisplayName = "Late" });
        var error = await alice.ReadAsync<ErrorResponse>(immutable, HttpStatusCode.Conflict);
        Assert.Equal("VERSION_IMMUTABLE", error.Code);

        // New draft, four-eyes on publish
        var v2 = await bob.ReadAsync<WorkflowDetailResponse>(await bob.PostAsync($"/api/workflows/{id}/versions", new CreateVersionRequest { ChangeNotes = "Raise threshold" }), HttpStatusCode.Created);
        Assert.Equal(2, v2.Graph.Version.VersionNo);
        var fourEyes = await bob.PostAsync($"/api/workflows/{id}/publish", new PublishWorkflowRequest { VersionNo = 2 });
        Assert.Equal(HttpStatusCode.Forbidden, fourEyes.StatusCode);
        Assert.Contains("Four-eyes", await fourEyes.Content.ReadAsStringAsync());

        var versions = await alice.ReadAsync<List<WorkflowVersion>>(await alice.GetAsync($"/api/workflows/{id}/versions"));
        Assert.Equal(2, versions.Count);
        var audit = await alice.ReadAsync<List<AuditLogEntry>>(await alice.GetAsync($"/api/workflows/{id}/audit"));
        Assert.Contains(audit, a => a.Action == "Published" && a.UserName == "bob.publisher");
        Assert.Contains(audit, a => a.Action == "VersionCreated");
    }

    [Fact]
    public async Task Activity_parameter_and_connection_endpoints_work_end_to_end()
    {
        using var alice = _host.ClientFor("alice.designer");
        var created = await alice.ReadAsync<WorkflowDetailResponse>(await alice.PostAsync("/api/workflows",
            new CreateWorkflowRequest { SourceSystemId = AgriId, ModuleId = ModuleId("KCC_SANCTION"), TemplateCode = "API_CRUD", WorkflowName = "CRUD test" }), HttpStatusCode.Created);
        var id = created.Template.WorkflowTemplateId;

        // POST activity
        var push = await alice.ReadAsync<WorkflowActivity>(await alice.PostAsync($"/api/workflows/{id}/activities", new ActivityRequest
        {
            ActivityKey = "apiPush", ActivityType = ActivityType.ApiDataPush, DisplayName = "Push", PositionX = 300, PositionY = 200,
            Config = new Dictionary<string, string?> { ["connectionProfile"] = "API_CBS_CORE", ["endpointPath"] = "/v1/limits" }
        }), HttpStatusCode.Created);
        Assert.Equal("POST", push.Config["httpMethod"]);

        // Secrets are rejected with field-level errors
        var secret = await alice.PutAsync($"/api/workflows/{id}/activities/{push.ActivityId}", new ActivityRequest
        {
            ActivityKey = "apiPush", ActivityType = ActivityType.ApiDataPush, DisplayName = "Push", RowVersion = push.RowVersion,
            Config = new Dictionary<string, string?> { ["connectionProfile"] = "API_CBS_CORE", ["endpointPath"] = "/v1/limits?apikey=abc&password=x" }
        });
        var secretError = await alice.ReadAsync<ErrorResponse>(secret, HttpStatusCode.BadRequest);
        Assert.True(secretError.Errors!.ContainsKey("config.endpointPath"));

        // PUT activity with parameter mapping
        var updated = await alice.ReadAsync<WorkflowActivity>(await alice.PutAsync($"/api/workflows/{id}/activities/{push.ActivityId}", new ActivityRequest
        {
            ActivityKey = "apiPush", ActivityType = ActivityType.ApiDataPush, DisplayName = "Push to CBS", RowVersion = push.RowVersion,
            Config = new Dictionary<string, string?>(push.Config),
            RetryPolicy = new RetryPolicyRequest { MaxAttempts = 4, InitialIntervalSeconds = 5, BackoffCoefficient = 2, MaxIntervalSeconds = 60 },
            Parameters = new List<ActivityParameterRequest>
            {
                new() { Direction = ParameterDirection.Input, Name = "payload", DataType = ParameterDataType.Json, IsMandatory = true, SourceType = MappingSourceType.WorkflowInput, SourceReference = "payload" },
                new() { Direction = ParameterDirection.Output, Name = "statusCode", DataType = ParameterDataType.Integer },
                new() { Direction = ParameterDirection.Output, Name = "responseBody", DataType = ParameterDataType.Json }
            }
        }));
        Assert.Equal(4, updated.RetryMaxAttempts);
        Assert.Equal("Push to CBS", updated.DisplayName);

        // Stale row version -> 409
        var stale = await alice.PutAsync($"/api/workflows/{id}/activities/{push.ActivityId}", new ActivityRequest
        {
            ActivityKey = "apiPush", ActivityType = ActivityType.ApiDataPush, DisplayName = "Again", RowVersion = push.RowVersion, Config = new Dictionary<string, string?>(push.Config)
        });
        Assert.Equal("CONCURRENCY_CONFLICT", (await alice.ReadAsync<ErrorResponse>(stale, HttpStatusCode.Conflict)).Code);

        // POST / PUT parameters
        var parameter = await alice.ReadAsync<WorkflowParameter>(await alice.PostAsync($"/api/workflows/{id}/parameters", new WorkflowParameterRequest
        {
            Direction = ParameterDirection.Input, Name = "payload", DataType = ParameterDataType.Json, IsMandatory = true, JsonSchema = "{\"type\":\"object\"}"
        }), HttpStatusCode.Created);
        var parameter2 = await alice.ReadAsync<WorkflowParameter>(await alice.PutAsync($"/api/workflows/{id}/parameters/{parameter.ParameterId}", new WorkflowParameterRequest
        {
            Direction = ParameterDirection.Input, Name = "payload", DataType = ParameterDataType.Json, IsMandatory = true, Description = "Limit update payload", RowVersion = parameter.RowVersion
        }));
        Assert.Equal("Limit update payload", parameter2.Description);

        var badDefault = await alice.PostAsync($"/api/workflows/{id}/parameters", new WorkflowParameterRequest { Direction = ParameterDirection.Input, Name = "amount", DataType = ParameterDataType.Decimal, DefaultValue = "ten" });
        Assert.Equal(HttpStatusCode.BadRequest, badDefault.StatusCode);

        // Connections and layout
        var c1 = await alice.ReadAsync<ActivityConnection>(await alice.PostAsync($"/api/workflows/{id}/connections", new ConnectionRequest { FromActivityKey = "start", ToActivityKey = "apiPush" }), HttpStatusCode.Created);
        await alice.ReadAsync<ActivityConnection>(await alice.PostAsync($"/api/workflows/{id}/connections", new ConnectionRequest { FromActivityKey = "apiPush", ToActivityKey = "end", Label = "done" }), HttpStatusCode.Created);
        Assert.Equal(HttpStatusCode.NoContent, (await alice.PutAsync($"/api/workflows/{id}/layout", new UpdateLayoutRequest { Positions = { new ActivityPositionRequest { ActivityKey = "apiPush", PositionX = 420, PositionY = 180 } } })).StatusCode);

        var report = await alice.ReadAsync<ValidationReport>(await alice.PostAsync($"/api/workflows/{id}/validate"));
        Assert.True(report.IsValid, string.Join(" | ", report.Issues.Select(i => i.Message)));

        // Header update with concurrency token
        var detail = await alice.ReadAsync<WorkflowDetailResponse>(await alice.GetAsync($"/api/workflows/{id}"));
        Assert.Equal(420, detail.Graph.Activities.Single(a => a.ActivityKey == "apiPush").PositionX);
        Assert.Equal(VersionStatus.Validated, detail.Graph.Version.Status);
        await alice.ReadAsync<WorkflowDetailResponse>(await alice.PutAsync($"/api/workflows/{id}", new UpdateWorkflowRequest { WorkflowName = "CRUD test (renamed)", RowVersion = detail.Template.RowVersion! }));
        Assert.Equal(HttpStatusCode.Conflict, (await alice.PutAsync($"/api/workflows/{id}", new UpdateWorkflowRequest { WorkflowName = "x-x-x", RowVersion = detail.Template.RowVersion! })).StatusCode);

        // Clone
        var clone = await alice.ReadAsync<WorkflowDetailResponse>(await alice.PostAsync($"/api/workflows/{id}/clone", new CloneWorkflowRequest { NewTemplateCode = "API_CRUD_COPY", WorkflowName = "CRUD copy" }), HttpStatusCode.Created);
        Assert.Equal(3, clone.Graph.Activities.Count);

        // DELETE endpoints
        Assert.Equal(HttpStatusCode.NoContent, (await alice.DeleteAsync($"/api/workflows/{id}/connections/{c1.ConnectionId}")).StatusCode);
        Assert.Equal(HttpStatusCode.NoContent, (await alice.DeleteAsync($"/api/workflows/{id}/parameters/{parameter.ParameterId}")).StatusCode);
        Assert.Equal(HttpStatusCode.NoContent, (await alice.DeleteAsync($"/api/workflows/{id}/activities/{push.ActivityId}")).StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, (await alice.DeleteAsync($"/api/workflows/{id}/activities/{push.ActivityId}")).StatusCode);

        var list = await alice.ReadAsync<PagedResult<WorkflowTemplate>>(await alice.GetAsync("/api/workflows?search=API_CRUD&pageSize=10"));
        Assert.Equal(2, list.TotalCount);
    }

    [Fact]
    public async Task Source_systems_and_schedulers_through_the_api()
    {
        using var admin = _host.ClientFor("dev.admin");
        using var alice = _host.ClientFor("alice.designer");
        using var bob = _host.ClientFor("bob.publisher");

        var ss = await admin.ReadAsync<SourceSystem>(await admin.PostAsync("/api/source-systems", new CreateSourceSystemRequest
        {
            SystemCode = "MSME_LOS", ApplicationName = "MSME Loan Origination",
            Modules = { new ModuleRequest { ModuleCode = "TERM_LOAN", ModuleName = "Term loan" } },
            AuthorizedUsers = { new SourceSystemUserRequest { UserPrincipal = "alice.designer", AccessRole = SourceSystemAccessRole.Designer } }
        }), HttpStatusCode.Created);
        var updated = await admin.ReadAsync<SourceSystem>(await admin.PutAsync($"/api/source-systems/{ss.SourceSystemId}", new UpdateSourceSystemRequest
        {
            ApplicationName = "MSME LOS", RowVersion = ss.RowVersion!, Status = EntityStatus.Active,
            Modules = { new ModuleRequest { ModuleCode = "TERM_LOAN", ModuleName = "Term loan" }, new ModuleRequest { ModuleCode = "WORKING_CAPITAL", ModuleName = "Working capital" } },
            AuthorizedUsers = { new SourceSystemUserRequest { UserPrincipal = "alice.designer", AccessRole = SourceSystemAccessRole.Designer } }
        }));
        Assert.Equal(2, updated.Modules.Count);

        var queries = await alice.ReadAsync<List<ApprovedOracleQuery>>(await alice.GetAsync("/api/reference/approved-queries"));
        var profilesText = await (await alice.GetAsync("/api/reference/connection-profiles")).Content.ReadAsStringAsync();
        Assert.DoesNotContain("cyberark://", profilesText);
        var catalog = await alice.GetAsync("/api/catalog/activities");
        Assert.Contains("ScheduledOracleQuery", await catalog.Content.ReadAsStringAsync());

        var imported = await alice.ReadAsync<WorkflowDetailResponse>(await alice.PostAsync("/api/workflows/import", Sample("13-scheduled-oracle-query.json", "API_SCHED_TARGET")), HttpStatusCode.Created);
        await bob.ReadAsync<PublishResult>(await bob.PostAsync($"/api/workflows/{imported.Template.WorkflowTemplateId}/publish", new PublishWorkflowRequest { VersionNo = 1 }));

        var cron = await alice.ReadAsync<CronValidationResult>(await alice.PostAsync("/api/schedulers/validate-cron", new CronValidationRequest { CronExpression = "0 0 6 ? * MON-FRI" }));
        Assert.True(cron.IsValid);

        var request = new SchedulerConfigRequest
        {
            SchedulerCode = "API_DAILY_DUE", SourceSystemId = AgriId, SchedulerName = "Daily due list",
            ApprovedQueryId = queries.Single(q => q.QueryCode == "Q_CAM_RENEWAL_DUE").ApprovedQueryId,
            CronExpression = "0 0 6 ? * MON-FRI", TimeZoneId = "UTC", TargetWorkflowTemplateId = imported.Template.WorkflowTemplateId,
            ExecutionParametersJson = "{\"asOfDate\":\"sys.businessDate\",\"windowDays\":30}"
        };
        var scheduler = await alice.ReadAsync<SchedulerConfiguration>(await alice.PostAsync("/api/schedulers", request), HttpStatusCode.Created);
        Assert.Equal("API_SCHED_TARGET", scheduler.TargetTemplateCode);

        request.CronExpression = "*/5 * * * *";
        request.SchedulerCode = "API_BAD_CRON";
        var bad = await alice.ReadAsync<ErrorResponse>(await alice.PostAsync("/api/schedulers", request), HttpStatusCode.BadRequest);
        Assert.True(bad.Errors!.ContainsKey("cronExpression"));

        var all = await alice.ReadAsync<List<SchedulerConfiguration>>(await alice.GetAsync("/api/schedulers"));
        Assert.Contains(all, s => s.SchedulerCode == "API_DAILY_DUE");

        var dashboard = await alice.ReadAsync<DashboardSummary>(await alice.GetAsync("/api/dashboard"));
        Assert.True(dashboard.TemplateCount >= 1);
        Assert.True(dashboard.SchedulerCount >= 1);
    }
}
