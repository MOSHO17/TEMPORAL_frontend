using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using BankWorkflowDesigner.Api;
using BankWorkflowDesigner.Application.Abstractions;
using BankWorkflowDesigner.Infrastructure.Data;
using BankWorkflowDesigner.TestSupport;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Hosting.Server.Features;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Xunit;

namespace BankWorkflowDesigner.ApiTests;

/// <summary>
/// Starts the real API pipeline (routing, authentication, authorization, anti-forgery, validation,
/// error middleware, controllers, services) on a random loopback port. Only the SQL Server
/// repositories are replaced with the in-memory implementation.
/// </summary>
public sealed class ApiTestHost : IAsyncLifetime
{
    private WebApplication? _app;

    public static readonly JsonSerializerOptions Json = CreateJson();

    public InMemoryDatabase Database { get; } = InMemoryDatabase.CreateSeeded();

    public Uri BaseAddress { get; private set; } = new("http://127.0.0.1");

    private static JsonSerializerOptions CreateJson()
    {
        var options = new JsonSerializerOptions(JsonSerializerDefaults.Web);
        options.Converters.Add(new JsonStringEnumConverter());
        return options;
    }

    public async Task InitializeAsync()
    {
        var settings = new Dictionary<string, string?>
        {
            ["Authentication:Mode"] = "Development",
            ["Authentication:DevelopmentUsers:0:UserName"] = "alice.designer",
            ["Authentication:DevelopmentUsers:0:Roles:0"] = "WF_DESIGNER",
            ["Authentication:DevelopmentUsers:1:UserName"] = "rita.reviewer",
            ["Authentication:DevelopmentUsers:1:Roles:0"] = "WF_REVIEWER",
            ["Authentication:DevelopmentUsers:2:UserName"] = "bob.publisher",
            ["Authentication:DevelopmentUsers:2:Roles:0"] = "WF_PUBLISHER",
            ["Authentication:DevelopmentUsers:2:Roles:1"] = "WF_DESIGNER",
            ["Authentication:DevelopmentUsers:3:UserName"] = "dev.admin",
            ["Authentication:DevelopmentUsers:3:Roles:0"] = "WF_SOURCE_ADMIN",
            ["Authentication:DevelopmentUsers:3:Roles:1"] = "WF_DESIGNER",
            ["Authentication:DevelopmentUsers:4:UserName"] = "temporal.svc",
            ["Authentication:DevelopmentUsers:4:Roles:0"] = "WF_DEFINITION_CONSUMER",
            ["Authentication:DevelopmentUsers:5:UserName"] = "tom.treasury",
            ["Authentication:DevelopmentUsers:5:Roles:0"] = "WF_DESIGNER",
            ["ConnectionStrings:WorkflowDesignerDb"] = "Server=unused;Database=unused",
            ["Swagger:Enabled"] = "true",
            ["Antiforgery:Enabled"] = "true",
            ["WorkflowSecurity:EnforcePublishSegregation"] = "true",
            ["Logging:LogLevel:Default"] = "Warning"
        };

        _app = ApiApplication.Build(
            new[] { "--environment", "Development", "--urls", "http://127.0.0.1:0" },
            builder => builder.Configuration.AddInMemoryCollection(settings),
            services =>
            {
                services.RemoveAll<ISqlConnectionFactory>();
                services.RemoveAll<ISourceSystemRepository>();
                services.RemoveAll<IWorkflowRepository>();
                services.RemoveAll<IActivityRepository>();
                services.RemoveAll<IParameterRepository>();
                services.RemoveAll<ISchedulerRepository>();
                services.RemoveAll<IReferenceDataRepository>();
                services.RemoveAll<IAuditRepository>();

                services.AddSingleton(Database);
                services.AddScoped<ISourceSystemRepository, InMemorySourceSystemRepository>();
                services.AddScoped<IWorkflowRepository, InMemoryWorkflowRepository>();
                services.AddScoped<IActivityRepository, InMemoryActivityRepository>();
                services.AddScoped<IParameterRepository, InMemoryParameterRepository>();
                services.AddScoped<ISchedulerRepository, InMemorySchedulerRepository>();
                services.AddScoped<InMemoryReferenceDataRepository>();
                services.AddScoped<IReferenceDataRepository>(sp => sp.GetRequiredService<InMemoryReferenceDataRepository>());
                services.AddScoped<IAuditRepository>(sp => sp.GetRequiredService<InMemoryReferenceDataRepository>());
            });

        await _app.StartAsync();
        var address = _app.Services.GetRequiredService<IServer>().Features.Get<IServerAddressesFeature>()!.Addresses.First();
        BaseAddress = new Uri(address);
    }

    public async Task DisposeAsync()
    {
        if (_app is not null)
        {
            await _app.StopAsync();
            await _app.DisposeAsync();
        }
    }

    public ApiClient ClientFor(string user) => new(BaseAddress, user);
}

/// <summary>HTTP client acting as one development user, handling the anti-forgery token like the browser does.</summary>
public sealed class ApiClient : IDisposable
{
    private readonly HttpClient _http;
    private string? _token;

    public ApiClient(Uri baseAddress, string user)
    {
        var handler = new HttpClientHandler { CookieContainer = new CookieContainer(), UseCookies = true };
        _http = new HttpClient(handler) { BaseAddress = baseAddress };
        _http.DefaultRequestHeaders.Add("X-Dev-User", user);
    }

    public bool SendAntiforgeryToken { get; set; } = true;

    public HttpClient Raw => _http;

    public async Task<HttpResponseMessage> SendAsync(HttpMethod method, string path, object? body = null)
    {
        using var request = new HttpRequestMessage(method, path);
        if (body is not null)
        {
            request.Content = JsonContent.Create(body, body.GetType(), options: ApiTestHost.Json);
        }

        if (method != HttpMethod.Get && SendAntiforgeryToken)
        {
            if (_token is null)
            {
                var tokenResponse = await _http.GetAsync("/api/security/antiforgery-token");
                tokenResponse.EnsureSuccessStatusCode();
                using var doc = JsonDocument.Parse(await tokenResponse.Content.ReadAsStringAsync());
                _token = doc.RootElement.GetProperty("token").GetString();
            }

            request.Headers.Add("X-XSRF-TOKEN", _token);
        }

        return await _http.SendAsync(request);
    }

    public Task<HttpResponseMessage> GetAsync(string path) => SendAsync(HttpMethod.Get, path);

    public Task<HttpResponseMessage> PostAsync(string path, object? body = null) => SendAsync(HttpMethod.Post, path, body ?? new { });

    public Task<HttpResponseMessage> PutAsync(string path, object body) => SendAsync(HttpMethod.Put, path, body);

    public Task<HttpResponseMessage> DeleteAsync(string path) => SendAsync(HttpMethod.Delete, path);

    public async Task<T> ReadAsync<T>(HttpResponseMessage response, HttpStatusCode expected = HttpStatusCode.OK)
    {
        var text = await response.Content.ReadAsStringAsync();
        Assert.True(response.StatusCode == expected, $"Expected {(int)expected} but got {(int)response.StatusCode}: {text}");
        return JsonSerializer.Deserialize<T>(text, ApiTestHost.Json)!;
    }

    public void Dispose() => _http.Dispose();
}
