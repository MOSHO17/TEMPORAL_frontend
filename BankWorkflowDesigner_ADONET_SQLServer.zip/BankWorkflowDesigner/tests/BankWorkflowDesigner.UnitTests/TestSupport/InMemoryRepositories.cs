using System.Text.Json;
using BankWorkflowDesigner.Application.Abstractions;
using BankWorkflowDesigner.Domain.Dtos;
using BankWorkflowDesigner.Domain.Entities;
using BankWorkflowDesigner.Domain.Enums;
using BankWorkflowDesigner.Domain.Exceptions;

namespace BankWorkflowDesigner.TestSupport;

/// <summary>
/// In-memory replacement for the SQL Server database used by unit and API integration tests.
/// It mirrors the behaviour of the stored procedures (draft-only edits, row versions, audit rows,
/// supersede-on-publish, four-eyes "last modifier" tracking) so the service layer can be tested without SQL Server.
/// </summary>
public sealed class InMemoryDatabase
{
    private static readonly JsonSerializerOptions CloneOptions = new() { IncludeFields = false };
    private int _id = 1000;
    private long _rowVersion = 1;

    public object Sync { get; } = new();
    public List<SourceSystem> SourceSystems { get; } = new();
    public List<ConnectionProfile> Profiles { get; } = new();
    public List<ApprovedOracleQuery> Queries { get; } = new();
    public List<WorkflowTemplate> Templates { get; } = new();
    public List<WorkflowVersion> Versions { get; } = new();
    public Dictionary<int, VersionContent> Content { get; } = new();
    public List<SchedulerConfiguration> Schedulers { get; } = new();
    public List<AuditLogEntry> Audit { get; } = new();

    public sealed class VersionContent
    {
        public List<WorkflowActivity> Activities { get; set; } = new();
        public List<ActivityConnection> Connections { get; set; } = new();
        public List<WorkflowParameter> Parameters { get; set; } = new();
    }

    public int NextId() => Interlocked.Increment(ref _id);

    public string NextRowVersion() => Convert.ToBase64String(BitConverter.GetBytes(Interlocked.Increment(ref _rowVersion)));

    public static T Clone<T>(T value) => JsonSerializer.Deserialize<T>(JsonSerializer.Serialize(value, CloneOptions), CloneOptions)!;

    public void WriteAudit(string entityType, object entityId, string action, AuditContext audit, object? details = null) =>
        Audit.Add(new AuditLogEntry
        {
            AuditLogId = NextId(),
            EntityType = entityType,
            EntityId = Convert.ToString(entityId, System.Globalization.CultureInfo.InvariantCulture)!,
            Action = action,
            UserName = audit.UserName,
            ActionOn = DateTime.UtcNow,
            CorrelationId = audit.CorrelationId,
            ClientIp = audit.ClientIp,
            Details = details is null ? null : JsonSerializer.Serialize(details)
        });

    /// <summary>Same reference data as database/.../11_SeedData.sql.</summary>
    public static InMemoryDatabase CreateSeeded()
    {
        var db = new InMemoryDatabase();
        var now = DateTime.UtcNow;

        SourceSystem System(string code, string name, string queue, params (string Code, string Name)[] modules)
        {
            var ss = new SourceSystem
            {
                SourceSystemId = db.NextId(), SystemCode = code, ApplicationName = name, DefaultTaskQueue = queue,
                Status = EntityStatus.Active, CreatedBy = "SYSTEM.SEED", CreatedOn = now, RowVersion = db.NextRowVersion()
            };
            foreach (var (mc, mn) in modules)
            {
                ss.Modules.Add(new SourceSystemModule { ModuleId = db.NextId(), SourceSystemId = ss.SourceSystemId, ModuleCode = mc, ModuleName = mn, Status = EntityStatus.Active, CreatedBy = "SYSTEM.SEED", CreatedOn = now });
            }

            db.SourceSystems.Add(ss);
            return ss;
        }

        var agri = System("AGRI_LOS", "Agri Loan Origination System", "agri-los-workflows",
            ("CAM_RENEWAL", "CAM Renewal"), ("KCC_SANCTION", "KCC Sanction"), ("ECLGS", "ECLGS Processing"), ("SECURITIZATION", "Securitization Sell-Down"));
        var treasury = System("TREASURY_OPS", "Treasury Operations", "treasury-ops-workflows", ("SETTLEMENT", "Settlement"));

        void User(SourceSystem ss, string principal, SourceSystemAccessRole role) =>
            ss.AuthorizedUsers.Add(new SourceSystemUser { SourceSystemUserId = db.NextId(), SourceSystemId = ss.SourceSystemId, UserPrincipal = principal, AccessRole = role, IsActive = true, CreatedBy = "SYSTEM.SEED", CreatedOn = now });

        User(agri, "alice.designer", SourceSystemAccessRole.Designer);
        User(agri, "rita.reviewer", SourceSystemAccessRole.Reviewer);
        User(agri, "bob.publisher", SourceSystemAccessRole.Publisher);
        User(agri, "bob.publisher", SourceSystemAccessRole.Designer);
        User(treasury, "tom.treasury", SourceSystemAccessRole.Designer);

        void Profile(string code, ConnectionProfileType type, SourceSystem ss) =>
            db.Profiles.Add(new ConnectionProfile { ConnectionProfileId = db.NextId(), ProfileCode = code, ProfileType = type, SecretStoreReference = $"cyberark://SAFE/{code.ToLowerInvariant()}", Environment = "UAT", SourceSystemId = ss.SourceSystemId, IsActive = true });

        Profile("SFTP_CBS_OUTBOUND", ConnectionProfileType.Sftp, agri);
        Profile("SFTP_PARTNER_INBOUND", ConnectionProfileType.Sftp, agri);
        Profile("API_CBS_CORE", ConnectionProfileType.Api, agri);
        Profile("API_CREDIT_BUREAU", ConnectionProfileType.Api, agri);
        Profile("ORA_AGRI_DWH", ConnectionProfileType.Oracle, agri);
        Profile("SFTP_TREASURY_SETTLE", ConnectionProfileType.Sftp, treasury);

        void Query(string code, string name, params string[] parameters) =>
            db.Queries.Add(new ApprovedOracleQuery { ApprovedQueryId = db.NextId(), QueryCode = code, QueryName = name, SourceSystemId = agri.SourceSystemId, DataSourceProfileCode = "ORA_AGRI_DWH", ParameterNames = parameters.ToList(), ApprovedBy = "dba.governance", ApprovedOn = now, IsActive = true });

        Query("Q_CAM_RENEWAL_DUE", "CAM renewals due", "asOfDate", "windowDays");
        Query("Q_ECLGS_PIPELINE", "ECLGS pipeline summary", "businessDate");
        Query("Q_SECURITIZATION_POOL", "Securitization candidate pool");
        return db;
    }

    // ------------------------------------------------------------------ helpers shared by repositories

    public WorkflowVersion AssertEditable(int workflowVersionId)
    {
        var version = Versions.FirstOrDefault(v => v.WorkflowVersionId == workflowVersionId) ?? throw new NotFoundException("Workflow version not found.");
        if (!version.IsEditable)
        {
            throw new ImmutableVersionException();
        }

        if (Templates.First(t => t.WorkflowTemplateId == version.WorkflowTemplateId).Status != TemplateStatus.Active)
        {
            throw new ConflictException("The workflow template is deactivated.");
        }

        return version;
    }

    public void Touch(WorkflowVersion version, string userName)
    {
        version.ModifiedBy = userName;
        version.ModifiedOn = DateTime.UtcNow;
        version.Status = VersionStatus.Draft;
        version.RowVersion = NextRowVersion();
    }

    public WorkflowTemplate TemplateView(WorkflowTemplate t)
    {
        var copy = Clone(t);
        var ss = SourceSystems.First(s => s.SourceSystemId == t.SourceSystemId);
        copy.SourceSystemCode = ss.SystemCode;
        copy.ModuleCode = ss.Modules.First(m => m.ModuleId == t.ModuleId).ModuleCode;
        copy.LatestVersionStatus = Versions.First(v => v.WorkflowTemplateId == t.WorkflowTemplateId && v.VersionNo == t.LatestVersionNo).Status;
        return copy;
    }

    public void CopyContent(int sourceVersionId, int targetVersionId, string userName)
    {
        var source = Content[sourceVersionId];
        var target = new VersionContent();
        foreach (var a in source.Activities)
        {
            var copy = Clone(a);
            copy.ActivityId = NextId();
            copy.WorkflowVersionId = targetVersionId;
            copy.RowVersion = NextRowVersion();
            copy.Parameters.ForEach(p => { p.ActivityParameterId = NextId(); p.ActivityId = copy.ActivityId; });
            if (copy.Approval is not null)
            {
                copy.Approval.ApprovalConfigId = NextId();
                copy.Approval.ActivityId = copy.ActivityId;
            }

            target.Activities.Add(copy);
        }

        foreach (var c in source.Connections)
        {
            var copy = Clone(c);
            copy.ConnectionId = NextId();
            copy.WorkflowVersionId = targetVersionId;
            target.Connections.Add(copy);
        }

        foreach (var p in source.Parameters)
        {
            var copy = Clone(p);
            copy.ParameterId = NextId();
            copy.WorkflowVersionId = targetVersionId;
            copy.RowVersion = NextRowVersion();
            target.Parameters.Add(copy);
        }

        Content[targetVersionId] = target;
    }
}

public sealed class InMemorySourceSystemRepository : ISourceSystemRepository
{
    private readonly InMemoryDatabase _db;

    public InMemorySourceSystemRepository(InMemoryDatabase db) => _db = db;

    public Task<IReadOnlyList<SourceSystem>> GetAllAsync(CancellationToken ct)
    {
        lock (_db.Sync)
        {
            return Task.FromResult<IReadOnlyList<SourceSystem>>(_db.SourceSystems.OrderBy(s => s.SystemCode).Select(InMemoryDatabase.Clone).ToList());
        }
    }

    public Task<SourceSystem?> GetByIdAsync(int sourceSystemId, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var s = _db.SourceSystems.FirstOrDefault(x => x.SourceSystemId == sourceSystemId);
            return Task.FromResult(s is null ? null : InMemoryDatabase.Clone(s));
        }
    }

    public Task<SourceSystem?> GetByCodeAsync(string systemCode, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var s = _db.SourceSystems.FirstOrDefault(x => string.Equals(x.SystemCode, systemCode, StringComparison.OrdinalIgnoreCase));
            return Task.FromResult(s is null ? null : InMemoryDatabase.Clone(s));
        }
    }

    public Task<int> CreateAsync(SourceSystem sourceSystem, AuditContext audit, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            if (_db.SourceSystems.Any(s => s.SystemCode == sourceSystem.SystemCode))
            {
                throw new ConflictException("Source system code already exists.");
            }

            var entity = InMemoryDatabase.Clone(sourceSystem);
            entity.SourceSystemId = _db.NextId();
            entity.CreatedBy = audit.UserName;
            entity.CreatedOn = DateTime.UtcNow;
            entity.RowVersion = _db.NextRowVersion();
            entity.Modules.ForEach(m => { m.ModuleId = _db.NextId(); m.SourceSystemId = entity.SourceSystemId; m.CreatedBy = audit.UserName; m.CreatedOn = DateTime.UtcNow; });
            entity.AuthorizedUsers.ForEach(u => { u.SourceSystemUserId = _db.NextId(); u.SourceSystemId = entity.SourceSystemId; u.CreatedBy = audit.UserName; u.CreatedOn = DateTime.UtcNow; });
            _db.SourceSystems.Add(entity);
            _db.WriteAudit("SourceSystem", entity.SourceSystemId, "Created", audit, new { entity.SystemCode });
            return Task.FromResult(entity.SourceSystemId);
        }
    }

    public Task UpdateAsync(SourceSystem sourceSystem, AuditContext audit, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var existing = _db.SourceSystems.FirstOrDefault(s => s.SourceSystemId == sourceSystem.SourceSystemId) ?? throw new NotFoundException("Source system not found.");
            if (existing.RowVersion != sourceSystem.RowVersion)
            {
                throw new ConcurrencyException();
            }

            existing.ApplicationName = sourceSystem.ApplicationName;
            existing.Description = sourceSystem.Description;
            existing.DefaultTaskQueue = sourceSystem.DefaultTaskQueue;
            existing.Status = sourceSystem.Status;
            existing.ModifiedBy = audit.UserName;
            existing.ModifiedOn = DateTime.UtcNow;
            existing.RowVersion = _db.NextRowVersion();

            foreach (var m in sourceSystem.Modules)
            {
                var current = existing.Modules.FirstOrDefault(x => x.ModuleCode == m.ModuleCode);
                if (current is null)
                {
                    existing.Modules.Add(new SourceSystemModule { ModuleId = _db.NextId(), SourceSystemId = existing.SourceSystemId, ModuleCode = m.ModuleCode, ModuleName = m.ModuleName, Description = m.Description, Status = m.Status, CreatedBy = audit.UserName, CreatedOn = DateTime.UtcNow });
                }
                else
                {
                    current.ModuleName = m.ModuleName;
                    current.Description = m.Description;
                    current.Status = m.Status;
                }
            }

            existing.AuthorizedUsers = sourceSystem.AuthorizedUsers.Select(u => new SourceSystemUser
            {
                SourceSystemUserId = _db.NextId(), SourceSystemId = existing.SourceSystemId, UserPrincipal = u.UserPrincipal, DisplayName = u.DisplayName,
                AccessRole = u.AccessRole, IsActive = u.IsActive, CreatedBy = audit.UserName, CreatedOn = DateTime.UtcNow
            }).ToList();
            _db.WriteAudit("SourceSystem", existing.SourceSystemId, "Updated", audit);
            return Task.CompletedTask;
        }
    }

    public Task<IReadOnlyList<SourceSystemAccessRole>> GetUserAccessRolesAsync(int sourceSystemId, string userPrincipal, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var roles = _db.SourceSystems
                .Where(s => s.SourceSystemId == sourceSystemId && s.Status == EntityStatus.Active)
                .SelectMany(s => s.AuthorizedUsers)
                .Where(u => u.IsActive && string.Equals(u.UserPrincipal, userPrincipal, StringComparison.OrdinalIgnoreCase))
                .Select(u => u.AccessRole).Distinct().ToList();
            return Task.FromResult<IReadOnlyList<SourceSystemAccessRole>>(roles);
        }
    }

    public Task<IReadOnlyList<int>> GetAuthorizedSourceSystemIdsAsync(string userPrincipal, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var ids = _db.SourceSystems
                .Where(s => s.Status == EntityStatus.Active && s.AuthorizedUsers.Any(u => u.IsActive && string.Equals(u.UserPrincipal, userPrincipal, StringComparison.OrdinalIgnoreCase)))
                .Select(s => s.SourceSystemId).ToList();
            return Task.FromResult<IReadOnlyList<int>>(ids);
        }
    }
}

public sealed class InMemoryWorkflowRepository : IWorkflowRepository
{
    private readonly InMemoryDatabase _db;

    public InMemoryWorkflowRepository(InMemoryDatabase db) => _db = db;

    public Task<PagedResult<WorkflowTemplate>> SearchAsync(WorkflowQuery query, IReadOnlyCollection<int>? allowedSourceSystemIds, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var items = _db.Templates.Select(_db.TemplateView)
                .Where(t => query.SourceSystemId is null || t.SourceSystemId == query.SourceSystemId)
                .Where(t => query.ModuleId is null || t.ModuleId == query.ModuleId)
                .Where(t => string.IsNullOrWhiteSpace(query.Status) || t.Status.ToString() == query.Status || t.LatestVersionStatus.ToString() == query.Status)
                .Where(t => string.IsNullOrWhiteSpace(query.Search) || t.TemplateCode.Contains(query.Search, StringComparison.OrdinalIgnoreCase) || t.WorkflowName.Contains(query.Search, StringComparison.OrdinalIgnoreCase))
                .Where(t => allowedSourceSystemIds is null || allowedSourceSystemIds.Contains(t.SourceSystemId))
                .OrderByDescending(t => t.ModifiedOn ?? t.CreatedOn).ThenByDescending(t => t.WorkflowTemplateId)
                .ToList();
            return Task.FromResult(new PagedResult<WorkflowTemplate>
            {
                TotalCount = items.Count,
                PageNumber = query.PageNumber,
                PageSize = query.PageSize,
                Items = items.Skip((query.PageNumber - 1) * query.PageSize).Take(query.PageSize).ToList()
            });
        }
    }

    public Task<WorkflowTemplate?> GetTemplateAsync(int workflowTemplateId, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var t = _db.Templates.FirstOrDefault(x => x.WorkflowTemplateId == workflowTemplateId);
            return Task.FromResult(t is null ? null : _db.TemplateView(t));
        }
    }

    public Task<WorkflowTemplate?> GetTemplateByCodeAsync(string templateCode, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var t = _db.Templates.FirstOrDefault(x => string.Equals(x.TemplateCode, templateCode, StringComparison.OrdinalIgnoreCase));
            return Task.FromResult(t is null ? null : _db.TemplateView(t));
        }
    }

    public Task<IReadOnlyList<WorkflowVersion>> GetVersionsAsync(int workflowTemplateId, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var list = _db.Versions.Where(v => v.WorkflowTemplateId == workflowTemplateId).OrderByDescending(v => v.VersionNo)
                .Select(v => { var c = InMemoryDatabase.Clone(v); c.DefinitionJson = null; return c; }).ToList();
            return Task.FromResult<IReadOnlyList<WorkflowVersion>>(list);
        }
    }

    public Task<WorkflowGraph?> GetGraphAsync(int workflowTemplateId, int? versionNo, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var template = _db.Templates.FirstOrDefault(t => t.WorkflowTemplateId == workflowTemplateId);
            if (template is null)
            {
                return Task.FromResult<WorkflowGraph?>(null);
            }

            var version = _db.Versions.FirstOrDefault(v => v.WorkflowTemplateId == workflowTemplateId && v.VersionNo == (versionNo ?? template.LatestVersionNo));
            if (version is null)
            {
                return Task.FromResult<WorkflowGraph?>(null);
            }

            var content = _db.Content[version.WorkflowVersionId];
            var ss = _db.SourceSystems.First(s => s.SourceSystemId == template.SourceSystemId);
            var versionCopy = InMemoryDatabase.Clone(version);
            versionCopy.DefinitionJson = null;
            return Task.FromResult<WorkflowGraph?>(new WorkflowGraph
            {
                Template = _db.TemplateView(template),
                Version = versionCopy,
                SourceSystem = new SourceSystem { SourceSystemId = ss.SourceSystemId, SystemCode = ss.SystemCode, ApplicationName = ss.ApplicationName, DefaultTaskQueue = ss.DefaultTaskQueue, Status = ss.Status },
                Module = InMemoryDatabase.Clone(ss.Modules.First(m => m.ModuleId == template.ModuleId)),
                Activities = content.Activities.Select(InMemoryDatabase.Clone).ToList(),
                Connections = content.Connections.Select(InMemoryDatabase.Clone).ToList(),
                Parameters = content.Parameters.Select(InMemoryDatabase.Clone).ToList()
            });
        }
    }

    public Task<int> CreateAsync(WorkflowTemplate template, string? changeNotes, WorkflowGraph initialGraph, AuditContext audit, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            if (_db.Templates.Any(t => t.TemplateCode == template.TemplateCode))
            {
                throw new ConflictException("Template code already exists.");
            }

            var entity = InMemoryDatabase.Clone(template);
            entity.WorkflowTemplateId = _db.NextId();
            entity.LatestVersionNo = 1;
            entity.Status = TemplateStatus.Active;
            entity.CreatedBy = audit.UserName;
            entity.CreatedOn = DateTime.UtcNow;
            entity.RowVersion = _db.NextRowVersion();
            _db.Templates.Add(entity);

            var version = new WorkflowVersion
            {
                WorkflowVersionId = _db.NextId(), WorkflowTemplateId = entity.WorkflowTemplateId, VersionNo = 1, Status = VersionStatus.Draft,
                ChangeNotes = changeNotes, CreatedBy = audit.UserName, CreatedOn = DateTime.UtcNow, RowVersion = _db.NextRowVersion()
            };
            _db.Versions.Add(version);

            var content = new InMemoryDatabase.VersionContent();
            foreach (var a in initialGraph.Activities)
            {
                var copy = InMemoryDatabase.Clone(a);
                copy.ActivityId = _db.NextId();
                copy.WorkflowVersionId = version.WorkflowVersionId;
                copy.RowVersion = _db.NextRowVersion();
                copy.Parameters.ForEach(p => { p.ActivityParameterId = _db.NextId(); p.ActivityId = copy.ActivityId; });
                if (copy.Approval is not null)
                {
                    copy.Approval.ApprovalConfigId = _db.NextId();
                    copy.Approval.ActivityId = copy.ActivityId;
                }

                content.Activities.Add(copy);
            }

            foreach (var c in initialGraph.Connections)
            {
                var copy = InMemoryDatabase.Clone(c);
                copy.ConnectionId = _db.NextId();
                copy.WorkflowVersionId = version.WorkflowVersionId;
                content.Connections.Add(copy);
            }

            foreach (var p in initialGraph.Parameters)
            {
                var copy = InMemoryDatabase.Clone(p);
                copy.ParameterId = _db.NextId();
                copy.WorkflowVersionId = version.WorkflowVersionId;
                copy.RowVersion = _db.NextRowVersion();
                content.Parameters.Add(copy);
            }

            _db.Content[version.WorkflowVersionId] = content;
            _db.WriteAudit("WorkflowTemplate", entity.WorkflowTemplateId, "Created", audit, new { entity.TemplateCode });
            return Task.FromResult(entity.WorkflowTemplateId);
        }
    }

    public Task UpdateHeaderAsync(int workflowTemplateId, string workflowName, string? description, string? changeNotes, string rowVersion, AuditContext audit, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var t = _db.Templates.FirstOrDefault(x => x.WorkflowTemplateId == workflowTemplateId) ?? throw new NotFoundException("Workflow template not found.");
            if (t.RowVersion != rowVersion)
            {
                throw new ConcurrencyException();
            }

            t.WorkflowName = workflowName;
            t.Description = description;
            t.ModifiedBy = audit.UserName;
            t.ModifiedOn = DateTime.UtcNow;
            t.RowVersion = _db.NextRowVersion();
            var draft = _db.Versions.FirstOrDefault(v => v.WorkflowTemplateId == workflowTemplateId && v.IsEditable);
            if (draft is not null)
            {
                draft.ChangeNotes = changeNotes;
            }

            _db.WriteAudit("WorkflowTemplate", workflowTemplateId, "HeaderUpdated", audit);
            return Task.CompletedTask;
        }
    }

    public Task<int> CreateVersionAsync(int workflowTemplateId, int basedOnVersionNo, string? changeNotes, AuditContext audit, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var t = _db.Templates.First(x => x.WorkflowTemplateId == workflowTemplateId);
            if (_db.Versions.Any(v => v.WorkflowTemplateId == workflowTemplateId && v.IsEditable))
            {
                throw new ConflictException("An open draft version already exists.");
            }

            var source = _db.Versions.FirstOrDefault(v => v.WorkflowTemplateId == workflowTemplateId && v.VersionNo == basedOnVersionNo) ?? throw new NotFoundException("Base version not found.");
            var version = new WorkflowVersion
            {
                WorkflowVersionId = _db.NextId(), WorkflowTemplateId = workflowTemplateId, VersionNo = t.LatestVersionNo + 1, Status = VersionStatus.Draft,
                BasedOnVersionNo = basedOnVersionNo, ChangeNotes = changeNotes, CreatedBy = audit.UserName, CreatedOn = DateTime.UtcNow, RowVersion = _db.NextRowVersion()
            };
            _db.Versions.Add(version);
            _db.CopyContent(source.WorkflowVersionId, version.WorkflowVersionId, audit.UserName);
            t.LatestVersionNo = version.VersionNo;
            t.ModifiedBy = audit.UserName;
            t.ModifiedOn = DateTime.UtcNow;
            t.RowVersion = _db.NextRowVersion();
            _db.WriteAudit("WorkflowTemplate", workflowTemplateId, "VersionCreated", audit, new { version.VersionNo });
            return Task.FromResult(version.VersionNo);
        }
    }

    public Task<int> CloneAsync(int workflowTemplateId, int fromVersionNo, string newTemplateCode, string workflowName, int sourceSystemId, int moduleId, AuditContext audit, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var source = _db.Templates.First(x => x.WorkflowTemplateId == workflowTemplateId);
            var sourceVersion = _db.Versions.FirstOrDefault(v => v.WorkflowTemplateId == workflowTemplateId && v.VersionNo == fromVersionNo) ?? throw new NotFoundException("Source version not found.");
            if (_db.Templates.Any(t => t.TemplateCode == newTemplateCode))
            {
                throw new ConflictException("Template code already exists.");
            }

            var entity = new WorkflowTemplate
            {
                WorkflowTemplateId = _db.NextId(), TemplateCode = newTemplateCode, SourceSystemId = sourceSystemId, ModuleId = moduleId, WorkflowName = workflowName,
                Description = source.Description, Status = TemplateStatus.Active, LatestVersionNo = 1, ClonedFromTemplateId = workflowTemplateId,
                CreatedBy = audit.UserName, CreatedOn = DateTime.UtcNow, RowVersion = _db.NextRowVersion()
            };
            _db.Templates.Add(entity);
            var version = new WorkflowVersion
            {
                WorkflowVersionId = _db.NextId(), WorkflowTemplateId = entity.WorkflowTemplateId, VersionNo = 1, Status = VersionStatus.Draft,
                ChangeNotes = $"Cloned from template {workflowTemplateId} version {fromVersionNo}", CreatedBy = audit.UserName, CreatedOn = DateTime.UtcNow, RowVersion = _db.NextRowVersion()
            };
            _db.Versions.Add(version);
            _db.CopyContent(sourceVersion.WorkflowVersionId, version.WorkflowVersionId, audit.UserName);
            _db.WriteAudit("WorkflowTemplate", entity.WorkflowTemplateId, "Cloned", audit);
            _db.WriteAudit("WorkflowTemplate", workflowTemplateId, "ClonedTo", audit);
            return Task.FromResult(entity.WorkflowTemplateId);
        }
    }

    public Task SaveValidationAsync(int workflowVersionId, bool isValid, string reportJson, AuditContext audit, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var v = _db.AssertEditable(workflowVersionId);
            v.Status = isValid ? VersionStatus.Validated : VersionStatus.Draft;
            v.ValidationResultJson = reportJson;
            v.ValidatedOn = DateTime.UtcNow;
            v.ValidatedBy = audit.UserName;
            v.RowVersion = _db.NextRowVersion();
            _db.WriteAudit("WorkflowTemplate", v.WorkflowTemplateId, "Validated", audit, new { v.VersionNo, isValid });
            return Task.CompletedTask;
        }
    }

    public Task<PublishResult> PublishAsync(int workflowVersionId, string expectedVersionRowVersion, string definitionJson, string definitionHash, string? comments, AuditContext audit, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var v = _db.AssertEditable(workflowVersionId);
            if (v.RowVersion != expectedVersionRowVersion)
            {
                throw new ConcurrencyException("The draft changed after it was validated for publishing. Reload and try again.");
            }

            foreach (var old in _db.Versions.Where(x => x.WorkflowTemplateId == v.WorkflowTemplateId && x.Status == VersionStatus.Published))
            {
                old.Status = VersionStatus.Superseded;
                old.RowVersion = _db.NextRowVersion();
            }

            v.Status = VersionStatus.Published;
            v.DefinitionJson = definitionJson;
            v.DefinitionHash = definitionHash;
            v.PublishedBy = audit.UserName;
            v.PublishedOn = DateTime.UtcNow;
            v.RowVersion = _db.NextRowVersion();
            var t = _db.Templates.First(x => x.WorkflowTemplateId == v.WorkflowTemplateId);
            t.PublishedVersionNo = v.VersionNo;
            t.ModifiedBy = audit.UserName;
            t.ModifiedOn = DateTime.UtcNow;
            t.RowVersion = _db.NextRowVersion();
            _db.WriteAudit("WorkflowTemplate", t.WorkflowTemplateId, "Published", audit, new { v.VersionNo, definitionHash, comments });
            return Task.FromResult(new PublishResult
            {
                WorkflowTemplateId = t.WorkflowTemplateId, TemplateCode = t.TemplateCode, VersionNo = v.VersionNo,
                DefinitionHash = definitionHash, PublishedBy = audit.UserName, PublishedOn = v.PublishedOn.Value
            });
        }
    }

    public Task SetTemplateStatusAsync(int workflowTemplateId, TemplateStatus status, string reason, AuditContext audit, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var t = _db.Templates.FirstOrDefault(x => x.WorkflowTemplateId == workflowTemplateId) ?? throw new NotFoundException("Workflow template not found.");
            t.Status = status;
            t.ModifiedBy = audit.UserName;
            t.ModifiedOn = DateTime.UtcNow;
            t.RowVersion = _db.NextRowVersion();
            _db.WriteAudit("WorkflowTemplate", workflowTemplateId, status == TemplateStatus.Active ? "Activated" : "Deactivated", audit, new { reason });
            return Task.CompletedTask;
        }
    }

    public Task<string?> GetPublishedDefinitionAsync(int workflowTemplateId, int? versionNo, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var t = _db.Templates.First(x => x.WorkflowTemplateId == workflowTemplateId);
            var v = _db.Versions.FirstOrDefault(x => x.WorkflowTemplateId == workflowTemplateId && x.VersionNo == (versionNo ?? t.PublishedVersionNo)
                                                     && x.Status is VersionStatus.Published or VersionStatus.Superseded);
            return Task.FromResult(v?.DefinitionJson);
        }
    }

    public Task<DashboardSummary> GetDashboardAsync(IReadOnlyCollection<int>? allowedSourceSystemIds, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            bool Allowed(int id) => allowedSourceSystemIds is null || allowedSourceSystemIds.Contains(id);
            var templates = _db.Templates.Where(t => Allowed(t.SourceSystemId)).ToList();
            return Task.FromResult(new DashboardSummary
            {
                SourceSystemCount = _db.SourceSystems.Count(s => Allowed(s.SourceSystemId)),
                TemplateCount = templates.Count,
                DraftVersionCount = _db.Versions.Count(v => v.IsEditable && templates.Any(t => t.WorkflowTemplateId == v.WorkflowTemplateId)),
                PublishedTemplateCount = templates.Count(t => t.PublishedVersionNo.HasValue),
                InactiveTemplateCount = templates.Count(t => t.Status == TemplateStatus.Inactive),
                SchedulerCount = _db.Schedulers.Count(s => Allowed(s.SourceSystemId)),
                RecentActivity = _db.Audit.OrderByDescending(a => a.AuditLogId).Take(15).Select(InMemoryDatabase.Clone).ToList()
            });
        }
    }
}

public sealed class InMemoryActivityRepository : IActivityRepository
{
    private readonly InMemoryDatabase _db;

    public InMemoryActivityRepository(InMemoryDatabase db) => _db = db;

    public Task<WorkflowActivity> AddAsync(int workflowVersionId, WorkflowActivity activity, AuditContext audit, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var v = _db.AssertEditable(workflowVersionId);
            var content = _db.Content[workflowVersionId];
            if (content.Activities.Any(a => a.ActivityKey == activity.ActivityKey))
            {
                throw new ConflictException("Activity key already exists in this version.");
            }

            var copy = InMemoryDatabase.Clone(activity);
            copy.ActivityId = _db.NextId();
            copy.WorkflowVersionId = workflowVersionId;
            copy.RowVersion = _db.NextRowVersion();
            copy.Parameters.ForEach(p => { p.ActivityParameterId = _db.NextId(); p.ActivityId = copy.ActivityId; });
            if (copy.Approval is not null)
            {
                copy.Approval.ApprovalConfigId = _db.NextId();
                copy.Approval.ActivityId = copy.ActivityId;
            }

            content.Activities.Add(copy);
            _db.Touch(v, audit.UserName);
            _db.WriteAudit("WorkflowTemplate", v.WorkflowTemplateId, "ActivityAdded", audit, new { copy.ActivityKey });
            return Task.FromResult(InMemoryDatabase.Clone(copy));
        }
    }

    public Task<WorkflowActivity> UpdateAsync(int workflowVersionId, WorkflowActivity activity, bool replaceParameters, AuditContext audit, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var v = _db.AssertEditable(workflowVersionId);
            var content = _db.Content[workflowVersionId];
            var existing = content.Activities.FirstOrDefault(a => a.ActivityId == activity.ActivityId) ?? throw new NotFoundException("Activity not found in this workflow version.");
            if (existing.RowVersion != activity.RowVersion)
            {
                throw new ConcurrencyException("The activity was modified by another user. Reload and try again.");
            }

            if (existing.ActivityKey != activity.ActivityKey && content.Activities.Any(a => a.ActivityKey == activity.ActivityKey))
            {
                throw new ConflictException("Activity key already exists in this version.");
            }

            var updated = InMemoryDatabase.Clone(activity);
            updated.WorkflowVersionId = workflowVersionId;
            updated.RowVersion = _db.NextRowVersion();
            updated.ModifiedBy = audit.UserName;
            updated.ModifiedOn = DateTime.UtcNow;
            updated.Parameters = replaceParameters ? updated.Parameters : existing.Parameters;
            updated.Parameters.ForEach(p => { p.ActivityParameterId = p.ActivityParameterId == 0 ? _db.NextId() : p.ActivityParameterId; p.ActivityId = updated.ActivityId; });
            updated.Approval = activity.Approval is null ? existing.Approval : InMemoryDatabase.Clone(activity.Approval);
            content.Activities[content.Activities.IndexOf(existing)] = updated;

            // Connections reference activities by id in SQL; keep keys in sync after a rename.
            foreach (var c in content.Connections)
            {
                if (c.FromActivityKey == existing.ActivityKey) { c.FromActivityKey = updated.ActivityKey; }
                if (c.ToActivityKey == existing.ActivityKey) { c.ToActivityKey = updated.ActivityKey; }
            }

            _db.Touch(v, audit.UserName);
            _db.WriteAudit("WorkflowTemplate", v.WorkflowTemplateId, "ActivityUpdated", audit, new { updated.ActivityKey });
            return Task.FromResult(InMemoryDatabase.Clone(updated));
        }
    }

    public Task DeleteAsync(int workflowVersionId, int activityId, AuditContext audit, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var v = _db.AssertEditable(workflowVersionId);
            var content = _db.Content[workflowVersionId];
            var existing = content.Activities.FirstOrDefault(a => a.ActivityId == activityId) ?? throw new NotFoundException("Activity not found in this workflow version.");
            content.Connections.RemoveAll(c => c.FromActivityKey == existing.ActivityKey || c.ToActivityKey == existing.ActivityKey);
            content.Activities.Remove(existing);
            _db.Touch(v, audit.UserName);
            _db.WriteAudit("WorkflowTemplate", v.WorkflowTemplateId, "ActivityDeleted", audit, new { existing.ActivityKey });
            return Task.CompletedTask;
        }
    }

    public Task UpdateLayoutAsync(int workflowVersionId, IReadOnlyList<ActivityPositionRequest> positions, AuditContext audit, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            _db.AssertEditable(workflowVersionId);
            var content = _db.Content[workflowVersionId];
            foreach (var p in positions)
            {
                var a = content.Activities.FirstOrDefault(x => x.ActivityKey == p.ActivityKey);
                if (a is not null)
                {
                    a.PositionX = p.PositionX;
                    a.PositionY = p.PositionY;
                }
            }

            return Task.CompletedTask;
        }
    }

    public Task SaveApprovalAsync(int workflowVersionId, int activityId, ApprovalConfiguration configuration, AuditContext audit, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var v = _db.AssertEditable(workflowVersionId);
            var a = _db.Content[workflowVersionId].Activities.FirstOrDefault(x => x.ActivityId == activityId) ?? throw new NotFoundException("Activity not found in this workflow version.");
            a.Approval = InMemoryDatabase.Clone(configuration);
            a.Approval.ActivityId = activityId;
            a.Approval.ApprovalConfigId = a.Approval.ApprovalConfigId == 0 ? _db.NextId() : a.Approval.ApprovalConfigId;
            _db.Touch(v, audit.UserName);
            _db.WriteAudit("WorkflowTemplate", v.WorkflowTemplateId, "ApprovalConfigured", audit, new { activityId });
            return Task.CompletedTask;
        }
    }

    public Task<ActivityConnection> AddConnectionAsync(int workflowVersionId, ActivityConnection connection, AuditContext audit, CancellationToken ct) =>
        SaveConnection(workflowVersionId, connection, audit, isNew: true);

    public Task<ActivityConnection> UpdateConnectionAsync(int workflowVersionId, ActivityConnection connection, AuditContext audit, CancellationToken ct) =>
        SaveConnection(workflowVersionId, connection, audit, isNew: false);

    private Task<ActivityConnection> SaveConnection(int workflowVersionId, ActivityConnection connection, AuditContext audit, bool isNew)
    {
        lock (_db.Sync)
        {
            var v = _db.AssertEditable(workflowVersionId);
            var content = _db.Content[workflowVersionId];
            if (content.Connections.Any(c => c.ConnectionId != connection.ConnectionId && c.FromActivityKey == connection.FromActivityKey
                                              && c.ToActivityKey == connection.ToActivityKey && c.ConnectionType == connection.ConnectionType))
            {
                throw new ConflictException("An identical connection already exists.");
            }

            var copy = InMemoryDatabase.Clone(connection);
            copy.WorkflowVersionId = workflowVersionId;
            if (isNew)
            {
                copy.ConnectionId = _db.NextId();
                content.Connections.Add(copy);
            }
            else
            {
                var index = content.Connections.FindIndex(c => c.ConnectionId == connection.ConnectionId);
                if (index < 0)
                {
                    throw new NotFoundException("Connection not found in this workflow version.");
                }

                content.Connections[index] = copy;
            }

            _db.Touch(v, audit.UserName);
            _db.WriteAudit("WorkflowTemplate", v.WorkflowTemplateId, isNew ? "ConnectionAdded" : "ConnectionUpdated", audit);
            return Task.FromResult(InMemoryDatabase.Clone(copy));
        }
    }

    public Task DeleteConnectionAsync(int workflowVersionId, int connectionId, AuditContext audit, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var v = _db.AssertEditable(workflowVersionId);
            if (_db.Content[workflowVersionId].Connections.RemoveAll(c => c.ConnectionId == connectionId) == 0)
            {
                throw new NotFoundException("Connection not found in this workflow version.");
            }

            _db.Touch(v, audit.UserName);
            _db.WriteAudit("WorkflowTemplate", v.WorkflowTemplateId, "ConnectionDeleted", audit);
            return Task.CompletedTask;
        }
    }
}

public sealed class InMemoryParameterRepository : IParameterRepository
{
    private readonly InMemoryDatabase _db;

    public InMemoryParameterRepository(InMemoryDatabase db) => _db = db;

    public Task<WorkflowParameter> AddAsync(int workflowVersionId, WorkflowParameter parameter, AuditContext audit, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var v = _db.AssertEditable(workflowVersionId);
            var content = _db.Content[workflowVersionId];
            if (content.Parameters.Any(p => p.Direction == parameter.Direction && p.Name == parameter.Name))
            {
                throw new ConflictException("A workflow parameter with this name and direction already exists.");
            }

            var copy = InMemoryDatabase.Clone(parameter);
            copy.ParameterId = _db.NextId();
            copy.WorkflowVersionId = workflowVersionId;
            copy.RowVersion = _db.NextRowVersion();
            content.Parameters.Add(copy);
            _db.Touch(v, audit.UserName);
            _db.WriteAudit("WorkflowTemplate", v.WorkflowTemplateId, "ParameterAdded", audit, new { copy.Name });
            return Task.FromResult(InMemoryDatabase.Clone(copy));
        }
    }

    public Task<WorkflowParameter> UpdateAsync(int workflowVersionId, WorkflowParameter parameter, AuditContext audit, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var v = _db.AssertEditable(workflowVersionId);
            var content = _db.Content[workflowVersionId];
            var index = content.Parameters.FindIndex(p => p.ParameterId == parameter.ParameterId);
            if (index < 0)
            {
                throw new NotFoundException("Parameter not found in this workflow version.");
            }

            if (content.Parameters[index].RowVersion != parameter.RowVersion)
            {
                throw new ConcurrencyException("The parameter was modified by another user. Reload and try again.");
            }

            var copy = InMemoryDatabase.Clone(parameter);
            copy.WorkflowVersionId = workflowVersionId;
            copy.RowVersion = _db.NextRowVersion();
            content.Parameters[index] = copy;
            _db.Touch(v, audit.UserName);
            _db.WriteAudit("WorkflowTemplate", v.WorkflowTemplateId, "ParameterUpdated", audit, new { copy.Name });
            return Task.FromResult(InMemoryDatabase.Clone(copy));
        }
    }

    public Task DeleteAsync(int workflowVersionId, int parameterId, AuditContext audit, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var v = _db.AssertEditable(workflowVersionId);
            if (_db.Content[workflowVersionId].Parameters.RemoveAll(p => p.ParameterId == parameterId) == 0)
            {
                throw new NotFoundException("Parameter not found in this workflow version.");
            }

            _db.Touch(v, audit.UserName);
            _db.WriteAudit("WorkflowTemplate", v.WorkflowTemplateId, "ParameterDeleted", audit);
            return Task.CompletedTask;
        }
    }
}

public sealed class InMemorySchedulerRepository : ISchedulerRepository
{
    private readonly InMemoryDatabase _db;

    public InMemorySchedulerRepository(InMemoryDatabase db) => _db = db;

    private SchedulerConfiguration View(SchedulerConfiguration s)
    {
        var copy = InMemoryDatabase.Clone(s);
        copy.ApprovedQueryCode = _db.Queries.First(q => q.ApprovedQueryId == s.ApprovedQueryId).QueryCode;
        copy.TargetTemplateCode = _db.Templates.First(t => t.WorkflowTemplateId == s.TargetWorkflowTemplateId).TemplateCode;
        return copy;
    }

    public Task<IReadOnlyList<SchedulerConfiguration>> GetAllAsync(IReadOnlyCollection<int>? allowedSourceSystemIds, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            return Task.FromResult<IReadOnlyList<SchedulerConfiguration>>(_db.Schedulers
                .Where(s => allowedSourceSystemIds is null || allowedSourceSystemIds.Contains(s.SourceSystemId))
                .OrderBy(s => s.SchedulerCode).Select(View).ToList());
        }
    }

    public Task<SchedulerConfiguration?> GetByIdAsync(int schedulerConfigId, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var s = _db.Schedulers.FirstOrDefault(x => x.SchedulerConfigId == schedulerConfigId);
            return Task.FromResult(s is null ? null : View(s));
        }
    }

    public Task<int> CreateAsync(SchedulerConfiguration configuration, AuditContext audit, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            if (_db.Schedulers.Any(s => s.SchedulerCode == configuration.SchedulerCode))
            {
                throw new ConflictException("Scheduler code already exists.");
            }

            var copy = InMemoryDatabase.Clone(configuration);
            copy.SchedulerConfigId = _db.NextId();
            copy.CreatedBy = audit.UserName;
            copy.CreatedOn = DateTime.UtcNow;
            copy.RowVersion = _db.NextRowVersion();
            _db.Schedulers.Add(copy);
            _db.WriteAudit("SchedulerConfiguration", copy.SchedulerConfigId, "Created", audit);
            return Task.FromResult(copy.SchedulerConfigId);
        }
    }

    public Task UpdateAsync(SchedulerConfiguration configuration, AuditContext audit, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            var index = _db.Schedulers.FindIndex(s => s.SchedulerConfigId == configuration.SchedulerConfigId);
            if (index < 0)
            {
                throw new NotFoundException("Scheduler configuration not found.");
            }

            if (_db.Schedulers[index].RowVersion != configuration.RowVersion)
            {
                throw new ConcurrencyException();
            }

            var copy = InMemoryDatabase.Clone(configuration);
            copy.CreatedBy = _db.Schedulers[index].CreatedBy;
            copy.CreatedOn = _db.Schedulers[index].CreatedOn;
            copy.ModifiedBy = audit.UserName;
            copy.ModifiedOn = DateTime.UtcNow;
            copy.RowVersion = _db.NextRowVersion();
            _db.Schedulers[index] = copy;
            _db.WriteAudit("SchedulerConfiguration", copy.SchedulerConfigId, "Updated", audit);
            return Task.CompletedTask;
        }
    }
}

public sealed class InMemoryReferenceDataRepository : IReferenceDataRepository, IAuditRepository
{
    private readonly InMemoryDatabase _db;

    public InMemoryReferenceDataRepository(InMemoryDatabase db) => _db = db;

    public Task<IReadOnlyList<ConnectionProfile>> GetConnectionProfilesAsync(CancellationToken ct)
    {
        lock (_db.Sync)
        {
            return Task.FromResult<IReadOnlyList<ConnectionProfile>>(_db.Profiles.Select(InMemoryDatabase.Clone).ToList());
        }
    }

    public Task<IReadOnlyList<ApprovedOracleQuery>> GetApprovedQueriesAsync(CancellationToken ct)
    {
        lock (_db.Sync)
        {
            return Task.FromResult<IReadOnlyList<ApprovedOracleQuery>>(_db.Queries.Select(InMemoryDatabase.Clone).ToList());
        }
    }

    public Task<IReadOnlyList<AuditLogEntry>> GetAsync(string? entityType, string? entityId, int maxRows, CancellationToken ct)
    {
        lock (_db.Sync)
        {
            return Task.FromResult<IReadOnlyList<AuditLogEntry>>(_db.Audit
                .Where(a => entityType is null || a.EntityType == entityType)
                .Where(a => entityId is null || a.EntityId == entityId)
                .OrderByDescending(a => a.AuditLogId).Take(maxRows).Select(InMemoryDatabase.Clone).ToList());
        }
    }
}
