using BankWorkflowDesigner.Application.Abstractions;
using BankWorkflowDesigner.Application.Definitions;
using BankWorkflowDesigner.Application.Services;
using BankWorkflowDesigner.Application.Validation;
using BankWorkflowDesigner.Domain.Security;
using Microsoft.Extensions.Options;

namespace BankWorkflowDesigner.TestSupport;

public sealed class FakeCurrentUser : ICurrentUser
{
    public FakeCurrentUser(string userName, params string[] roles)
    {
        UserName = userName;
        RoleSet = new HashSet<string>(roles);
    }

    public string UserName { get; set; }
    public HashSet<string> RoleSet { get; }
    public bool IsAuthenticated => true;
    public IReadOnlyCollection<string> Roles => RoleSet;
    public bool IsInRole(string role) => RoleSet.Contains(role);
    public string? CorrelationId => "test-correlation";
    public string? ClientIp => "127.0.0.1";
}

/// <summary>Wires the real application services to the in-memory repositories.</summary>
public sealed class TestHarness
{
    public TestHarness(FakeCurrentUser? user = null, InMemoryDatabase? db = null, bool enforceFourEyes = true)
    {
        Db = db ?? InMemoryDatabase.CreateSeeded();
        User = user ?? Users.Alice();
        var options = Options.Create(new WorkflowSecurityOptions { EnforcePublishSegregation = enforceFourEyes, AdminsBypassSourceSystemAuthorization = true });

        SourceSystemRepository = new InMemorySourceSystemRepository(Db);
        WorkflowRepository = new InMemoryWorkflowRepository(Db);
        ActivityRepository = new InMemoryActivityRepository(Db);
        ParameterRepository = new InMemoryParameterRepository(Db);
        SchedulerRepository = new InMemorySchedulerRepository(Db);
        ReferenceRepository = new InMemoryReferenceDataRepository(Db);

        Guard = new AccessGuard(User, SourceSystemRepository, options);
        SourceSystems = new SourceSystemService(SourceSystemRepository, Guard);
        Workflows = new WorkflowService(WorkflowRepository, SourceSystemRepository, ReferenceRepository, new WorkflowValidator(),
            new WorkflowDefinitionBuilder(), Guard, User, new SystemClock(), ReferenceRepository, options);
        Activities = new ActivityService(WorkflowRepository, ActivityRepository, Guard);
        Parameters = new ParameterService(WorkflowRepository, ParameterRepository, Guard);
        Schedulers = new SchedulerService(SchedulerRepository, WorkflowRepository, ReferenceRepository, Guard);
    }

    public InMemoryDatabase Db { get; }
    public FakeCurrentUser User { get; }
    public InMemorySourceSystemRepository SourceSystemRepository { get; }
    public InMemoryWorkflowRepository WorkflowRepository { get; }
    public InMemoryActivityRepository ActivityRepository { get; }
    public InMemoryParameterRepository ParameterRepository { get; }
    public InMemorySchedulerRepository SchedulerRepository { get; }
    public InMemoryReferenceDataRepository ReferenceRepository { get; }
    public AccessGuard Guard { get; }
    public SourceSystemService SourceSystems { get; }
    public WorkflowService Workflows { get; }
    public ActivityService Activities { get; }
    public ParameterService Parameters { get; }
    public SchedulerService Schedulers { get; }

    /// <summary>Same database, different caller.</summary>
    public TestHarness As(FakeCurrentUser user) => new(user, Db);

    public int AgriId => Db.SourceSystems.First(s => s.SystemCode == "AGRI_LOS").SourceSystemId;

    public int ModuleId(string code) => Db.SourceSystems.SelectMany(s => s.Modules).First(m => m.ModuleCode == code).ModuleId;
}

public static class Users
{
    public static FakeCurrentUser Alice() => new("alice.designer", AppRoles.Designer);
    public static FakeCurrentUser Rita() => new("rita.reviewer", AppRoles.Reviewer);
    public static FakeCurrentUser Bob() => new("bob.publisher", AppRoles.Publisher, AppRoles.Designer);
    public static FakeCurrentUser Admin() => new("dev.admin", AppRoles.SourceSystemAdmin, AppRoles.Designer, AppRoles.Reviewer, AppRoles.Publisher);
    public static FakeCurrentUser Tom() => new("tom.treasury", AppRoles.Designer);
    public static FakeCurrentUser Temporal() => new("temporal.svc", AppRoles.DefinitionConsumer);
}
