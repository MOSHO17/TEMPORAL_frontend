using System.Text.Json;
using System.Text.Json.Serialization;
using BankWorkflowDesigner.Domain.Dtos;
using BankWorkflowDesigner.Domain.Enums;
using BankWorkflowDesigner.Domain.Exceptions;
using BankWorkflowDesigner.TestSupport;
using Xunit;

namespace BankWorkflowDesigner.UnitTests;

public sealed class WorkflowServiceTests
{
    private static readonly JsonSerializerOptions JsonOptions = CreateJsonOptions();

    private static JsonSerializerOptions CreateJsonOptions()
    {
        var options = new JsonSerializerOptions(JsonSerializerDefaults.Web);
        options.Converters.Add(new JsonStringEnumConverter());
        return options;
    }

    internal static WorkflowImportRequest LoadSample(string fileName, string? templateCode = null)
    {
        var path = Path.Combine(AppContext.BaseDirectory, "samples", fileName);
        var request = JsonSerializer.Deserialize<WorkflowImportRequest>(File.ReadAllText(path), JsonOptions)!;
        if (templateCode is not null)
        {
            request.TemplateCode = templateCode;
        }

        return request;
    }

    private static async Task<WorkflowDetailResponse> CreateSimpleAsync(TestHarness h, string code = "WF_SIMPLE") =>
        await h.Workflows.CreateAsync(new CreateWorkflowRequest
        {
            SourceSystemId = h.AgriId, ModuleId = h.ModuleId("CAM_RENEWAL"), TemplateCode = code, WorkflowName = "Simple workflow"
        }, CancellationToken.None);

    [Fact]
    public async Task Create_adds_draft_v1_with_start_and_end()
    {
        var h = new TestHarness();
        var detail = await CreateSimpleAsync(h);
        Assert.Equal(1, detail.Graph.Version.VersionNo);
        Assert.Equal(VersionStatus.Draft, detail.Graph.Version.Status);
        Assert.Equal(2, detail.Graph.Activities.Count);
        Assert.Contains(h.Db.Audit, a => a.Action == "Created" && a.UserName == "alice.designer");
    }

    [Fact]
    public async Task Duplicate_template_codes_are_rejected()
    {
        var h = new TestHarness();
        await CreateSimpleAsync(h);
        await Assert.ThrowsAsync<ConflictException>(() => CreateSimpleAsync(h));
    }

    [Fact]
    public async Task Users_not_authorised_for_the_source_system_are_forbidden()
    {
        var h = new TestHarness();
        var detail = await CreateSimpleAsync(h);
        var tom = h.As(Users.Tom());
        await Assert.ThrowsAsync<ForbiddenException>(() => tom.Workflows.GetDetailAsync(detail.Template.WorkflowTemplateId, null, CancellationToken.None));
        await Assert.ThrowsAsync<ForbiddenException>(() => CreateSimpleAsync(tom, "WF_TOM"));

        var search = await tom.Workflows.SearchAsync(new WorkflowQuery(), CancellationToken.None);
        Assert.Equal(0, search.TotalCount);
    }

    [Fact]
    public async Task Reviewer_cannot_edit_but_can_validate()
    {
        var h = new TestHarness();
        var detail = await CreateSimpleAsync(h);
        var rita = h.As(Users.Rita());
        await Assert.ThrowsAsync<ForbiddenException>(() => rita.Activities.AddAsync(detail.Template.WorkflowTemplateId,
            new ActivityRequest { ActivityKey = "maker", ActivityType = ActivityType.Maker, DisplayName = "Maker" }, CancellationToken.None));
        var report = await rita.Workflows.ValidateAsync(detail.Template.WorkflowTemplateId, CancellationToken.None);
        Assert.False(report.IsValid);
    }

    [Fact]
    public async Task Full_lifecycle_import_validate_publish_version_clone()
    {
        var alice = new TestHarness();
        var imported = await alice.Workflows.ImportAsync(LoadSample("02-checker.json"), CancellationToken.None);
        var id = imported.Template.WorkflowTemplateId;

        var report = await alice.Workflows.ValidateAsync(id, CancellationToken.None);
        Assert.True(report.IsValid, string.Join("; ", report.Issues.Select(i => i.Message)));
        Assert.Equal(VersionStatus.Validated, (await alice.Workflows.GetDetailAsync(id, null, CancellationToken.None)).Graph.Version.Status);

        // Four-eyes: the designer who built it cannot publish (even with the role), another publisher can.
        var aliceAsPublisher = alice.As(new FakeCurrentUser("alice.designer", "WF_PUBLISHER", "WF_DESIGNER"));
        await Assert.ThrowsAsync<ForbiddenException>(() => aliceAsPublisher.Workflows.PublishAsync(id, new PublishWorkflowRequest { VersionNo = 1 }, CancellationToken.None));

        var bob = alice.As(Users.Bob());
        await Assert.ThrowsAsync<ConflictException>(() => bob.Workflows.PublishAsync(id, new PublishWorkflowRequest { VersionNo = 2 }, CancellationToken.None));
        var published = await bob.Workflows.PublishAsync(id, new PublishWorkflowRequest { VersionNo = 1, Comments = "CAB-123" }, CancellationToken.None);
        Assert.Equal(1, published.VersionNo);
        Assert.Equal(64, published.DefinitionHash.Length);

        // Published versions are immutable.
        var graph = (await alice.Workflows.GetDetailAsync(id, null, CancellationToken.None)).Graph;
        await Assert.ThrowsAsync<ImmutableVersionException>(() => alice.Activities.AddAsync(id,
            new ActivityRequest { ActivityKey = "another", ActivityType = ActivityType.Maker, DisplayName = "Another" }, CancellationToken.None));
        await Assert.ThrowsAsync<ImmutableVersionException>(() => alice.Activities.DeleteAsync(id, graph.Activities[0].ActivityId, CancellationToken.None));

        // The Temporal consumer reads the stored definition.
        var temporal = alice.As(Users.Temporal());
        var json = await temporal.Workflows.GetPublishedDefinitionByCodeAsync("SAMPLE_CHECKER", null, CancellationToken.None);
        using (var doc = JsonDocument.Parse(json))
        {
            Assert.Equal("SAMPLE_CHECKER:v1", doc.RootElement.GetProperty("definitionId").GetString());
            Assert.Equal(published.DefinitionHash, doc.RootElement.GetProperty("metadata").GetProperty("definitionHash").GetString());
        }

        // New draft version copies the graph; publishing it supersedes v1.
        var v2 = await alice.Workflows.CreateVersionAsync(id, new CreateVersionRequest { ChangeNotes = "SLA change" }, CancellationToken.None);
        Assert.Equal(2, v2.Graph.Version.VersionNo);
        Assert.Equal(graph.Activities.Count, v2.Graph.Activities.Count);
        Assert.Equal(graph.Connections.Count, v2.Graph.Connections.Count);
        await Assert.ThrowsAsync<ConflictException>(() => alice.Workflows.CreateVersionAsync(id, new CreateVersionRequest(), CancellationToken.None));

        var checker = v2.Graph.Activities.Single(a => a.ActivityKey == "checker");
        await alice.Activities.UpdateAsync(id, checker.ActivityId, new ActivityRequest
        {
            ActivityKey = "checker", ActivityType = ActivityType.Checker, DisplayName = "Branch checker (v2)",
            Config = new Dictionary<string, string?>(checker.Config), RowVersion = checker.RowVersion
        }, CancellationToken.None);

        await bob.Workflows.PublishAsync(id, new PublishWorkflowRequest { VersionNo = 2 }, CancellationToken.None);
        var versions = await alice.Workflows.GetVersionHistoryAsync(id, CancellationToken.None);
        Assert.Equal(VersionStatus.Superseded, versions.Single(v => v.VersionNo == 1).Status);
        Assert.Equal(VersionStatus.Published, versions.Single(v => v.VersionNo == 2).Status);
        var v1Json = await temporal.Workflows.GetPublishedDefinitionAsync(id, 1, CancellationToken.None);
        Assert.Contains("SAMPLE_CHECKER:v1", v1Json);

        // Clone into a new template.
        var clone = await alice.Workflows.CloneAsync(id, new CloneWorkflowRequest { NewTemplateCode = "SAMPLE_CHECKER_COPY", WorkflowName = "Copy" }, CancellationToken.None);
        Assert.Equal(id, clone.Template.ClonedFromTemplateId);
        Assert.Equal(VersionStatus.Draft, clone.Graph.Version.Status);
        Assert.Equal(v2.Graph.Activities.Count, clone.Graph.Activities.Count);
    }

    [Fact]
    public async Task Publishing_an_invalid_draft_fails_with_the_errors()
    {
        var h = new TestHarness();
        var detail = await CreateSimpleAsync(h);
        var bob = h.As(Users.Bob());
        var ex = await Assert.ThrowsAsync<BusinessValidationException>(() => bob.Workflows.PublishAsync(detail.Template.WorkflowTemplateId, new PublishWorkflowRequest { VersionNo = 1 }, CancellationToken.None));
        Assert.NotEmpty(ex.Errors);
    }

    [Fact]
    public async Task Stale_row_versions_raise_concurrency_errors()
    {
        var h = new TestHarness();
        var detail = await CreateSimpleAsync(h);
        var id = detail.Template.WorkflowTemplateId;
        await h.Workflows.UpdateAsync(id, new UpdateWorkflowRequest { WorkflowName = "Renamed", RowVersion = detail.Template.RowVersion! }, CancellationToken.None);
        await Assert.ThrowsAsync<ConcurrencyException>(() =>
            h.Workflows.UpdateAsync(id, new UpdateWorkflowRequest { WorkflowName = "Again", RowVersion = detail.Template.RowVersion! }, CancellationToken.None));

        var start = detail.Graph.Activities.First();
        await h.Activities.UpdateAsync(id, start.ActivityId, new ActivityRequest { ActivityKey = "start", ActivityType = ActivityType.Start, DisplayName = "Begin", RowVersion = start.RowVersion }, CancellationToken.None);
        await Assert.ThrowsAsync<ConcurrencyException>(() =>
            h.Activities.UpdateAsync(id, start.ActivityId, new ActivityRequest { ActivityKey = "start", ActivityType = ActivityType.Start, DisplayName = "Begin 2", RowVersion = start.RowVersion }, CancellationToken.None));
    }

    [Fact]
    public async Task Activity_settings_reject_secrets_sql_and_unknown_keys_at_save_time()
    {
        var h = new TestHarness();
        var id = (await CreateSimpleAsync(h)).Template.WorkflowTemplateId;

        var ex = await Assert.ThrowsAsync<BusinessValidationException>(() => h.Activities.AddAsync(id, new ActivityRequest
        {
            ActivityKey = "api", ActivityType = ActivityType.ApiDataPush, DisplayName = "API",
            Config = new Dictionary<string, string?> { ["connectionProfile"] = "API_CBS_CORE", ["endpointPath"] = "/x", ["apiKey"] = "123", ["contentType"] = "password=abc" }
        }, CancellationToken.None));
        Assert.True(ex.Errors.ContainsKey("config.apiKey"));
        Assert.True(ex.Errors.ContainsKey("config.contentType"));

        await Assert.ThrowsAsync<BusinessValidationException>(() => h.Activities.AddAsync(id, new ActivityRequest
        {
            ActivityKey = "query", ActivityType = ActivityType.ScheduledOracleQuery, DisplayName = "Query",
            Config = new Dictionary<string, string?> { ["approvedQueryCode"] = "SELECT * FROM LOANS" }
        }, CancellationToken.None));

        await Assert.ThrowsAsync<BusinessValidationException>(() => h.Parameters.AddAsync(id, new WorkflowParameterRequest
        {
            Direction = ParameterDirection.Input, Name = "dbPassword", DataType = ParameterDataType.String, DefaultValue = "secret"
        }, CancellationToken.None));
    }

    [Fact]
    public async Task Activity_crud_connections_parameters_and_approval()
    {
        var h = new TestHarness();
        var id = (await CreateSimpleAsync(h)).Template.WorkflowTemplateId;

        var maker = await h.Activities.AddAsync(id, new ActivityRequest
        {
            ActivityKey = "maker", ActivityType = ActivityType.Maker, DisplayName = "Maker",
            Config = new Dictionary<string, string?> { ["assignedRole"] = "AGRI_MAKER", ["formCode"] = "FORM_A" }
        }, CancellationToken.None);
        Assert.Contains(maker.Parameters, p => p.Name == "formData" && p.Direction == ParameterDirection.Output);
        Assert.Equal(604800, maker.TimeoutSeconds);

        var checker = await h.Activities.AddAsync(id, new ActivityRequest
        {
            ActivityKey = "checker", ActivityType = ActivityType.Checker, DisplayName = "Checker",
            Config = new Dictionary<string, string?> { ["formCode"] = "FORM_B" }
        }, CancellationToken.None);

        var withApproval = await h.Activities.SaveApprovalAsync(id, checker.ActivityId, new ApprovalConfigRequest
        {
            SlaHours = 24,
            Levels = { new ApprovalLevelRequest { LevelNo = 1, LevelName = "Checker", Roles = { new ApprovalLevelRoleRequest { RoleCode = "AGRI_CHECKER" } } } }
        }, CancellationToken.None);
        Assert.NotNull(withApproval.Approval);

        await Assert.ThrowsAsync<BusinessValidationException>(() => h.Activities.SaveApprovalAsync(id, maker.ActivityId, new ApprovalConfigRequest(), CancellationToken.None));
        await Assert.ThrowsAsync<BusinessValidationException>(() => h.Activities.SaveApprovalAsync(id, checker.ActivityId, new ApprovalConfigRequest
        {
            Levels = { new ApprovalLevelRequest { LevelNo = 1, LevelName = "Dup", Roles = { new ApprovalLevelRoleRequest { RoleCode = "R1" }, new ApprovalLevelRoleRequest { RoleCode = "r1" } } } }
        }, CancellationToken.None));

        var c1 = await h.Activities.AddConnectionAsync(id, new ConnectionRequest { FromActivityKey = "start", ToActivityKey = "maker" }, CancellationToken.None);
        await h.Activities.AddConnectionAsync(id, new ConnectionRequest { FromActivityKey = "maker", ToActivityKey = "checker" }, CancellationToken.None);
        await h.Activities.AddConnectionAsync(id, new ConnectionRequest { FromActivityKey = "checker", ToActivityKey = "end" }, CancellationToken.None);
        await h.Activities.AddConnectionAsync(id, new ConnectionRequest { FromActivityKey = "checker", ToActivityKey = "maker", ConnectionType = ConnectionType.Rejection }, CancellationToken.None);
        await Assert.ThrowsAsync<ConflictException>(() => h.Activities.AddConnectionAsync(id, new ConnectionRequest { FromActivityKey = "start", ToActivityKey = "maker" }, CancellationToken.None));
        await Assert.ThrowsAsync<BusinessValidationException>(() => h.Activities.AddConnectionAsync(id, new ConnectionRequest { FromActivityKey = "maker", ToActivityKey = "start" }, CancellationToken.None));
        await Assert.ThrowsAsync<BusinessValidationException>(() => h.Activities.AddConnectionAsync(id, new ConnectionRequest { FromActivityKey = "maker", ToActivityKey = "end", ConnectionType = ConnectionType.Rejection }, CancellationToken.None));

        // Map checker input from maker output (full parameter replacement)
        var graph = (await h.Workflows.GetDetailAsync(id, null, CancellationToken.None)).Graph;
        checker = graph.Activities.Single(a => a.ActivityKey == "checker");
        await h.Activities.UpdateAsync(id, checker.ActivityId, new ActivityRequest
        {
            ActivityKey = "checker", ActivityType = ActivityType.Checker, DisplayName = "Checker", Config = new Dictionary<string, string?>(checker.Config), RowVersion = checker.RowVersion,
            Parameters = checker.Parameters.Select(p => new ActivityParameterRequest
            {
                Direction = p.Direction, Name = p.Name, DataType = p.DataType, IsMandatory = p.IsMandatory,
                SourceType = p.Name == "requestData" ? MappingSourceType.ActivityOutput : MappingSourceType.None,
                SourceReference = p.Name == "requestData" ? "maker.formData" : null
            }).ToList()
        }, CancellationToken.None);

        var input = await h.Parameters.AddAsync(id, new WorkflowParameterRequest { Direction = ParameterDirection.Input, Name = "loanAccountNo", DataType = ParameterDataType.String, IsMandatory = true }, CancellationToken.None);
        await Assert.ThrowsAsync<ConflictException>(() => h.Parameters.AddAsync(id, new WorkflowParameterRequest { Direction = ParameterDirection.Input, Name = "loanAccountNo" }, CancellationToken.None));
        var updated = await h.Parameters.UpdateAsync(id, input.ParameterId, new WorkflowParameterRequest
        {
            Direction = ParameterDirection.Input, Name = "loanAccountNo", DataType = ParameterDataType.String, DefaultValue = "ACC-1", RowVersion = input.RowVersion
        }, CancellationToken.None);
        Assert.Equal("ACC-1", updated.DefaultValue);

        var report = await h.Workflows.ValidateAsync(id, CancellationToken.None);
        Assert.True(report.IsValid, string.Join("; ", report.Issues.Where(i => i.Severity == IssueSeverity.Error).Select(i => i.Message)));

        await h.Parameters.DeleteAsync(id, input.ParameterId, CancellationToken.None);
        await h.Activities.DeleteConnectionAsync(id, c1.ConnectionId, CancellationToken.None);
        await h.Activities.DeleteAsync(id, graph.Activities.Single(a => a.ActivityKey == "maker").ActivityId, CancellationToken.None);
        var after = (await h.Workflows.GetDetailAsync(id, null, CancellationToken.None)).Graph;
        Assert.DoesNotContain(after.Connections, c => c.FromActivityKey == "maker" || c.ToActivityKey == "maker");
        Assert.Equal(VersionStatus.Draft, after.Version.Status);
    }

    [Fact]
    public async Task Deactivated_templates_block_changes_and_new_instances()
    {
        var h = new TestHarness();
        var imported = await h.Workflows.ImportAsync(LoadSample("01-maker.json"), CancellationToken.None);
        var id = imported.Template.WorkflowTemplateId;
        var bob = h.As(Users.Bob());
        await bob.Workflows.PublishAsync(id, new PublishWorkflowRequest { VersionNo = 1 }, CancellationToken.None);
        await bob.Workflows.ChangeStatusAsync(id, new ChangeWorkflowStatusRequest { Status = TemplateStatus.Inactive, Reason = "Product withdrawn" }, CancellationToken.None);

        var ex = await Assert.ThrowsAsync<ConflictException>(() => h.Workflows.GetPublishedDefinitionAsync(id, null, CancellationToken.None));
        Assert.Equal("TEMPLATE_INACTIVE", ex.Code);
        Assert.NotNull(await h.Workflows.GetPublishedDefinitionAsync(id, 1, CancellationToken.None));
        await Assert.ThrowsAsync<ConflictException>(() => h.Workflows.CreateVersionAsync(id, new CreateVersionRequest(), CancellationToken.None));
    }

    [Fact]
    public async Task Source_system_admin_manages_systems()
    {
        var h = new TestHarness(Users.Admin());
        var created = await h.SourceSystems.CreateAsync(new CreateSourceSystemRequest
        {
            SystemCode = "RETAIL_LOS", ApplicationName = "Retail LOS",
            Modules = { new ModuleRequest { ModuleCode = "HOME_LOAN", ModuleName = "Home loan" } },
            AuthorizedUsers = { new SourceSystemUserRequest { UserPrincipal = "BANK\\ravi", AccessRole = SourceSystemAccessRole.Designer } }
        }, CancellationToken.None);
        Assert.Equal("retail_los-workflows", created.DefaultTaskQueue);

        await Assert.ThrowsAsync<ConflictException>(() => h.SourceSystems.CreateAsync(new CreateSourceSystemRequest
        {
            SystemCode = "RETAIL_LOS", ApplicationName = "Dup", Modules = { new ModuleRequest { ModuleCode = "X1", ModuleName = "X1" } }
        }, CancellationToken.None));

        var removeModule = new UpdateSourceSystemRequest { ApplicationName = "Retail", RowVersion = created.RowVersion!, Modules = { new ModuleRequest { ModuleCode = "AUTO_LOAN", ModuleName = "Auto" } } };
        await Assert.ThrowsAsync<BusinessValidationException>(() => h.SourceSystems.UpdateAsync(created.SourceSystemId, removeModule, CancellationToken.None));

        var update = new UpdateSourceSystemRequest
        {
            ApplicationName = "Retail LOS v2", RowVersion = created.RowVersion!,
            Modules = { new ModuleRequest { ModuleCode = "HOME_LOAN", ModuleName = "Home loan" }, new ModuleRequest { ModuleCode = "AUTO_LOAN", ModuleName = "Auto loan" } }
        };
        var updated = await h.SourceSystems.UpdateAsync(created.SourceSystemId, update, CancellationToken.None);
        Assert.Equal(2, updated.Modules.Count);
        Assert.Empty(updated.AuthorizedUsers);
        await Assert.ThrowsAsync<ConcurrencyException>(() => h.SourceSystems.UpdateAsync(created.SourceSystemId, update, CancellationToken.None));
    }

    [Fact]
    public async Task Scheduler_configuration_accepts_only_governed_queries_and_valid_cron()
    {
        var h = new TestHarness();
        var imported = await h.Workflows.ImportAsync(LoadSample("13-scheduled-oracle-query.json"), CancellationToken.None);
        var id = imported.Template.WorkflowTemplateId;
        var query = h.Db.Queries.Single(q => q.QueryCode == "Q_CAM_RENEWAL_DUE");

        SchedulerConfigRequest Request() => new()
        {
            SchedulerCode = "CAM_DUE_DAILY", SourceSystemId = h.AgriId, SchedulerName = "Daily CAM due list", ApprovedQueryId = query.ApprovedQueryId,
            CronExpression = "0 0 6 ? * MON-FRI", TimeZoneId = "India Standard Time", TargetWorkflowTemplateId = id,
            ExecutionParametersJson = "{\"asOfDate\":\"today\",\"windowDays\":30}"
        };

        // Target must be published first.
        var notPublished = await Assert.ThrowsAsync<BusinessValidationException>(() => h.Schedulers.CreateAsync(Request(), CancellationToken.None));
        Assert.True(notPublished.Errors.ContainsKey("targetWorkflowTemplateId"));
        await h.As(Users.Bob()).Workflows.PublishAsync(id, new PublishWorkflowRequest { VersionNo = 1 }, CancellationToken.None);

        var bad = Request();
        bad.CronExpression = "* * * * *";
        bad.ExecutionParametersJson = "{\"asOfDate\":\"x\",\"password\":\"p\"}";
        var ex = await Assert.ThrowsAsync<BusinessValidationException>(() => h.Schedulers.CreateAsync(bad, CancellationToken.None));
        Assert.True(ex.Errors.ContainsKey("cronExpression"));
        Assert.True(ex.Errors.ContainsKey("executionParametersJson.password"));
        Assert.True(ex.Errors.ContainsKey("executionParametersJson"));

        var sql = Request();
        sql.ExecutionParametersJson = "{\"asOfDate\":\"x\",\"windowDays\":\"1; DELETE FROM loans\"}";
        await Assert.ThrowsAsync<BusinessValidationException>(() => h.Schedulers.CreateAsync(sql, CancellationToken.None));

        var created = await h.Schedulers.CreateAsync(Request(), CancellationToken.None);
        Assert.Equal("Q_CAM_RENEWAL_DUE", created.ApprovedQueryCode);

        var update = Request();
        update.CronExpression = "0 30 7 ? * MON-SAT";
        update.RowVersion = created.RowVersion;
        var updated = await h.Schedulers.UpdateAsync(created.SchedulerConfigId, update, CancellationToken.None);
        Assert.Equal("0 30 7 ? * MON-SAT", updated.CronExpression);
        await Assert.ThrowsAsync<ConcurrencyException>(() => h.Schedulers.UpdateAsync(created.SchedulerConfigId, update, CancellationToken.None));
    }
}

public sealed class SampleTemplateTests
{
    public static IEnumerable<object[]> SampleFiles() =>
        Directory.GetFiles(Path.Combine(AppContext.BaseDirectory, "samples"), "*.json").OrderBy(f => f).Select(f => new object[] { Path.GetFileName(f) });

    [Fact]
    public async Task Every_sample_template_imports_validates_and_publishes()
    {
        var files = SampleFiles().Select(f => (string)f[0]).ToList();
        Assert.True(files.Count >= 14, $"Expected at least 14 samples, found {files.Count}.");

        var covered = new HashSet<ActivityType>();
        var h = new TestHarness();
        foreach (var file in files)
        {
            var request = WorkflowServiceTests.LoadSample(file);
            var imported = await h.Workflows.ImportAsync(request, CancellationToken.None);
            var report = await h.Workflows.ValidateAsync(imported.Template.WorkflowTemplateId, CancellationToken.None);
            var errors = report.Issues.Where(i => i.Severity == IssueSeverity.Error).Select(i => $"{i.ActivityKey}: [{i.Code}] {i.Message}").ToList();
            Assert.True(report.IsValid, $"{file}: {string.Join(" | ", errors)}");

            var published = await h.As(Users.Bob()).Workflows.PublishAsync(imported.Template.WorkflowTemplateId, new PublishWorkflowRequest { VersionNo = 1 }, CancellationToken.None);
            Assert.Equal(1, published.VersionNo);
            imported.Graph.Activities.ForEach(a => covered.Add(a.ActivityType));
        }

        foreach (var type in Enum.GetValues<ActivityType>())
        {
            Assert.True(covered.Contains(type), $"No sample covers activity type {type}.");
        }
    }
}
