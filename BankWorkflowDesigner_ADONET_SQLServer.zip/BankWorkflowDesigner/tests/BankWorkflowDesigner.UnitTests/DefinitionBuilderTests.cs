using System.Text.Json;
using BankWorkflowDesigner.Application.Definitions;
using BankWorkflowDesigner.Domain.Enums;
using Xunit;

namespace BankWorkflowDesigner.UnitTests;

public sealed class DefinitionBuilderTests
{
    private readonly WorkflowDefinitionBuilder _builder = new();

    [Fact]
    public void Builds_temporal_definition_with_transitions_and_approval()
    {
        var graph = GraphBuilder.MakerChecker().Graph;
        var definition = _builder.Build(graph, "bob.publisher", new DateTime(2026, 9, 1, 10, 0, 0, DateTimeKind.Utc));

        Assert.Equal("TEST_WF:v1", definition.DefinitionId);
        Assert.Equal("agri-los-workflows", definition.Temporal.TaskQueue);
        Assert.Equal("start", definition.StartActivity);
        Assert.Equal("start", definition.Activities[0].Key);

        var checker = definition.Activities.Single(a => a.Key == "checker");
        Assert.NotNull(checker.Approval);
        Assert.Equal("maker", checker.Approval!.RejectionTarget);
        Assert.Contains(checker.Transitions, t => t.To == "end" && t.Type == "Sequence");
        Assert.Contains(checker.Transitions, t => t.To == "maker" && t.Type == "Rejection");

        var input = checker.Inputs.Single(i => i.Name == "requestData");
        Assert.Equal("activityOutput", input.Source!.Kind);
        Assert.Equal("maker", input.Source.Activity);
        Assert.Equal("formData", input.Source.Parameter);
    }

    [Fact]
    public void Hash_is_deterministic_and_covers_content()
    {
        var graph = GraphBuilder.MakerChecker().Graph;
        var on = new DateTime(2026, 9, 1, 10, 0, 0, DateTimeKind.Utc);

        var (json1, hash1) = _builder.Serialize(_builder.Build(graph, "bob", on));
        var (_, hash2) = _builder.Serialize(_builder.Build(graph, "bob", on));
        Assert.Equal(hash1, hash2);
        Assert.Equal(64, hash1.Length);

        graph.Activities.First(a => a.ActivityKey == "maker").DisplayName = "Changed";
        var (_, hash3) = _builder.Serialize(_builder.Build(graph, "bob", on));
        Assert.NotEqual(hash1, hash3);

        using var doc = JsonDocument.Parse(json1);
        Assert.Equal(hash1, doc.RootElement.GetProperty("metadata").GetProperty("definitionHash").GetString());
    }

    [Fact]
    public void Fills_catalog_defaults_and_never_emits_vault_references()
    {
        var builder = new GraphBuilder()
            .Activity("start", ActivityType.Start)
            .Activity("push", ActivityType.SftpFilePush, a =>
            {
                a.Config.Clear();
                a.Config["connectionProfile"] = "SFTP_CBS_OUTBOUND";
                a.Config["remoteDirectory"] = "/in";
            })
            .Activity("end", ActivityType.End)
            .Connect("start", "push").Connect("push", "end");

        var (json, _) = _builder.Serialize(_builder.Build(builder.Graph, null, null));
        var push = _builder.Build(builder.Graph, null, null).Activities.Single(a => a.Key == "push");
        Assert.Equal("SHA256", push.Config["checksumAlgorithm"]);
        Assert.Equal("SFTP_CBS_OUTBOUND", push.Config["connectionProfile"]);
        Assert.DoesNotContain("cyberark://", json);
        Assert.DoesNotContain("password", json, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void Default_branch_is_ordered_last_and_has_no_condition()
    {
        var builder = new GraphBuilder()
            .Activity("start", ActivityType.Start).Maker().Activity("decide", ActivityType.Decision)
            .Activity("a", ActivityType.End).Activity("b", ActivityType.End)
            .Connect("start", "maker").Connect("maker", "decide")
            .Connect("decide", "a", ConnectionType.Conditional, "true", isDefault: true)
            .Connect("decide", "b", ConnectionType.Conditional, "activities.maker.outcome == 'Submitted'");
        var decide = _builder.Build(builder.Graph, null, null).Activities.Single(a => a.Key == "decide");
        Assert.Equal("b", decide.Transitions[0].To);
        Assert.True(decide.Transitions[1].IsDefault);
        Assert.Null(decide.Transitions[1].Condition);
    }
}
