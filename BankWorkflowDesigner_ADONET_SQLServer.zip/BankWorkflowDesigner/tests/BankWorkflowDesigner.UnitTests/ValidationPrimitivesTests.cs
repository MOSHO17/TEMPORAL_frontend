using BankWorkflowDesigner.Application.Validation;
using BankWorkflowDesigner.Domain.Enums;
using Xunit;

namespace BankWorkflowDesigner.UnitTests;

public sealed class ExpressionValidatorTests
{
    [Theory]
    [InlineData("activities.checker.outcome == 'Approved'")]
    [InlineData("workflow.input.amount > 500000 && workflow.input.amount <= 5000000")]
    [InlineData("!(activities.apiPush.output.statusCode == 201) || sys.initiator != null")]
    [InlineData("contains(workflow.input.branchCode, 'MUM') && isEmpty(workflow.input.remarks) == false")]
    [InlineData("workflow.input.amount >= -10.5")]
    public void Accepts_valid_expressions(string expression)
    {
        var result = ExpressionValidator.Validate(expression);
        Assert.True(result.IsValid, string.Join("; ", result.Errors));
    }

    [Theory]
    [InlineData("workflow.input.amount = 5")]
    [InlineData("workflow.input.amount > 5; DROP TABLE x")]
    [InlineData("System.IO.File.Delete('x')")]
    [InlineData("eval('1+1')")]
    [InlineData("activities.checker.outcome == 'Approved")]
    [InlineData("workflow.amount > 5")]
    [InlineData("sys.password == 'x'")]
    [InlineData("")]
    [InlineData("(workflow.input.a == 1")]
    public void Rejects_invalid_expressions(string expression)
    {
        Assert.False(ExpressionValidator.Validate(expression).IsValid);
    }

    [Fact]
    public void Extracts_references()
    {
        var result = ExpressionValidator.Validate("activities.checker.outcome == 'Approved' && workflow.input.amount > 10 && activities.api.output.statusCode == 200");
        Assert.True(result.IsValid);
        Assert.Equal(3, result.References.Count);
        Assert.Contains(result.References, r => r.Kind == "activityOutput" && r.ActivityKey == "checker" && r.Name == "outcome");
        Assert.Contains(result.References, r => r.Kind == "workflowInput" && r.Name == "amount");
        Assert.Contains(result.References, r => r.ActivityKey == "api" && r.Name == "statusCode");
    }
}

public sealed class ContentSafetyScannerTests
{
    [Theory]
    [InlineData("Server=db;User Id=sa;Password=P@ssw0rd")]
    [InlineData("pwd: secret123")]
    [InlineData("client_secret=abc123")]
    [InlineData("-----BEGIN RSA PRIVATE KEY-----")]
    [InlineData("AKIAABCDEFGHIJKLMNOP")]
    [InlineData("eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.abcdefghijklmnop")]
    [InlineData("sftp://svc_user:hunter2@sftp.bank.local/in")]
    public void Detects_secrets(string value)
    {
        Assert.True(ContentSafetyScanner.ContainsSecret(value));
        Assert.NotNull(ContentSafetyScanner.Inspect(null, value));
    }

    [Theory]
    [InlineData("SELECT * FROM loans WHERE 1=1")]
    [InlineData("delete from wf.AuditLog")]
    [InlineData("DROP TABLE customers")]
    [InlineData("UPDATE accounts SET balance = 0")]
    [InlineData("EXEC sp_executesql N'x'")]
    [InlineData("BEGIN dbms_output.put_line('x'); END;")]
    [InlineData("insert into x values (1)")]
    public void Detects_free_sql(string value)
    {
        Assert.True(ContentSafetyScanner.ContainsSql(value));
    }

    [Theory]
    [InlineData("/inbound/agri/{yyyyMMdd}")]
    [InlineData("CAM_RENEWAL_FORM")]
    [InlineData("Q_CAM_RENEWAL_DUE")]
    [InlineData("application/json")]
    [InlineData("200,201,202")]
    public void Allows_normal_configuration_values(string value)
    {
        Assert.Null(ContentSafetyScanner.Inspect("remoteDirectory", value));
    }

    [Fact]
    public void Flags_values_of_secret_named_parameters()
    {
        Assert.NotNull(ContentSafetyScanner.Inspect("apiKey", "abc"));
        Assert.NotNull(ContentSafetyScanner.Inspect("dbPassword", "x"));
        Assert.Null(ContentSafetyScanner.Inspect("apiKey", null));
    }
}

public sealed class CronExpressionValidatorTests
{
    [Theory]
    [InlineData("0 0 6 ? * MON-FRI")]
    [InlineData("0 30 1 * * ?")]
    [InlineData("0 0/30 * * * ?")]
    [InlineData("0 0 22 L * ?")]
    [InlineData("0 0 7 1 * ? 2027")]
    [InlineData("0 15 10 ? * 6#3")]
    [InlineData("0 0 12 ? JAN,JUL MON")]
    public void Accepts_valid_quartz_expressions(string cron)
    {
        var result = CronExpressionValidator.Validate(cron);
        Assert.True(result.IsValid, result.Error);
        Assert.NotNull(result.Description);
    }

    [Theory]
    [InlineData("0 6 * * *")]              // unix 5-field
    [InlineData("0 0 6 * * *")]            // both day fields set
    [InlineData("0 0 6 ? * ?")]            // both '?'
    [InlineData("* * * ? * *")]            // every second
    [InlineData("0 * * ? * *")]            // every minute
    [InlineData("0 0 25 ? * *")]           // hour out of range
    [InlineData("0 0 6 ? * MON; rm -rf")]  // illegal chars
    [InlineData("")]
    public void Rejects_invalid_expressions(string cron)
    {
        Assert.False(CronExpressionValidator.Validate(cron).IsValid);
    }
}

public sealed class ParameterValueValidatorTests
{
    [Theory]
    [InlineData(ParameterDataType.Integer, "42", true)]
    [InlineData(ParameterDataType.Integer, "4.2", false)]
    [InlineData(ParameterDataType.Decimal, "4.25", true)]
    [InlineData(ParameterDataType.Boolean, "true", true)]
    [InlineData(ParameterDataType.Boolean, "yes", false)]
    [InlineData(ParameterDataType.Date, "2026-03-31", true)]
    [InlineData(ParameterDataType.Date, "31/03/2026", false)]
    [InlineData(ParameterDataType.DateTime, "2026-03-31T10:00:00Z", true)]
    [InlineData(ParameterDataType.Json, "{\"a\":1}", true)]
    [InlineData(ParameterDataType.Json, "{a:1}", false)]
    [InlineData(ParameterDataType.Array, "[1,2]", true)]
    [InlineData(ParameterDataType.Array, "{}", false)]
    [InlineData(ParameterDataType.String, "anything", true)]
    public void Validates_values_against_data_types(ParameterDataType type, string value, bool valid)
    {
        Assert.Equal(valid, ParameterValueValidator.ValidateValue(type, value) is null);
    }

    [Fact]
    public void Validates_json_schema_and_required_properties()
    {
        Assert.Null(ParameterValueValidator.ValidateJsonSchema("{\"type\":\"object\",\"required\":[\"loanId\"]}"));
        Assert.NotNull(ParameterValueValidator.ValidateJsonSchema("{\"type\":\"widget\"}"));
        Assert.NotNull(ParameterValueValidator.ValidateJsonSchema("[1,2]"));
        Assert.NotNull(ParameterValueValidator.ValidateJsonSchema("{bad json"));
        Assert.Null(ParameterValueValidator.ValidateAgainstSchema("{\"type\":\"object\",\"required\":[\"loanId\"]}", "{\"loanId\":\"1\"}"));
        Assert.NotNull(ParameterValueValidator.ValidateAgainstSchema("{\"type\":\"object\",\"required\":[\"loanId\"]}", "{\"x\":1}"));
    }

    [Fact]
    public void Type_compatibility_rules()
    {
        Assert.True(ParameterValueValidator.AreCompatible(ParameterDataType.Integer, ParameterDataType.Decimal));
        Assert.True(ParameterValueValidator.AreCompatible(ParameterDataType.Array, ParameterDataType.Json));
        Assert.False(ParameterValueValidator.AreCompatible(ParameterDataType.Decimal, ParameterDataType.Integer));
        Assert.False(ParameterValueValidator.AreCompatible(ParameterDataType.Json, ParameterDataType.Boolean));
    }
}

public sealed class TimeZoneValidatorTests
{
    [Theory]
    [InlineData("India Standard Time")]
    [InlineData("Asia/Kolkata")]
    [InlineData("UTC")]
    [InlineData("Singapore Standard Time")]
    public void Accepts_windows_and_iana_ids(string id) => Assert.True(TimeZoneValidator.IsKnown(id));

    [Theory]
    [InlineData("Mars/Olympus_Mons")]
    [InlineData("")]
    public void Rejects_unknown_ids(string id) => Assert.False(TimeZoneValidator.IsKnown(id));
}

public sealed class DatabaseScriptSplitterTests
{
    [Fact]
    public void Splits_on_go_lines_and_skips_sqlcmd_directives()
    {
        const string script = "CREATE TABLE a (x INT);\nGO\n:r .\\other.sql\nSELECT 1;\ngo -- comment\n\nGO\nSELECT 2";
        var batches = BankWorkflowDesigner.Database.Program.SplitBatches(script).ToList();
        Assert.Equal(3, batches.Count);
        Assert.Contains("CREATE TABLE", batches[0]);
        Assert.DoesNotContain(":r", batches[1]);
        Assert.Contains("SELECT 2", batches[2]);
    }
}
