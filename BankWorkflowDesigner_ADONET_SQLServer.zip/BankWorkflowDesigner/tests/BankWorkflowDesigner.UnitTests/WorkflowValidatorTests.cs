using BankWorkflowDesigner.Application.Validation;
using BankWorkflowDesigner.Domain.Catalog;
using BankWorkflowDesigner.Domain.Dtos;
using BankWorkflowDesigner.Domain.Entities;
using BankWorkflowDesigner.Domain.Enums;
using BankWorkflowDesigner.TestSupport;
using Xunit;

namespace BankWorkflowDesigner.UnitTests;

/// <summary>Fluent builder for in-memory workflow graphs used by validator / builder tests.</summary>
internal sealed class GraphBuilder
{
    private readonly WorkflowGraph _graph = new()
    {
        Template = new WorkflowTemplate { WorkflowTemplateId = 1, TemplateCode = "TEST_WF", WorkflowName = "Test", SourceSystemCode = "AGRI_LOS", ModuleCode = "CAM_RENEWAL" },
        Version = new WorkflowVersion { VersionNo = 1, Status = VersionStatus.Draft, ChangeNotes = "test" },
        SourceSystem = new SourceSystem { SystemCode = "AGRI_LOS", ApplicationName = "Agri LOS", DefaultTaskQueue = "agri-los-workflows" },
        Module = new SourceSystemModule { ModuleCode = "CAM_RENEWAL", ModuleName = "CAM Renewal" }
    };

    public WorkflowGraph Graph => _graph;

    public GraphBuilder Activity(string key, ActivityType type, Action<WorkflowActivity>? configure = null)
    {
        var descriptor = ActivityCatalog.Get(type);
        var activity = new WorkflowActivity
        {
            ActivityId = _graph.Activities.Count + 1,
            ActivityKey = key,
            ActivityType = type,
            DisplayName = key,
            TimeoutSeconds = descriptor.DefaultTimeoutSeconds,
            RetryMaxAttempts = descriptor.DefaultRetryAttempts,
            Config = descriptor.ConfigFields.Where(f => f.DefaultValue is not null).ToDictionary(f => f.Key, f => (string?)f.DefaultValue, StringComparer.OrdinalIgnoreCase),
            Parameters = descriptor.DefaultInputs.Select(t => new ActivityParameter { Direction = ParameterDirection.Input, Name = t.Name, DataType = t.DataType, IsMandatory = t.IsMandatory })
                .Concat(descriptor.DefaultOutputs.Select(t => new ActivityParameter { Direction = ParameterDirection.Output, Name = t.Name, DataType = t.DataType, IsMandatory = t.IsMandatory }))
                .ToList()
        };
        configure?.Invoke(activity);
        _graph.Activities.Add(activity);
        return this;
    }

    public GraphBuilder Maker(string key = "maker") => Activity(key, ActivityType.Maker, a =>
    {
        a.Config["assignedRole"] = "AGRI_MAKER";
        a.Config["formCode"] = "FORM_A";
    });

    public GraphBuilder Approval(string key, ActivityType type, int levels = 1, RejectionRouting routing = RejectionRouting.ToMaker, string source = "maker.formData",
        LevelExecutionMode mode = LevelExecutionMode.Sequential, int rolesPerLevel = 1) =>
        Activity(key, type, a =>
        {
            a.Config["formCode"] = "FORM_APPROVAL";
            Map(a, "requestData", MappingSourceType.ActivityOutput, source);
            a.Approval = new ApprovalConfiguration
            {
                RejectionRouting = routing,
                SlaHours = 48,
                Levels = Enumerable.Range(1, levels).Select(n => new ApprovalLevel
                {
                    LevelNo = n, LevelName = $"L{n}", ExecutionMode = mode, MinApprovals = 1,
                    Roles = Enumerable.Range(1, rolesPerLevel).Select(r => new ApprovalLevelRole { RoleCode = $"ROLE_{n}_{r}", SequenceNo = r }).ToList()
                }).ToList()
            };
        });

    public GraphBuilder Connect(string from, string to, ConnectionType type = ConnectionType.Sequence, string? condition = null, bool isDefault = false)
    {
        _graph.Connections.Add(new ActivityConnection
        {
            ConnectionId = _graph.Connections.Count + 1, FromActivityKey = from, ToActivityKey = to, ConnectionType = type, ConditionExpression = condition, IsDefault = isDefault
        });
        return this;
    }

    public GraphBuilder WorkflowParameter(ParameterDirection direction, string name, ParameterDataType type, bool mandatory = false, MappingSourceType source = MappingSourceType.None, string? reference = null)
    {
        _graph.Parameters.Add(new WorkflowParameter { ParameterId = _graph.Parameters.Count + 1, Direction = direction, Name = name, DataType = type, IsMandatory = mandatory, SourceType = source, SourceReference = reference });
        return this;
    }

    public static void Map(WorkflowActivity a, string input, MappingSourceType source, string reference)
    {
        var p = a.Parameters.First(x => x.Direction == ParameterDirection.Input && x.Name == input);
        p.SourceType = source;
        p.SourceReference = reference;
    }

    /// <summary>start -> maker -> checker -> end, with a rejection loop checker -> maker.</summary>
    public static GraphBuilder MakerChecker() => new GraphBuilder()
        .Activity("start", ActivityType.Start)
        .Maker()
        .Approval("checker", ActivityType.Checker)
        .Activity("end", ActivityType.End)
        .Connect("start", "maker")
        .Connect("maker", "checker")
        .Connect("checker", "end")
        .Connect("checker", "maker", ConnectionType.Rejection);
}

public sealed class WorkflowValidatorTests
{
    private static readonly WorkflowValidationContext Context = new()
    {
        ConnectionProfiles = InMemoryDatabase.CreateSeeded().Profiles,
        ApprovedQueries = InMemoryDatabase.CreateSeeded().Queries
    };

    private static List<ValidationIssue> Validate(GraphBuilder builder) => new WorkflowValidator().Validate(builder.Graph, Context);

    private static void AssertError(List<ValidationIssue> issues, string code) =>
        Assert.Contains(issues, i => i.Severity == IssueSeverity.Error && i.Code == code);

    [Fact]
    public void Maker_checker_with_rejection_loop_is_valid()
    {
        var issues = Validate(GraphBuilder.MakerChecker());
        Assert.DoesNotContain(issues, i => i.Severity == IssueSeverity.Error);
    }

    [Fact]
    public void Missing_start_and_end_are_errors()
    {
        var issues = Validate(new GraphBuilder().Maker());
        AssertError(issues, "START_COUNT");
        AssertError(issues, "END_MISSING");
    }

    [Fact]
    public void Unreachable_and_dead_end_activities_are_detected()
    {
        var builder = GraphBuilder.MakerChecker().Activity("orphan", ActivityType.FileGeneration, a =>
        {
            a.Config["fileNamePattern"] = "X.csv";
            GraphBuilder.Map(a, "records", MappingSourceType.Literal, "[]");
        });
        var issues = Validate(builder);
        AssertError(issues, "UNREACHABLE");
        AssertError(issues, "DEAD_END");
        AssertError(issues, "NO_PATH_TO_END");
    }

    [Fact]
    public void Loops_without_rejection_route_are_rejected()
    {
        var builder = GraphBuilder.MakerChecker().Connect("checker", "maker", ConnectionType.Sequence);
        AssertError(Validate(builder), "ILLEGAL_LOOP");
    }

    [Fact]
    public void Decision_requires_conditional_branches()
    {
        var builder = new GraphBuilder()
            .Activity("start", ActivityType.Start).Maker().Activity("decide", ActivityType.Decision)
            .Activity("end", ActivityType.End).Activity("end2", ActivityType.End)
            .Connect("start", "maker").Connect("maker", "decide")
            .Connect("decide", "end", ConnectionType.Sequence)
            .Connect("decide", "end2", ConnectionType.Conditional);
        var issues = Validate(builder);
        AssertError(issues, "DECISION_TYPE");
        AssertError(issues, "CONDITION_MISSING");
    }

    [Fact]
    public void Decision_conditions_must_reference_upstream_outputs()
    {
        var builder = new GraphBuilder()
            .Activity("start", ActivityType.Start).Maker().Activity("decide", ActivityType.Decision)
            .Activity("end", ActivityType.End).Activity("end2", ActivityType.End)
            .Connect("start", "maker").Connect("maker", "decide")
            .Connect("decide", "end", ConnectionType.Conditional, "activities.maker.outcome == 'Submitted'")
            .Connect("decide", "end2", ConnectionType.Conditional, "activities.ghost.output.x == 1");
        var issues = Validate(builder);
        AssertError(issues, "EXPRESSION_ACTIVITY_UNKNOWN");
        Assert.DoesNotContain(issues, i => i.Code == "EXPRESSION_NOT_UPSTREAM");
    }

    [Fact]
    public void Parallel_branches_must_join()
    {
        var builder = new GraphBuilder()
            .Activity("start", ActivityType.Start).Activity("split", ActivityType.ParallelSplit)
            .Maker("m1").Maker("m2").Activity("end", ActivityType.End)
            .Connect("start", "split").Connect("split", "m1", ConnectionType.Parallel).Connect("split", "m2", ConnectionType.Parallel)
            .Connect("m1", "end").Connect("m2", "end");
        AssertError(Validate(builder), "PARALLEL_BRANCH_UNJOINED");

        var joined = new GraphBuilder()
            .Activity("start", ActivityType.Start).Activity("split", ActivityType.ParallelSplit)
            .Maker("m1").Maker("m2").Activity("join", ActivityType.ParallelJoin).Activity("end", ActivityType.End)
            .Connect("start", "split").Connect("split", "m1", ConnectionType.Parallel).Connect("split", "m2", ConnectionType.Parallel)
            .Connect("m1", "join").Connect("m2", "join").Connect("join", "end");
        Assert.DoesNotContain(Validate(joined), i => i.Severity == IssueSeverity.Error);
    }

    [Fact]
    public void Approval_activities_need_configuration_and_levels()
    {
        var builder = GraphBuilder.MakerChecker();
        builder.Graph.Activities.First(a => a.ActivityKey == "checker").Approval = null;
        AssertError(Validate(builder), "APPROVAL_MISSING");

        var multi = new GraphBuilder().Activity("start", ActivityType.Start).Maker()
            .Approval("ml", ActivityType.MultilevelApprover, levels: 1).Activity("end", ActivityType.End)
            .Connect("start", "maker").Connect("maker", "ml").Connect("ml", "end");
        AssertError(Validate(multi), "APPROVAL_LEVELS_MIN");

        var parallel = new GraphBuilder().Activity("start", ActivityType.Start).Maker()
            .Approval("pa", ActivityType.ParallelApprover, mode: LevelExecutionMode.Parallel, rolesPerLevel: 1).Activity("end", ActivityType.End)
            .Connect("start", "maker").Connect("maker", "pa").Connect("pa", "end");
        AssertError(Validate(parallel), "APPROVAL_PARALLEL_GROUPS");
    }

    [Fact]
    public void Reject_to_maker_requires_an_upstream_maker()
    {
        var builder = new GraphBuilder().Activity("start", ActivityType.Start)
            .Approval("approver", ActivityType.Approver, source: "end.nothing").Activity("end", ActivityType.End)
            .Connect("start", "approver").Connect("approver", "end");
        var issues = Validate(builder);
        AssertError(issues, "REJECTION_NO_MAKER");
        AssertError(issues, "SOURCE_NOT_UPSTREAM");
    }

    [Fact]
    public void Connection_profiles_and_approved_queries_are_verified()
    {
        var builder = new GraphBuilder().Activity("start", ActivityType.Start)
            .Activity("push", ActivityType.SftpFilePush, a =>
            {
                a.Config["connectionProfile"] = "API_CBS_CORE";           // wrong profile type
                a.Config["remoteDirectory"] = "/in";
                GraphBuilder.Map(a, "localFilePath", MappingSourceType.Literal, "/tmp/a.csv");
            })
            .Activity("query", ActivityType.ScheduledOracleQuery, a => a.Config["approvedQueryCode"] = "Q_NOT_APPROVED")
            .Activity("end", ActivityType.End)
            .Connect("start", "push").Connect("push", "query").Connect("query", "end");
        var issues = Validate(builder);
        AssertError(issues, "PROFILE_TYPE");
        AssertError(issues, "QUERY_NOT_APPROVED");
    }

    [Fact]
    public void Secrets_free_sql_and_unknown_settings_are_rejected()
    {
        var builder = new GraphBuilder().Activity("start", ActivityType.Start)
            .Activity("api", ActivityType.ApiDataPush, a =>
            {
                a.Config["connectionProfile"] = "API_CBS_CORE";
                a.Config["endpointPath"] = "/v1/x";
                a.Config["password"] = "P@ss";                                  // unknown key
                a.Config["idempotencyKeyParameter"] = "SELECT * FROM users";   // free SQL
                GraphBuilder.Map(a, "payload", MappingSourceType.Literal, "{\"token\":\"Bearer abcdefghijklmnopqrstuvwxyz0123\"}");
            })
            .Activity("end", ActivityType.End)
            .Connect("start", "api").Connect("api", "end");
        var issues = Validate(builder);
        AssertError(issues, "CONFIG_UNKNOWN");
        AssertError(issues, "CONFIG_UNSAFE");
        AssertError(issues, "PARAM_UNSAFE");
    }

    [Fact]
    public void Mandatory_inputs_must_be_mapped_and_mappings_must_resolve()
    {
        var builder = GraphBuilder.MakerChecker();
        var checker = builder.Graph.Activities.First(a => a.ActivityKey == "checker");
        var input = checker.Parameters.First(p => p.Name == "requestData");
        input.SourceType = MappingSourceType.None;
        AssertError(Validate(builder), "INPUT_UNMAPPED");

        input.SourceType = MappingSourceType.ActivityOutput;
        input.SourceReference = "maker.doesNotExist";
        AssertError(Validate(builder), "SOURCE_OUTPUT_UNKNOWN");

        input.SourceType = MappingSourceType.WorkflowInput;
        input.SourceReference = "missing";
        AssertError(Validate(builder), "SOURCE_INPUT_UNKNOWN");

        input.SourceType = MappingSourceType.SystemVariable;
        input.SourceReference = "sys.initiator";
        Assert.DoesNotContain(Validate(builder), i => i.Severity == IssueSeverity.Error);
    }

    [Fact]
    public void Workflow_outputs_and_default_values_are_type_checked()
    {
        var builder = GraphBuilder.MakerChecker()
            .WorkflowParameter(ParameterDirection.Output, "result", ParameterDataType.Json, mandatory: true)
            .WorkflowParameter(ParameterDirection.Input, "amount", ParameterDataType.Decimal);
        builder.Graph.Parameters.Last().DefaultValue = "ten";
        var issues = Validate(builder);
        AssertError(issues, "WORKFLOW_OUTPUT_UNMAPPED");
        AssertError(issues, "DEFAULT_TYPE");
    }

    [Fact]
    public void Error_routing_requires_existing_target()
    {
        var builder = GraphBuilder.MakerChecker();
        var maker = builder.Graph.Activities.First(a => a.ActivityKey == "maker");
        maker.ErrorHandling = ErrorHandlingStrategy.RouteToActivity;
        AssertError(Validate(builder), "ERROR_ROUTE_MISSING");
        maker.ErrorRouteActivityKey = "nowhere";
        AssertError(Validate(builder), "ERROR_ROUTE_INVALID");
        maker.ErrorRouteActivityKey = "end";
        Assert.DoesNotContain(Validate(builder), i => i.Code.StartsWith("ERROR_ROUTE", StringComparison.Ordinal) && i.Severity == IssueSeverity.Error);
    }

    [Fact]
    public void Rejection_connections_only_from_approvals()
    {
        var builder = GraphBuilder.MakerChecker().Connect("maker", "start", ConnectionType.Rejection);
        AssertError(Validate(builder), "REJECTION_SOURCE");
    }
}
