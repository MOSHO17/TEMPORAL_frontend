# Samples

## workflow-templates/
Importable designs (Workflow Templates -> Import JSON, or `POST /api/workflows/import`). All use source system
`AGRI_LOS` from `11_SeedData.sql`; change `templateCode` before importing a file a second time.
Every file validates without errors and publishes (verified by `SampleTemplateTests`).

| File | Demonstrates |
|---|---|
| 01-maker.json | Maker task, workflow input -> activity input, activity output -> workflow output |
| 02-checker.json | Maker / Checker with rejection loop back to the maker |
| 03-approver.json | Single approver, decision on the outcome, two End outcomes |
| 04-multilevel-approver.json | 3 levels (sequential, sequential, parallel committee), escalation, SLA |
| 05-sequential-approver.json | Three approvers in sequence |
| 06-parallel-approver.json | Risk / Legal / Compliance in parallel, majority policy |
| 07-sftp-file-push.json | SFTP push with retry policy, non-retryable errors and error route to a failure End |
| 08-sftp-file-pull.json | SFTP pull feeding File Reading |
| 09-api-data-push.json | API push with JSON-schema input and conditional branching on the HTTP status |
| 10-api-data-pull.json | API pull, output mapped to a workflow output |
| 11-file-generation.json | CSV generation from an array input |
| 12-file-reading.json | Fixed-width file parsing |
| 13-scheduled-oracle-query.json | Approved Oracle query -> file -> SFTP, execution condition; target for a scheduler |
| 14-cam-renewal-end-to-end.json | Parallel split/join, maker-checker, amount-based decision, multilevel vs single approval, CBS update |

## published-definitions/
Definitions produced by the API when `14-...` and `02-...` were published - the reference for the
Temporal execution service (see `docs/DEFINITION-CONTRACT.md`).
