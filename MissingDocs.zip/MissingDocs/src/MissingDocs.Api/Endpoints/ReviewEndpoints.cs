using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using MissingDocs.Api.Auth;
using MissingDocs.Api.Services;
using MissingDocs.Contracts;
using MissingDocs.Core;
using MissingDocs.Core.Abstractions;
using MissingDocs.Core.Entities;
using MissingDocs.Infrastructure.Data;
using Temporalio.Client;

namespace MissingDocs.Api.Endpoints;

/// <summary>Branch review portal endpoints. Only the portal (app identity) can call them.</summary>
public static class ReviewEndpoints
{
    public static void MapReviewEndpoints(this IEndpointRouteBuilder app)
    {
        var g = app.MapGroup("/api/review").RequireAuthorization(AuthSetup.PortalPolicy);

        g.MapGet("/cases", (string? search, string? view, int? page, int? pageSize, ReviewQueryService q, CancellationToken ct) =>
            q.ListCasesAsync(search, view, page ?? 1, pageSize ?? 20, ct));

        g.MapGet("/cases/{agreementNo}", async (string agreementNo, ReviewQueryService q, CancellationToken ct) =>
            await q.GetCaseAsync(agreementNo, ct) is { } detail ? Results.Ok(detail) : Results.NotFound());

        // Streams the uploaded image to the reviewer; every view is audited.
        g.MapGet("/uploads/{uploadId:long}/content", async (long uploadId, HttpContext http, MissingDocsDbContext db,
            IDocumentStore store, CancellationToken ct) =>
        {
            var reviewer = Reviewer.From(http);
            if (reviewer is null) return Results.BadRequest("Reviewer identity missing");

            var upload = await db.Uploads.Include(u => u.CaseDocument).SingleOrDefaultAsync(u => u.UploadId == uploadId, ct);
            if (upload is null) return Results.NotFound();

            db.Audit(upload.CaseDocument.CaseId, upload.CaseDocumentId, reviewer.Id, "DocumentViewed", $"upload {uploadId}");
            await db.SaveChangesAsync(ct);

            var stream = await store.OpenReadAsync(upload.StoragePath, ct);
            return Results.Stream(stream, upload.ContentType);
        });

        g.MapPost("/documents/{caseDocumentId:long}/decision", async (long caseDocumentId, ReviewDecisionRequest body,
            HttpContext http, MissingDocsDbContext db, ITemporalClient temporal, ILoggerFactory lf, CancellationToken ct) =>
        {
            var reviewer = Reviewer.From(http);
            if (reviewer is null) return Results.BadRequest("Reviewer identity missing");
            if (body.Outcome == ReviewOutcome.RequestReupload && string.IsNullOrWhiteSpace(body.Reason))
                return Results.BadRequest("A reason is required when asking the customer to upload again; it is shown to the customer.");

            var doc = await db.CaseDocuments.Include(d => d.Uploads).SingleOrDefaultAsync(d => d.CaseDocumentId == caseDocumentId, ct);
            if (doc is null) return Results.NotFound();
            if (doc.Status != DocumentStatus.AwaitingReview) return Results.Conflict("This document is not waiting for review.");

            var latest = doc.Uploads.OrderByDescending(u => u.Attempt).First();
            if (latest.UploadId != body.UploadId) return Results.Conflict("A newer upload exists. Please refresh.");
            if (await db.ReviewDecisions.AnyAsync(r => r.UploadId == body.UploadId, ct)) return Results.Conflict("Already decided.");

            var reason = body.Reason?.Trim();
            var decision = new ReviewDecision
            {
                CaseDocumentId = doc.CaseDocumentId,
                UploadId = body.UploadId,
                Outcome = body.Outcome,
                Reason = reason is { Length: > 300 } ? reason[..300] : reason,
                DecidedBy = reviewer.Id,
                DecidedAt = DateTimeOffset.UtcNow,
            };
            db.ReviewDecisions.Add(decision);
            db.Audit(doc.CaseId, doc.CaseDocumentId, reviewer.Id, $"Review:{body.Outcome}", reason);
            await db.SaveChangesAsync(ct);   // unique index on UploadId blocks double clicks

            try
            {
                await temporal.GetWorkflowHandle(doc.WorkflowId).SignalAsync(WorkflowConstants.ReviewDecisionSignal,
                    new object?[] { new ReviewDecisionSignal(body.UploadId, body.Outcome, decision.Reason, reviewer.Id) });
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                lf.CreateLogger("Review").LogError(ex, "Signal failed for {WorkflowId}", doc.WorkflowId);
                db.ReviewDecisions.Remove(decision);
                db.Audit(doc.CaseId, doc.CaseDocumentId, "SYSTEM", "SignalFailed", ex.Message);
                await db.SaveChangesAsync(ct);
                return Results.Problem("Could not record the decision right now. Please try again.", statusCode: 503);
            }
            return Results.Accepted();
        });

        // Assisted upload by the sales RM on the customer's behalf.
        g.MapPost("/documents/{caseDocumentId:long}/upload", async (long caseDocumentId, [FromForm] IFormFile file,
            HttpContext http, MissingDocsDbContext db, UploadService uploads, CancellationToken ct) =>
        {
            var reviewer = Reviewer.From(http);
            if (reviewer is null) return Results.BadRequest("Reviewer identity missing");
            var doc = await db.CaseDocuments.AsNoTracking().SingleOrDefaultAsync(d => d.CaseDocumentId == caseDocumentId, ct);
            if (doc is null) return Results.NotFound();
            var result = await uploads.UploadAsync(doc.CaseId, doc.DocTypeCode, file, reviewer.Id, ct);
            return result.Accepted ? Results.Ok(result) : Results.BadRequest(result);
        }).DisableAntiforgery();

        g.MapPost("/cases/{agreementNo}/resend-link", async (string agreementNo, HttpContext http, MissingDocsDbContext db,
            ILinkTokenService links, INotificationSender notifier, IOptions<CaseOptions> options, CancellationToken ct) =>
        {
            var reviewer = Reviewer.From(http);
            if (reviewer is null) return Results.BadRequest("Reviewer identity missing");
            var c = await db.Cases.Include(x => x.Documents).ThenInclude(d => d.DocumentType)
                .SingleOrDefaultAsync(x => x.AgreementNo == agreementNo && x.Status == CaseStatus.Open, ct);
            if (c is null) return Results.NotFound();

            var pending = c.Documents.Where(d => UploadService.UploadableStatuses.Contains(d.Status)).ToList();
            if (pending.Count == 0) return Results.Conflict("Nothing is pending with the customer.");

            var o = options.Value;
            var token = await links.IssueAsync(c.CaseId, TimeSpan.FromDays(o.LinkValidDays), ct);
            await notifier.SendAsync(c.MobileNo, "Reminder", new Dictionary<string, string>
            {
                ["FirstName"] = Masking.FirstName(c.CustomerName),
                ["AgreementNo"] = c.AgreementNo,
                ["Count"] = pending.Count.ToString(),
                ["DocList"] = string.Join(", ", pending.Select(d => d.DocumentType.DisplayName)),
                ["Link"] = $"{o.PortalBaseUrl.TrimEnd('/')}/u/{token}",
                ["BankName"] = o.BankName,
            }, ct);
            db.Audit(c.CaseId, null, reviewer.Id, "LinkResent");
            await db.SaveChangesAsync(ct);
            return Results.Accepted();
        });
    }

    public static void MapAdminEndpoints(this IEndpointRouteBuilder app)
    {
        var g = app.MapGroup("/api/admin").RequireAuthorization(AuthSetup.PortalPolicy);

        g.MapGet("/rules", async (MissingDocsDbContext db, CancellationToken ct) =>
        {
            var types = await db.DocumentTypes.AsNoTracking().Where(t => t.IsActive).ToListAsync(ct);
            var rules = await db.LoanTypeDocumentRules.AsNoTracking().Where(r => r.IsMandatory).ToListAsync(ct);
            return types.Select(t => new DocumentTypeRuleDto(t.DocTypeCode, t.DisplayName, t.AzureModelId, t.MatchFields, t.AutoAcceptThreshold,
                rules.Where(r => r.DocTypeCode == t.DocTypeCode).Select(r => r.LoanType).OrderBy(x => x).ToList()));
        });
    }
}
