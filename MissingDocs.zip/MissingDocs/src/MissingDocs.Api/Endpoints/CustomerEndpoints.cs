using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MissingDocs.Api.Services;
using MissingDocs.Contracts;
using MissingDocs.Core;
using MissingDocs.Core.Abstractions;
using MissingDocs.Infrastructure.Data;
using MissingDocs.Infrastructure.Security;

namespace MissingDocs.Api.Endpoints;

/// <summary>
/// Public endpoints behind the API gateway, used by the customer upload portal.
/// Access: link token from the SMS -> OTP to the registered mobile -> 30-minute session token.
/// </summary>
public static class CustomerEndpoints
{
    public const string SessionHeader = "X-Customer-Session";

    public static void MapCustomerEndpoints(this IEndpointRouteBuilder app)
    {
        var g = app.MapGroup("/api/customer").AllowAnonymous().RequireRateLimiting("customer");

        // Before OTP: only first name and masked mobile, so a forwarded link reveals almost nothing.
        g.MapGet("/links/{token}", async (string token, ILinkTokenService links, MissingDocsDbContext db, CancellationToken ct) =>
        {
            var caseId = await links.ResolveCaseIdAsync(token, ct);
            if (caseId is null) return Results.Ok(new CustomerLinkSummaryDto(false, null, null, null));
            var c = await db.Cases.AsNoTracking().SingleAsync(x => x.CaseId == caseId, ct);
            return Results.Ok(new CustomerLinkSummaryDto(c.Status == CaseStatus.Open,
                Masking.FirstName(c.CustomerName), Masking.Mobile(c.MobileNo), Masking.Identifier(c.AgreementNo)));
        });

        g.MapPost("/links/{token}/otp", async (string token, ILinkTokenService links, MissingDocsDbContext db, OtpService otp, CancellationToken ct) =>
        {
            var caseId = await links.ResolveCaseIdAsync(token, ct);
            if (caseId is null) return Results.NotFound();
            var c = await db.Cases.SingleAsync(x => x.CaseId == caseId, ct);
            if (c.Status != CaseStatus.Open) return Results.NotFound();

            return await otp.SendAsync(c, ct) == OtpSendResult.Sent
                ? Results.Accepted()
                : Results.StatusCode(StatusCodes.Status429TooManyRequests);
        });

        g.MapPost("/links/{token}/otp/verify", async (string token, OtpVerifyRequest body, ILinkTokenService links,
            OtpService otp, CustomerSessionService sessions, CancellationToken ct) =>
        {
            var caseId = await links.ResolveCaseIdAsync(token, ct);
            if (caseId is null) return Results.NotFound();

            var result = await otp.VerifyAsync(caseId.Value, body.Code ?? "", ct);
            if (result != OtpVerifyResult.Verified)
            {
                var message = result switch
                {
                    OtpVerifyResult.Expired => "The OTP has expired. Please request a new one.",
                    OtpVerifyResult.Locked => "Too many wrong attempts. Please request a new OTP.",
                    _ => "The OTP is not correct.",
                };
                return Results.Ok(new OtpVerifyResponse(false, null, null, message));
            }

            var (session, expires) = sessions.Issue(caseId.Value);
            return Results.Ok(new OtpVerifyResponse(true, session, expires, null));
        });

        g.MapGet("/documents", async (HttpContext http, CustomerSessionService sessions, MissingDocsDbContext db, CancellationToken ct) =>
        {
            var caseId = sessions.Validate(http.Request.Headers[SessionHeader]);
            if (caseId is null) return Results.Unauthorized();

            var c = await db.Cases.AsNoTracking()
                .Include(x => x.Documents).ThenInclude(d => d.DocumentType)
                .Include(x => x.Documents).ThenInclude(d => d.Uploads)
                .AsSplitQuery()
                .SingleAsync(x => x.CaseId == caseId, ct);

            var rules = await db.LoanTypeDocumentRules.AsNoTracking()
                .Where(r => r.LoanType == c.LoanType)
                .ToDictionaryAsync(r => r.DocTypeCode, r => r.SortOrder, ct);

            var docs = c.Documents
                .OrderBy(d => rules.GetValueOrDefault(d.DocTypeCode, 99))
                .Select(d =>
                {
                    var latest = d.Uploads.OrderByDescending(u => u.Attempt).FirstOrDefault();
                    var status = d.Status switch
                    {
                        DocumentStatus.AwaitingUpload => "Pending",
                        DocumentStatus.ReuploadRequested => "Re-upload needed",
                        DocumentStatus.Approved => "Verified",
                        DocumentStatus.Expired => "Expired - branch will contact you",
                        _ => "Under review",
                    };
                    return new CustomerDocumentDto(d.DocTypeCode, d.DocumentType.DisplayName, d.DocumentType.CustomerHint, status,
                        c.Status == CaseStatus.Open && UploadService.UploadableStatuses.Contains(d.Status),
                        d.Status == DocumentStatus.ReuploadRequested ? d.LastReason : null,
                        latest?.FileName, latest?.UploadedAt);
                })
                .ToList();

            var uploaded = c.Documents.Count(d => !UploadService.UploadableStatuses.Contains(d.Status) && d.Status != DocumentStatus.Expired);
            return Results.Ok(new CustomerDocumentsDto(c.AgreementNo, Masking.FirstName(c.CustomerName),
                LoanTypes.DisplayName(c.LoanType), uploaded, c.Documents.Count, docs));
        });

        g.MapPost("/documents/{docTypeCode}", async (string docTypeCode, HttpContext http, [FromForm] IFormFile file,
            CustomerSessionService sessions, UploadService uploads, CancellationToken ct) =>
        {
            var caseId = sessions.Validate(http.Request.Headers[SessionHeader]);
            if (caseId is null) return Results.Unauthorized();
            var result = await uploads.UploadAsync(caseId.Value, docTypeCode, file, "CUSTOMER", ct);
            return result.Accepted ? Results.Ok(result) : Results.BadRequest(result);
        })
        .DisableAntiforgery();   // header-based session, no cookies: CSRF does not apply
    }
}
