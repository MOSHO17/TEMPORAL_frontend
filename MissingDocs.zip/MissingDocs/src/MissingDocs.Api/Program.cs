using System.Text.Json.Serialization;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.HttpOverrides;
using MissingDocs.Api.Auth;
using MissingDocs.Api.Endpoints;
using MissingDocs.Api.Services;
using MissingDocs.Core;
using MissingDocs.Infrastructure;
using Temporalio.Client;

var builder = WebApplication.CreateBuilder(args);
var config = builder.Configuration;

builder.Services.AddMissingDocsInfrastructure(config);

builder.Services.AddSingleton<ITemporalClient>(_ => TemporalClient.CreateLazy(
    new TemporalClientConnectOptions(config["Temporal:Address"] ?? "localhost:7233")
    {
        Namespace = config["Temporal:Namespace"] ?? "default",
    }));

// Session tokens are encrypted with Data Protection. In production persist keys to a shared,
// protected location (Azure Blob + Key Vault, or a file share + certificate) so every API instance can read them.
var dp = builder.Services.AddDataProtection().SetApplicationName("MissingDocs.Api");
if (config["DataProtection:KeyPath"] is { Length: > 0 } keyPath) dp.PersistKeysToFileSystem(new DirectoryInfo(keyPath));

builder.Services.AddScoped<CustomerSessionService>();
builder.Services.AddScoped<UploadService>();
builder.Services.AddScoped<ReviewQueryService>();

builder.Services.AddPortalAuth(config, builder.Environment);

// Customer endpoints are public: limit per client IP (the gateway / WAF adds a second layer).
builder.Services.AddRateLimiter(o =>
{
    o.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    o.AddPolicy("customer", http => RateLimitPartition.GetFixedWindowLimiter(
        http.Connection.RemoteIpAddress?.ToString() ?? "unknown",
        _ => new FixedWindowRateLimiterOptions { PermitLimit = 30, Window = TimeSpan.FromMinutes(1) }));
});

var maxUpload = config.GetValue($"{CaseOptions.Section}:MaxUploadBytes", 10 * 1024 * 1024);
builder.Services.Configure<FormOptions>(o => o.MultipartBodyLengthLimit = maxUpload + 64 * 1024);
builder.WebHost.ConfigureKestrel(k => k.Limits.MaxRequestBodySize = maxUpload + 64 * 1024);

// Enums travel as strings ("Approve", "AwaitingReview") between portal and API.
builder.Services.ConfigureHttpJsonOptions(o => o.SerializerOptions.Converters.Add(new JsonStringEnumConverter()));
builder.Services.AddProblemDetails();
builder.Services.AddHealthChecks();

// Behind the API gateway: trust X-Forwarded-For only from the gateway so rate limiting sees the real client IP.
builder.Services.Configure<ForwardedHeadersOptions>(o =>
{
    o.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
    foreach (var proxy in config.GetSection("Gateway:KnownProxies").Get<string[]>() ?? [])
        o.KnownProxies.Add(System.Net.IPAddress.Parse(proxy));
});

var app = builder.Build();

app.UseForwardedHeaders();
app.UseExceptionHandler();
app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();
app.UseRateLimiter();

app.MapCustomerEndpoints();
app.MapReviewEndpoints();
app.MapAdminEndpoints();
app.MapHealthChecks("/health");

app.Run();
