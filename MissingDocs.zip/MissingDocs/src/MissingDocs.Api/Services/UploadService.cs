using System.Security.Cryptography;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using MissingDocs.Contracts;
using MissingDocs.Core;
using MissingDocs.Core.Abstractions;
using MissingDocs.Core.Entities;
using MissingDocs.Infrastructure.Data;
using Temporalio.Client;

namespace MissingDocs.Api.Services;

/// <summary>Validates and stores an upload, then signals the document's child workflow.</summary>
public sealed class UploadService(
    MissingDocsDbContext db,
    IDocumentStore store,
    ITemporalClient temporal,
    IOptions<CaseOptions> options,
    ILogger<UploadService> logger)
{
    private static readonly Dictionary<string, byte[][]> Signatures = new(StringComparer.OrdinalIgnoreCase)
    {
        ["image/jpeg"] = new[] { new byte[] { 0xFF, 0xD8, 0xFF } },
        ["image/png"] = new[] { new byte[] { 0x89, 0x50, 0x4E, 0x47 } },
        ["application/pdf"] = new[] { "%PDF"u8.ToArray() },
        ["image/webp"] = new[] { "RIFF"u8.ToArray() },
    };

    public static readonly DocumentStatus[] UploadableStatuses = { DocumentStatus.AwaitingUpload, DocumentStatus.ReuploadRequested };

    public async Task<UploadResultDto> UploadAsync(long caseId, string docTypeCode, IFormFile file, string uploadedBy, CancellationToken ct)
    {
        if (file.Length == 0) return new(false, "The file is empty.");
        if (file.Length > options.Value.MaxUploadBytes)
            return new(false, $"The file is larger than {options.Value.MaxUploadBytes / (1024 * 1024)} MB. Please upload a smaller photo.");

        var contentType = file.ContentType.ToLowerInvariant() == "image/jpg" ? "image/jpeg" : file.ContentType.ToLowerInvariant();
        if (!Signatures.TryGetValue(contentType, out var magic))
            return new(false, "Please upload a JPG, PNG or PDF file.");

        var doc = await db.CaseDocuments
            .Include(d => d.Case)
            .SingleOrDefaultAsync(d => d.CaseId == caseId && d.DocTypeCode == docTypeCode, ct);
        if (doc is null || doc.Case.Status != CaseStatus.Open) return new(false, "This document is not pending for your loan.");
        if (!UploadableStatuses.Contains(doc.Status)) return new(false, "This document has already been received and is being checked.");

        // Read into memory (bounded by MaxUploadBytes), check the real file type and hash it.
        using var buffer = new MemoryStream((int)file.Length);
        await file.CopyToAsync(buffer, ct);
        var bytes = buffer.ToArray();
        if (!magic.Any(sig => bytes.AsSpan().StartsWith(sig)))
            return new(false, "The file does not look like a valid image or PDF.");
        var sha = Convert.ToHexString(SHA256.HashData(bytes));

        var attempt = doc.Attempts + 1;
        buffer.Position = 0;
        var path = await store.SaveAsync(doc.Case.AgreementNo, doc.DocTypeCode, attempt, file.FileName, contentType, buffer, ct);

        var previousStatus = doc.Status;
        var upload = new DocumentUpload
        {
            CaseDocumentId = doc.CaseDocumentId,
            Attempt = attempt,
            StoragePath = path,
            FileName = Path.GetFileName(file.FileName),
            ContentType = contentType,
            SizeBytes = bytes.LongLength,
            Sha256 = sha,
            UploadedBy = uploadedBy,
            UploadedAt = DateTimeOffset.UtcNow,
        };
        db.Uploads.Add(upload);
        doc.Attempts = attempt;
        doc.Status = DocumentStatus.Uploaded;
        doc.StatusChangedAt = DateTimeOffset.UtcNow;
        db.Audit(doc.CaseId, doc.CaseDocumentId, uploadedBy, "Uploaded", $"attempt {attempt}, {bytes.LongLength} bytes");

        try
        {
            await db.SaveChangesAsync(ct);   // RowVersion stops two parallel uploads for the same document
        }
        catch (DbUpdateConcurrencyException)
        {
            return new(false, "This document is already being uploaded. Please refresh the page.");
        }

        try
        {
            var handle = temporal.GetWorkflowHandle(doc.WorkflowId);
            await handle.SignalAsync(WorkflowConstants.UploadReceivedSignal, new object?[] { new UploadReceivedSignal(upload.UploadId) });
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogError(ex, "Could not signal workflow {WorkflowId} for upload {UploadId}", doc.WorkflowId, upload.UploadId);
            doc.Status = previousStatus;
            db.Audit(doc.CaseId, doc.CaseDocumentId, "SYSTEM", "SignalFailed", ex.Message);
            await db.SaveChangesAsync(ct);
            return new(false, "We could not process the upload right now. Please try again in a few minutes.");
        }

        return new(true, "Thank you. Your document has been received and is being checked.");
    }
}
