using System.Globalization;
using Microsoft.AspNetCore.DataProtection;

namespace MissingDocs.Api.Services;

/// <summary>
/// Short-lived session issued after OTP verification. The token is the case id encrypted and signed with
/// ASP.NET Core Data Protection (time-limited); nothing is stored server-side.
/// </summary>
public sealed class CustomerSessionService(IDataProtectionProvider provider)
{
    public static readonly TimeSpan Lifetime = TimeSpan.FromMinutes(30);
    private readonly ITimeLimitedDataProtector _protector =
        provider.CreateProtector("MissingDocs.CustomerSession.v1").ToTimeLimitedDataProtector();

    public (string Token, DateTimeOffset ExpiresAt) Issue(long caseId)
    {
        var expires = DateTimeOffset.UtcNow.Add(Lifetime);
        return (_protector.Protect(caseId.ToString(CultureInfo.InvariantCulture), expires), expires);
    }

    public long? Validate(string? token)
    {
        if (string.IsNullOrWhiteSpace(token)) return null;
        try
        {
            return long.Parse(_protector.Unprotect(token), CultureInfo.InvariantCulture);
        }
        catch (System.Security.Cryptography.CryptographicException)
        {
            return null;   // expired or tampered
        }
    }
}
