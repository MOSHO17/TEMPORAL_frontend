using Microsoft.EntityFrameworkCore;
using MissingDocs.Contracts;
using MissingDocs.Core;
using MissingDocs.Core.Entities;
using MissingDocs.Infrastructure.Data;

namespace MissingDocs.Api.Services;

/// <summary>Read models for the branch review portal.</summary>
public sealed class ReviewQueryService(MissingDocsDbContext db)
{
    /// <param name="view">all | review (anything waiting for a reviewer) | customer | done</param>
    public async Task<PagedResult<CaseListItemDto>> ListCasesAsync(string? search, string? view, int page, int pageSize, CancellationToken ct)
    {
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize, 5, 100);
        var q = db.Cases.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.Trim();
            q = q.Where(c => c.AgreementNo.StartsWith(s) || c.CustomerName.Contains(s) || c.MobileNo.EndsWith(s));
        }

        q = view switch
        {
            "review" => q.Where(c => c.Status == CaseStatus.Open && c.Documents.Any(d => d.Status == DocumentStatus.AwaitingReview)),
            "customer" => q.Where(c => c.Status == CaseStatus.Open && c.Documents.Any(d => d.Status == DocumentStatus.AwaitingUpload || d.Status == DocumentStatus.ReuploadRequested)),
            "done" => q.Where(c => c.Status != CaseStatus.Open),
            _ => q,
        };

        var total = await q.CountAsync(ct);
        var items = await q
            .OrderByDescending(c => c.Documents.Any(d => d.Status == DocumentStatus.AwaitingReview))
            .ThenBy(c => c.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(c => new CaseListItemDto(
                c.AgreementNo, c.CustomerName, c.LoanType, c.Branch, c.Status, c.CreatedAt,
                c.Documents.Count,
                c.Documents.Count(d => d.Status == DocumentStatus.Approved),
                c.Documents.Count(d => d.Status == DocumentStatus.AwaitingReview),
                c.Documents.Count(d => d.Status == DocumentStatus.Uploaded || d.Status == DocumentStatus.AiReview),
                c.Documents.Count(d => d.Status == DocumentStatus.AwaitingUpload || d.Status == DocumentStatus.ReuploadRequested)))
            .ToListAsync(ct);

        return new PagedResult<CaseListItemDto>(items, total, page, pageSize);
    }

    public async Task<CaseDetailDto?> GetCaseAsync(string agreementNo, CancellationToken ct)
    {
        var c = await db.Cases.AsNoTracking()
            .Where(x => x.AgreementNo == agreementNo)
            .OrderByDescending(x => x.CaseId)
            .Include(x => x.Documents).ThenInclude(d => d.DocumentType)
            .Include(x => x.Documents).ThenInclude(d => d.Uploads).ThenInclude(u => u.OcrResult)
            .Include(x => x.Documents).ThenInclude(d => d.Uploads).ThenInclude(u => u.FieldMatches)
            .AsSplitQuery()
            .FirstOrDefaultAsync(ct);
        if (c is null) return null;

        var uploadIds = c.Documents.SelectMany(d => d.Uploads).Select(u => u.UploadId).ToList();
        var decisions = await db.ReviewDecisions.AsNoTracking()
            .Where(r => uploadIds.Contains(r.UploadId))
            .ToDictionaryAsync(r => r.UploadId, ct);

        var rules = await db.LoanTypeDocumentRules.AsNoTracking()
            .Where(r => r.LoanType == c.LoanType)
            .ToDictionaryAsync(r => r.DocTypeCode, r => r.SortOrder, ct);

        var docs = c.Documents
            .OrderBy(d => rules.GetValueOrDefault(d.DocTypeCode, 99))
            .Select(d => ToDto(c, d, decisions))
            .ToList();

        return new CaseDetailDto(c.AgreementNo, c.CustomerName, Masking.Mobile(c.MobileNo), LoanTypes.DisplayName(c.LoanType),
            c.VehicleRegNo, c.ChassisNo, c.Branch, c.Status, c.CreatedAt, c.LinkSentAt, docs);
    }

    private static CaseDocumentDto ToDto(MissingDocCase c, CaseDocument d, IReadOnlyDictionary<long, ReviewDecision> decisions)
    {
        var latest = d.Uploads.OrderByDescending(u => u.Attempt).FirstOrDefault();
        var decision = latest is null ? null : decisions.GetValueOrDefault(latest.UploadId);

        var pendingWith = d.Status switch
        {
            DocumentStatus.AwaitingUpload or DocumentStatus.ReuploadRequested => "Customer",
            DocumentStatus.Uploaded or DocumentStatus.AiReview => "AI / OCR",
            DocumentStatus.AwaitingReview => "Bank reviewer",
            DocumentStatus.Expired => "Branch follow-up",
            _ => "-",
        };

        var fields = latest?.FieldMatches
            .Select(f => new FieldMatchDto(f.FieldName, f.ExpectedValue, f.ExtractedValue, f.Score, f.Result))
            .ToList() ?? new List<FieldMatchDto>();

        return new CaseDocumentDto(
            d.CaseDocumentId, d.DocTypeCode, d.DocumentType.DisplayName, d.Status, pendingWith,
            d.Status == DocumentStatus.Approved ? null : d.StatusChangedAt,
            d.MatchScore, d.Attempts, latest?.UploadId, latest?.FileName, latest?.ContentType, d.LastReason,
            BuildStages(c, d, latest, decision), fields);
    }

    /// <summary>Five-step tracker: Msg sent, Uploaded, AI review, Human review, Approved.</summary>
    private static IReadOnlyList<StageDto> BuildStages(MissingDocCase c, CaseDocument d, DocumentUpload? latest, ReviewDecision? decision)
    {
        var current = d.Status switch
        {
            DocumentStatus.AwaitingUpload or DocumentStatus.ReuploadRequested or DocumentStatus.Expired => 1,
            DocumentStatus.Uploaded or DocumentStatus.AiReview => 2,
            DocumentStatus.AwaitingReview => 3,
            _ => 5,   // Approved: everything done
        };
        var failed = d.Status is DocumentStatus.Expired or DocumentStatus.ReuploadRequested;

        var names = new[] { "Msg sent", "Uploaded", "AI review", "Human review", "Approved" };
        var times = new DateTimeOffset?[]
        {
            c.LinkSentAt,
            current > 1 ? latest?.UploadedAt : null,
            current > 2 ? latest?.OcrResult?.CreatedAt : null,
            current > 3 ? decision?.DecidedAt : null,
            d.ApprovedAt,
        };

        return names.Select((name, i) =>
        {
            var state = i < current ? "done" : i == current ? (failed ? "failed" : "current") : "todo";
            if (i == 0 && c.LinkSentAt is null) state = "current";
            return new StageDto(name, state, state == "done" ? times[i] : i == current ? d.StatusChangedAt : null);
        }).ToList();
    }
}
