using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Options;
using Microsoft.Identity.Web;

namespace MissingDocs.Api.Auth;

/// <summary>
/// Staff endpoints are called only by the Blazor portal (trusted subsystem inside the bank network).
/// Production: Entra ID / Azure AD app-to-app token carrying the "Portal.Backend" app role.
/// Development: a shared API key header. The signed-in reviewer is passed in X-Reviewer-* headers.
/// </summary>
public static class AuthSetup
{
    public const string PortalPolicy = "PortalBackend";

    public static IServiceCollection AddPortalAuth(this IServiceCollection services, IConfiguration config, IHostEnvironment env)
    {
        if (!string.IsNullOrWhiteSpace(config["AzureAd:ClientId"]))
        {
            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddMicrosoftIdentityWebApi(config.GetSection("AzureAd"));
            services.AddAuthorizationBuilder()
                .AddPolicy(PortalPolicy, p => p.RequireAuthenticatedUser().RequireRole("Portal.Backend"));
        }
        else
        {
            if (!env.IsDevelopment())
                throw new InvalidOperationException("AzureAd must be configured outside Development.");

            services.AddAuthentication(ApiKeyAuthHandler.Scheme)
                .AddScheme<AuthenticationSchemeOptions, ApiKeyAuthHandler>(ApiKeyAuthHandler.Scheme, null);
            services.AddAuthorizationBuilder()
                .AddPolicy(PortalPolicy, p => p.RequireAuthenticatedUser());
        }
        return services;
    }
}

/// <summary>Development-only scheme: X-Api-Key must equal configuration "Auth:DevApiKey".</summary>
public sealed class ApiKeyAuthHandler(
    IOptionsMonitor<AuthenticationSchemeOptions> options,
    ILoggerFactory logger,
    UrlEncoder encoder,
    IConfiguration config) : AuthenticationHandler<AuthenticationSchemeOptions>(options, logger, encoder)
{
    public const string Scheme = "DevApiKey";

    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        var expected = config["Auth:DevApiKey"];
        if (string.IsNullOrEmpty(expected) || !Request.Headers.TryGetValue("X-Api-Key", out var provided))
            return Task.FromResult(AuthenticateResult.NoResult());

        if (!CryptographicOperations.FixedTimeEquals(Encoding.UTF8.GetBytes(expected), Encoding.UTF8.GetBytes(provided.ToString())))
            return Task.FromResult(AuthenticateResult.Fail("Invalid API key"));

        var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, "dev-portal") }, Scheme);
        return Task.FromResult(AuthenticateResult.Success(new AuthenticationTicket(new ClaimsPrincipal(identity), Scheme)));
    }
}

/// <summary>The reviewer on whose behalf the portal is calling.</summary>
public sealed record Reviewer(string Id, string Name)
{
    public static Reviewer? From(HttpContext http)
    {
        var id = http.Request.Headers["X-Reviewer-Id"].ToString();
        if (string.IsNullOrWhiteSpace(id) || id.Length > 100) return null;
        var name = Uri.UnescapeDataString(http.Request.Headers["X-Reviewer-Name"].ToString());
        return new Reviewer(id, string.IsNullOrWhiteSpace(name) ? id : name);
    }
}
