using MissingDocs.Contracts;

namespace MissingDocs.Core.Entities;

// Plain entities mapped by EF Core to the tables in db/001_schema.sql.

/// <summary>Reference data: one row per document type (RC, INSURANCE, INVOICE ...).</summary>
public class DocumentType
{
    public string DocTypeCode { get; set; } = default!;
    public string DisplayName { get; set; } = default!;
    public string CustomerHint { get; set; } = "";
    /// <summary>Label the Azure custom classifier returns for this type (null = skip classification).</summary>
    public string? ClassifierLabel { get; set; }
    /// <summary>Azure Document Intelligence model used for extraction, e.g. prebuilt-read or a custom model id.</summary>
    public string AzureModelId { get; set; } = "prebuilt-read";
    /// <summary>Comma-separated case fields to verify: CustomerName,AgreementNo,VehicleRegNo,ChassisNo,EngineNo,Address.</summary>
    public string MatchFields { get; set; } = "CustomerName";
    public decimal AutoAcceptThreshold { get; set; } = 90m;
    public bool IsActive { get; set; } = true;
}

/// <summary>Rule matrix: which document types are mandatory for which loan type (2W = 5 docs, 4W = 10 docs ...).</summary>
public class LoanTypeDocumentRule
{
    public string LoanType { get; set; } = default!;
    public string DocTypeCode { get; set; } = default!;
    public bool IsMandatory { get; set; } = true;
    public int SortOrder { get; set; }
}

public class MissingDocCase
{
    public long CaseId { get; set; }
    public string AgreementNo { get; set; } = default!;
    public string LoanType { get; set; } = default!;
    public string CustomerName { get; set; } = default!;
    public string MobileNo { get; set; } = default!;
    public string? Address { get; set; }
    public string? VehicleRegNo { get; set; }
    public string? ChassisNo { get; set; }
    public string? EngineNo { get; set; }
    public string Branch { get; set; } = default!;
    public CaseStatus Status { get; set; } = CaseStatus.Open;
    public string WorkflowId { get; set; } = default!;
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? LinkSentAt { get; set; }
    /// <summary>Null until the parent workflow has been started; the sync service retries these.</summary>
    public DateTimeOffset? WorkflowStartedAt { get; set; }
    public DateTimeOffset? ClosedAt { get; set; }

    public List<CaseDocument> Documents { get; set; } = new();
}

public class CaseDocument
{
    public long CaseDocumentId { get; set; }
    public long CaseId { get; set; }
    public string DocTypeCode { get; set; } = default!;
    public DocumentStatus Status { get; set; } = DocumentStatus.AwaitingUpload;
    public int Attempts { get; set; }
    public decimal? MatchScore { get; set; }
    public string? LastReason { get; set; }
    public string WorkflowId { get; set; } = default!;
    public DateTimeOffset StatusChangedAt { get; set; }
    public DateTimeOffset? ApprovedAt { get; set; }
    public byte[] RowVersion { get; set; } = default!;

    public MissingDocCase Case { get; set; } = default!;
    public DocumentType DocumentType { get; set; } = default!;
    public List<DocumentUpload> Uploads { get; set; } = new();
}

public class DocumentUpload
{
    public long UploadId { get; set; }
    public long CaseDocumentId { get; set; }
    public int Attempt { get; set; }
    public string StoragePath { get; set; } = default!;
    public string FileName { get; set; } = default!;
    public string ContentType { get; set; } = default!;
    public long SizeBytes { get; set; }
    public string Sha256 { get; set; } = default!;
    /// <summary>CUSTOMER or the staff id of the RM who uploaded on the customer's behalf.</summary>
    public string UploadedBy { get; set; } = "CUSTOMER";
    public DateTimeOffset UploadedAt { get; set; }
    public bool? QualityPassed { get; set; }
    public string? QualityNote { get; set; }

    public CaseDocument CaseDocument { get; set; } = default!;
    public OcrResult? OcrResult { get; set; }
    public List<FieldMatch> FieldMatches { get; set; } = new();
}

public class OcrResult
{
    public long OcrResultId { get; set; }
    public long UploadId { get; set; }
    public string? ClassifiedType { get; set; }
    public decimal? ClassifierConfidence { get; set; }
    public string ModelId { get; set; } = default!;
    public string ExtractedText { get; set; } = "";
    public string FieldsJson { get; set; } = "{}";
    public decimal MatchScore { get; set; }
    public bool TypeMatched { get; set; }
    public string AiMode { get; set; } = default!;
    public DateTimeOffset CreatedAt { get; set; }
}

public class FieldMatch
{
    public long FieldMatchId { get; set; }
    public long UploadId { get; set; }
    public string FieldName { get; set; } = default!;
    public string? ExpectedValue { get; set; }
    public string? ExtractedValue { get; set; }
    public decimal Score { get; set; }
    public string Result { get; set; } = default!;   // Match | Partial | Mismatch | NotFound
}

public class ReviewDecision
{
    public long ReviewDecisionId { get; set; }
    public long CaseDocumentId { get; set; }
    public long UploadId { get; set; }
    public ReviewOutcome Outcome { get; set; }
    public string? Reason { get; set; }
    /// <summary>Staff id, or "AI-AUTO" for an automatic approval.</summary>
    public string DecidedBy { get; set; } = default!;
    public DateTimeOffset DecidedAt { get; set; }
}

/// <summary>Each SMS/WhatsApp link carries its own token; only the SHA-256 hash is stored.</summary>
public class CaseLinkToken
{
    public string TokenHash { get; set; } = default!;
    public long CaseId { get; set; }
    public DateTimeOffset IssuedAt { get; set; }
    public DateTimeOffset ExpiresAt { get; set; }
    public bool Revoked { get; set; }
}

public class OtpChallenge
{
    public long OtpChallengeId { get; set; }
    public long CaseId { get; set; }
    public string CodeHash { get; set; } = default!;
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset ExpiresAt { get; set; }
    public int FailedAttempts { get; set; }
    public DateTimeOffset? VerifiedAt { get; set; }
}

public class AuditLogEntry
{
    public long AuditId { get; set; }
    public long? CaseId { get; set; }
    public long? CaseDocumentId { get; set; }
    public string Actor { get; set; } = default!;
    public string Action { get; set; } = default!;
    public string? Detail { get; set; }
    public DateTimeOffset At { get; set; }
}
