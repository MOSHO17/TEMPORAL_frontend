using System.Globalization;
using System.Text;
using MissingDocs.Core.Entities;

namespace MissingDocs.Core.Matching;

public enum FieldKind { PersonName, Identifier, Address }

public sealed record ExpectedField(string Name, string Value, FieldKind Kind, decimal Weight);

public sealed record MatchInput(
    string ExpectedDocType,
    string? ExpectedClassifierLabel,
    string? ClassifiedType,
    IReadOnlyList<ExpectedField> Expected,
    IReadOnlyDictionary<string, string> ExtractedFields,
    string FullText);

public sealed record FieldMatchResult(string Field, string Expected, string? Extracted, decimal Score, string Result);

public sealed record MatchOutcome(decimal Score, bool TypeMatched, IReadOnlyList<FieldMatchResult> Fields);

/// <summary>
/// Compares what OCR read from the document with what the core system (Finnone) holds for the agreement.
/// Produces a 0-100 match score plus field-level results that the reviewer sees side by side.
/// Deterministic and dependency-free so it can be unit tested and explained to auditors.
/// </summary>
public static class MatchEngine
{
    public const decimal MatchThreshold = 0.95m;
    public const decimal PartialThreshold = 0.75m;
    private const decimal WrongTypePenalty = 0.4m;

    public static MatchOutcome Evaluate(MatchInput input)
    {
        var typeMatched = input.ExpectedClassifierLabel is null
                          || input.ClassifiedType is null
                          || string.Equals(input.ClassifiedType, input.ExpectedClassifierLabel, StringComparison.OrdinalIgnoreCase);

        var textTokens = Tokenize(input.FullText);
        var compactText = Compact(input.FullText);
        var results = new List<FieldMatchResult>();
        decimal weighted = 0, totalWeight = 0;

        foreach (var field in input.Expected)
        {
            if (string.IsNullOrWhiteSpace(field.Value)) continue;

            input.ExtractedFields.TryGetValue(field.Name, out var extracted);
            var (score, found) = field.Kind switch
            {
                FieldKind.Identifier => ScoreIdentifier(field.Value, extracted, compactText),
                FieldKind.PersonName => ScoreName(field.Value, extracted, textTokens),
                FieldKind.Address => ScoreAddress(field.Value, extracted, textTokens),
                _ => (0m, (string?)null),
            };

            var result = score >= MatchThreshold ? "Match"
                       : score >= PartialThreshold ? "Partial"
                       : found is null ? "NotFound"
                       : "Mismatch";

            results.Add(new FieldMatchResult(field.Name, field.Value, found, Math.Round(score * 100m, 1), result));
            weighted += score * field.Weight;
            totalWeight += field.Weight;
        }

        var fieldsScore = totalWeight == 0 ? 0m : weighted / totalWeight;
        var overall = typeMatched ? fieldsScore : fieldsScore * WrongTypePenalty;
        return new MatchOutcome(Math.Round(overall * 100m, 1), typeMatched, results);
    }

    // ---------------- Identifiers: agreement no., chassis no., registration no. ----------------

    internal static (decimal Score, string? Found) ScoreIdentifier(string expected, string? extracted, string compactText)
    {
        var exp = Compact(expected);
        if (exp.Length == 0) return (0m, null);

        if (!string.IsNullOrWhiteSpace(extracted))
        {
            var ext = Compact(extracted);
            return (Similarity(exp, ext), extracted.Trim());
        }

        if (compactText.Contains(exp, StringComparison.Ordinal)) return (1m, expected);

        // Fuzzy window search: tolerates one or two OCR misreads (0/O, 1/I, 8/B).
        decimal best = 0; string? bestText = null;
        if (compactText.Length >= exp.Length)
        {
            for (var i = 0; i + exp.Length <= compactText.Length; i++)
            {
                var window = compactText.AsSpan(i, exp.Length).ToString();
                var s = Similarity(exp, window);
                if (s > best) { best = s; bestText = window; }
            }
        }
        return best >= 0.6m ? (best, bestText) : (0m, null);
    }

    // ---------------- Names: tolerant of order, initials and small spelling variations ----------------

    internal static (decimal Score, string? Found) ScoreName(string expected, string? extracted, IReadOnlyList<string> textTokens)
    {
        var expTokens = Tokenize(expected).Where(t => t.Length > 1).ToList();
        if (expTokens.Count == 0) return (0m, null);

        var candidates = string.IsNullOrWhiteSpace(extracted) ? textTokens : Tokenize(extracted);
        decimal sum = 0;
        var matched = new List<string>();
        foreach (var token in expTokens)
        {
            var (bestScore, bestToken) = BestJaroWinkler(token, candidates);
            if (bestScore >= 0.88m) { sum += bestScore; matched.Add(bestToken!); }
        }

        var score = sum / expTokens.Count;
        var found = !string.IsNullOrWhiteSpace(extracted) ? extracted.Trim()
                  : matched.Count > 0 ? string.Join(' ', matched) : null;
        return (score, found);
    }

    // ---------------- Address: share of meaningful words present ----------------

    private static readonly HashSet<string> AddressStopWords = new(StringComparer.Ordinal)
    {
        "NEAR", "OPP", "OPPOSITE", "ROAD", "RD", "STREET", "ST", "NAGAR", "POST", "DIST", "DISTRICT", "TALUK", "TAL", "VILLAGE", "VIL", "AT", "PO", "THE", "AND",
    };

    internal static (decimal Score, string? Found) ScoreAddress(string expected, string? extracted, IReadOnlyList<string> textTokens)
    {
        var expTokens = Tokenize(expected).Where(t => t.Length >= 3 && !AddressStopWords.Contains(t)).Distinct().ToList();
        if (expTokens.Count == 0) return (0m, null);

        var candidates = string.IsNullOrWhiteSpace(extracted) ? textTokens : Tokenize(extracted);
        var hits = new List<string>();
        foreach (var token in expTokens)
        {
            var (s, best) = BestJaroWinkler(token, candidates);
            if (s >= 0.9m) hits.Add(best!);
        }
        var score = (decimal)hits.Count / expTokens.Count;
        return (score, hits.Count > 0 ? (extracted?.Trim() ?? string.Join(' ', hits)) : null);
    }

    // ---------------- Helpers ----------------

    /// <summary>Upper-case letters and digits only, with common OCR confusions folded.</summary>
    internal static string Compact(string? value)
    {
        if (string.IsNullOrEmpty(value)) return "";
        var sb = new StringBuilder(value.Length);
        foreach (var ch in value.Normalize(NormalizationForm.FormKD))
        {
            if (char.IsLetterOrDigit(ch) && ch < 128) sb.Append(char.ToUpperInvariant(ch));
        }
        return sb.ToString();
    }

    internal static List<string> Tokenize(string? value)
    {
        var tokens = new List<string>();
        if (string.IsNullOrEmpty(value)) return tokens;
        var sb = new StringBuilder();
        foreach (var ch in value.Normalize(NormalizationForm.FormKD))
        {
            if (char.IsLetterOrDigit(ch) && ch < 128) sb.Append(char.ToUpper(ch, CultureInfo.InvariantCulture));
            else if (sb.Length > 0) { tokens.Add(sb.ToString()); sb.Clear(); }
        }
        if (sb.Length > 0) tokens.Add(sb.ToString());
        return tokens;
    }

    /// <summary>1 - normalised Levenshtein distance, after folding characters OCR commonly confuses.</summary>
    internal static decimal Similarity(string a, string b)
    {
        a = FoldOcrConfusions(a); b = FoldOcrConfusions(b);
        if (a.Length == 0 && b.Length == 0) return 1m;
        var d = Levenshtein(a, b);
        return Math.Max(0m, 1m - (decimal)d / Math.Max(a.Length, b.Length));
    }

    private static string FoldOcrConfusions(string s) =>
        s.Replace('O', '0').Replace('I', '1').Replace('L', '1').Replace('S', '5').Replace('B', '8').Replace('Z', '2');

    internal static int Levenshtein(string a, string b)
    {
        var prev = new int[b.Length + 1];
        var cur = new int[b.Length + 1];
        for (var j = 0; j <= b.Length; j++) prev[j] = j;
        for (var i = 1; i <= a.Length; i++)
        {
            cur[0] = i;
            for (var j = 1; j <= b.Length; j++)
            {
                var cost = a[i - 1] == b[j - 1] ? 0 : 1;
                cur[j] = Math.Min(Math.Min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            (prev, cur) = (cur, prev);
        }
        return prev[b.Length];
    }

    private static (decimal Score, string? Token) BestJaroWinkler(string token, IReadOnlyList<string> candidates)
    {
        decimal best = 0; string? bestToken = null;
        foreach (var c in candidates)
        {
            var s = JaroWinkler(token, c);
            if (s > best) { best = s; bestToken = c; if (s == 1m) break; }
        }
        return (best, bestToken);
    }

    internal static decimal JaroWinkler(string s1, string s2)
    {
        if (s1 == s2) return 1m;
        if (s1.Length == 0 || s2.Length == 0) return 0m;

        var matchDistance = Math.Max(s1.Length, s2.Length) / 2 - 1;
        var s1Matches = new bool[s1.Length];
        var s2Matches = new bool[s2.Length];
        var matches = 0;
        for (var i = 0; i < s1.Length; i++)
        {
            var start = Math.Max(0, i - matchDistance);
            var end = Math.Min(i + matchDistance + 1, s2.Length);
            for (var j = start; j < end; j++)
            {
                if (s2Matches[j] || s1[i] != s2[j]) continue;
                s1Matches[i] = s2Matches[j] = true;
                matches++;
                break;
            }
        }
        if (matches == 0) return 0m;

        double transpositions = 0;
        var k = 0;
        for (var i = 0; i < s1.Length; i++)
        {
            if (!s1Matches[i]) continue;
            while (!s2Matches[k]) k++;
            if (s1[i] != s2[k]) transpositions++;
            k++;
        }
        double m = matches;
        var jaro = (m / s1.Length + m / s2.Length + (m - transpositions / 2) / m) / 3.0;

        var prefix = 0;
        for (var i = 0; i < Math.Min(4, Math.Min(s1.Length, s2.Length)); i++)
        {
            if (s1[i] == s2[i]) prefix++; else break;
        }
        return (decimal)(jaro + prefix * 0.1 * (1 - jaro));
    }
}

/// <summary>Builds the list of fields to verify for a document type from the case data.</summary>
public static class ExpectedFieldsBuilder
{
    public static IReadOnlyList<ExpectedField> Build(MissingDocCase c, DocumentType docType)
    {
        var list = new List<ExpectedField>();
        foreach (var raw in docType.MatchFields.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            switch (raw)
            {
                case "CustomerName": list.Add(new(raw, c.CustomerName, FieldKind.PersonName, 2m)); break;
                case "AgreementNo": list.Add(new(raw, c.AgreementNo, FieldKind.Identifier, 3m)); break;
                case "VehicleRegNo": if (c.VehicleRegNo is not null) list.Add(new(raw, c.VehicleRegNo, FieldKind.Identifier, 3m)); break;
                case "ChassisNo": if (c.ChassisNo is not null) list.Add(new(raw, c.ChassisNo, FieldKind.Identifier, 3m)); break;
                case "EngineNo": if (c.EngineNo is not null) list.Add(new(raw, c.EngineNo, FieldKind.Identifier, 2m)); break;
                case "Address": if (c.Address is not null) list.Add(new(raw, c.Address, FieldKind.Address, 1m)); break;
            }
        }
        return list;
    }
}
