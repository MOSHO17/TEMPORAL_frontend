namespace MissingDocs.Core;

public static class Masking
{
    /// <summary>98xxxxxx21 style: keeps the first two and last two digits.</summary>
    public static string Mobile(string? mobile)
    {
        if (string.IsNullOrWhiteSpace(mobile)) return "";
        var digits = new string(mobile.Where(char.IsDigit).ToArray());
        if (digits.Length <= 4) return new string('•', digits.Length);
        return digits[..2] + new string('•', digits.Length - 4) + digits[^2..];
    }

    /// <summary>AG••••01 style.</summary>
    public static string Identifier(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "";
        if (value.Length <= 4) return new string('•', value.Length);
        return value[..2] + new string('•', value.Length - 4) + value[^2..];
    }

    public static string FirstName(string? fullName) =>
        string.IsNullOrWhiteSpace(fullName) ? "" : fullName.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries)[0];
}
