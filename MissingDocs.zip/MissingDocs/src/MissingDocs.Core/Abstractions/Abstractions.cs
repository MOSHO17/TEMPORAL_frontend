using MissingDocs.Core.Entities;

namespace MissingDocs.Core.Abstractions;

/// <summary>OCR / document AI. Implemented with Azure AI Document Intelligence.</summary>
public interface IOcrService
{
    Task<OcrOutput> AnalyzeAsync(Stream content, string contentType, DocumentType docType, CancellationToken ct);
}

/// <param name="Fields">Extracted key/value fields (custom model) keyed by field name, case-insensitive.</param>
public sealed record OcrOutput(
    string ModelId,
    string FullText,
    IReadOnlyDictionary<string, string> Fields,
    string? ClassifiedType,
    decimal? ClassifierConfidence,
    string RawFieldsJson);

/// <summary>Encrypted storage for uploaded images (Azure Blob or the bank DMS).</summary>
public interface IDocumentStore
{
    Task<string> SaveAsync(string agreementNo, string docTypeCode, int attempt, string fileName, string contentType, Stream content, CancellationToken ct);
    Task<Stream> OpenReadAsync(string storagePath, CancellationToken ct);
}

public interface IImageQualityChecker
{
    Task<ImageQualityResult> CheckAsync(Stream content, string contentType, CancellationToken ct);
}

public sealed record ImageQualityResult(bool Passed, string? Reason, double? Sharpness, int? Width, int? Height);

/// <summary>SMS / WhatsApp gateway.</summary>
public interface INotificationSender
{
    Task SendAsync(string mobileNo, string templateKey, IReadOnlyDictionary<string, string> values, CancellationToken ct);
}

/// <summary>Integration with Finnone (LOS): read pending agreements, write back verified status.</summary>
public interface IFinnoneGateway
{
    Task<IReadOnlyList<PendingAgreement>> GetAgreementsWithMissingDocumentsAsync(int maxRows, CancellationToken ct);
    Task PublishDocumentStatusAsync(string agreementNo, string docTypeCode, string status, string? storagePath, CancellationToken ct);
}

public sealed record PendingAgreement(
    string AgreementNo,
    string LoanType,
    string CustomerName,
    string MobileNo,
    string? Address,
    string? VehicleRegNo,
    string? ChassisNo,
    string? EngineNo,
    string Branch,
    IReadOnlyList<string> MissingDocTypeCodes);

public interface ILinkTokenService
{
    /// <summary>Creates a new random token for the case, stores its hash, returns the raw token for the message.</summary>
    Task<string> IssueAsync(long caseId, TimeSpan validFor, CancellationToken ct);
    Task<long?> ResolveCaseIdAsync(string rawToken, CancellationToken ct);
    Task RevokeAllAsync(long caseId, CancellationToken ct);
}
