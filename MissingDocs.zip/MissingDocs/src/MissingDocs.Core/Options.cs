using MissingDocs.Contracts;

namespace MissingDocs.Core;

/// <summary>Business settings, bound from the "Case" configuration section.</summary>
public sealed class CaseOptions
{
    public const string Section = "Case";

    /// <summary>Public base URL of the customer upload portal, e.g. https://docs.bank.example</summary>
    public string PortalBaseUrl { get; set; } = "https://localhost:7180";
    public string BankName { get; set; } = "Bank";
    public int LinkValidDays { get; set; } = 10;
    public int ReminderIntervalHours { get; set; } = 48;
    public int MaxReminders { get; set; } = 3;
    /// <summary>After this, a document with no upload is marked Expired and handed to the branch.</summary>
    public int UploadWindowHours { get; set; } = 240;
    /// <summary>Reviewer SLA; after this the item is escalated (it still waits for a person).</summary>
    public int ReviewSlaHours { get; set; } = 24;
    public int SyncIntervalMinutes { get; set; } = 30;
    public int SyncBatchSize { get; set; } = 200;
    public int MaxUploadBytes { get; set; } = 10 * 1024 * 1024;
}

/// <summary>AI trust level, bound from the "Ai" section. Changed only after the accuracy gate is signed off.</summary>
public sealed class AiOptions
{
    public const string Section = "Ai";
    public AiMode Mode { get; set; } = AiMode.Shadow;
    /// <summary>Share of auto-accept candidates still sent to a person (random audit sample).</summary>
    public double AuditSampleRate { get; set; } = 0.05;
}

public static class LoanTypes
{
    public static string DisplayName(string loanType) => loanType switch
    {
        "2W" => "Two-Wheeler",
        "4W" => "Four-Wheeler",
        "CV" => "Commercial Vehicle",
        "TR" => "Tractor",
        _ => loanType,
    };
}
