using MissingDocs.Contracts;
using MissingDocs.Workflows.Activities;
using Temporalio.Workflows;

namespace MissingDocs.Workflows.Workflows;

/// <summary>
/// Parent workflow: one per agreement.
/// Sends the customer one message listing every missing document, starts one child workflow per
/// document, sends case-level reminders while anything is still with the customer, and closes the
/// case (write-back to Finnone) only when every child has finished.
/// </summary>
[Workflow(WorkflowConstants.CaseWorkflowType)]
public class AgreementCaseWorkflow
{
    private int _remindersSent;
    private readonly Dictionary<string, DocumentStatus> _finished = new();

    [WorkflowQuery]
    public int RemindersSent => _remindersSent;

    [WorkflowQuery]
    public IReadOnlyDictionary<string, DocumentStatus> FinishedDocuments => _finished;

    [WorkflowRun]
    public async Task<CaseWorkflowResult> RunAsync(CaseWorkflowInput input)
    {
        await Workflow.ExecuteActivityAsync(
            (CaseActivities a) => a.SendCaseLinkAsync(input.CaseId), ActivityProfiles.Messaging);

        // One child per missing document; they run in parallel.
        var children = new List<Task<DocumentWorkflowResult>>();
        foreach (var doc in input.Documents)
        {
            var childInput = new DocumentWorkflowInput(
                input.CaseId, input.AgreementNo, doc.CaseDocumentId, doc.DocTypeCode, input.UploadWindowHours, input.ReviewSlaHours);

            children.Add(TrackAsync(doc.DocTypeCode, Workflow.ExecuteChildWorkflowAsync(
                (DocumentWorkflow wf) => wf.RunAsync(childInput),
                new ChildWorkflowOptions
                {
                    Id = WorkflowConstants.DocumentWorkflowId(input.AgreementNo, input.CaseId, doc.DocTypeCode),
                })));
        }

        var all = Workflow.WhenAllAsync(children);

        // Case-level reminders: one message for all pending documents instead of one per child.
        while (!all.IsCompleted)
        {
            var done = await Workflow.WaitConditionAsync(() => all.IsCompleted, TimeSpan.FromHours(input.ReminderIntervalHours));
            if (done) break;

            if (_remindersSent < input.MaxReminders)
            {
                _remindersSent++;
                var reminderNo = _remindersSent;
                await Workflow.ExecuteActivityAsync(
                    (CaseActivities a) => a.SendPendingReminderAsync(input.CaseId, reminderNo), ActivityProfiles.Messaging);
            }
        }

        var results = await all;
        var approved = results.Count(r => r.FinalStatus == DocumentStatus.Approved);
        var expired = results.Count(r => r.FinalStatus == DocumentStatus.Expired);
        var finalStatus = expired == 0 ? CaseStatus.Completed : CaseStatus.Expired;

        await Workflow.ExecuteActivityAsync(
            (CaseActivities a) => a.CompleteCaseAsync(new CaseCompletion(input.CaseId, finalStatus)), ActivityProfiles.CoreSystem);

        return new CaseWorkflowResult(input.CaseId, finalStatus, approved, expired);
    }

    private async Task<DocumentWorkflowResult> TrackAsync(string docTypeCode, Task<DocumentWorkflowResult> child)
    {
        var result = await child;
        _finished[docTypeCode] = result.FinalStatus;
        return result;
    }
}
