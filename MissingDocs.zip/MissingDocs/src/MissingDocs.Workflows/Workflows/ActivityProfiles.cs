using Temporalio.Common;
using Temporalio.Workflows;

namespace MissingDocs.Workflows.Workflows;

/// <summary>Timeouts and retry policies per kind of activity. Each call gets a fresh instance.</summary>
internal static class ActivityProfiles
{
    /// <summary>Database-only work.</summary>
    public static ActivityOptions Short => new()
    {
        StartToCloseTimeout = TimeSpan.FromSeconds(30),
        RetryPolicy = new RetryPolicy { InitialInterval = TimeSpan.FromSeconds(2), BackoffCoefficient = 2, MaximumInterval = TimeSpan.FromMinutes(2), MaximumAttempts = 10 },
    };

    /// <summary>SMS / WhatsApp gateway: keep retrying for a while, gateways have short outages.</summary>
    public static ActivityOptions Messaging => new()
    {
        StartToCloseTimeout = TimeSpan.FromMinutes(1),
        RetryPolicy = new RetryPolicy { InitialInterval = TimeSpan.FromSeconds(10), BackoffCoefficient = 2, MaximumInterval = TimeSpan.FromMinutes(15), MaximumAttempts = 20 },
    };

    /// <summary>Image quality check (CPU only).</summary>
    public static ActivityOptions Processing => new()
    {
        StartToCloseTimeout = TimeSpan.FromMinutes(2),
        RetryPolicy = new RetryPolicy { InitialInterval = TimeSpan.FromSeconds(5), MaximumAttempts = 5 },
    };

    /// <summary>Azure Document Intelligence. After the last attempt the document falls back to manual review.</summary>
    public static ActivityOptions Ocr => new()
    {
        StartToCloseTimeout = TimeSpan.FromMinutes(5),
        RetryPolicy = new RetryPolicy { InitialInterval = TimeSpan.FromSeconds(15), BackoffCoefficient = 2, MaximumInterval = TimeSpan.FromMinutes(5), MaximumAttempts = 6 },
    };

    /// <summary>Write-back to Finnone outbox: must eventually succeed, retry indefinitely.</summary>
    public static ActivityOptions CoreSystem => new()
    {
        StartToCloseTimeout = TimeSpan.FromMinutes(2),
        RetryPolicy = new RetryPolicy { InitialInterval = TimeSpan.FromSeconds(30), BackoffCoefficient = 2, MaximumInterval = TimeSpan.FromMinutes(30), MaximumAttempts = 0 },
    };
}
