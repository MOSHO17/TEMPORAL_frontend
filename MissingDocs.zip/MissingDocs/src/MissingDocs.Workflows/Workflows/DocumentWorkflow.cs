using MissingDocs.Contracts;
using MissingDocs.Workflows.Activities;
using Temporalio.Exceptions;
using Temporalio.Workflows;

namespace MissingDocs.Workflows.Workflows;

/// <summary>
/// Child workflow: one per missing document. Loops until the document is approved or the upload window lapses:
///   1. wait for an upload (signal from the API)
///   2. image quality check  -> instant retake request if it fails
///   3. Azure OCR + match    -> match % (falls back to manual review if the AI is unavailable)
///   4. auto-accept only in AutoAccept mode, above threshold, and not picked for the audit sample
///   5. otherwise wait for the reviewer's decision (signal); re-upload goes back to step 1
/// </summary>
[Workflow(WorkflowConstants.DocumentWorkflowType)]
public class DocumentWorkflow
{
    private readonly Queue<UploadReceivedSignal> _uploads = new();
    private ReviewDecisionSignal? _decision;
    private DocumentStatus _status = DocumentStatus.AwaitingUpload;
    private int _attempts;

    [WorkflowQuery]
    public DocumentStatus Status => _status;

    [WorkflowQuery]
    public int Attempts => _attempts;

    [WorkflowSignal(WorkflowConstants.UploadReceivedSignal)]
    public Task UploadReceivedAsync(UploadReceivedSignal signal)
    {
        _uploads.Enqueue(signal);
        return Task.CompletedTask;
    }

    [WorkflowSignal(WorkflowConstants.ReviewDecisionSignal)]
    public Task ReviewDecisionAsync(ReviewDecisionSignal signal)
    {
        _decision = signal;
        return Task.CompletedTask;
    }

    [WorkflowRun]
    public async Task<DocumentWorkflowResult> RunAsync(DocumentWorkflowInput input)
    {
        var uploadDeadline = Workflow.UtcNow.AddHours(input.UploadWindowHours);

        while (true)
        {
            // 1. Wait for the customer (or the RM, assisted) to upload.
            var remaining = uploadDeadline - Workflow.UtcNow;
            var gotUpload = remaining > TimeSpan.Zero
                            && await Workflow.WaitConditionAsync(() => _uploads.Count > 0, remaining);
            if (!gotUpload)
            {
                await SetStatusAsync(input, DocumentStatus.Expired, "No upload within the allowed window; handed to branch for follow-up");
                return Result(input, DocumentStatus.Expired);
            }

            var upload = _uploads.Dequeue();
            while (_uploads.Count > 0) upload = _uploads.Dequeue();   // only the latest upload counts
            _attempts++;
            _status = DocumentStatus.Uploaded;

            // 2. Quality gate (cheap, before paying for OCR).
            var quality = await Workflow.ExecuteActivityAsync(
                (DocumentActivities a) => a.CheckQualityAsync(upload.UploadId), ActivityProfiles.Processing);
            if (!quality.Passed)
            {
                await RequestReuploadAsync(input, quality.Reason ?? "The image is not clear enough", "AI-QUALITY");
                uploadDeadline = Workflow.UtcNow.AddHours(input.UploadWindowHours);
                continue;
            }

            // 3. OCR + match. If the AI is down after all retries, a person checks it instead.
            await SetStatusAsync(input, DocumentStatus.AiReview, null);
            AiAssessment? ai = null;
            try
            {
                ai = await Workflow.ExecuteActivityAsync(
                    (DocumentActivities a) => a.AnalyzeAndMatchAsync(upload.UploadId), ActivityProfiles.Ocr);
            }
            catch (ActivityFailureException ex)
            {
                Workflow.Logger.LogWarning(ex, "AI check failed for upload {UploadId}; routing to manual review", upload.UploadId);
            }

            // 4. Auto-accept: only when the bank has switched the AI to AutoAccept mode.
            if (ai is { Mode: AiMode.AutoAccept, TypeMatched: true }
                && ai.MatchScore >= ai.AutoAcceptThreshold
                && Workflow.Random.NextDouble() >= ai.AuditSampleRate)
            {
                await Workflow.ExecuteActivityAsync(
                    (DocumentActivities a) => a.RecordAutoApprovalAsync(upload.UploadId), ActivityProfiles.Short);
                _status = DocumentStatus.Approved;
                return Result(input, DocumentStatus.Approved);
            }

            // 5. Human review. The API only accepts a decision while the status is AwaitingReview.
            _decision = null;
            await SetStatusAsync(input, DocumentStatus.AwaitingReview,
                ai is null ? "AI check unavailable - please verify manually" : null);

            bool IsDecided() => _decision is not null && _decision.UploadId == upload.UploadId;
            if (!await Workflow.WaitConditionAsync(IsDecided, TimeSpan.FromHours(input.ReviewSlaHours)))
            {
                await Workflow.ExecuteActivityAsync(
                    (CaseActivities a) => a.NotifyReviewEscalationAsync(input.CaseDocumentId), ActivityProfiles.Short);
                await Workflow.WaitConditionAsync(IsDecided);   // a person must still decide
            }

            var decision = _decision!;
            if (decision.Outcome == ReviewOutcome.Approve)
            {
                await SetStatusAsync(input, DocumentStatus.Approved, null);
                return Result(input, DocumentStatus.Approved);
            }

            await RequestReuploadAsync(input, decision.Reason ?? "Please upload a clearer copy", decision.ReviewerId);
            uploadDeadline = Workflow.UtcNow.AddHours(input.UploadWindowHours);
        }
    }

    private async Task SetStatusAsync(DocumentWorkflowInput input, DocumentStatus status, string? reason)
    {
        _status = status;
        await Workflow.ExecuteActivityAsync(
            (CaseActivities a) => a.SetDocumentStatusAsync(new DocumentStatusUpdate(input.CaseDocumentId, status, reason)),
            ActivityProfiles.Short);
    }

    private async Task RequestReuploadAsync(DocumentWorkflowInput input, string reason, string requestedBy)
    {
        _status = DocumentStatus.ReuploadRequested;
        await Workflow.ExecuteActivityAsync(
            (CaseActivities a) => a.RequestReuploadAsync(new ReuploadRequest(input.CaseDocumentId, reason, requestedBy)),
            ActivityProfiles.Messaging);
    }

    private DocumentWorkflowResult Result(DocumentWorkflowInput input, DocumentStatus status) =>
        new(input.CaseDocumentId, input.DocTypeCode, status, _attempts);
}
