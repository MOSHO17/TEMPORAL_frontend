using MissingDocs.Contracts;
using MissingDocs.Infrastructure;
using MissingDocs.Workflows.Activities;
using MissingDocs.Workflows.Services;
using MissingDocs.Workflows.Workflows;
using Temporalio.Client;
using Temporalio.Extensions.Hosting;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.AddMissingDocsInfrastructure(builder.Configuration);

var temporalAddress = builder.Configuration["Temporal:Address"] ?? "localhost:7233";
var temporalNamespace = builder.Configuration["Temporal:Namespace"] ?? "default";

// Temporal worker: hosts both workflows and their activities (activities resolved per call from DI).
builder.Services
    .AddHostedTemporalWorker(clientTargetHost: temporalAddress, clientNamespace: temporalNamespace, taskQueue: WorkflowConstants.TaskQueue)
    .AddScopedActivities<CaseActivities>()
    .AddScopedActivities<DocumentActivities>()
    .AddWorkflow<AgreementCaseWorkflow>()
    .AddWorkflow<DocumentWorkflow>();

// Client used by the Finnone sync to start parent workflows.
builder.Services.AddSingleton<ITemporalClient>(_ =>
    TemporalClient.CreateLazy(new TemporalClientConnectOptions(temporalAddress) { Namespace = temporalNamespace }));

if (builder.Configuration.GetValue("Case:SyncEnabled", true))
{
    builder.Services.AddHostedService<FinnoneSyncService>();
}

builder.Build().Run();
