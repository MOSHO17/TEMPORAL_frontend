using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using MissingDocs.Contracts;
using MissingDocs.Core;
using MissingDocs.Core.Abstractions;
using MissingDocs.Core.Entities;
using MissingDocs.Infrastructure.Data;
using Temporalio.Activities;

namespace MissingDocs.Workflows.Activities;

public sealed record CaseCompletion(long CaseId, CaseStatus Status);
public sealed record DocumentStatusUpdate(long CaseDocumentId, DocumentStatus Status, string? Reason);
public sealed record ReuploadRequest(long CaseDocumentId, string Reason, string RequestedBy);

/// <summary>Case-level side effects: messages, status updates, write-back. Every method is safe to retry.</summary>
public sealed class CaseActivities(
    MissingDocsDbContext db,
    ILinkTokenService links,
    INotificationSender notifier,
    IFinnoneGateway finnone,
    IOptions<CaseOptions> options,
    ILogger<CaseActivities> logger)
{
    private readonly CaseOptions _o = options.Value;

    [Activity]
    public async Task SendCaseLinkAsync(long caseId)
    {
        var ct = ActivityExecutionContext.Current.CancellationToken;
        var c = await LoadCaseAsync(caseId, ct);
        if (c.LinkSentAt is not null) return;   // already sent on an earlier attempt

        var pending = c.Documents.Where(d => d.Status != DocumentStatus.Approved).ToList();
        await SendWithLinkAsync(c, "CaseLink", pending, extra: null, ct);

        c.LinkSentAt = DateTimeOffset.UtcNow;
        db.Audit(c.CaseId, null, "SYSTEM", "LinkSent", $"{pending.Count} documents");
        await db.SaveChangesAsync(ct);
    }

    [Activity]
    public async Task SendPendingReminderAsync(long caseId, int reminderNo)
    {
        var ct = ActivityExecutionContext.Current.CancellationToken;
        var c = await LoadCaseAsync(caseId, ct);
        var pending = c.Documents
            .Where(d => d.Status is DocumentStatus.AwaitingUpload or DocumentStatus.ReuploadRequested)
            .ToList();
        if (pending.Count == 0) return;   // nothing is with the customer right now

        await SendWithLinkAsync(c, "Reminder", pending, extra: null, ct);
        db.Audit(c.CaseId, null, "SYSTEM", "ReminderSent", $"#{reminderNo}, {pending.Count} documents");
        await db.SaveChangesAsync(ct);
    }

    [Activity]
    public async Task SetDocumentStatusAsync(DocumentStatusUpdate update)
    {
        var ct = ActivityExecutionContext.Current.CancellationToken;
        var doc = await db.CaseDocuments.SingleAsync(d => d.CaseDocumentId == update.CaseDocumentId, ct);
        if (doc.Status == update.Status && doc.LastReason == update.Reason) return;

        doc.Status = update.Status;
        doc.StatusChangedAt = DateTimeOffset.UtcNow;
        if (update.Reason is not null) doc.LastReason = update.Reason;
        if (update.Status == DocumentStatus.Approved) { doc.ApprovedAt = DateTimeOffset.UtcNow; doc.LastReason = null; }

        db.Audit(doc.CaseId, doc.CaseDocumentId, "SYSTEM", $"Status:{update.Status}", update.Reason);
        await db.SaveChangesAsync(ct);
    }

    [Activity]
    public async Task RequestReuploadAsync(ReuploadRequest request)
    {
        var ct = ActivityExecutionContext.Current.CancellationToken;
        var doc = await db.CaseDocuments
            .Include(d => d.Case)
            .Include(d => d.DocumentType)
            .SingleAsync(d => d.CaseDocumentId == request.CaseDocumentId, ct);

        if (doc.Status != DocumentStatus.ReuploadRequested)
        {
            doc.Status = DocumentStatus.ReuploadRequested;
            doc.LastReason = request.Reason;
            doc.StatusChangedAt = DateTimeOffset.UtcNow;
            db.Audit(doc.CaseId, doc.CaseDocumentId, request.RequestedBy, "ReuploadRequested", request.Reason);
            await db.SaveChangesAsync(ct);
        }

        await SendWithLinkAsync(doc.Case, "Reupload", new[] { doc },
            extra: new Dictionary<string, string> { ["DocName"] = doc.DocumentType.DisplayName, ["Reason"] = request.Reason }, ct);
    }

    [Activity]
    public async Task NotifyReviewEscalationAsync(long caseDocumentId)
    {
        var ct = ActivityExecutionContext.Current.CancellationToken;
        var doc = await db.CaseDocuments.SingleAsync(d => d.CaseDocumentId == caseDocumentId, ct);
        db.Audit(doc.CaseId, doc.CaseDocumentId, "SYSTEM", "ReviewSlaBreached", $"Waiting since {doc.StatusChangedAt:u}");
        await db.SaveChangesAsync(ct);
        // Hook for e-mail / Teams alert to the branch manager.
        logger.LogWarning("Review SLA breached for case document {CaseDocumentId}", caseDocumentId);
    }

    /// <summary>Closes the case and writes each document's final status to the Finnone outbox.</summary>
    [Activity]
    public async Task CompleteCaseAsync(CaseCompletion completion)
    {
        var ct = ActivityExecutionContext.Current.CancellationToken;
        var c = await db.Cases
            .Include(x => x.Documents).ThenInclude(d => d.Uploads)
            .SingleAsync(x => x.CaseId == completion.CaseId, ct);

        foreach (var doc in c.Documents)
        {
            var latest = doc.Uploads.OrderByDescending(u => u.Attempt).FirstOrDefault();
            var status = doc.Status == DocumentStatus.Approved ? "Approved" : "Expired";
            await finnone.PublishDocumentStatusAsync(c.AgreementNo, doc.DocTypeCode, status,
                doc.Status == DocumentStatus.Approved ? latest?.StoragePath : null, ct);
        }

        if (c.Status == CaseStatus.Open)
        {
            c.Status = completion.Status;
            c.ClosedAt = DateTimeOffset.UtcNow;
            db.Audit(c.CaseId, null, "SYSTEM", "CaseClosed", completion.Status.ToString());
            await db.SaveChangesAsync(ct);
            await links.RevokeAllAsync(c.CaseId, ct);

            if (completion.Status == CaseStatus.Completed)
            {
                await notifier.SendAsync(c.MobileNo, "CaseCompleted", BaseValues(c), ct);
            }
        }
    }

    // ---------------- helpers ----------------

    private Task<MissingDocCase> LoadCaseAsync(long caseId, CancellationToken ct) =>
        db.Cases
            .Include(c => c.Documents).ThenInclude(d => d.DocumentType)
            .SingleAsync(c => c.CaseId == caseId, ct);

    private async Task SendWithLinkAsync(MissingDocCase c, string template, IReadOnlyCollection<CaseDocument> docs,
        Dictionary<string, string>? extra, CancellationToken ct)
    {
        var token = await links.IssueAsync(c.CaseId, TimeSpan.FromDays(_o.LinkValidDays), ct);
        var values = BaseValues(c);
        values["Count"] = docs.Count.ToString();
        values["DocList"] = string.Join(", ", docs.Select(d => d.DocumentType.DisplayName));
        values["Link"] = $"{_o.PortalBaseUrl.TrimEnd('/')}/u/{token}";
        values["ValidDays"] = _o.LinkValidDays.ToString();
        if (extra is not null) foreach (var (k, v) in extra) values[k] = v;

        await notifier.SendAsync(c.MobileNo, template, values, ct);
    }

    private Dictionary<string, string> BaseValues(MissingDocCase c) => new()
    {
        ["FirstName"] = Masking.FirstName(c.CustomerName),
        ["AgreementNo"] = c.AgreementNo,
        ["LoanTypeName"] = LoanTypes.DisplayName(c.LoanType),
        ["BankName"] = _o.BankName,
    };
}
