using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using MissingDocs.Contracts;
using MissingDocs.Core;
using MissingDocs.Core.Abstractions;
using MissingDocs.Core.Entities;
using MissingDocs.Core.Matching;
using MissingDocs.Infrastructure.Data;
using Temporalio.Activities;

namespace MissingDocs.Workflows.Activities;

/// <summary>Per-upload processing: quality gate, Azure OCR, matching, auto-approval record.</summary>
public sealed class DocumentActivities(
    MissingDocsDbContext db,
    IDocumentStore store,
    IImageQualityChecker quality,
    IOcrService ocr,
    IOptions<AiOptions> aiOptions,
    ILogger<DocumentActivities> logger)
{
    [Activity]
    public async Task<QualityCheckResult> CheckQualityAsync(long uploadId)
    {
        var ct = ActivityExecutionContext.Current.CancellationToken;
        var upload = await db.Uploads.SingleAsync(u => u.UploadId == uploadId, ct);
        if (upload.QualityPassed is not null) return new QualityCheckResult(upload.QualityPassed.Value, upload.QualityNote);

        await using var content = await store.OpenReadAsync(upload.StoragePath, ct);
        var result = await quality.CheckAsync(content, upload.ContentType, ct);

        upload.QualityPassed = result.Passed;
        upload.QualityNote = result.Reason ?? (result.Sharpness is null ? null : $"sharpness {result.Sharpness:0}");
        await db.SaveChangesAsync(ct);
        return new QualityCheckResult(result.Passed, result.Reason);
    }

    /// <summary>Runs OCR and matching once per upload; a retry after a crash reuses the stored result.</summary>
    [Activity]
    public async Task<AiAssessment> AnalyzeAndMatchAsync(long uploadId)
    {
        var ct = ActivityExecutionContext.Current.CancellationToken;
        var ai = aiOptions.Value;

        var upload = await db.Uploads
            .Include(u => u.OcrResult)
            .Include(u => u.CaseDocument).ThenInclude(d => d.DocumentType)
            .Include(u => u.CaseDocument).ThenInclude(d => d.Case)
            .SingleAsync(u => u.UploadId == uploadId, ct);
        var docType = upload.CaseDocument.DocumentType;

        if (upload.OcrResult is { } existing)
        {
            return new AiAssessment(uploadId, existing.MatchScore, existing.TypeMatched, existing.ClassifiedType,
                ai.Mode, docType.AutoAcceptThreshold, ai.AuditSampleRate);
        }

        OcrOutput output;
        await using (var content = await store.OpenReadAsync(upload.StoragePath, ct))
        {
            output = await ocr.AnalyzeAsync(content, upload.ContentType, docType, ct);
        }
        ActivityExecutionContext.Current.Heartbeat();

        var match = MatchEngine.Evaluate(new MatchInput(
            ExpectedDocType: docType.DocTypeCode,
            ExpectedClassifierLabel: docType.ClassifierLabel,
            ClassifiedType: output.ClassifiedType,
            Expected: ExpectedFieldsBuilder.Build(upload.CaseDocument.Case, docType),
            ExtractedFields: output.Fields,
            FullText: output.FullText));

        db.OcrResults.Add(new OcrResult
        {
            UploadId = uploadId,
            ClassifiedType = output.ClassifiedType,
            ClassifierConfidence = output.ClassifierConfidence,
            ModelId = output.ModelId,
            ExtractedText = output.FullText,
            FieldsJson = output.RawFieldsJson,
            MatchScore = match.Score,
            TypeMatched = match.TypeMatched,
            AiMode = ai.Mode.ToString(),
            CreatedAt = DateTimeOffset.UtcNow,
        });
        db.FieldMatches.AddRange(match.Fields.Select(f => new FieldMatch
        {
            UploadId = uploadId,
            FieldName = f.Field,
            ExpectedValue = f.Expected,
            ExtractedValue = f.Extracted,
            Score = f.Score,
            Result = f.Result,
        }));
        upload.CaseDocument.MatchScore = match.Score;
        db.Audit(upload.CaseDocument.CaseId, upload.CaseDocumentId, "AI", "AiAssessed",
            $"score {match.Score}, type {(match.TypeMatched ? "ok" : "mismatch:" + output.ClassifiedType)}, mode {ai.Mode}");
        await db.SaveChangesAsync(ct);

        logger.LogInformation("Upload {UploadId} scored {Score} (type matched {TypeMatched})", uploadId, match.Score, match.TypeMatched);
        return new AiAssessment(uploadId, match.Score, match.TypeMatched, output.ClassifiedType, ai.Mode, docType.AutoAcceptThreshold, ai.AuditSampleRate);
    }

    [Activity]
    public async Task RecordAutoApprovalAsync(long uploadId)
    {
        var ct = ActivityExecutionContext.Current.CancellationToken;
        var upload = await db.Uploads.Include(u => u.CaseDocument).SingleAsync(u => u.UploadId == uploadId, ct);
        var doc = upload.CaseDocument;

        if (!await db.ReviewDecisions.AnyAsync(r => r.UploadId == uploadId, ct))
        {
            db.ReviewDecisions.Add(new ReviewDecision
            {
                CaseDocumentId = doc.CaseDocumentId,
                UploadId = uploadId,
                Outcome = ReviewOutcome.Approve,
                Reason = $"Auto-accepted at match {doc.MatchScore}%",
                DecidedBy = "AI-AUTO",
                DecidedAt = DateTimeOffset.UtcNow,
            });
        }
        doc.Status = DocumentStatus.Approved;
        doc.ApprovedAt = DateTimeOffset.UtcNow;
        doc.StatusChangedAt = DateTimeOffset.UtcNow;
        doc.LastReason = null;
        db.Audit(doc.CaseId, doc.CaseDocumentId, "AI", "AutoApproved", $"match {doc.MatchScore}");
        await db.SaveChangesAsync(ct);
    }
}
