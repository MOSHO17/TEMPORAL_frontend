using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using MissingDocs.Contracts;
using MissingDocs.Core;
using MissingDocs.Core.Abstractions;
using MissingDocs.Core.Entities;
using MissingDocs.Infrastructure.Data;
using MissingDocs.Workflows.Workflows;
using Temporalio.Api.Enums.V1;
using Temporalio.Client;
using Temporalio.Exceptions;

namespace MissingDocs.Workflows.Services;

/// <summary>
/// Every N minutes: read agreements with missing documents from the Finnone extract, create a case
/// (one row per missing document) and start the parent workflow. Also retries cases whose workflow
/// start did not complete last time (WorkflowStartedAt is null).
/// </summary>
public sealed class FinnoneSyncService(
    IServiceScopeFactory scopes,
    ITemporalClient temporal,
    IOptions<CaseOptions> options,
    ILogger<FinnoneSyncService> logger) : BackgroundService
{
    private readonly CaseOptions _o = options.Value;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var timer = new PeriodicTimer(TimeSpan.FromMinutes(_o.SyncIntervalMinutes));
        do
        {
            try
            {
                await SyncOnceAsync(stoppingToken);
            }
            catch (Exception ex) when (!stoppingToken.IsCancellationRequested)
            {
                logger.LogError(ex, "Finnone sync failed; will retry on next tick");
            }
        }
        while (await timer.WaitForNextTickAsync(stoppingToken));
    }

    public async Task SyncOnceAsync(CancellationToken ct)
    {
        using var scope = scopes.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<MissingDocsDbContext>();
        var finnone = scope.ServiceProvider.GetRequiredService<IFinnoneGateway>();

        var pending = await finnone.GetAgreementsWithMissingDocumentsAsync(_o.SyncBatchSize, ct);
        foreach (var agreement in pending)
        {
            await CreateCaseAsync(db, agreement, ct);
        }

        var notStarted = await db.Cases
            .Include(c => c.Documents)
            .Where(c => c.Status == CaseStatus.Open && c.WorkflowStartedAt == null)
            .OrderBy(c => c.CaseId)
            .Take(_o.SyncBatchSize)
            .ToListAsync(ct);

        foreach (var c in notStarted)
        {
            await StartWorkflowAsync(db, c, ct);
        }

        if (pending.Count > 0 || notStarted.Count > 0)
            logger.LogInformation("Sync: {New} new cases, {Started} workflows started", pending.Count, notStarted.Count);
    }

    private async Task CreateCaseAsync(MissingDocsDbContext db, PendingAgreement a, CancellationToken ct)
    {
        // EnableRetryOnFailure requires user transactions to run inside the execution strategy.
        var strategy = db.Database.CreateExecutionStrategy();
        try
        {
            await strategy.ExecuteAsync(async () =>
            {
                db.ChangeTracker.Clear();
                await using var tx = await db.Database.BeginTransactionAsync(ct);
                var c = NewCase(a);
                db.Cases.Add(c);
                await db.SaveChangesAsync(ct);

                // Ids are known now; workflow ids include the case id.
                c.WorkflowId = WorkflowConstants.CaseWorkflowId(c.AgreementNo, c.CaseId);
                foreach (var d in c.Documents) d.WorkflowId = WorkflowConstants.DocumentWorkflowId(c.AgreementNo, c.CaseId, d.DocTypeCode);
                db.Audit(c.CaseId, null, "SYSTEM", "CaseCreated", $"{c.Documents.Count} missing: {string.Join(',', a.MissingDocTypeCodes)}");
                await db.SaveChangesAsync(ct);
                await tx.CommitAsync(ct);
            });
        }
        catch (DbUpdateException ex)
        {
            // Unique index on open cases: another sync instance created it first.
            logger.LogWarning(ex, "Case for {AgreementNo} not created (probably already exists)", a.AgreementNo);
        }
        finally
        {
            db.ChangeTracker.Clear();
        }
    }

    private static MissingDocCase NewCase(PendingAgreement a)
    {
        var now = DateTimeOffset.UtcNow;
        var c = new MissingDocCase
        {
            AgreementNo = a.AgreementNo,
            LoanType = a.LoanType,
            CustomerName = a.CustomerName,
            MobileNo = a.MobileNo,
            Address = a.Address,
            VehicleRegNo = a.VehicleRegNo,
            ChassisNo = a.ChassisNo,
            EngineNo = a.EngineNo,
            Branch = a.Branch,
            Status = CaseStatus.Open,
            WorkflowId = "pending",
            CreatedAt = now,
            Documents = a.MissingDocTypeCodes.Select(code => new CaseDocument
            {
                DocTypeCode = code,
                Status = DocumentStatus.AwaitingUpload,
                WorkflowId = "pending",
                StatusChangedAt = now,
            }).ToList(),
        };
        return c;
    }

    private async Task StartWorkflowAsync(MissingDocsDbContext db, MissingDocCase c, CancellationToken ct)
    {
        var input = new CaseWorkflowInput(
            c.CaseId,
            c.AgreementNo,
            c.Documents.Select(d => new MissingDocumentInput(d.CaseDocumentId, d.DocTypeCode)).ToList(),
            _o.ReminderIntervalHours,
            _o.MaxReminders,
            _o.UploadWindowHours,
            _o.ReviewSlaHours);

        try
        {
            await temporal.StartWorkflowAsync(
                (AgreementCaseWorkflow wf) => wf.RunAsync(input),
                new WorkflowOptions(id: c.WorkflowId, taskQueue: WorkflowConstants.TaskQueue)
                {
                    IdReusePolicy = WorkflowIdReusePolicy.RejectDuplicate,
                });
        }
        catch (WorkflowAlreadyStartedException)
        {
            // Started on a previous run; just record it.
        }

        c.WorkflowStartedAt = DateTimeOffset.UtcNow;
        await db.SaveChangesAsync(ct);
    }
}
