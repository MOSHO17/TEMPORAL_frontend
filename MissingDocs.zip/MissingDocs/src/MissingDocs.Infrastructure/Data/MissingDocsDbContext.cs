using Microsoft.EntityFrameworkCore;
using MissingDocs.Core.Entities;

namespace MissingDocs.Infrastructure.Data;

/// <summary>Maps the entities to the tables created by db/001_schema.sql (database-first; no EF migrations).</summary>
public class MissingDocsDbContext(DbContextOptions<MissingDocsDbContext> options) : DbContext(options)
{
    public DbSet<DocumentType> DocumentTypes => Set<DocumentType>();
    public DbSet<LoanTypeDocumentRule> LoanTypeDocumentRules => Set<LoanTypeDocumentRule>();
    public DbSet<MissingDocCase> Cases => Set<MissingDocCase>();
    public DbSet<CaseDocument> CaseDocuments => Set<CaseDocument>();
    public DbSet<DocumentUpload> Uploads => Set<DocumentUpload>();
    public DbSet<OcrResult> OcrResults => Set<OcrResult>();
    public DbSet<FieldMatch> FieldMatches => Set<FieldMatch>();
    public DbSet<ReviewDecision> ReviewDecisions => Set<ReviewDecision>();
    public DbSet<CaseLinkToken> LinkTokens => Set<CaseLinkToken>();
    public DbSet<OtpChallenge> OtpChallenges => Set<OtpChallenge>();
    public DbSet<AuditLogEntry> AuditLog => Set<AuditLogEntry>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.HasDefaultSchema("dbo");

        b.Entity<DocumentType>(e =>
        {
            e.ToTable("DocumentType");
            e.HasKey(x => x.DocTypeCode);
            e.Property(x => x.AutoAcceptThreshold).HasPrecision(5, 2);
        });

        b.Entity<LoanTypeDocumentRule>(e =>
        {
            e.ToTable("LoanTypeDocumentRule");
            e.HasKey(x => new { x.LoanType, x.DocTypeCode });
        });

        b.Entity<MissingDocCase>(e =>
        {
            e.ToTable("MissingDocCase");
            e.HasKey(x => x.CaseId);
            e.Property(x => x.Status).HasConversion<string>().HasMaxLength(20);
            e.HasMany(x => x.Documents).WithOne(d => d.Case).HasForeignKey(d => d.CaseId);
        });

        b.Entity<CaseDocument>(e =>
        {
            e.ToTable("CaseDocument");
            e.HasKey(x => x.CaseDocumentId);
            e.Property(x => x.Status).HasConversion<string>().HasMaxLength(20);
            e.Property(x => x.MatchScore).HasPrecision(5, 2);
            e.Property(x => x.RowVersion).IsRowVersion();
            e.HasOne(x => x.DocumentType).WithMany().HasForeignKey(x => x.DocTypeCode);
            e.HasMany(x => x.Uploads).WithOne(u => u.CaseDocument).HasForeignKey(u => u.CaseDocumentId);
        });

        b.Entity<DocumentUpload>(e =>
        {
            e.ToTable("DocumentUpload");
            e.HasKey(x => x.UploadId);
            e.Property(x => x.Sha256).IsFixedLength().HasMaxLength(64);
            e.HasOne(x => x.OcrResult).WithOne().HasForeignKey<OcrResult>(o => o.UploadId);
            e.HasMany(x => x.FieldMatches).WithOne().HasForeignKey(f => f.UploadId);
        });

        b.Entity<OcrResult>(e =>
        {
            e.ToTable("OcrResult");
            e.HasKey(x => x.OcrResultId);
            e.Property(x => x.ClassifierConfidence).HasPrecision(5, 4);
            e.Property(x => x.MatchScore).HasPrecision(5, 2);
        });

        b.Entity<FieldMatch>(e =>
        {
            e.ToTable("FieldMatch");
            e.HasKey(x => x.FieldMatchId);
            e.Property(x => x.Score).HasPrecision(5, 2);
        });

        b.Entity<ReviewDecision>(e =>
        {
            e.ToTable("ReviewDecision");
            e.HasKey(x => x.ReviewDecisionId);
            e.Property(x => x.Outcome).HasConversion<string>().HasMaxLength(20);
        });

        b.Entity<CaseLinkToken>(e =>
        {
            e.ToTable("CaseLinkToken");
            e.HasKey(x => x.TokenHash);
            e.Property(x => x.TokenHash).IsFixedLength().HasMaxLength(64);
        });

        b.Entity<OtpChallenge>(e =>
        {
            e.ToTable("OtpChallenge");
            e.HasKey(x => x.OtpChallengeId);
            e.Property(x => x.CodeHash).IsFixedLength().HasMaxLength(64);
        });

        b.Entity<AuditLogEntry>(e =>
        {
            e.ToTable("AuditLog");
            e.HasKey(x => x.AuditId);
        });
    }

    /// <summary>Adds an audit row to the current unit of work (saved with the business change).</summary>
    public void Audit(long? caseId, long? caseDocumentId, string actor, string action, string? detail = null) =>
        AuditLog.Add(new AuditLogEntry
        {
            CaseId = caseId,
            CaseDocumentId = caseDocumentId,
            Actor = actor,
            Action = action,
            Detail = detail is { Length: > 1000 } ? detail[..1000] : detail,
            At = DateTimeOffset.UtcNow,
        });
}
