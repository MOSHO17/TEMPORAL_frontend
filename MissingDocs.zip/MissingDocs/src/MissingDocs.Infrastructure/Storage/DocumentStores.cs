using Azure.Identity;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.Extensions.Options;
using MissingDocs.Core.Abstractions;

namespace MissingDocs.Infrastructure.Storage;

public sealed class DocumentStoreOptions
{
    public const string Section = "DocumentStore";

    /// <summary>Blob | Local</summary>
    public string Provider { get; set; } = "Local";
    public string? BlobConnectionString { get; set; }
    /// <summary>e.g. https://mdstore.blob.core.windows.net (used with Managed Identity when no connection string).</summary>
    public string? BlobServiceUri { get; set; }
    public string Container { get; set; } = "missing-docs";
    public string LocalRoot { get; set; } = "./_uploads";
}

internal static class StoragePaths
{
    public static string Build(string agreementNo, string docTypeCode, int attempt, string fileName)
    {
        var ext = Path.GetExtension(fileName).ToLowerInvariant();
        if (ext is not (".jpg" or ".jpeg" or ".png" or ".pdf" or ".heic" or ".webp")) ext = ".bin";
        // Never use the customer's file name in the path.
        return $"{Sanitize(agreementNo)}/{Sanitize(docTypeCode)}/{attempt:00}-{Guid.NewGuid():N}{ext}";
    }

    private static string Sanitize(string s) => new(s.Where(c => char.IsLetterOrDigit(c) || c is '-' or '_').ToArray());
}

/// <summary>Azure Blob Storage: private container, encryption at rest, versioning enabled on the account.</summary>
public sealed class AzureBlobDocumentStore : IDocumentStore
{
    private readonly BlobContainerClient _container;
    private int _ensured;

    public AzureBlobDocumentStore(IOptions<DocumentStoreOptions> options)
    {
        var o = options.Value;
        var service = !string.IsNullOrWhiteSpace(o.BlobConnectionString)
            ? new BlobServiceClient(o.BlobConnectionString)
            : new BlobServiceClient(new Uri(o.BlobServiceUri!), new DefaultAzureCredential());
        _container = service.GetBlobContainerClient(o.Container);
    }

    public async Task<string> SaveAsync(string agreementNo, string docTypeCode, int attempt, string fileName, string contentType, Stream content, CancellationToken ct)
    {
        if (Interlocked.Exchange(ref _ensured, 1) == 0)
        {
            await _container.CreateIfNotExistsAsync(PublicAccessType.None, cancellationToken: ct);
        }
        var path = StoragePaths.Build(agreementNo, docTypeCode, attempt, fileName);
        await _container.GetBlobClient(path).UploadAsync(content,
            new BlobUploadOptions { HttpHeaders = new BlobHttpHeaders { ContentType = contentType } }, ct);
        return path;
    }

    public async Task<Stream> OpenReadAsync(string storagePath, CancellationToken ct) =>
        await _container.GetBlobClient(storagePath).OpenReadAsync(cancellationToken: ct);
}

/// <summary>Local folder store for development only.</summary>
public sealed class LocalFileDocumentStore(IOptions<DocumentStoreOptions> options) : IDocumentStore
{
    private readonly string _root = Path.GetFullPath(options.Value.LocalRoot);

    public async Task<string> SaveAsync(string agreementNo, string docTypeCode, int attempt, string fileName, string contentType, Stream content, CancellationToken ct)
    {
        var path = StoragePaths.Build(agreementNo, docTypeCode, attempt, fileName);
        var full = Path.Combine(_root, path);
        Directory.CreateDirectory(Path.GetDirectoryName(full)!);
        await using var file = File.Create(full);
        await content.CopyToAsync(file, ct);
        return path;
    }

    public Task<Stream> OpenReadAsync(string storagePath, CancellationToken ct)
    {
        var full = Path.GetFullPath(Path.Combine(_root, storagePath));
        if (!full.StartsWith(_root, StringComparison.Ordinal)) throw new UnauthorizedAccessException("Invalid storage path");
        return Task.FromResult<Stream>(File.OpenRead(full));
    }
}
