using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MissingDocs.Core;
using MissingDocs.Core.Abstractions;
using MissingDocs.Infrastructure.Data;
using MissingDocs.Infrastructure.Finnone;
using MissingDocs.Infrastructure.Notifications;
using MissingDocs.Infrastructure.Ocr;
using MissingDocs.Infrastructure.Quality;
using MissingDocs.Infrastructure.Security;
using MissingDocs.Infrastructure.Storage;

namespace MissingDocs.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddMissingDocsInfrastructure(this IServiceCollection services, IConfiguration config)
    {
        services.Configure<CaseOptions>(config.GetSection(CaseOptions.Section));
        services.Configure<AiOptions>(config.GetSection(AiOptions.Section));
        services.Configure<DocumentIntelligenceOptions>(config.GetSection(DocumentIntelligenceOptions.Section));
        services.Configure<DocumentStoreOptions>(config.GetSection(DocumentStoreOptions.Section));
        services.Configure<ImageQualityOptions>(config.GetSection(ImageQualityOptions.Section));
        services.Configure<NotificationOptions>(config.GetSection(NotificationOptions.Section));
        services.Configure<OtpOptions>(config.GetSection(OtpOptions.Section));

        services.AddDbContext<MissingDocsDbContext>(o => o.UseSqlServer(
            config.GetConnectionString("MissingDocs"),
            sql => sql.EnableRetryOnFailure(maxRetryCount: 5)));

        // OCR: Azure Document Intelligence when configured, otherwise a no-op that routes everything to people.
        if (!string.IsNullOrWhiteSpace(config[$"{DocumentIntelligenceOptions.Section}:Endpoint"]))
            services.AddSingleton<IOcrService, AzureDocumentIntelligenceOcrService>();
        else
            services.AddSingleton<IOcrService, NotConfiguredOcrService>();

        if (string.Equals(config[$"{DocumentStoreOptions.Section}:Provider"], "Blob", StringComparison.OrdinalIgnoreCase))
            services.AddSingleton<IDocumentStore, AzureBlobDocumentStore>();
        else
            services.AddSingleton<IDocumentStore, LocalFileDocumentStore>();

        if (string.Equals(config[$"{NotificationOptions.Section}:Provider"], "Http", StringComparison.OrdinalIgnoreCase))
            services.AddHttpClient<INotificationSender, HttpNotificationSender>(c => c.Timeout = TimeSpan.FromSeconds(15));
        else
            services.AddSingleton<INotificationSender, LoggingNotificationSender>();

        services.AddSingleton<IImageQualityChecker, SkiaImageQualityChecker>();
        services.AddScoped<IFinnoneGateway, SqlStagingFinnoneGateway>();
        services.AddScoped<ILinkTokenService, LinkTokenService>();
        services.AddScoped<OtpService>();
        return services;
    }
}
