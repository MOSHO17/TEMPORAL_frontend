using System.Net.Http.Json;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MissingDocs.Core;
using MissingDocs.Core.Abstractions;

namespace MissingDocs.Infrastructure.Notifications;

public sealed class NotificationOptions
{
    public const string Section = "Notifications";

    /// <summary>Http | Log</summary>
    public string Provider { get; set; } = "Log";
    public string? BaseUrl { get; set; }
    public string? ApiKey { get; set; }
    public string SenderId { get; set; } = "BANKVL";
    /// <summary>Message text per template key with {Placeholders}. Text must match the DLT-registered template.</summary>
    public Dictionary<string, string> Templates { get; set; } = new();
    /// <summary>DLT template id per template key (TRAI requirement for transactional SMS in India).</summary>
    public Dictionary<string, string> DltTemplateIds { get; set; } = new();
}

public static partial class TemplateRenderer
{
    [GeneratedRegex(@"\{(\w+)\}")]
    private static partial Regex Placeholder();

    public static string Render(string template, IReadOnlyDictionary<string, string> values) =>
        Placeholder().Replace(template, m => values.TryGetValue(m.Groups[1].Value, out var v) ? v : m.Value);
}

/// <summary>Generic HTTP SMS / WhatsApp gateway. Adapt the payload to the bank's empanelled provider.</summary>
public sealed class HttpNotificationSender(HttpClient http, IOptions<NotificationOptions> options, ILogger<HttpNotificationSender> logger) : INotificationSender
{
    private readonly NotificationOptions _o = options.Value;

    public async Task SendAsync(string mobileNo, string templateKey, IReadOnlyDictionary<string, string> values, CancellationToken ct)
    {
        if (!_o.Templates.TryGetValue(templateKey, out var template))
            throw new InvalidOperationException($"No message template configured for '{templateKey}'.");

        var payload = new
        {
            to = mobileNo,
            sender = _o.SenderId,
            dltTemplateId = _o.DltTemplateIds.GetValueOrDefault(templateKey),
            message = TemplateRenderer.Render(template, values),
        };

        using var request = new HttpRequestMessage(HttpMethod.Post, _o.BaseUrl) { Content = JsonContent.Create(payload) };
        if (!string.IsNullOrEmpty(_o.ApiKey)) request.Headers.Add("X-Api-Key", _o.ApiKey);

        using var response = await http.SendAsync(request, ct);
        response.EnsureSuccessStatusCode();   // non-2xx throws -> Temporal retries the activity
        logger.LogInformation("Sent {Template} to {Mobile}", templateKey, Masking.Mobile(mobileNo));
    }
}

/// <summary>Development sender: writes the rendered message to the log instead of sending it.</summary>
public sealed class LoggingNotificationSender(IOptions<NotificationOptions> options, ILogger<LoggingNotificationSender> logger) : INotificationSender
{
    public Task SendAsync(string mobileNo, string templateKey, IReadOnlyDictionary<string, string> values, CancellationToken ct)
    {
        var template = options.Value.Templates.GetValueOrDefault(templateKey, templateKey);
        logger.LogWarning("[DEV SMS to {Mobile}] {Message}", Masking.Mobile(mobileNo), TemplateRenderer.Render(template, values));
        return Task.CompletedTask;
    }
}
