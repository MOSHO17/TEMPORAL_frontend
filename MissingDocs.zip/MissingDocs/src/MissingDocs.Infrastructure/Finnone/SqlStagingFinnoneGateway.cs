using Microsoft.EntityFrameworkCore;
using MissingDocs.Core.Abstractions;
using MissingDocs.Infrastructure.Data;

namespace MissingDocs.Infrastructure.Finnone;

/// <summary>
/// Reads agreements with missing documents from the Finnone extract (stg schema) and writes verified
/// status to the stg.DocStatusOutbound outbox. Swap for an API-based gateway if Finnone exposes one.
/// </summary>
public sealed class SqlStagingFinnoneGateway(MissingDocsDbContext db) : IFinnoneGateway
{
    public async Task<IReadOnlyList<PendingAgreement>> GetAgreementsWithMissingDocumentsAsync(int maxRows, CancellationToken ct)
    {
        var rows = await db.Database
            .SqlQuery<PendingAgreementRow>($"EXEC dbo.usp_GetAgreementsWithMissingDocs @MaxRows = {maxRows}")
            .ToListAsync(ct);

        return rows.Select(r => new PendingAgreement(
                r.AgreementNo, r.LoanType, r.CustomerName, r.MobileNo, r.Address, r.VehicleRegNo, r.ChassisNo, r.EngineNo, r.Branch,
                r.MissingDocTypeCodes.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)))
            .ToList();
    }

    public Task PublishDocumentStatusAsync(string agreementNo, string docTypeCode, string status, string? storagePath, CancellationToken ct) =>
        db.Database.ExecuteSqlInterpolatedAsync($"""
            IF NOT EXISTS (SELECT 1 FROM stg.DocStatusOutbound WHERE AgreementNo = {agreementNo} AND DocTypeCode = {docTypeCode} AND Status = {status})
                INSERT stg.DocStatusOutbound (AgreementNo, DocTypeCode, Status, StoragePath) VALUES ({agreementNo}, {docTypeCode}, {status}, {storagePath});
            """, ct);

    internal sealed class PendingAgreementRow
    {
        public string AgreementNo { get; set; } = default!;
        public string LoanType { get; set; } = default!;
        public string CustomerName { get; set; } = default!;
        public string MobileNo { get; set; } = default!;
        public string? Address { get; set; }
        public string? VehicleRegNo { get; set; }
        public string? ChassisNo { get; set; }
        public string? EngineNo { get; set; }
        public string Branch { get; set; } = default!;
        public string MissingDocTypeCodes { get; set; } = "";
    }
}
