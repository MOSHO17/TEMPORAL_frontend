using System.Text.Json;
using Azure;
using Azure.AI.DocumentIntelligence;
using Azure.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MissingDocs.Core.Abstractions;
using MissingDocs.Core.Entities;

namespace MissingDocs.Infrastructure.Ocr;

public sealed class DocumentIntelligenceOptions
{
    public const string Section = "AzureDocumentIntelligence";

    /// <summary>Resource endpoint in an India region, e.g. https://md-docintel.cognitiveservices.azure.com/</summary>
    public string Endpoint { get; set; } = "";

    /// <summary>Leave empty to use Managed Identity / DefaultAzureCredential (recommended in production).</summary>
    public string? ApiKey { get; set; }

    /// <summary>Custom classification model id. Empty = skip classification (type check is then neutral).</summary>
    public string? ClassifierId { get; set; }
}

/// <summary>
/// Azure AI Document Intelligence: (1) optional custom classifier answers "which document is this?",
/// (2) the per-type model (prebuilt-read or a trained custom extraction model) returns text and fields.
/// Processing stays in the region the resource is created in.
/// </summary>
public sealed class AzureDocumentIntelligenceOcrService : IOcrService
{
    private readonly DocumentIntelligenceClient _client;
    private readonly DocumentIntelligenceOptions _options;
    private readonly ILogger<AzureDocumentIntelligenceOcrService> _logger;

    public AzureDocumentIntelligenceOcrService(IOptions<DocumentIntelligenceOptions> options, ILogger<AzureDocumentIntelligenceOcrService> logger)
    {
        _options = options.Value;
        _logger = logger;
        var endpoint = new Uri(_options.Endpoint);
        _client = string.IsNullOrWhiteSpace(_options.ApiKey)
            ? new DocumentIntelligenceClient(endpoint, new DefaultAzureCredential())
            : new DocumentIntelligenceClient(endpoint, new AzureKeyCredential(_options.ApiKey));
    }

    public async Task<OcrOutput> AnalyzeAsync(Stream content, string contentType, DocumentType docType, CancellationToken ct)
    {
        var bytes = await BinaryData.FromStreamAsync(content, ct);

        string? classified = null;
        decimal? confidence = null;
        if (!string.IsNullOrWhiteSpace(_options.ClassifierId) && docType.ClassifierLabel is not null)
        {
            Operation<AnalyzeResult> classify = await _client.ClassifyDocumentAsync(
                WaitUntil.Completed, _options.ClassifierId, bytes, cancellationToken: ct);
            var top = classify.Value.Documents.OrderByDescending(d => d.Confidence).FirstOrDefault();
            classified = top?.DocumentType;
            confidence = top is null ? null : (decimal)top.Confidence;
        }

        Operation<AnalyzeResult> analyze = await _client.AnalyzeDocumentAsync(
            WaitUntil.Completed, docType.AzureModelId, bytes, cancellationToken: ct);
        var result = analyze.Value;

        var fields = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var document in result.Documents)
        {
            foreach (var (name, field) in document.Fields)
            {
                if (!string.IsNullOrWhiteSpace(field.Content)) fields.TryAdd(name, field.Content);
            }
        }

        _logger.LogInformation("OCR {Model} for {DocType}: {Chars} chars, {Fields} fields, classified {Classified} ({Confidence})",
            docType.AzureModelId, docType.DocTypeCode, result.Content?.Length ?? 0, fields.Count, classified, confidence);

        return new OcrOutput(docType.AzureModelId, result.Content ?? "", fields, classified, confidence, JsonSerializer.Serialize(fields));
    }
}

/// <summary>Used when no Azure endpoint is configured (local dev): everything goes to human review.</summary>
public sealed class NotConfiguredOcrService(ILogger<NotConfiguredOcrService> logger) : IOcrService
{
    public Task<OcrOutput> AnalyzeAsync(Stream content, string contentType, DocumentType docType, CancellationToken ct)
    {
        logger.LogWarning("AzureDocumentIntelligence:Endpoint is not configured; returning empty OCR result for {DocType}", docType.DocTypeCode);
        return Task.FromResult(new OcrOutput("not-configured", "", new Dictionary<string, string>(), null, null, "{}"));
    }
}
