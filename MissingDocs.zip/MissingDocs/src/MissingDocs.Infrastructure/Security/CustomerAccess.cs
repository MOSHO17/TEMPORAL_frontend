using System.Buffers.Text;
using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using MissingDocs.Core;
using MissingDocs.Core.Abstractions;
using MissingDocs.Core.Entities;
using MissingDocs.Infrastructure.Data;

namespace MissingDocs.Infrastructure.Security;

internal static class Hashing
{
    public static string Sha256Hex(string value) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(value)));

    public static string Sha256Hex(byte[] value) => Convert.ToHexString(SHA256.HashData(value));
}

/// <summary>
/// Every message carries its own random 256-bit token. Only the SHA-256 hash is stored, tokens expire,
/// and all tokens are revoked when the case closes. Several valid tokens can exist per case.
/// </summary>
public sealed class LinkTokenService(MissingDocsDbContext db) : ILinkTokenService
{
    public async Task<string> IssueAsync(long caseId, TimeSpan validFor, CancellationToken ct)
    {
        var raw = Base64Url.EncodeToString(RandomNumberGenerator.GetBytes(32));
        var now = DateTimeOffset.UtcNow;
        db.LinkTokens.Add(new CaseLinkToken
        {
            TokenHash = Hashing.Sha256Hex(raw),
            CaseId = caseId,
            IssuedAt = now,
            ExpiresAt = now.Add(validFor),
        });
        await db.SaveChangesAsync(ct);
        return raw;
    }

    public async Task<long?> ResolveCaseIdAsync(string rawToken, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(rawToken) || rawToken.Length > 100) return null;
        var hash = Hashing.Sha256Hex(rawToken);
        var now = DateTimeOffset.UtcNow;
        return await db.LinkTokens
            .Where(t => t.TokenHash == hash && !t.Revoked && t.ExpiresAt > now)
            .Select(t => (long?)t.CaseId)
            .FirstOrDefaultAsync(ct);
    }

    public Task RevokeAllAsync(long caseId, CancellationToken ct) =>
        db.LinkTokens.Where(t => t.CaseId == caseId && !t.Revoked)
            .ExecuteUpdateAsync(s => s.SetProperty(t => t.Revoked, true), ct);
}

public sealed class OtpOptions
{
    public const string Section = "Otp";
    public int Length { get; set; } = 6;
    public int ValidMinutes { get; set; } = 5;
    public int MaxFailedAttempts { get; set; } = 5;
    public int MaxSendsPer15Minutes { get; set; } = 3;
    /// <summary>Secret pepper mixed into the OTP hash. Keep in Key Vault.</summary>
    public string Pepper { get; set; } = "change-me";
}

public enum OtpSendResult { Sent, RateLimited }
public enum OtpVerifyResult { Verified, Invalid, Expired, Locked }

public sealed class OtpService(MissingDocsDbContext db, INotificationSender notifier, IOptions<OtpOptions> options)
{
    private readonly OtpOptions _o = options.Value;

    public async Task<OtpSendResult> SendAsync(MissingDocCase c, CancellationToken ct)
    {
        var now = DateTimeOffset.UtcNow;
        var recent = await db.OtpChallenges.CountAsync(o => o.CaseId == c.CaseId && o.CreatedAt > now.AddMinutes(-15), ct);
        if (recent >= _o.MaxSendsPer15Minutes) return OtpSendResult.RateLimited;

        var code = RandomNumberGenerator.GetInt32(0, (int)Math.Pow(10, _o.Length)).ToString(new string('0', _o.Length));
        db.OtpChallenges.Add(new OtpChallenge
        {
            CaseId = c.CaseId,
            CodeHash = Hash(c.CaseId, code),
            CreatedAt = now,
            ExpiresAt = now.AddMinutes(_o.ValidMinutes),
        });
        db.Audit(c.CaseId, null, "CUSTOMER", "OtpSent");
        await db.SaveChangesAsync(ct);

        await notifier.SendAsync(c.MobileNo, "Otp", new Dictionary<string, string>
        {
            ["Otp"] = code,
            ["Minutes"] = _o.ValidMinutes.ToString(),
        }, ct);
        return OtpSendResult.Sent;
    }

    public async Task<OtpVerifyResult> VerifyAsync(long caseId, string code, CancellationToken ct)
    {
        var challenge = await db.OtpChallenges
            .Where(o => o.CaseId == caseId && o.VerifiedAt == null)
            .OrderByDescending(o => o.CreatedAt)
            .FirstOrDefaultAsync(ct);

        if (challenge is null) return OtpVerifyResult.Invalid;
        if (challenge.FailedAttempts >= _o.MaxFailedAttempts) return OtpVerifyResult.Locked;
        if (challenge.ExpiresAt < DateTimeOffset.UtcNow) return OtpVerifyResult.Expired;

        var ok = CryptographicOperations.FixedTimeEquals(
            Encoding.ASCII.GetBytes(challenge.CodeHash),
            Encoding.ASCII.GetBytes(Hash(caseId, code.Trim())));

        if (!ok)
        {
            challenge.FailedAttempts++;
            db.Audit(caseId, null, "CUSTOMER", "OtpFailed");
            await db.SaveChangesAsync(ct);
            return challenge.FailedAttempts >= _o.MaxFailedAttempts ? OtpVerifyResult.Locked : OtpVerifyResult.Invalid;
        }

        challenge.VerifiedAt = DateTimeOffset.UtcNow;
        db.Audit(caseId, null, "CUSTOMER", "OtpVerified");
        await db.SaveChangesAsync(ct);
        return OtpVerifyResult.Verified;
    }

    private string Hash(long caseId, string code) => Hashing.Sha256Hex($"{caseId}:{code}:{_o.Pepper}");
}
