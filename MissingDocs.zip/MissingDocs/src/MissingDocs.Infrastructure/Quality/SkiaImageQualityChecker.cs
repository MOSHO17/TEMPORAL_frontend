using Microsoft.Extensions.Options;
using MissingDocs.Core.Abstractions;
using SkiaSharp;

namespace MissingDocs.Infrastructure.Quality;

public sealed class ImageQualityOptions
{
    public const string Section = "ImageQuality";
    public int MinWidth { get; set; } = 700;
    public int MinHeight { get; set; } = 500;
    /// <summary>Variance of the Laplacian on a 1000px-wide greyscale copy. Below this the photo is too blurred.</summary>
    public double MinSharpness { get; set; } = 60;
    public double MinBrightness { get; set; } = 40;
    public double MaxBrightness { get; set; } = 235;
}

/// <summary>
/// Cheap checks before paying for OCR: unreadable file, low resolution, blur, too dark / glare.
/// A failure gives the customer an instant "please retake" with the reason. PDFs are passed to OCR as-is.
/// </summary>
public sealed class SkiaImageQualityChecker(IOptions<ImageQualityOptions> options) : IImageQualityChecker
{
    private readonly ImageQualityOptions _o = options.Value;

    public async Task<ImageQualityResult> CheckAsync(Stream content, string contentType, CancellationToken ct)
    {
        if (contentType.Equals("application/pdf", StringComparison.OrdinalIgnoreCase))
            return new ImageQualityResult(true, null, null, null, null);

        using var ms = new MemoryStream();
        await content.CopyToAsync(ms, ct);
        ms.Position = 0;

        using var original = SKBitmap.Decode(ms);
        if (original is null)
            return new ImageQualityResult(false, "We could not open this image. Please upload a JPG, PNG or PDF.", null, null, null);

        if (original.Width < _o.MinWidth || original.Height < _o.MinHeight)
            return new ImageQualityResult(false, "The photo is too small. Please retake it closer, filling the screen with the document.",
                null, original.Width, original.Height);

        // Normalise size so the sharpness score is comparable across phones.
        var targetWidth = Math.Min(1000, original.Width);
        var targetHeight = (int)Math.Round(original.Height * (targetWidth / (double)original.Width));
        using var scaled = original.Resize(new SKImageInfo(targetWidth, targetHeight), new SKSamplingOptions(SKFilterMode.Linear)) ?? original;

        var (sharpness, brightness) = Measure(scaled);

        if (brightness < _o.MinBrightness)
            return new ImageQualityResult(false, "The photo is too dark. Please retake it in better light.", sharpness, original.Width, original.Height);
        if (brightness > _o.MaxBrightness)
            return new ImageQualityResult(false, "There is too much glare. Please avoid direct light or flash.", sharpness, original.Width, original.Height);
        if (sharpness < _o.MinSharpness)
            return new ImageQualityResult(false, "The photo is blurred. Please hold the phone steady and retake it.", sharpness, original.Width, original.Height);

        return new ImageQualityResult(true, null, sharpness, original.Width, original.Height);
    }

    /// <summary>Variance of a 3x3 Laplacian (edge strength) and mean luminance.</summary>
    private static (double Sharpness, double Brightness) Measure(SKBitmap bmp)
    {
        int w = bmp.Width, h = bmp.Height;
        var gray = new double[w * h];
        var pixels = bmp.Pixels;
        double sumLum = 0;
        for (var i = 0; i < pixels.Length; i++)
        {
            var p = pixels[i];
            var lum = 0.299 * p.Red + 0.587 * p.Green + 0.114 * p.Blue;
            gray[i] = lum;
            sumLum += lum;
        }

        double sum = 0, sumSq = 0; long n = 0;
        for (var y = 1; y < h - 1; y++)
        {
            for (var x = 1; x < w - 1; x++)
            {
                var i = y * w + x;
                var lap = gray[i - w] + gray[i + w] + gray[i - 1] + gray[i + 1] - 4 * gray[i];
                sum += lap; sumSq += lap * lap; n++;
            }
        }
        var mean = n == 0 ? 0 : sum / n;
        var variance = n == 0 ? 0 : sumSq / n - mean * mean;
        return (variance, sumLum / pixels.Length);
    }
}
