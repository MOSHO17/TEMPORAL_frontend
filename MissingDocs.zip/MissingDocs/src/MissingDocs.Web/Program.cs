using MissingDocs.Web.Auth;
using MissingDocs.Web.Components;
using MissingDocs.Web.Endpoints;
using MissingDocs.Web.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorComponents().AddInteractiveServerComponents();
builder.AddPortalAuthentication();

var apiBase = new Uri(builder.Configuration["Api:BaseUrl"] ?? "https://localhost:7100/");
builder.Services.AddHttpClient<CustomerApiClient>(c => c.BaseAddress = apiBase);               // public endpoints
builder.Services.AddHttpClient<ReviewApiClient>(c => c.BaseAddress = apiBase)
    .AddHttpMessageHandler<ApiAuthHandler>();                                                    // portal credentials

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/error", createScopeForErrors: true);
    app.UseHsts();
}

// The customer link carries a token in the URL path: never leak it in Referer headers.
app.Use(async (ctx, next) =>
{
    var h = ctx.Response.Headers;
    h["Referrer-Policy"] = "no-referrer";
    h["X-Content-Type-Options"] = "nosniff";
    h["X-Frame-Options"] = "DENY";
    h["Permissions-Policy"] = "camera=(self), geolocation=()";
    await next();
});

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();
app.UseAntiforgery();

app.MapStaticAssets();
app.MapPortalEndpoints();
app.MapDevLogin();
app.MapRazorComponents<App>().AddInteractiveServerRenderMode();

app.Run();
