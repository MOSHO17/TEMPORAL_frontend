using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Security.Claims;
using System.Text.Json;
using System.Text.Json.Serialization;
using MissingDocs.Contracts;

namespace MissingDocs.Web.Services;

internal static class Json
{
    public static readonly JsonSerializerOptions Options = new(JsonSerializerDefaults.Web)
    {
        Converters = { new JsonStringEnumConverter() },
    };
}

/// <summary>Calls the public customer endpoints server-side on behalf of the customer's browser.</summary>
public sealed class CustomerApiClient(HttpClient http)
{
    public const string SessionHeader = "X-Customer-Session";

    public async Task<CustomerLinkSummaryDto> GetLinkSummaryAsync(string token, string? clientIp, CancellationToken ct = default)
    {
        using var req = Request(HttpMethod.Get, $"api/customer/links/{Uri.EscapeDataString(token)}", clientIp);
        using var res = await http.SendAsync(req, ct);
        res.EnsureSuccessStatusCode();
        return (await res.Content.ReadFromJsonAsync<CustomerLinkSummaryDto>(Json.Options, ct))!;
    }

    public async Task<bool> SendOtpAsync(string token, string? clientIp, CancellationToken ct = default)
    {
        using var req = Request(HttpMethod.Post, $"api/customer/links/{Uri.EscapeDataString(token)}/otp", clientIp);
        using var res = await http.SendAsync(req, ct);
        return res.StatusCode == HttpStatusCode.Accepted;
    }

    public async Task<OtpVerifyResponse> VerifyOtpAsync(string token, string code, string? clientIp, CancellationToken ct = default)
    {
        using var req = Request(HttpMethod.Post, $"api/customer/links/{Uri.EscapeDataString(token)}/otp/verify", clientIp);
        req.Content = JsonContent.Create(new OtpVerifyRequest(code), options: Json.Options);
        using var res = await http.SendAsync(req, ct);
        if (!res.IsSuccessStatusCode) return new OtpVerifyResponse(false, null, null, "This link is no longer valid.");
        return (await res.Content.ReadFromJsonAsync<OtpVerifyResponse>(Json.Options, ct))!;
    }

    /// <returns>null when the session has expired.</returns>
    public async Task<CustomerDocumentsDto?> GetDocumentsAsync(string session, string? clientIp, CancellationToken ct = default)
    {
        using var req = Request(HttpMethod.Get, "api/customer/documents", clientIp);
        req.Headers.Add(SessionHeader, session);
        using var res = await http.SendAsync(req, ct);
        if (res.StatusCode == HttpStatusCode.Unauthorized) return null;
        res.EnsureSuccessStatusCode();
        return await res.Content.ReadFromJsonAsync<CustomerDocumentsDto>(Json.Options, ct);
    }

    public async Task<UploadResultDto> UploadAsync(string session, string docTypeCode, IFormFile file, string? clientIp, CancellationToken ct = default)
    {
        using var req = Request(HttpMethod.Post, $"api/customer/documents/{Uri.EscapeDataString(docTypeCode)}", clientIp);
        req.Headers.Add(SessionHeader, session);
        using var content = new MultipartFormDataContent();
        var part = new StreamContent(file.OpenReadStream());
        part.Headers.ContentType = new MediaTypeHeaderValue(string.IsNullOrEmpty(file.ContentType) ? "application/octet-stream" : file.ContentType);
        content.Add(part, "file", file.FileName);
        req.Content = content;

        using var res = await http.SendAsync(req, ct);
        if (res.StatusCode == HttpStatusCode.Unauthorized) return new UploadResultDto(false, "Your session has expired. Please verify the OTP again.");
        return await res.Content.ReadFromJsonAsync<UploadResultDto>(Json.Options, ct)
               ?? new UploadResultDto(false, "Upload failed. Please try again.");
    }

    /// <summary>The API trusts X-Forwarded-For from this portal so per-customer rate limiting still works.</summary>
    private static HttpRequestMessage Request(HttpMethod method, string url, string? clientIp)
    {
        var req = new HttpRequestMessage(method, url);
        if (!string.IsNullOrEmpty(clientIp)) req.Headers.Add("X-Forwarded-For", clientIp);
        return req;
    }
}

/// <summary>The signed-in staff member, forwarded to the API for audit.</summary>
public sealed record ReviewerIdentity(string Id, string Name)
{
    public static ReviewerIdentity From(ClaimsPrincipal user) => new(
        user.FindFirst("preferred_username")?.Value ?? user.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? user.Identity?.Name ?? "unknown",
        user.FindFirst("name")?.Value ?? user.Identity?.Name ?? "Reviewer");
}

/// <summary>Calls the review API with the portal's credentials plus the reviewer identity.</summary>
public sealed class ReviewApiClient(HttpClient http)
{
    public async Task<PagedResult<CaseListItemDto>> GetCasesAsync(ReviewerIdentity who, string? search, string view, int page, CancellationToken ct = default)
    {
        var url = $"api/review/cases?view={Uri.EscapeDataString(view)}&page={page}&pageSize=20";
        if (!string.IsNullOrWhiteSpace(search)) url += $"&search={Uri.EscapeDataString(search)}";
        using var req = Request(HttpMethod.Get, url, who);
        using var res = await http.SendAsync(req, ct);
        res.EnsureSuccessStatusCode();
        return (await res.Content.ReadFromJsonAsync<PagedResult<CaseListItemDto>>(Json.Options, ct))!;
    }

    public async Task<CaseDetailDto?> GetCaseAsync(ReviewerIdentity who, string agreementNo, CancellationToken ct = default)
    {
        using var req = Request(HttpMethod.Get, $"api/review/cases/{Uri.EscapeDataString(agreementNo)}", who);
        using var res = await http.SendAsync(req, ct);
        if (res.StatusCode == HttpStatusCode.NotFound) return null;
        res.EnsureSuccessStatusCode();
        return await res.Content.ReadFromJsonAsync<CaseDetailDto>(Json.Options, ct);
    }

    public async Task<(bool Ok, string? Error)> DecideAsync(ReviewerIdentity who, long caseDocumentId, ReviewDecisionRequest body, CancellationToken ct = default)
    {
        using var req = Request(HttpMethod.Post, $"api/review/documents/{caseDocumentId}/decision", who);
        req.Content = JsonContent.Create(body, options: Json.Options);
        using var res = await http.SendAsync(req, ct);
        return res.IsSuccessStatusCode ? (true, null) : (false, await ErrorText(res, ct));
    }

    public async Task<UploadResultDto> AssistedUploadAsync(ReviewerIdentity who, long caseDocumentId, Stream file, string fileName, string contentType, CancellationToken ct = default)
    {
        using var req = Request(HttpMethod.Post, $"api/review/documents/{caseDocumentId}/upload", who);
        using var content = new MultipartFormDataContent();
        var part = new StreamContent(file);
        part.Headers.ContentType = new MediaTypeHeaderValue(contentType);
        content.Add(part, "file", fileName);
        req.Content = content;
        using var res = await http.SendAsync(req, ct);
        return await res.Content.ReadFromJsonAsync<UploadResultDto>(Json.Options, ct) ?? new UploadResultDto(false, await ErrorText(res, ct));
    }

    public async Task<(bool Ok, string? Error)> ResendLinkAsync(ReviewerIdentity who, string agreementNo, CancellationToken ct = default)
    {
        using var req = Request(HttpMethod.Post, $"api/review/cases/{Uri.EscapeDataString(agreementNo)}/resend-link", who);
        using var res = await http.SendAsync(req, ct);
        return res.IsSuccessStatusCode ? (true, null) : (false, await ErrorText(res, ct));
    }

    /// <summary>Caller disposes the response (streamed straight to the browser).</summary>
    public async Task<HttpResponseMessage> GetUploadContentAsync(ReviewerIdentity who, long uploadId, CancellationToken ct = default)
    {
        var req = Request(HttpMethod.Get, $"api/review/uploads/{uploadId}/content", who);
        return await http.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct);
    }

    private static HttpRequestMessage Request(HttpMethod method, string url, ReviewerIdentity who)
    {
        var req = new HttpRequestMessage(method, url);
        req.Headers.Add("X-Reviewer-Id", who.Id);
        req.Headers.Add("X-Reviewer-Name", Uri.EscapeDataString(who.Name));
        return req;
    }

    private static async Task<string> ErrorText(HttpResponseMessage res, CancellationToken ct)
    {
        var text = await res.Content.ReadAsStringAsync(ct);
        return string.IsNullOrWhiteSpace(text) ? $"Request failed ({(int)res.StatusCode})" : text.Trim('"');
    }
}
