using Microsoft.AspNetCore.Antiforgery;
using MissingDocs.Web.Auth;
using MissingDocs.Web.Services;

namespace MissingDocs.Web.Endpoints;

/// <summary>
/// Plain HTML form posts from the customer page (no JavaScript, no websocket) and the image proxy
/// for reviewers. Every customer POST validates the antiforgery token and redirects back (PRG).
/// </summary>
public static class PortalEndpoints
{
    public const string SessionCookie = "md_cs";

    public static string? ReadSession(HttpContext http) => http.Request.Cookies[SessionCookie];

    public static string? ClientIp(HttpContext http) => http.Connection.RemoteIpAddress?.ToString();

    public static void MapPortalEndpoints(this WebApplication app)
    {
        app.MapPost("/u/{token}/otp/send", async (string token, HttpContext http, IAntiforgery af, CustomerApiClient api) =>
        {
            if (!await af.IsRequestValidAsync(http)) return Results.BadRequest();
            var sent = await api.SendOtpAsync(token, ClientIp(http));
            return Results.LocalRedirect(sent ? $"/u/{token}?otp=sent" : $"/u/{token}?err=otp-limit");
        });

        app.MapPost("/u/{token}/otp/verify", async (string token, HttpContext http, IAntiforgery af, CustomerApiClient api) =>
        {
            if (!await af.IsRequestValidAsync(http)) return Results.BadRequest();
            var form = await http.Request.ReadFormAsync();
            var code = form["code"].ToString();

            var result = await api.VerifyOtpAsync(token, code, ClientIp(http));
            if (!result.Verified || result.SessionToken is null)
                return Results.LocalRedirect($"/u/{token}?otp=sent&err={Uri.EscapeDataString(result.Message ?? "invalid")}");

            http.Response.Cookies.Append(SessionCookie, result.SessionToken, new CookieOptions
            {
                HttpOnly = true,
                Secure = true,
                SameSite = SameSiteMode.Lax,
                Path = $"/u/{token}",
                Expires = result.ExpiresAt,
                IsEssential = true,
            });
            return Results.LocalRedirect($"/u/{token}");
        });

        app.MapPost("/u/{token}/upload/{docTypeCode}", async (string token, string docTypeCode, HttpContext http, IAntiforgery af, CustomerApiClient api) =>
        {
            if (!await af.IsRequestValidAsync(http)) return Results.BadRequest();
            var session = ReadSession(http);
            if (session is null) return Results.LocalRedirect($"/u/{token}");

            // The page offers "Take photo" (camera) and "Upload file" (gallery/PDF) inputs; use whichever has a file.
            var form = await http.Request.ReadFormAsync();
            var file = form.Files.FirstOrDefault(f => f.Length > 0);
            if (file is null) return Results.LocalRedirect($"/u/{token}?err={Uri.EscapeDataString("Please choose a photo or file.")}");

            var result = await api.UploadAsync(session, docTypeCode, file, ClientIp(http));
            var key = result.Accepted ? "msg" : "err";
            return Results.LocalRedirect($"/u/{token}?{key}={Uri.EscapeDataString(result.Message)}#doc-{docTypeCode}");
        });

        // Reviewer image viewer: streams the upload from the API using the portal's credentials.
        app.MapGet("/review/files/{uploadId:long}", async (long uploadId, HttpContext http, ReviewApiClient api) =>
        {
            var response = await api.GetUploadContentAsync(ReviewerIdentity.From(http.User), uploadId);
            if (!response.IsSuccessStatusCode) { response.Dispose(); return Results.NotFound(); }
            http.Response.RegisterForDispose(response);
            http.Response.Headers.CacheControl = "no-store";
            var type = response.Content.Headers.ContentType?.ToString() ?? "application/octet-stream";
            return Results.Stream(await response.Content.ReadAsStreamAsync(), type);
        }).RequireAuthorization(WebAuthSetup.ReviewerPolicy);
    }
}
