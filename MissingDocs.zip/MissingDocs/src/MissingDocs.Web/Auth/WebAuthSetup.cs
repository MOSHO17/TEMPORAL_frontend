using System.Net.Http.Headers;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.Identity.Web;

namespace MissingDocs.Web.Auth;

/// <summary>
/// Staff sign-in. Production: Entra ID / Azure AD (OpenID Connect) with app roles
/// DocReview.Reviewer and DocReview.SalesRM. Development: a local cookie sign-in at /dev/login.
/// </summary>
public static class WebAuthSetup
{
    public const string ReviewerPolicy = "Reviewer";

    public static bool UseEntra(IConfiguration config) => !string.IsNullOrWhiteSpace(config["AzureAd:ClientId"]);

    public static void AddPortalAuthentication(this WebApplicationBuilder builder)
    {
        var config = builder.Configuration;
        if (UseEntra(config))
        {
            builder.Services.AddAuthentication(OpenIdConnectDefaults.AuthenticationScheme)
                .AddMicrosoftIdentityWebApp(config.GetSection("AzureAd"))
                .EnableTokenAcquisitionToCallDownstreamApi()
                .AddInMemoryTokenCaches();
            builder.Services.AddAuthorizationBuilder()
                .AddPolicy(ReviewerPolicy, p => p.RequireRole("DocReview.Reviewer", "DocReview.SalesRM"));
        }
        else
        {
            if (!builder.Environment.IsDevelopment())
                throw new InvalidOperationException("AzureAd must be configured outside Development.");

            builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
                .AddCookie(o => { o.LoginPath = "/dev/login"; o.Cookie.Name = "md_staff"; });
            builder.Services.AddAuthorizationBuilder()
                .AddPolicy(ReviewerPolicy, p => p.RequireAuthenticatedUser());
        }

        builder.Services.AddCascadingAuthenticationState();
        builder.Services.AddTransient<ApiAuthHandler>();
    }

    /// <summary>Development-only sign-in as a fixed reviewer.</summary>
    public static void MapDevLogin(this WebApplication app)
    {
        if (UseEntra(app.Configuration) || !app.Environment.IsDevelopment()) return;

        app.MapGet("/dev/login", async (HttpContext http, string? returnUrl) =>
        {
            var identity = new ClaimsIdentity(new[]
            {
                new Claim(ClaimTypes.NameIdentifier, "dev.reviewer"),
                new Claim(ClaimTypes.Name, "Dev Reviewer"),
            }, CookieAuthenticationDefaults.AuthenticationScheme);
            await http.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));
            return Results.LocalRedirect(string.IsNullOrEmpty(returnUrl) || !returnUrl.StartsWith('/') ? "/review" : returnUrl);
        });
    }
}

/// <summary>
/// Adds the portal's own credentials to calls to the review API:
/// an Entra app token (client credentials, app role Portal.Backend) or the dev API key.
/// </summary>
public sealed class ApiAuthHandler(IConfiguration config, IServiceProvider services) : DelegatingHandler
{
    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
    {
        if (WebAuthSetup.UseEntra(config))
        {
            var tokens = services.GetRequiredService<ITokenAcquisition>();
            var token = await tokens.GetAccessTokenForAppAsync(config["Api:Scope"]!);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }
        else
        {
            request.Headers.Add("X-Api-Key", config["Api:DevApiKey"]);
        }
        return await base.SendAsync(request, ct);
    }
}
