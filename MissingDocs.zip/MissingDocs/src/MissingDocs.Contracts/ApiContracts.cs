namespace MissingDocs.Contracts;

// ======================= Customer portal =======================

/// <summary>Shown before OTP: deliberately minimal (no full name, masked mobile).</summary>
public sealed record CustomerLinkSummaryDto(bool LinkValid, string? FirstName, string? MaskedMobile, string? AgreementNoMasked);

public sealed record OtpVerifyRequest(string Code);

public sealed record OtpVerifyResponse(bool Verified, string? SessionToken, DateTimeOffset? ExpiresAt, string? Message);

public sealed record CustomerDocumentDto(
    string DocTypeCode,
    string DisplayName,
    string CustomerHint,
    string CustomerStatus,      // Pending | Under review | Verified | Re-upload needed | Expired
    bool CanUpload,
    string? Reason,
    string? LastFileName,
    DateTimeOffset? LastUploadedAt);

public sealed record CustomerDocumentsDto(
    string AgreementNo,
    string FirstName,
    string LoanTypeName,
    int Uploaded,
    int Total,
    IReadOnlyList<CustomerDocumentDto> Documents);

public sealed record UploadResultDto(bool Accepted, string Message);

// ======================= Branch review portal =======================

public sealed record PagedResult<T>(IReadOnlyList<T> Items, int Total, int Page, int PageSize);

public sealed record CaseListItemDto(
    string AgreementNo,
    string CustomerName,
    string LoanType,
    string Branch,
    CaseStatus Status,
    DateTimeOffset OpenedAt,
    int TotalDocs,
    int Approved,
    int WithBank,
    int WithAi,
    int WithCustomer);

public sealed record CaseDetailDto(
    string AgreementNo,
    string CustomerName,
    string MaskedMobile,
    string LoanType,
    string? VehicleRegNo,
    string? ChassisNo,
    string Branch,
    CaseStatus Status,
    DateTimeOffset OpenedAt,
    DateTimeOffset? LinkSentAt,
    IReadOnlyList<CaseDocumentDto> Documents);

public sealed record CaseDocumentDto(
    long CaseDocumentId,
    string DocTypeCode,
    string DisplayName,
    DocumentStatus Status,
    string PendingWith,           // Customer | AI / OCR | Bank reviewer | -
    DateTimeOffset? PendingSince,
    decimal? MatchScore,
    int Attempts,
    long? LatestUploadId,
    string? LatestFileName,
    string? LatestContentType,
    string? LastReason,
    IReadOnlyList<StageDto> Stages,
    IReadOnlyList<FieldMatchDto> Fields);

/// <summary>State is one of: done | current | todo | failed.</summary>
public sealed record StageDto(string Name, string State, DateTimeOffset? At);

public sealed record FieldMatchDto(string Field, string? Expected, string? Extracted, decimal Score, string Result);

public sealed record ReviewDecisionRequest(long UploadId, ReviewOutcome Outcome, string? Reason);

public sealed record DocumentTypeRuleDto(
    string DocTypeCode,
    string DisplayName,
    string? AzureModelId,
    string MatchFields,
    decimal AutoAcceptThreshold,
    IReadOnlyList<string> RequiredForLoanTypes);
