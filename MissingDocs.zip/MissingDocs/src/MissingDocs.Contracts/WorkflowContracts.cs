namespace MissingDocs.Contracts;

/// <summary>Names shared by the Temporal worker, the API (which sends signals) and the sync service.</summary>
public static class WorkflowConstants
{
    public const string TaskQueue = "missing-docs";

    public const string CaseWorkflowType = "AgreementCaseWorkflow";
    public const string DocumentWorkflowType = "DocumentWorkflow";

    public const string UploadReceivedSignal = "UploadReceived";
    public const string ReviewDecisionSignal = "ReviewDecision";

    /// <summary>Includes the case id so a later case for the same agreement never collides with a closed one.</summary>
    public static string CaseWorkflowId(string agreementNo, long caseId) => $"case-{agreementNo}-{caseId}";

    public static string DocumentWorkflowId(string agreementNo, long caseId, string docTypeCode) =>
        $"case-{agreementNo}-{caseId}-doc-{docTypeCode}";
}

/// <summary>Lifecycle of one missing document (one child workflow).</summary>
public enum DocumentStatus
{
    AwaitingUpload = 0,
    Uploaded = 1,
    AiReview = 2,
    AwaitingReview = 3,
    ReuploadRequested = 4,
    Approved = 5,
    Expired = 6,
}

/// <summary>Lifecycle of an agreement-level case (parent workflow).</summary>
public enum CaseStatus
{
    Open = 0,
    Completed = 1,
    Expired = 2,
}

/// <summary>How much the AI is trusted. Moves forward only after the accuracy gate is passed.</summary>
public enum AiMode
{
    /// <summary>AI scores every document; staff still review everything. Used to measure accuracy.</summary>
    Shadow = 0,

    /// <summary>Staff review everything, queue sorted by match % with mismatches highlighted.</summary>
    Assisted = 1,

    /// <summary>High-confidence documents are approved automatically, except a random audit sample.</summary>
    AutoAccept = 2,
}

public enum ReviewOutcome
{
    Approve = 0,
    RequestReupload = 1,
}

// ---------- Workflow inputs / outputs / signals (serialised by Temporal as JSON) ----------

public sealed record CaseWorkflowInput(
    long CaseId,
    string AgreementNo,
    IReadOnlyList<MissingDocumentInput> Documents,
    int ReminderIntervalHours,
    int MaxReminders,
    int UploadWindowHours,
    int ReviewSlaHours);

public sealed record MissingDocumentInput(long CaseDocumentId, string DocTypeCode);

public sealed record DocumentWorkflowInput(
    long CaseId,
    string AgreementNo,
    long CaseDocumentId,
    string DocTypeCode,
    int UploadWindowHours,
    int ReviewSlaHours);

public sealed record DocumentWorkflowResult(long CaseDocumentId, string DocTypeCode, DocumentStatus FinalStatus, int Attempts);

public sealed record CaseWorkflowResult(long CaseId, CaseStatus FinalStatus, int Approved, int Expired);

public sealed record UploadReceivedSignal(long UploadId);

public sealed record ReviewDecisionSignal(long UploadId, ReviewOutcome Outcome, string? Reason, string ReviewerId);

public sealed record QualityCheckResult(bool Passed, string? Reason);

public sealed record AiAssessment(
    long UploadId,
    decimal MatchScore,
    bool TypeMatched,
    string? ClassifiedType,
    AiMode Mode,
    decimal AutoAcceptThreshold,
    double AuditSampleRate);
