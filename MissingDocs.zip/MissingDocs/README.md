# Missing Document Automation

Collects missing loan documents from customers after disbursal and verifies them with AI, cutting a 7+ day
branch / sales follow-up loop to about one day. This is the reference implementation of the
"Technical architecture: solution stack" slide.

| Layer | Technology | Project |
|---|---|---|
| Customer upload portal | Blazor Web App, static server rendering (no websocket, no JS framework) | `MissingDocs.Web` |
| Branch review portal | Blazor Interactive Server, Entra ID / AD sign-in | `MissingDocs.Web` |
| APIs | ASP.NET Core minimal APIs (.NET 10) | `MissingDocs.Api` |
| Orchestration | Temporal (.NET SDK): parent workflow per agreement, child workflow per document | `MissingDocs.Workflows` |
| OCR / document AI | Azure AI Document Intelligence (India region) + .NET match engine | `MissingDocs.Infrastructure`, `MissingDocs.Core` |
| Database | SQL Server 2019+ (application data, audit log) | `db/*.sql` |
| Documents | Azure Blob Storage (or the bank DMS) | `MissingDocs.Infrastructure` |
| Core system | Finnone extract (staging tables) in, status outbox out | `db/003_finnone_staging.sql` |

> **Temporal and SQL Server:** Temporal Server cannot use SQL Server for its own persistence (supported:
> PostgreSQL, MySQL, Cassandra). Run Temporal on PostgreSQL or use Temporal Cloud; all *application* data
> stays in SQL Server.

---

## How it works

```
Finnone extract (stg.FinnoneAgreementDocs, one column per document type)
   │  every 30 min: FinnoneSyncService → dbo.usp_GetAgreementsWithMissingDocs
   ▼     (rule matrix per loan type − received = missing list; 2W = 5 docs, 4W = 10)
MissingDocCase + CaseDocument rows ──► start AgreementCaseWorkflow (parent, one per agreement)
   │   1. SMS / WhatsApp with a secure link listing all missing documents
   │   2. one DocumentWorkflow (child) per missing document, in parallel
   │   3. case-level reminders while anything is still with the customer
   │   4. when every child has finished → write status to stg.DocStatusOutbound, close case
   ▼
DocumentWorkflow (child) loop:
   wait for upload (signal from API) ─► image quality check ─► Azure OCR + match % ─►
   ├─ AutoAccept mode, score ≥ threshold, not in 5% audit sample → approved
   └─ otherwise wait for reviewer decision (signal) → approve | re-upload with reason (loop)
   Upload window lapses → Expired → branch follow-up.  AI unavailable → manual review.
```

Customer access: link token (only its SHA-256 hash is stored, expires, revoked on close) → OTP to the
registered mobile → 30-minute encrypted session. The page before OTP shows only first name and masked mobile.

AI trust levels (`Ai:Mode`): `Shadow` (AI scores, staff check everything) → `Assisted` (queue sorted by match %)
→ `AutoAccept` (high-confidence documents pass, a random sample is still checked). Move up only after the
accuracy gate is signed off. Every AI score, model id, mode and decision is stored for accuracy reporting.

---

## Solution layout

```
db/                       SQL Server scripts (run in order)
deploy/docker-compose.yml SQL Server + Temporal for local development
src/
  MissingDocs.Contracts   DTOs, workflow inputs/signals, enums (no dependencies)
  MissingDocs.Core        Entities, interfaces, MatchEngine (fuzzy name / ID / address matching), options
  MissingDocs.Infrastructure
                          EF Core DbContext, Azure Document Intelligence, Blob/local store,
                          SkiaSharp image quality check, SMS/WhatsApp sender, Finnone gateway,
                          link tokens, OTP
  MissingDocs.Workflows   Temporal worker host: AgreementCaseWorkflow, DocumentWorkflow,
                          CaseActivities, DocumentActivities, FinnoneSyncService
  MissingDocs.Api         Customer endpoints (/api/customer), review endpoints (/api/review), admin
  MissingDocs.Web         Blazor: /u/{token} customer page, /review list, /review/{agreementNo}
tests/MissingDocs.Core.Tests   xUnit tests for the match engine
docs/screenshots/         Portal pages rendered from this code (against sample data)
```

---

## Run locally

Prerequisites: .NET 10 SDK, Docker, SQL tooling (sqlcmd / SSMS / Azure Data Studio).

```bash
# 1. Dependencies (SQL Server + Temporal dev server with UI on http://localhost:8233)
docker compose -f deploy/docker-compose.yml --profile dev up -d

# 2. Database
sqlcmd -S localhost,1433 -U sa -P 'Your_strong_Passw0rd' -C -Q "CREATE DATABASE MissingDocs"
for f in db/001_schema.sql db/002_reference_data.sql db/003_finnone_staging.sql db/004_sample_data.sql; do
  sqlcmd -S localhost,1433 -U sa -P 'Your_strong_Passw0rd' -C -d MissingDocs -i "$f"; done

# 3. Run the three processes (separate terminals)
dotnet run --project src/MissingDocs.Workflows     # worker + Finnone sync (creates cases for AG1001, AG1002)
dotnet run --project src/MissingDocs.Api           # https://localhost:7100
dotnet run --project src/MissingDocs.Web           # https://localhost:7180/review  (dev sign-in)

# 4. Tests
dotnet test
```

In Development: SMS messages (with the upload link and OTP) are written to the worker / API log, uploads go
to `./_uploads`, and with no Azure endpoint configured OCR returns nothing so every document goes to the
reviewer. Open the link from the log on a phone-sized browser to try the customer flow.

---

## Configuration

| Section | Key settings |
|---|---|
| `ConnectionStrings:MissingDocs` | SQL Server. Use Managed Identity / integrated auth in production. |
| `Temporal` | `Address`, `Namespace`. Add mTLS for production clusters. |
| `Case` | `PortalBaseUrl`, `LinkValidDays`, `ReminderIntervalHours`, `MaxReminders`, `UploadWindowHours`, `ReviewSlaHours`, `SyncIntervalMinutes` |
| `Ai` | `Mode` (Shadow / Assisted / AutoAccept), `AuditSampleRate` |
| `AzureDocumentIntelligence` | `Endpoint` (India region), `ApiKey` or Managed Identity, `ClassifierId` (custom classifier) |
| `DocumentStore` | `Provider` Blob / Local, `BlobServiceUri`, `Container` |
| `Notifications` | `Provider` Http / Log, gateway `BaseUrl`, `ApiKey`, `SenderId`, message `Templates`, `DltTemplateIds` |
| `Otp` | length, validity, attempt limits, `Pepper` (keep in Key Vault) |
| `AzureAd` (Api, Web) | Entra ID app registrations; Web needs `Api:Scope` for the app-to-app token |
| `Gateway:KnownProxies` (Api) | IPs of the API gateway **and the Web server**, so rate limiting sees the customer IP |
| `DataProtection:KeyPath` (Api) | Shared key ring location when running more than one API instance |

Per document type (table `dbo.DocumentType`): display name, customer hint, Azure model id (start with
`prebuilt-read`, move to trained custom extraction models), classifier label, fields to match and the
auto-accept threshold. Loan-type rules live in `dbo.LoanTypeDocumentRule`.

---

## Production checklist

- **Identity:** register Web (OIDC, app roles `DocReview.Reviewer`, `DocReview.SalesRM`) and Api
  (app role `Portal.Backend` granted to the Web app). Without `AzureAd:ClientId` both apps refuse to start outside Development.
- **Azure:** Document Intelligence and Blob in an India region with private endpoints; train a custom classifier
  and extraction models on real (masked) samples; never send full Aadhaar numbers (mask before upload / use masked copies).
- **Temporal:** cluster on PostgreSQL (or Temporal Cloud) with mTLS; run 2+ worker replicas; set `Case:SyncEnabled`
  to `true` on one replica only (the unique open-case index also protects against duplicates).
- **SMS / WhatsApp:** register templates on DLT; template text in config must match exactly.
- **Finnone:** point the existing extract job at `stg.FinnoneAgreementDocs`; have the update job read
  `stg.DocStatusOutbound` and set `PickedAt`. Document columns in the staging table must match `DocTypeCode`s.
- **Security review:** WAF in front of `/u/*` and `/api/customer/*`, antivirus scan of uploads (hook in
  `UploadService` before `store.SaveAsync`), TDE on SQL Server, log masking, penetration test of the customer flow.
- **Accuracy gate:** run in `Shadow` mode during the pilot; report agreement between AI score and reviewer
  decisions from `dbo.OcrResult` + `dbo.ReviewDecision` before switching modes.

---

## Verification status of this code

| Part | Status |
|---|---|
| `Contracts`, `Core` (incl. match engine) | Compiled; match-engine tests run and pass (7/7) |
| `Web` (Blazor) | Compiled and run against a stand-in API; pages in `docs/screenshots` are real renders |
| `Infrastructure`, `Workflows`, `Api` | Written against the published APIs of EF Core 10, Temporalio .NET, Azure.AI.DocumentIntelligence 1.x, Azure.Storage.Blobs, SkiaSharp 3 and Microsoft.Identity.Web, but **not compiled here** (no NuGet access in the build environment). Expect minor fixes on first `dotnet build`. |
| SQL scripts | Reviewed, not executed here |

Package versions are pinned centrally in `Directory.Packages.props`; update them to the bank-approved latest
versions before the first build.
