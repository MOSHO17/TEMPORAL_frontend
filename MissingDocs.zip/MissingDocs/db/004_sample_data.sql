/* DEV ONLY: two agreements as they would arrive from the Finnone extract. */
SET NOCOUNT ON;
DELETE FROM stg.FinnoneAgreementDocs WHERE AgreementNo IN ('AG1001','AG1002');

INSERT stg.FinnoneAgreementDocs
 (AgreementNo, LoanType, CustomerName, MobileNo, Address, VehicleRegNo, ChassisNo, EngineNo, Branch, DisbursedOn,
  RC, INSURANCE, INVOICE, KYC, NACH, ADDRESS_PROOF, HYPOTHECATION, FORM_34, DELIVERY_ORDER, BANK_STATEMENT)
VALUES
 -- 2W: RC, Insurance and Invoice missing -> 3 child workflows
 ('AG1001','2W',N'Ramesh Kumar','9876543221',N'12 Main Road, Hadapsar, Pune 411028','MH12AB1234','ME4JF505KLT123456','JF50ET1234567',N'Pune - Hadapsar','2026-09-28',
  'N','N','N','Y','Y', NULL,NULL,NULL,NULL,NULL),
 -- 4W: four documents missing -> 4 child workflows
 ('AG1002','4W',N'Suresh Patil','9822004521',N'Flat 4, Kothrud, Pune 411038','MH12XY9876','MA3EWB22S00123456','K12MN1234567',N'Pune - Kothrud','2026-09-12',
  'Y','N','N','Y','Y','Y','N','Y','Y','N');
GO
