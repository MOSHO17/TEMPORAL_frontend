/* Document types and the loan-type rule matrix.
   2W needs 5 documents, 4W needs 10. Adjust codes to match Finnone column names. */
SET NOCOUNT ON;

MERGE dbo.DocumentType AS t
USING (VALUES
 ('RC',             N'RC Copy',               N'Front and back; hypothecation must be visible',          'RC',            'prebuilt-read', 'CustomerName,VehicleRegNo,ChassisNo,EngineNo', 92),
 ('INSURANCE',      N'Insurance Policy',      N'All pages; vehicle number and name clearly visible',      'INSURANCE',     'prebuilt-read', 'CustomerName,VehicleRegNo,ChassisNo',          90),
 ('INVOICE',        N'Dealer Invoice',        N'Original invoice with chassis and engine number',         'INVOICE',       'prebuilt-read', 'CustomerName,ChassisNo,EngineNo,Address',      90),
 ('KYC',            N'KYC / Photo ID',        N'Aadhaar (masked) or PAN; name must be readable',          'KYC',           'prebuilt-read', 'CustomerName',                                  95),
 ('NACH',           N'NACH Mandate',          N'Signed mandate with account holder name',                 'NACH',          'prebuilt-read', 'CustomerName,AgreementNo',                      92),
 ('ADDRESS_PROOF',  N'Address Proof',         N'Utility bill or ration card, last 3 months',              'ADDRESS_PROOF', 'prebuilt-read', 'CustomerName,Address',                          90),
 ('HYPOTHECATION',  N'Hypothecation Letter',  N'Signed letter with agreement number',                     'HYPOTHECATION', 'prebuilt-read', 'CustomerName,AgreementNo,ChassisNo',            92),
 ('FORM_34',        N'Form 34',               N'RTO Form 34 with bank endorsement',                       'FORM_34',       'prebuilt-read', 'CustomerName,ChassisNo,EngineNo',               92),
 ('DELIVERY_ORDER', N'Delivery Order',        N'Dealer delivery order / gate pass',                       'DELIVERY_ORDER','prebuilt-read', 'CustomerName,ChassisNo',                        90),
 ('BANK_STATEMENT', N'Bank Statement',        N'Last 3 months, all pages',                                'BANK_STATEMENT','prebuilt-read', 'CustomerName,Address',                          90)
) AS s (DocTypeCode, DisplayName, CustomerHint, ClassifierLabel, AzureModelId, MatchFields, AutoAcceptThreshold)
ON t.DocTypeCode = s.DocTypeCode
WHEN MATCHED THEN UPDATE SET DisplayName = s.DisplayName, CustomerHint = s.CustomerHint, ClassifierLabel = s.ClassifierLabel,
     AzureModelId = s.AzureModelId, MatchFields = s.MatchFields, AutoAcceptThreshold = s.AutoAcceptThreshold
WHEN NOT MATCHED THEN INSERT (DocTypeCode, DisplayName, CustomerHint, ClassifierLabel, AzureModelId, MatchFields, AutoAcceptThreshold)
     VALUES (s.DocTypeCode, s.DisplayName, s.CustomerHint, s.ClassifierLabel, s.AzureModelId, s.MatchFields, s.AutoAcceptThreshold);

MERGE dbo.LoanTypeDocumentRule AS t
USING (VALUES
 ('2W','RC',1),('2W','INSURANCE',2),('2W','INVOICE',3),('2W','KYC',4),('2W','NACH',5),
 ('4W','RC',1),('4W','INSURANCE',2),('4W','INVOICE',3),('4W','KYC',4),('4W','NACH',5),
 ('4W','ADDRESS_PROOF',6),('4W','HYPOTHECATION',7),('4W','FORM_34',8),('4W','DELIVERY_ORDER',9),('4W','BANK_STATEMENT',10)
) AS s (LoanType, DocTypeCode, SortOrder)
ON t.LoanType = s.LoanType AND t.DocTypeCode = s.DocTypeCode
WHEN MATCHED THEN UPDATE SET SortOrder = s.SortOrder, IsMandatory = 1
WHEN NOT MATCHED THEN INSERT (LoanType, DocTypeCode, IsMandatory, SortOrder) VALUES (s.LoanType, s.DocTypeCode, 1, s.SortOrder);
GO
