/* =====================================================================
   Finnone integration layer.
   Finnone (Oracle) is NOT queried directly by the application. The bank's
   existing extract job lands agreement rows in stg.FinnoneAgreementDocs,
   one column per document type ('Y' = received), exactly like the Finnone
   report. The app reads the unpivoted view and writes status back to
   stg.DocStatusOutbound for the Finnone/DMS update job to pick up.
   ===================================================================== */
SET XACT_ABORT ON;
GO

CREATE TABLE stg.FinnoneAgreementDocs
(
    AgreementNo     varchar(30)   NOT NULL CONSTRAINT PK_FinnoneAgreementDocs PRIMARY KEY,
    LoanType        varchar(10)   NOT NULL,
    CustomerName    nvarchar(150) NOT NULL,
    MobileNo        varchar(15)   NOT NULL,
    Address         nvarchar(400) NULL,
    VehicleRegNo    varchar(20)   NULL,
    ChassisNo       varchar(30)   NULL,
    EngineNo        varchar(30)   NULL,
    Branch          nvarchar(100) NOT NULL,
    DisbursedOn     date          NULL,
    -- one column per document type (column header = document type)
    RC              char(1) NULL,
    INSURANCE       char(1) NULL,
    INVOICE         char(1) NULL,
    KYC             char(1) NULL,
    NACH            char(1) NULL,
    ADDRESS_PROOF   char(1) NULL,
    HYPOTHECATION   char(1) NULL,
    FORM_34         char(1) NULL,
    DELIVERY_ORDER  char(1) NULL,
    BANK_STATEMENT  char(1) NULL,
    ExtractedAt     datetimeoffset(3) NOT NULL CONSTRAINT DF_FinnoneDocs_Extracted DEFAULT (SYSDATETIMEOFFSET())
);
GO

/* Unpivot: one row per agreement + document type, Received = 1 when 'Y'. */
CREATE OR ALTER VIEW stg.vw_FinnoneDocStatus
AS
SELECT u.AgreementNo, u.DocTypeCode, CAST(CASE WHEN u.Flag = 'Y' THEN 1 ELSE 0 END AS bit) AS Received
FROM
(
    SELECT AgreementNo,
           ISNULL(RC,'N') AS RC, ISNULL(INSURANCE,'N') AS INSURANCE, ISNULL(INVOICE,'N') AS INVOICE,
           ISNULL(KYC,'N') AS KYC, ISNULL(NACH,'N') AS NACH, ISNULL(ADDRESS_PROOF,'N') AS ADDRESS_PROOF,
           ISNULL(HYPOTHECATION,'N') AS HYPOTHECATION, ISNULL(FORM_34,'N') AS FORM_34,
           ISNULL(DELIVERY_ORDER,'N') AS DELIVERY_ORDER, ISNULL(BANK_STATEMENT,'N') AS BANK_STATEMENT
    FROM stg.FinnoneAgreementDocs
) AS p
UNPIVOT (Flag FOR DocTypeCode IN (RC, INSURANCE, INVOICE, KYC, NACH, ADDRESS_PROOF, HYPOTHECATION, FORM_34, DELIVERY_ORDER, BANK_STATEMENT)) AS u;
GO

/* Agreements that have at least one mandatory document missing and no case yet.
   Required (rule matrix for the loan type) minus Received = Missing list. */
CREATE OR ALTER PROCEDURE dbo.usp_GetAgreementsWithMissingDocs
    @MaxRows int = 500
AS
BEGIN
    SET NOCOUNT ON;

    WITH Missing AS
    (
        SELECT a.AgreementNo, r.DocTypeCode, r.SortOrder
        FROM stg.FinnoneAgreementDocs a
        JOIN dbo.LoanTypeDocumentRule r ON r.LoanType = a.LoanType AND r.IsMandatory = 1
        JOIN dbo.DocumentType d ON d.DocTypeCode = r.DocTypeCode AND d.IsActive = 1
        LEFT JOIN stg.vw_FinnoneDocStatus s ON s.AgreementNo = a.AgreementNo AND s.DocTypeCode = r.DocTypeCode
        WHERE ISNULL(s.Received, 0) = 0
          AND NOT EXISTS (SELECT 1 FROM dbo.MissingDocCase c WHERE c.AgreementNo = a.AgreementNo)
    )
    SELECT TOP (@MaxRows)
           a.AgreementNo, a.LoanType, a.CustomerName, a.MobileNo, a.Address, a.VehicleRegNo,
           a.ChassisNo, a.EngineNo, a.Branch,
           STRING_AGG(CAST(m.DocTypeCode AS varchar(max)), ',') WITHIN GROUP (ORDER BY m.SortOrder) AS MissingDocTypeCodes
    FROM stg.FinnoneAgreementDocs a
    JOIN Missing m ON m.AgreementNo = a.AgreementNo
    GROUP BY a.AgreementNo, a.LoanType, a.CustomerName, a.MobileNo, a.Address, a.VehicleRegNo, a.ChassisNo, a.EngineNo, a.Branch, a.ExtractedAt
    ORDER BY a.ExtractedAt;
END
GO

/* Outbox read by the Finnone / DMS update job. */
CREATE TABLE stg.DocStatusOutbound
(
    OutboundId   bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_DocStatusOutbound PRIMARY KEY,
    AgreementNo  varchar(30)   NOT NULL,
    DocTypeCode  varchar(30)   NOT NULL,
    Status       varchar(20)   NOT NULL,      -- Approved | Expired
    StoragePath  varchar(400)  NULL,
    CreatedAt    datetimeoffset(3) NOT NULL CONSTRAINT DF_Outbound_Created DEFAULT (SYSDATETIMEOFFSET()),
    PickedAt     datetimeoffset(3) NULL
);
CREATE UNIQUE INDEX UX_DocStatusOutbound ON stg.DocStatusOutbound (AgreementNo, DocTypeCode, Status);
GO
