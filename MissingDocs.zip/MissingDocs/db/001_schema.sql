/* =====================================================================
   Missing Document Automation - application database (SQL Server 2019+)
   Run in order: 001_schema.sql, 002_reference_data.sql,
                 003_finnone_staging.sql, 004_sample_data.sql (dev only)
   ===================================================================== */
SET XACT_ABORT ON;
GO
IF SCHEMA_ID('stg') IS NULL EXEC('CREATE SCHEMA stg');
GO

/* ---------- Reference data ---------- */

CREATE TABLE dbo.DocumentType
(
    DocTypeCode          varchar(30)    NOT NULL CONSTRAINT PK_DocumentType PRIMARY KEY,
    DisplayName          nvarchar(100)  NOT NULL,
    CustomerHint         nvarchar(200)  NOT NULL CONSTRAINT DF_DocumentType_Hint DEFAULT (N''),
    ClassifierLabel      varchar(50)    NULL,        -- label returned by the Azure custom classifier
    AzureModelId         varchar(100)   NOT NULL CONSTRAINT DF_DocumentType_Model DEFAULT ('prebuilt-read'),
    MatchFields          varchar(200)   NOT NULL,    -- CustomerName,AgreementNo,VehicleRegNo,ChassisNo,EngineNo,Address
    AutoAcceptThreshold  decimal(5,2)   NOT NULL CONSTRAINT DF_DocumentType_Auto DEFAULT (90),
    IsActive             bit            NOT NULL CONSTRAINT DF_DocumentType_Active DEFAULT (1)
);

CREATE TABLE dbo.LoanTypeDocumentRule
(
    LoanType     varchar(10)  NOT NULL,             -- 2W, 4W ...
    DocTypeCode  varchar(30)  NOT NULL CONSTRAINT FK_Rule_DocType REFERENCES dbo.DocumentType (DocTypeCode),
    IsMandatory  bit          NOT NULL CONSTRAINT DF_Rule_Mandatory DEFAULT (1),
    SortOrder    int          NOT NULL CONSTRAINT DF_Rule_Sort DEFAULT (0),
    CONSTRAINT PK_LoanTypeDocumentRule PRIMARY KEY (LoanType, DocTypeCode)
);

/* ---------- Case (one per agreement) ---------- */

CREATE TABLE dbo.MissingDocCase
(
    CaseId        bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_MissingDocCase PRIMARY KEY,
    AgreementNo   varchar(30)     NOT NULL,
    LoanType      varchar(10)     NOT NULL,
    CustomerName  nvarchar(150)   NOT NULL,
    MobileNo      varchar(15)     NOT NULL,
    Address       nvarchar(400)   NULL,
    VehicleRegNo  varchar(20)     NULL,
    ChassisNo     varchar(30)     NULL,
    EngineNo      varchar(30)     NULL,
    Branch        nvarchar(100)   NOT NULL,
    Status        varchar(20)     NOT NULL CONSTRAINT DF_Case_Status DEFAULT ('Open'),  -- Open | Completed | Expired
    WorkflowId    varchar(100)    NOT NULL,
    CreatedAt     datetimeoffset(3) NOT NULL CONSTRAINT DF_Case_Created DEFAULT (SYSDATETIMEOFFSET()),
    LinkSentAt    datetimeoffset(3) NULL,
    WorkflowStartedAt datetimeoffset(3) NULL,   -- NULL = workflow start still pending (retried by sync)
    ClosedAt      datetimeoffset(3) NULL
);
-- One open case per agreement at a time.
CREATE UNIQUE INDEX UX_MissingDocCase_Agreement_Open ON dbo.MissingDocCase (AgreementNo) WHERE Status = 'Open';
CREATE INDEX IX_MissingDocCase_Status ON dbo.MissingDocCase (Status, CreatedAt DESC) INCLUDE (AgreementNo, CustomerName, LoanType, Branch);

/* ---------- One row per missing document (one child workflow) ---------- */

CREATE TABLE dbo.CaseDocument
(
    CaseDocumentId   bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_CaseDocument PRIMARY KEY,
    CaseId           bigint        NOT NULL CONSTRAINT FK_CaseDocument_Case REFERENCES dbo.MissingDocCase (CaseId),
    DocTypeCode      varchar(30)   NOT NULL CONSTRAINT FK_CaseDocument_DocType REFERENCES dbo.DocumentType (DocTypeCode),
    Status           varchar(20)   NOT NULL,   -- AwaitingUpload | Uploaded | AiReview | AwaitingReview | ReuploadRequested | Approved | Expired
    Attempts         int           NOT NULL CONSTRAINT DF_CaseDocument_Attempts DEFAULT (0),
    MatchScore       decimal(5,2)  NULL,
    LastReason       nvarchar(300) NULL,
    WorkflowId       varchar(120)  NOT NULL,
    StatusChangedAt  datetimeoffset(3) NOT NULL CONSTRAINT DF_CaseDocument_Changed DEFAULT (SYSDATETIMEOFFSET()),
    ApprovedAt       datetimeoffset(3) NULL,
    RowVersion       rowversion    NOT NULL,
    CONSTRAINT UX_CaseDocument_Case_Type UNIQUE (CaseId, DocTypeCode)
);
CREATE INDEX IX_CaseDocument_Status ON dbo.CaseDocument (Status, StatusChangedAt) INCLUDE (CaseId, DocTypeCode, MatchScore);

/* ---------- Uploads, OCR and matching ---------- */

CREATE TABLE dbo.DocumentUpload
(
    UploadId        bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_DocumentUpload PRIMARY KEY,
    CaseDocumentId  bigint         NOT NULL CONSTRAINT FK_Upload_CaseDocument REFERENCES dbo.CaseDocument (CaseDocumentId),
    Attempt         int            NOT NULL,
    StoragePath     varchar(400)   NOT NULL,
    FileName        nvarchar(260)  NOT NULL,
    ContentType     varchar(100)   NOT NULL,
    SizeBytes       bigint         NOT NULL,
    Sha256          char(64)       NOT NULL,
    UploadedBy      varchar(50)    NOT NULL,   -- CUSTOMER or staff id (assisted upload)
    UploadedAt      datetimeoffset(3) NOT NULL CONSTRAINT DF_Upload_At DEFAULT (SYSDATETIMEOFFSET()),
    QualityPassed   bit            NULL,
    QualityNote     nvarchar(300)  NULL
);
CREATE INDEX IX_DocumentUpload_CaseDocument ON dbo.DocumentUpload (CaseDocumentId, Attempt DESC);

CREATE TABLE dbo.OcrResult
(
    OcrResultId           bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_OcrResult PRIMARY KEY,
    UploadId              bigint        NOT NULL CONSTRAINT FK_Ocr_Upload REFERENCES dbo.DocumentUpload (UploadId),
    ClassifiedType        varchar(50)   NULL,
    ClassifierConfidence  decimal(5,4)  NULL,
    ModelId               varchar(100)  NOT NULL,
    ExtractedText         nvarchar(max) NOT NULL,
    FieldsJson            nvarchar(max) NOT NULL,
    MatchScore            decimal(5,2)  NOT NULL,
    TypeMatched           bit           NOT NULL,
    AiMode                varchar(20)   NOT NULL,   -- Shadow | Assisted | AutoAccept (for accuracy reporting)
    CreatedAt             datetimeoffset(3) NOT NULL CONSTRAINT DF_Ocr_At DEFAULT (SYSDATETIMEOFFSET()),
    CONSTRAINT UX_OcrResult_Upload UNIQUE (UploadId)   -- makes the OCR activity idempotent on retry
);

CREATE TABLE dbo.FieldMatch
(
    FieldMatchId    bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_FieldMatch PRIMARY KEY,
    UploadId        bigint        NOT NULL CONSTRAINT FK_FieldMatch_Upload REFERENCES dbo.DocumentUpload (UploadId),
    FieldName       varchar(50)   NOT NULL,
    ExpectedValue   nvarchar(400) NULL,
    ExtractedValue  nvarchar(400) NULL,
    Score           decimal(5,2)  NOT NULL,
    Result          varchar(20)   NOT NULL     -- Match | Partial | Mismatch | NotFound
);
CREATE INDEX IX_FieldMatch_Upload ON dbo.FieldMatch (UploadId);

/* ---------- Human decisions ---------- */

CREATE TABLE dbo.ReviewDecision
(
    ReviewDecisionId  bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_ReviewDecision PRIMARY KEY,
    CaseDocumentId    bigint        NOT NULL CONSTRAINT FK_Decision_CaseDocument REFERENCES dbo.CaseDocument (CaseDocumentId),
    UploadId          bigint        NOT NULL CONSTRAINT FK_Decision_Upload REFERENCES dbo.DocumentUpload (UploadId),
    Outcome           varchar(20)   NOT NULL,  -- Approve | RequestReupload
    Reason            nvarchar(300) NULL,
    DecidedBy         varchar(100)  NOT NULL,  -- staff id or AI-AUTO
    DecidedAt         datetimeoffset(3) NOT NULL CONSTRAINT DF_Decision_At DEFAULT (SYSDATETIMEOFFSET()),
    CONSTRAINT UX_ReviewDecision_Upload UNIQUE (UploadId)   -- one decision per upload, blocks double clicks
);

/* ---------- Customer access ---------- */

CREATE TABLE dbo.CaseLinkToken
(
    TokenHash  char(64)  NOT NULL CONSTRAINT PK_CaseLinkToken PRIMARY KEY,   -- SHA-256 hex of the raw token
    CaseId     bigint    NOT NULL CONSTRAINT FK_LinkToken_Case REFERENCES dbo.MissingDocCase (CaseId),
    IssuedAt   datetimeoffset(3) NOT NULL,
    ExpiresAt  datetimeoffset(3) NOT NULL,
    Revoked    bit       NOT NULL CONSTRAINT DF_LinkToken_Revoked DEFAULT (0)
);
CREATE INDEX IX_CaseLinkToken_Case ON dbo.CaseLinkToken (CaseId);

CREATE TABLE dbo.OtpChallenge
(
    OtpChallengeId  bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_OtpChallenge PRIMARY KEY,
    CaseId          bigint     NOT NULL CONSTRAINT FK_Otp_Case REFERENCES dbo.MissingDocCase (CaseId),
    CodeHash        char(64)   NOT NULL,
    CreatedAt       datetimeoffset(3) NOT NULL,
    ExpiresAt       datetimeoffset(3) NOT NULL,
    FailedAttempts  int        NOT NULL CONSTRAINT DF_Otp_Failed DEFAULT (0),
    VerifiedAt      datetimeoffset(3) NULL
);
CREATE INDEX IX_OtpChallenge_Case ON dbo.OtpChallenge (CaseId, CreatedAt DESC);

/* ---------- Audit ---------- */

CREATE TABLE dbo.AuditLog
(
    AuditId         bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_AuditLog PRIMARY KEY,
    CaseId          bigint        NULL,
    CaseDocumentId  bigint        NULL,
    Actor           varchar(100)  NOT NULL,   -- CUSTOMER | staff id | SYSTEM | AI
    Action          varchar(60)   NOT NULL,
    Detail          nvarchar(1000) NULL,
    At              datetimeoffset(3) NOT NULL CONSTRAINT DF_Audit_At DEFAULT (SYSDATETIMEOFFSET())
);
CREATE INDEX IX_AuditLog_Case ON dbo.AuditLog (CaseId, At);
GO
