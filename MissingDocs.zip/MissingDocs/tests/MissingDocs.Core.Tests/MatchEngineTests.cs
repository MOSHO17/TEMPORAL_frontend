using MissingDocs.Core;
using MissingDocs.Core.Matching;

namespace MissingDocs.Core.Tests;

public class MatchEngineTests
{
    private static readonly IReadOnlyDictionary<string, string> NoFields = new Dictionary<string, string>();

    private static MatchInput Invoice(string text, string? classified = "INVOICE") => new(
        ExpectedDocType: "INVOICE",
        ExpectedClassifierLabel: "INVOICE",
        ClassifiedType: classified,
        Expected: new[]
        {
            new ExpectedField("CustomerName", "Suresh Patil", FieldKind.PersonName, 2m),
            new ExpectedField("ChassisNo", "MA3EWB22S00123456", FieldKind.Identifier, 3m),
            new ExpectedField("Address", "Flat 4, Kothrud, Pune", FieldKind.Address, 1m),
        },
        ExtractedFields: NoFields,
        FullText: text);

    [Fact]
    public void Clean_document_scores_high()
    {
        var outcome = MatchEngine.Evaluate(Invoice(
            "TAX INVOICE Sai Motors Pune. Buyer: SURESH B. PATIL, Flat 4 Kothrud Pune 411038. Chassis No: MA3EWB22S00123456 Engine: K12MN1234567"));

        Assert.True(outcome.TypeMatched);
        Assert.True(outcome.Score >= 95m, $"score was {outcome.Score}");
        Assert.All(outcome.Fields, f => Assert.Equal("Match", f.Result));
    }

    [Fact]
    public void Ocr_misread_in_chassis_number_is_tolerated()
    {
        // O read instead of 0, and one digit wrong.
        var outcome = MatchEngine.Evaluate(Invoice(
            "Buyer SURESH PATIL Kothrud Pune Chassis MA3EWB22SOO123459"));

        var chassis = outcome.Fields.Single(f => f.Field == "ChassisNo");
        Assert.Equal("Partial", chassis.Result);
        Assert.InRange(chassis.Score, 90m, 99.9m);
    }

    [Fact]
    public void Wrong_person_is_flagged()
    {
        var outcome = MatchEngine.Evaluate(Invoice(
            "Buyer RAMESH KUMAR, Hadapsar Pune. Chassis MA3EWB22S00999999"));

        Assert.True(outcome.Score < 60m, $"score was {outcome.Score}");
        Assert.NotEqual("Match", outcome.Fields.Single(f => f.Field == "CustomerName").Result);
    }

    [Fact]
    public void Wrong_document_type_is_penalised()
    {
        var right = MatchEngine.Evaluate(Invoice("SURESH PATIL Kothrud Pune MA3EWB22S00123456"));
        var wrong = MatchEngine.Evaluate(Invoice("SURESH PATIL Kothrud Pune MA3EWB22S00123456", classified: "INSURANCE"));

        Assert.False(wrong.TypeMatched);
        Assert.True(wrong.Score < right.Score * 0.5m);
    }

    [Fact]
    public void Extracted_field_takes_precedence_over_full_text()
    {
        var input = Invoice("unrelated text") with
        {
            ExtractedFields = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                ["CustomerName"] = "Suresh Patil",
                ["ChassisNo"] = "MA3EWB22S00123456",
                ["Address"] = "Flat 4, Kothrud, Pune",
            },
        };
        var outcome = MatchEngine.Evaluate(input);
        Assert.True(outcome.Score >= 95m, $"score was {outcome.Score}");
    }

    [Theory]
    [InlineData("9876543221", "98••••••21")]
    [InlineData("+91 98765 43221", "91••••••••21")]
    public void Mobile_is_masked(string input, string expected) => Assert.Equal(expected, Masking.Mobile(input));
}
